#!/usr/bin/env python3
"""YABBAI deep brain — an AirLLM sidecar that runs a 70B+ model on an 8 GB GPU.

AirLLM streams the model from disk one layer at a time, so every new token reads the whole
model off your SSD: expect seconds to tens of seconds PER TOKEN. That makes it a batch
worker, not a chat partner — YABBAI sends it slow, high-value jobs and polls for the result.

Endpoints (localhost only, bearer token = the YABBAI engine token):
  GET    /health          model, load state, device, queue
  POST   /jobs            {"messages":[...], "max_new_tokens":400} -> {"id": ...}
  GET    /jobs/<id>       status, tokens so far, partial text, timings
  DELETE /jobs/<id>       cancel
Run:  python server.py --config ../data/deepbrain/config.json      (or --fake for tests)
"""
import argparse
import json
import os
import queue
import sys
import threading
import time
import traceback
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
JOBS = {}
ORDER = []
WORK = queue.Queue()
STATE = {"model": None, "loaded": False, "loading": False, "device": None, "compression": None, "error": "", "note": "", "load_seconds": None, "fake": False}
LOCK = threading.Lock()


def log(*a):
    print(time.strftime("%H:%M:%S"), *a, flush=True)


class Job:
    def __init__(self, messages, max_new):
        self.id = uuid.uuid4().hex[:12]
        self.messages = messages
        self.max_new = max_new
        self.status = "queued"
        self.tokens = 0
        self.text = ""
        self.error = ""
        self.message = "waiting for the deep brain"
        self.created = time.time()
        self.started = None
        self.gen_started = None
        self.finished = None
        self.cancel = threading.Event()

    def view(self):
        gen = (self.finished or time.time()) - self.gen_started if self.gen_started else None
        iso = lambda t: time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(t)) if t else None
        return {"id": self.id, "status": self.status, "tokens": self.tokens, "max": self.max_new, "text": self.text, "error": self.error, "message": self.message, "created_at": iso(self.created), "started_at": iso(self.started), "finished_at": iso(self.finished), "gen_seconds": round(gen, 1) if gen else None}


# ── backends ────────────────────────────────────────────────
class FakeBackend:
    """Deterministic stand-in so YABBAI's plumbing can be tested without a GPU or a download."""

    def __init__(self, delay):
        self.delay = delay

    def load(self):
        time.sleep(0.2)
        STATE.update(model="fake/deep-brain-70b", device="none (fake)", compression="none")

    def generate(self, job):
        words = ("Deep brain answer (fake test backend): the live state shows verified money only from the ledger, "
                 "so the honest next move is to send the approved drafts and ship one kit this week.").split()
        for i, w in enumerate(words[: job.max_new]):
            if job.cancel.is_set():
                return
            time.sleep(self.delay)
            job.tokens = i + 1
            job.text = " ".join(words[: i + 1])


class AirBackend:
    def __init__(self, cfg, token):
        self.cfg = cfg
        self.token = token
        self.model = None

    def load(self):
        import torch  # noqa: F401  (imported here so --fake never needs torch)
        from airllm import AutoModel

        STATE["device"] = "cuda:0" if torch.cuda.is_available() else "cpu"
        kwargs = dict(
            compression=self.cfg.get("compression") or None,
            layer_shards_saving_path=self.cfg.get("shards") or None,
            hf_token=self.token or None,
            max_seq_len=int(self.cfg.get("max_seq_len", 4096)),  # AirLLM's default is only 512 tokens
            delete_original=bool(self.cfg.get("delete_original", True)),
        )
        if STATE["device"] == "cpu":
            kwargs["device"] = "cpu"
        t0 = time.time()
        try:
            self.model = AutoModel.from_pretrained(self.cfg["model"], **kwargs)
        except ImportError as e:
            if kwargs["compression"]:
                STATE["note"] = f"4-bit compression unavailable ({e}); running uncompressed — slower."
                log(STATE["note"])
                kwargs["compression"] = None
                self.model = AutoModel.from_pretrained(self.cfg["model"], **kwargs)
            else:
                raise
        STATE.update(model=self.cfg["model"], compression=kwargs["compression"] or "none", load_seconds=round(time.time() - t0, 1))

    def generate(self, job):
        import torch
        from transformers import StoppingCriteria, StoppingCriteriaList

        tok = self.model.tokenizer
        msgs = [{"role": m.get("role", "user"), "content": str(m.get("content", ""))} for m in job.messages]
        if getattr(tok, "chat_template", None):
            prompt = tok.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True)
        else:
            prompt = "\n\n".join(f"{m['role'].upper()}: {m['content']}" for m in msgs) + "\n\nASSISTANT:"
        ids = tok([prompt], return_tensors="pt", return_attention_mask=False)["input_ids"]
        room = int(self.cfg.get("max_seq_len", 4096)) - job.max_new - 8
        if ids.shape[1] > room:
            ids = ids[:, -room:]  # keep the newest context
        prompt_len = ids.shape[1]
        if STATE["device"] != "cpu":
            ids = ids.cuda()

        class Progress(StoppingCriteria):
            def __call__(self, input_ids, scores, **kw):
                n = input_ids.shape[1] - prompt_len
                job.tokens = n
                if n % 4 == 0:
                    job.text = tok.decode(input_ids[0][prompt_len:], skip_special_tokens=True)
                return torch.full((input_ids.shape[0],), job.cancel.is_set(), dtype=torch.bool, device=input_ids.device)

        out = self.model.generate(ids, max_new_tokens=job.max_new, do_sample=False, use_cache=True, return_dict_in_generate=True, stopping_criteria=StoppingCriteriaList([Progress()]))
        seq = out.sequences[0][prompt_len:]
        job.tokens = int(seq.shape[0])
        job.text = tok.decode(seq, skip_special_tokens=True).strip()


BACKEND = None


def ensure_loaded(job=None):
    with LOCK:
        if STATE["loaded"]:
            return
        STATE["loading"] = True
        if job:
            job.status = "loading"
            job.message = "loading the model — the first time downloads and splits it, which can take an hour or more"
        log("loading model…")
        try:
            BACKEND.load()
            STATE["loaded"] = True
            STATE["error"] = ""
            log(f"model ready: {STATE['model']} on {STATE['device']} ({STATE['compression']})")
        finally:
            STATE["loading"] = False


def worker():
    while True:
        job = WORK.get()
        if job.cancel.is_set():
            job.status = "cancelled"
            job.finished = time.time()
            continue
        job.started = time.time()
        try:
            ensure_loaded(job)
            job.status = "running"
            job.message = "generating — each word streams the whole model from disk"
            job.gen_started = time.time()
            BACKEND.generate(job)
            job.status = "cancelled" if job.cancel.is_set() else "done"
            job.message = ""
        except Exception as e:  # report, keep serving
            STATE["error"] = str(e)
            job.status = "error"
            job.error = f"{type(e).__name__}: {e}"
            log("job failed:", job.error)
            traceback.print_exc()
        finally:
            job.finished = time.time()


# ── HTTP ────────────────────────────────────────────────────
def engine_token(data_dir):
    try:
        return json.loads((data_dir / "secret.json").read_text())["token"]
    except Exception:
        return None


class Handler(BaseHTTPRequestHandler):
    server_version = "YABBAI-DeepBrain/13"

    def log_message(self, fmt, *args):
        pass

    def send(self, status, obj):
        body = json.dumps(obj).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def guard(self):
        host = (self.headers.get("Host") or "").split(":")[0]
        if host not in ("127.0.0.1", "localhost"):
            self.send(403, {"error": "local only"})
            return False
        tok = engine_token(self.server.data_dir)
        auth = self.headers.get("Authorization") or ""
        if not tok or auth != f"Bearer {tok}":
            self.send(401, {"error": "missing or wrong engine token"})
            return False
        return True

    def do_GET(self):
        if not self.guard():
            return
        if self.path == "/health":
            busy = any(j.status in ("loading", "running") for j in JOBS.values())
            return self.send(200, {"ok": True, **STATE, "busy": busy, "queue": WORK.qsize()})
        if self.path.startswith("/jobs/"):
            job = JOBS.get(self.path.split("/")[2])
            return self.send(200, job.view()) if job else self.send(404, {"error": "no such job"})
        self.send(404, {"error": "not found"})

    def do_POST(self):
        if not self.guard():
            return
        if self.path != "/jobs":
            return self.send(404, {"error": "not found"})
        try:
            n = int(self.headers.get("Content-Length") or 0)
            body = json.loads(self.rfile.read(min(n, 2_000_000)) or b"{}")
            msgs = body.get("messages")
            if not isinstance(msgs, list) or not msgs:
                raise ValueError("messages required")
            max_new = max(1, min(2000, int(body.get("max_new_tokens", 400))))
        except Exception as e:
            return self.send(400, {"error": str(e)})
        job = Job(msgs, max_new)
        JOBS[job.id] = job
        ORDER.append(job.id)
        while len(ORDER) > 50:
            JOBS.pop(ORDER.pop(0), None)
        WORK.put(job)
        self.send(200, {"id": job.id})

    def do_DELETE(self):
        if not self.guard():
            return
        job = JOBS.get(self.path.split("/")[2]) if self.path.startswith("/jobs/") else None
        if not job:
            return self.send(404, {"error": "no such job"})
        job.cancel.set()
        self.send(200, job.view())


def main():
    global BACKEND
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config", default=str(ROOT / "data" / "deepbrain" / "config.json"))
    ap.add_argument("--data", default=str(ROOT / "data"))
    ap.add_argument("--port", type=int)
    ap.add_argument("--fake", action="store_true", help="test backend: no torch, no download")
    ap.add_argument("--fake-delay", type=float, default=0.05)
    ap.add_argument("--prepare", action="store_true", help="download + split the model, then exit (used by the installer)")
    a = ap.parse_args()
    data_dir = Path(a.data)
    cfg = {}
    if Path(a.config).exists():
        cfg = json.loads(Path(a.config).read_text())
    if cfg.get("hf_home"):
        os.environ.setdefault("HF_HOME", cfg["hf_home"])
    token = os.environ.get("HF_TOKEN", "")
    if not token:
        try:
            token = json.loads((data_dir / "secrets" / "hf.json").read_text()).get("token", "")
        except Exception:
            token = ""
    if a.fake:
        BACKEND = FakeBackend(a.fake_delay)
        STATE["fake"] = True
    else:
        if not cfg.get("model"):
            sys.exit("No model configured — run INSTALL-DEEP-BRAIN.bat first.")
        BACKEND = AirBackend(cfg, token)
    if a.prepare:
        ensure_loaded()
        log("model downloaded and split — the deep brain is ready.")
        return
    threading.Thread(target=worker, daemon=True).start()
    port = a.port or int(cfg.get("port", 7861))
    srv = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    srv.data_dir = data_dir
    log(f"YABBAI deep brain on http://127.0.0.1:{port} ({'fake' if a.fake else cfg.get('model')})")
    srv.serve_forever()


if __name__ == "__main__":
    main()
