'use strict';
// v13 suite: brains (local / HF / deep), 16 agents, approval queue, money spine + vault,
// payouts, MRR, Solana deposits, paper loop + judge.   node engine/test/smoke13.js
// v16: the vault is Director Vault v2 (PIN + authenticator), money decisions are treasury
// approvals, and owner pay is a transfer.
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const ROOT = path.resolve(__dirname, '..', '..');
const PORT = 7881, MOCK = 11565, DEEP = 7889;
const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'yabbai13-'));
const VAULT_ADDR = 'Vau1tAddr3ss1111111111111111111111111111111';
let pass = 0, fail = 0;
const procs = [];
const ok = (c, label, x) => (c ? (pass++, console.log(`  PASS  ${label}`)) : (fail++, console.log(`  FAIL  ${label}${x !== undefined ? ' → ' + JSON.stringify(x).slice(0, 400) : ''}`)));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function req(port, method, p, body, headers = {}) {
  return new Promise((resolve, reject) => {
    const data = body === undefined ? undefined : JSON.stringify(body);
    const r = http.request({ host: '127.0.0.1', port, method, path: p, headers: { ...(data ? { 'Content-Type': 'application/json' } : {}), ...headers } }, (res) => {
      let s = '';
      res.on('data', (c) => (s += c));
      res.on('end', () => {
        let json = null;
        try { json = JSON.parse(s); } catch {}
        resolve({ status: res.statusCode, text: s, json });
      });
    });
    r.on('error', reject);
    if (data) r.write(data);
    r.end();
  });
}
const vault = require('./vault-helper');
let VAULT = {};
const ui = (method, p, body, extra = {}) => req(PORT, method, p, body, method === 'GET' ? { ...VAULT, ...extra } : { 'X-Yabbai': '1', ...VAULT, ...extra });
const state = async () => (await ui('GET', '/api/state')).json;
async function until(fn, ms = 15000) { const t0 = Date.now(); while (Date.now() - t0 < ms) { const v = await fn(); if (v) return v; await sleep(200); } return null; }
const run = async (id) => { await ui('POST', `/api/agents/${id}/run`, {}); await until(async () => { const a = (await state()).agents[id]; return a.status !== 'queued' && a.status !== 'running' && a.runs > 0 ? a : null; }); };

async function paperUnit() {
  console.log('\n[paper loop + self-upgrade judge, in-process]');
  process.env.YABBAI_DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'yabbai13u-'));
  const store = require('../lib/store');
  store.load();
  const loop = require('../lib/loop');
  const q = (bid, ask) => ({ bid, ask });
  const board = (t, solBin, solKr) => ({ at: new Date(t).toISOString(), verdict: 'OPPORTUNITY', alertNetBps: 15, notionalAud: 1000, venues: {}, rows: [{ coin: 'SOL', buyVenue: 'KRAKEN', buyAsk: solKr, sellVenue: 'BINANCE', sellBid: solBin, netBps: 40, grossBps: 100, feeBps: 60, quotes: { KRAKEN: q(solKr - 0.05, solKr), BINANCE: q(solBin, solBin + 0.05) } }], best: { coin: 'SOL', buyVenue: 'KRAKEN', buyAsk: solKr, sellVenue: 'BINANCE', sellBid: solBin, netBps: 40 } });
  const t0 = Date.now();
  store.db.settings.loop.strategy = 'SPREAD';
  loop.paperStep(board(t0, 151.5, 150), t0);
  let open = store.db.paper.trades.filter((x) => x.status === 'open');
  ok(open.length === 1 && open[0].kind === 'SPREAD' && open[0].entry === 150, 'SPREAD opens a paper position at the live ask', open[0]);
  let closed = loop.paperStep(board(t0 + 5 * 60000, 152, 150.2), t0 + 5 * 60000);
  ok(!closed.length, 'it waits out the transfer delay (20 min) before selling');
  closed = loop.paperStep(board(t0 + 21 * 60000, 152, 150.2), t0 + 21 * 60000);
  // ret = 152/150 − 1 = 1.333%; fees 40+10(Binance taker)+10 buffer = 60 bps → 500×(0.013333−0.006) = A$3.67
  ok(closed.length === 1 && Math.abs(closed[0].pnlAud - 3.67) < 0.01, 'sells at the destination bid after the delay, fees deducted: +A$3.67 paper', closed[0]);
  store.db.paper.trades = store.db.paper.trades.filter((x) => x.status === 'closed'); // SPREAD re-opened SOL; clear it so MOMENTUM is tested on its own
  store.db.scout.boards = [board(t0 - 11 * 60000, 150, 150)];
  store.db.settings.loop.strategy = 'MOMENTUM';
  loop.paperStep(board(t0, 151.5, 151.5), t0);
  const mom = store.db.paper.trades.find((x) => x.kind === 'MOMENTUM');
  ok(mom && mom.status === 'open', 'MOMENTUM buys a coin up ≥30 bps in 10 minutes', mom);
  closed = loop.paperStep(board(t0 + 60000, 149.9, 149.9), t0 + 60000);
  ok(closed.length === 1 && closed[0].reason === 'stop-loss', 'MOMENTUM stop-loss at −1%', closed[0] && closed[0].reason);
  const mk = (pnl, i) => ({ id: `j${i}`, kind: 'SPREAD', status: 'closed', pnlAud: pnl, closedAt: new Date(t0 + i * 1000).toISOString(), sizeAud: 500 });
  store.db.paper.trades = [3, 2, 4, -1, 5, 2, 1, -2].map(mk);
  store.db.settings.loop.dial = 1;
  const n = loop.judge();
  ok(n && n.to === 1.1 && store.db.settings.loop.dial === 1.1, 'judge: net > 0 with ≥6 wins → paper size 1.0× → 1.1×', n);
  ok(loop.judge() === null, 'judge does not re-nudge on the same trades');
  store.db.paper.trades = [-3, -2, 1, -4, -1, -2].map((p, i) => mk(p, 100 + i));
  ok(loop.judge().to === 1.0, 'judge: net < 0 with ≤2 wins → back to 1.0×');
}

(async () => {
  await paperUnit();
  procs.push(spawn(process.execPath, [path.join(__dirname, 'mock-ollama.js')], { env: { ...process.env, MOCK_PORT: String(MOCK) }, stdio: 'ignore' }));
  await sleep(300);
  procs.push(spawn(process.execPath, [path.join(ROOT, 'engine', 'server.js')], { env: { ...process.env, YABBAI_PORT: String(PORT), YABBAI_DATA: DATA, OLLAMA_URL: `http://127.0.0.1:${MOCK}`, HF_ROUTER_URL: `http://127.0.0.1:${MOCK}/v1`, YABBAI_DEEP_POLL_MS: '300', OPENWEBUI_URL: 'http://127.0.0.1:18999', HF_TOKEN: '' }, stdio: ['ignore', 'ignore', 'inherit'] }));
  await until(async () => (await ui('GET', '/api/health').catch(() => ({}))).status === 200);
  await ui('POST', '/api/autopilot', { on: false });
  procs.push(spawn('python3', [path.join(ROOT, 'deepbrain', 'server.py'), '--fake', '--fake-delay', '0.02', '--port', String(DEEP), '--data', DATA], { stdio: 'ignore' }));
  await sleep(800);

  console.log('\n[16 agents]');
  let st = await state();
  const ids = Object.keys(st.agents);
  ok(ids.length === 16 && st.agents.closer.name === 'Pitcher' && !st.agents.treasurer.ai && st.agents.builder.ai && ids.filter((k) => st.agents[k].ai).length === 7 && ['reconciler', 'taxplanner', 'forecaster', 'riskguardian'].every((k) => !st.agents[k].ai), '16 agents: 7 AI, 9 rules (Pitcher = outreach; v16 treasury team is rules only)', ids);

  console.log('\n[brains: Hugging Face 70B+]');
  ok((await ui('POST', '/api/brains', { hfToken: 'hf_ABCDEFGHIJKLMNOPQRSTUVWXYZ999999' })).status === 423, 'saving a provider token needs the Director vault');
  VAULT = await vault.open(ui);
  ok(!!VAULT['X-Yabbai-Vault'], 'Director Vault v2 set up: PIN + authenticator code');
  ok((await ui('POST', '/api/brains', { hfToken: 'not-a-token' })).status === 400, 'rejects a malformed HF token');
  ok((await ui('POST', '/api/brains', { hfToken: 'hf_ABCDEFGHIJKLMNOPQRSTUVWXYZ123456' })).json.hf.hint === 'hf_…3456', 'saves the token, only ever shows the last 4');
  ok(!JSON.stringify(await state()).includes('ABCDEFGHIJ'), 'the token never appears in cockpit state');
  let r = await ui('POST', '/api/brains/test', { brain: 'hf' });
  ok(r.json && /HF 70B mock reply \(meta-llama\/Llama-3\.3-70B-Instruct\)/.test(r.json.text), 'HF test call hits Llama 3.3 70B through the router', r.json);
  r = await ui('POST', '/api/chat', { message: 'big brain please', brain: 'hf' });
  const toks = r.text.split('\n\n').map((x) => x.replace(/^data: /, '')).filter((x) => x.startsWith('{')).map((x) => JSON.parse(x));
  ok(/HF 70B mock reply/.test(toks.filter((e) => e.type === 'token').map((e) => e.text).join('')) && toks.some((e) => e.type === 'done' && e.stats.brain === 'hf'), 'cockpit chat streams from the HF 70B brain', toks.slice(0, 3));
  await ui('POST', '/api/brains', { agents: 'hf' });
  const lead1 = (await ui('POST', '/api/leads', { business: 'Smith & Co Lawyers', niche: 'family law', offerId: 'capital-colony' })).json;
  await run('qualifier');
  st = await state();
  const L1 = st.leads.find((l) => l.id === lead1.id);
  ok(L1.score === 49 && L1.fit === 'strong', 'Qualifier scored the lead via the HF brain (schema-guided JSON)', L1);
  const lastHf = (await req(MOCK, 'GET', '/__lasthf')).json;
  ok(lastHf && /JSON Schema/.test(lastHf.messages[lastHf.messages.length - 1].content), 'HF calls carry the JSON schema in the prompt');
  await ui('POST', '/api/brains', { agents: 'local' });

  console.log('\n[deep brain: AirLLM sidecar (fake backend)]');
  await ui('POST', '/api/brains', { deepUrl: `http://127.0.0.1:${DEEP}`, deepEnabled: true });
  const b = (await ui('GET', '/api/brains')).json;
  ok(b.deep.up && b.deep.fake, 'deep brain sidecar is up and authenticated with the engine token', b.deep);
  ok((await req(DEEP, 'GET', '/health')).status === 401, 'sidecar refuses calls without the engine token');
  const job = (await ui('POST', '/api/deep/jobs', { prompt: 'Write a 90-day plan', maxTokens: 30 })).json;
  ok(job && job.status === 'queued', 'deep job queued', job);
  const doneJob = await until(async () => (await state()).deep.jobs.find((j) => j.id === job.id && j.status === 'done'));
  ok(doneJob && doneJob.tokens === 30 && /Deep brain answer/.test(doneJob.text) && doneJob.secPerToken > 0, 'deep job finished with text, token count and seconds-per-token', doneJob);
  const j2 = (await ui('POST', '/api/deep/jobs', { prompt: 'long one', maxTokens: 2000 })).json;
  await sleep(300);
  await ui('POST', `/api/deep/jobs/${j2.id}/cancel`, {});
  const c2 = await until(async () => (await state()).deep.jobs.find((j) => j.id === j2.id && ['cancelled'].includes(j.status)));
  ok(!!c2, 'deep job can be cancelled');

  console.log('\n[approval queue: Pitcher → Director]');
  await run('closer');
  st = await state();
  const qd = st.queue.find((x) => x.kind === 'draft');
  ok(qd && qd.agent === 'PITCHER' && qd.risk === 'low', 'Pitcher’s draft waits in the approval queue', qd);
  await ui('POST', `/api/queue/draft/${qd.id}`, { action: 'authorize' });
  st = await state();
  ok(st.outbox.find((d) => d.id === qd.id).status === 'approved' && !st.queue.find((x) => x.id === qd.id), 'Authorize → approved, ready to send (nothing is sent automatically)');
  await ui('POST', `/api/outbox/${qd.id}`, { status: 'sent' });

  console.log('\n[Caller + Supporter]');
  await ui('POST', '/api/agents/caller/config', { followDays: 0 });
  await run('caller');
  st = await state();
  ok(st.queue.some((x) => x.kind === 'followup' && x.agent === 'CALLER'), 'Caller prepared a follow-up + call script for the quiet lead');
  await ui('POST', `/api/leads/${lead1.id}/reply`, { text: 'What would the audit cost for two offices?' });
  await run('supporter');
  st = await state();
  const qr = st.queue.find((x) => x.kind === 'reply');
  ok(qr && /two offices/.test(qr.body) && st.leads.find((l) => l.id === lead1.id).stage === 'replied', 'a pasted reply → Supporter drafts an answer for approval', qr);
  await ui('POST', `/api/queue/reply/${qr.id}`, { action: 'authorize' });
  await ui('POST', `/api/queue/reply/${qr.id}`, { action: 'done' });
  ok((await state()).replies.find((x) => x.id === qr.id).status === 'sent', 'reply authorized then marked sent');

  console.log('\n[Builder → Shipper]');
  await run('forge');
  st = await state();
  const kit = st.forge.kits[0];
  await ui('PATCH', `/api/forge/kits/${kit.id}`, { status: 'building' });
  await run('builder');
  st = await state();
  const k2 = st.forge.kits.find((k) => k.id === kit.id);
  ok(k2.status === 'built' && k2.built.length === 2 && fs.existsSync(path.join(DATA, 'forge', k2.built[0].file)), 'Builder wrote the product files to disk', k2.built);
  await ui('POST', `/api/queue/kit_built/${kit.id}`, { action: 'authorize' });
  await run('shipper');
  st = await state();
  const k3 = st.forge.kits.find((k) => k.id === kit.id);
  ok(k3.status === 'ship-ready' && ['BUNDLE.md', 'LISTING.md', 'LAUNCH.md'].every((f) => fs.existsSync(path.join(DATA, 'forge', k3.shipPack, f))), 'Shipper packed BUNDLE.md, LISTING.md, LAUNCH.md', k3.shipPack);
  await ui('POST', `/api/queue/kit_ship/${kit.id}`, { action: 'listed', listingUrl: 'https://gumroad.com/l/x' });
  ok((await state()).forge.kits.find((k) => k.id === kit.id).status === 'listed', 'Mark listed from the queue');

  console.log('\n[money spine, vault, payouts, MRR]');
  await ui('POST', '/api/ledger', { amount: 1000, source: 'client', ref: 'INV-77', note: 'Retainer Oct', recurring: '1', agent: 'closer' });
  await run('treasurer');
  st = await state();
  const qa = st.queue.find((x) => x.kind === 'approval' && x.agent === 'TREASURER');
  // Policy v1 is the v15 spine: 30/30/20/10/10. Trading capital gets nothing until you set
  // its cap, so its 10% stays in operating: operating A$400, owner pay A$300.
  ok(qa && qa.money && /Operating A\$400\.00/.test(qa.body) && /Owner pay A\$300\.00/.test(qa.body), 'Treasurer proposes the split from the journal (trading capital unfunded until you set a cap)', qa && qa.body);
  ok(st.mrr.amount === 1000 && st.mrr.count === 1, 'MRR counts only flagged monthly retainers: A$1,000', st.mrr);
  ok((await ui('POST', '/api/vault/pin', { pin: '2468' })).status === 410, 'the v15 PIN-only vault is retired (410 with directions)');
  await ui('POST', '/api/vault/lock', {});
  const saved = VAULT;
  VAULT = {};
  r = await ui('POST', `/api/queue/approval/${qa.id}`, { action: 'approve' });
  ok(r.status === 423, 'sealed vault blocks approving money', r.status);
  ok((await ui('POST', '/api/v2/vault/unlock', { pin: '000000', code: '123456' })).status === 403, 'wrong PIN refused');
  ok((await ui('POST', '/api/vault/unlock', { pin: '2468' })).status === 410, 'a PIN alone no longer unlocks anything');
  VAULT = await vault.unlock(ui);
  ok(VAULT['X-Yabbai-Vault'] && VAULT['X-Yabbai-Vault'] !== saved['X-Yabbai-Vault'], 'PIN + a fresh authenticator code open a new session');
  r = await ui('POST', `/api/queue/approval/${qa.id}`, { action: 'approve' });
  ok(r.status === 200 && r.json.approval.status === 'approved', 'approved from the queue by the director', r.json);
  st = await state();
  ok(st.pools.treasury.executed === 400 && st.pools.pay.available === 300, 'pools: operating A$400 earmarked, owner pay A$300 available', st.pools);
  r = await ui('POST', '/api/payouts', { amount: 200, method: 'bank', note: 'Week 1' });
  ok(r.status === 410 && /Treasury/.test(r.json.error), 'owner pay is a treasury transfer now (410 with directions)', r.json);
  ok((await ui('POST', '/api/money/spine', { treasury: 20, pay: 40, reinvest: 20, fuel: 10, reserve: 10 })).status === 400, 'treasury below 30% is refused');
  r = await ui('POST', '/api/money/spine', { treasury: 40, pay: 30, reinvest: 10, fuel: 10, reserve: 10 });
  ok(r.status === 200 && r.json.proposedPolicy && r.json.proposedPolicy.version === 2, 'a spine change becomes a proposed policy version (never silently active)', r.json);

  console.log('\n[Solana deposit rail (keyless, mock RPC)]');
  await ui('POST', '/api/settings', {});
  await ui('POST', '/api/solana/address', { address: 'not an address' }).then((x) => ok(x.status === 400, 'invalid Solana address refused'));
  // point the RPC at the mock
  await ui('POST', '/api/solana/address', { address: VAULT_ADDR });
  const dbPatch = require('fs').readFileSync(path.join(DATA, 'db.json'), 'utf8');
  void dbPatch;
  await ui('POST', '/api/settings', { solanaRpc: `http://127.0.0.1:${MOCK}/solana` });
  st = await state();
  if (!st.settings.solana.rpc.includes(String(MOCK))) {
    // settings route doesn't expose the RPC; set it via the documented env-free path: direct db edit + restart is overkill, so use the internal test hook
    await ui('POST', '/api/solana/rpc', { rpc: `http://127.0.0.1:${MOCK}/solana` });
  }
  let s1 = (await ui('POST', '/api/solana/scan', {})).json;
  ok(s1 && s1.baselined && s1.balanceSol === 1.5 && !(await state()).deposits.length, 'first scan: 1.5 SOL balance, history baselined (not flagged)', s1);
  await req(MOCK, 'POST', '/__solana', { sig: 'NEWsig' + 'x'.repeat(80) });
  await ui('POST', '/api/solana/scan', {});
  st = await state();
  const dep = st.deposits[0];
  ok(dep && dep.sol === 1.1 && st.queue.some((x) => x.kind === 'deposit'), 'new incoming transfer detected: +1.1 SOL → Mission Control', dep);
  await ui('POST', `/api/queue/deposit/${dep.id}`, { action: 'log', amount: 260.5, source: 'product' });
  st = await state();
  ok(st.ledger.some((e) => e.ref === dep.sig && e.amount === 260.5), 'logged as income with the tx signature as the receipt');

  console.log('\n[rule agents: Diagnost, Configurator, Auditor]');
  await ui('POST', '/api/ledger', { amount: 50, source: 'product', ref: 'INV-77', note: 'dup' });
  await run('configurator');
  await run('auditor');
  await run('diagnost');
  st = await state();
  const open = st.findings.filter((f) => f.status === 'open');
  ok(open.some((f) => f.agent === 'Configurator' && /\[your name\]/.test(f.title)), 'Configurator: outreach unsigned', open.map((f) => f.title));
  ok(open.some((f) => f.agent === 'Auditor' && /INV-77.*2 times/.test(f.title)), 'Auditor: duplicate receipt caught');
  const before = open.length;
  await run('configurator');
  ok((await state()).findings.filter((f) => f.status === 'open').length === before, 'findings de-duplicate across runs');
  const fd = open[0];
  await ui('POST', `/api/queue/finding/${fd.id}`, { action: 'dismiss' });
  ok(!(await state()).queue.some((x) => x.id === fd.id), 'finding dismissed');

  console.log('\n[loop]');
  await ui('POST', '/api/loop', { cadenceSec: 10, strategy: 'MOMENTUM' });
  r = await ui('POST', '/api/loop/cycle', {});
  st = await state();
  ok(st.loop.state.cycles === 1 && st.loop.settings.cadenceSec === 10 && st.loop.settings.strategy === 'MOMENTUM', 'manual cycle runs; cadence + strategy saved', st.loop.state);
  ok((await ui('POST', '/api/loop', { cadenceSec: 3 })).json.cadenceSec === 10, 'cadence clamps to 10–120 s');

  console.log('\n[cockpit page]');
  const page = (await ui('GET', '/console')).text;
  ok(['COSMOS', 'MISSION CONTROL', 'MONEY DESK', 'BANG TERMINAL', 'AUTONOMY CORE', 'INCOME CORE', 'PAYOUT BRIDGE', 'VAULT &amp; STUDIO', 'AGENT HUB', 'OPS DESK'].every((t) => page.includes(t)), 'all ten YABBAI FLASH surfaces are in the tab bar');
  ok((await ui('GET', '/v13.js')).status === 200, 'v13.js served');

  console.log(`\n${pass} passed, ${fail} failed`);
  procs.forEach((p) => p.kill());
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.error(e); procs.forEach((p) => p.kill()); process.exit(1); });
