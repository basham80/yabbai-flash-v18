'use strict';
// v16 broker link: the oil desk against a stand-in cTrader Open API proxy.
//   node engine/test/smoke16-broker.js
// Covers: connect and account pick, symbol mapping, journal rows from broker positions,
// the guardian blocking orders, a real order payload, stop changes, full and partial
// closes with the broker's own P&L, a close found in the deal history after downtime,
// OAuth sign-in, token refresh, the demo/live switch, and no secrets in any output.
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const mock = require('./mock-ctrader');
const vault = require('./vault-helper');

const PORT = 7893;
const TOKEN = 'yb_test_token_broker_0123456789';
const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'yabbai16b-'));
const FIXTURE = path.join(DATA, 'desk-fixture.json');
let pass = 0;
let fail = 0;
const ok = (c, label, x) => (c ? (pass++, console.log(`  PASS  ${label}`)) : (fail++, console.log(`  FAIL  ${label}${x !== undefined ? ' → ' + JSON.stringify(x).slice(0, 600) : ''}`)));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let VAULT = {};

function req(method, p, body, headers = {}) {
  return new Promise((resolve, reject) => {
    const data = body === undefined ? undefined : typeof body === 'string' ? body : JSON.stringify(body);
    const r = http.request({ host: '127.0.0.1', port: PORT, method, path: p, headers: { ...(data ? { 'Content-Type': 'application/json' } : {}), ...headers } }, (res) => {
      let s = '';
      res.on('data', (c) => (s += c));
      res.on('end', () => {
        let json = null;
        try {
          json = JSON.parse(s);
        } catch {}
        resolve({ status: res.statusCode, headers: res.headers, text: s, json });
      });
    });
    r.on('error', reject);
    if (data) r.write(data);
    r.end();
  });
}
const ui = (method, p, body, extra = {}) => req(method, p, body, method === 'GET' ? { ...VAULT, ...extra } : { 'X-Yabbai': '1', ...VAULT, ...extra });
async function until(fn, ms = 4000) {
  const end = Date.now() + ms;
  let last;
  while (Date.now() < end) {
    last = await fn();
    if (last) return last;
    await sleep(60);
  }
  return last;
}
const brokerStatus = async () => (await ui('GET', '/api/desk/broker')).json;
const ready = (want = 'ready') => until(async () => {
  const s = await brokerStatus();
  return s && s.status === want ? s : null;
});

async function main() {
  fs.writeFileSync(FIXTURE, JSON.stringify({ WTI: { price: 61.0, prevClose: 60, at: new Date().toISOString() }, BRENT: { price: 64.9, prevClose: 64, at: new Date().toISOString() } }));
  const ct = await mock.start();
  const env = {
    ...process.env,
    YABBAI_PORT: String(PORT),
    YABBAI_DATA: DATA,
    YABBAI_TOKEN: TOKEN,
    YABBAI_DESK_FIXTURE: FIXTURE,
    YABBAI_CTRADER_URL: ct.url,
    YABBAI_CTRADER_TOKEN_URL: ct.tokenUrl,
    YABBAI_PUBLIC_URL: `http://127.0.0.1:${PORT}`,
    OLLAMA_URL: 'http://127.0.0.1:9',
  };
  delete env.PORT;
  delete env.RENDER;
  const proc = spawn(process.execPath, [path.join(__dirname, '..', 'server.js')], { env, stdio: ['ignore', 'pipe', 'pipe'] });
  let log = '';
  proc.stdout.on('data', (c) => (log += c));
  proc.stderr.on('data', (c) => (log += c));
  try {
    const up = await until(() => req('GET', '/healthz').then((r) => r.status === 200, () => false), 9000);
    ok(up, 'engine boots');
    VAULT = await vault.open(ui);

    console.log('\n[connect]');
    let s = await brokerStatus();
    ok(s.status === 'off' && !s.configured.clientId && s.canTrade === false, 'no broker until you add one', s);
    const noVault = await req('POST', '/api/desk/broker/config', { clientId: 'cid' }, { 'X-Yabbai': '1' });
    ok(noVault.status === 423, 'broker credentials need the Director vault', noVault.json);
    const cfg = await ui('POST', '/api/desk/broker/config', { clientId: 'cid', clientSecret: 'csecret', accessToken: 'at_good' });
    ok(cfg.status === 200, 'save the app and token', cfg.json);
    s = await ready();
    ok(s && s.account && s.account.id === '111' && s.env === 'demo', 'demo by default; the only demo account is picked', s && { account: s.account, env: s.env, error: s.error });
    ok(s && s.symbols.WTI && s.symbols.WTI.symbolId === 101 && s.symbols.BRENT.symbolId === 102 && s.symbols.WTI.unitsPerLot === 100, 'XTIUSD → WTI, XBRUSD → BRENT, 100 bbl a lot from the broker', s && s.symbols);
    ok(s && s.spots.WTI && s.spots.WTI.bid === 61.48 && s.spots.WTI.ask === 61.5, 'live bid/ask from the broker (1/100000 units)', s && s.spots);
    ok(s && s.account.balance === 10000 && s.account.currency === 'USD', 'balance in account money (moneyDigits 2)', s && s.account);
    ok(s && s.positions.length === 1 && s.positions[0].positionId === '555' && s.positions[0].lots === 1, 'open positions read back', s && s.positions);

    let desk = (await ui('GET', '/api/desk')).json;
    const row555 = desk.open.find((t) => t.ticket === 'ct-555');
    ok(row555 && row555.source === 'broker' && row555.broker === 'cTrader 123456' && row555.entry === 60.5 && row555.stop === 59.9 && row555.bbl === 100, 'a position opened elsewhere gets its journal row', row555);
    ok(row555 && row555.mark === 61.48 && row555.markSource === 'cTrader bid' && row555.openPnlUsd === 98, "broker rows are marked with the broker's bid, not the futures price", row555);
    ok(desk.broker.connected === true && desk.broker.provider === 'ctrader' && desk.broker.armed === false, 'the desk summary carries the broker state', desk.broker);

    console.log('\n[guardian]');
    let pv = (await ui('POST', '/api/desk/orders/preview', { instrument: 'WTI', side: 'long', lots: 1, stop: 61.0 })).json;
    ok(pv.ok === false && pv.blockers.some((b) => /account size/.test(b)) && pv.blockers.some((b) => /not armed/.test(b)), 'no account size and not armed: blocked', pv);
    const noStop = await ui('POST', '/api/desk/orders/preview', { instrument: 'WTI', side: 'long', lots: 1 });
    ok(noStop.status === 400 && /stop/.test(noStop.json.error), 'no order without a stop', noStop.json);
    await ui('POST', '/api/desk/account', { name: 'Demo', sizeUsd: 10000, riskPct: 1, dailyLossPct: 5, maxDrawdownPct: 10 });
    pv = (await ui('POST', '/api/desk/orders/preview', { instrument: 'WTI', side: 'long', lots: 3, stop: 61.0 })).json;
    ok(pv.riskUsd === 150 && pv.blockers.some((b) => /per-trade limit of US\$100/.test(b)), '3 lots × 100 bbl × 0.50 = US$150 risk: over the 1% limit', pv);
    pv = (await ui('POST', '/api/desk/orders/preview', { instrument: 'WTI', side: 'long', lots: 1, stop: 62 })).json;
    ok(pv.blockers.some((b) => /stop sits below the ask/.test(b)), 'a long stop above the ask is refused', pv.blockers);
    const armNo = await req('POST', '/api/desk/broker/arm', { armed: true }, { 'X-Yabbai': '1' });
    ok(armNo.status === 423, 'arming needs the Director vault', armNo.json);
    s = (await ui('POST', '/api/desk/broker/arm', { armed: true })).json;
    ok(s.armed === true && s.canTrade === true, 'armed on the demo account', s);
    pv = (await ui('POST', '/api/desk/orders/preview', { instrument: 'WTI', side: 'long', lots: 1, stop: 61.0, target: 62.5 })).json;
    ok(pv.ok === true && pv.volume === 10000 && pv.riskUsd === 50 && pv.rewardUsd === 100 && pv.rr === 2 && pv.ref === 61.5, 'preview: 1 lot = volume 10000, risk US$50, reward US$100, 2R from the ask', pv);

    console.log('\n[order]');
    const placed = await ui('POST', '/api/desk/orders', { instrument: 'WTI', side: 'long', lots: 1, stop: 61.0, target: 62.5 });
    ok(placed.status === 200 && placed.json.status === 'filled' && placed.json.positionId === '777' && placed.json.price === 61.5, 'market order filled at the ask', placed.json);
    const sent = ct.S.orders[0] || {};
    ok(sent.orderType === 1 && sent.tradeSide === 1 && sent.volume === 10000 && sent.relativeStopLoss === 50000 && sent.relativeTakeProfit === 100000 && sent.symbolId === 101 && sent.label === 'YABBAI' && /^yb-/.test(sent.clientOrderId), 'what cTrader received: MARKET BUY 10000, stop 0.50 and target 1.00 as relative distances', sent);
    desk = (await ui('GET', '/api/desk')).json;
    let row777 = desk.open.find((t) => t.ticket === 'ct-777');
    ok(row777 && row777.entry === 61.5 && row777.stop === 61 && row777.target === 62.5 && row777.riskUsd === 50, 'the fill opens its journal row with the broker stop and target', row777);
    const prot = await ui('POST', '/api/desk/positions/777/protect', { stop: 61.2 });
    ok(prot.status === 200 && prot.json.stop === 61.2 && ct.S.amends[0] && ct.S.amends[0].stopLoss === 61.2 && ct.S.amends[0].takeProfit === 62.5, 'move the stop at the broker (target kept)', { res: prot.json, sent: ct.S.amends[0] });
    row777 = (await ui('GET', '/api/desk')).json.open.find((t) => t.ticket === 'ct-777');
    ok(row777 && row777.stop === 61.2 && row777.riskUsd === 30, 'the journal row follows the new stop (risk 30)', row777);
    const badProt = await ui('POST', '/api/desk/positions/777/protect', { stop: 61.6 });
    ok(badProt.status === 400, 'a stop above the bid on a long is refused before it reaches the broker', badProt.json);
    ct.S.nextClose = { price: 61.75, swap: -50, commission: -300 };
    const closed = await ui('POST', '/api/desk/positions/777/close', {});
    ok(closed.status === 200 && closed.json.status === 'closed' && closed.json.net === 21.5, 'close: gross 25.00 − swap 0.50 − commission 3.00 = 21.50', closed.json);
    desk = (await ui('GET', '/api/desk')).json;
    const c777 = desk.closed.find((t) => t.ticket === 'ct-777');
    ok(c777 && c777.pnlUsd === 21.5 && c777.pnlSource === 'broker' && c777.exit === 61.75 && c777.feesUsd === 3.5, "the journal records the broker's own net", c777);

    console.log('\n[partial close]');
    const p2 = await ui('POST', '/api/desk/orders', { instrument: 'WTI', side: 'long', lots: 2, stop: 61.0 });
    ok(p2.status === 200 && p2.json.positionId === '778', 'a 2-lot order (US$100 risk, right at the limit)', p2.json);
    ct.S.nextClose = { price: 61.6, swap: 0, commission: -150 };
    const half = await ui('POST', '/api/desk/positions/778/close', { lots: 1 });
    ok(half.status === 200 && half.json.status === 'partial' && half.json.net === 8.5 && ct.S.closes[1].volume === 10000, 'close 1 of 2 lots: gross 10.00 − 1.50 = 8.50', half.json);
    let r778 = await until(async () => (await ui('GET', '/api/desk')).json.open.find((t) => t.ticket === 'ct-778' && t.lots === 1));
    ok(r778 && r778.partialPnlUsd === 8.5 && r778.bbl === 100, 'the row stays open with 1 lot and the partial P&L held', r778);
    desk = (await ui('GET', '/api/desk')).json;
    ok(desk.stats.realizedTodayUsd === 30, 'realized today counts the partial (21.50 + 8.50)', desk.stats);
    ct.S.nextClose = { price: 61.4, swap: 0, commission: -150 };
    await ui('POST', '/api/desk/positions/778/close', {});
    desk = (await ui('GET', '/api/desk')).json;
    const c778 = desk.closed.find((t) => t.ticket === 'ct-778');
    ok(c778 && c778.pnlUsd === -3 && desk.stats.realizedTodayUsd === 18.5, 'the final close adds the rest: 8.50 + (−0.10 × 100 − 1.50) = −3.00; today 21.50 − 3.00 = 18.50', { row: c778, stats: desk.stats });

    console.log('\n[closed while away]');
    s = (await ui('POST', '/api/desk/broker/disconnect', {})).json;
    ok(s.status === 'off', 'disconnect', s.status);
    ct.closeOffline(555, { price: 61.48, swap: -20, commission: -300 });
    await ui('POST', '/api/desk/broker/connect', {});
    s = await ready();
    desk = (await ui('GET', '/api/desk')).json;
    const c555 = desk.closed.find((t) => t.ticket === 'ct-555');
    ok(c555 && c555.pnlUsd === 94.8 && c555.exit === 61.48 && !desk.open.some((t) => t.ticket === 'ct-555'), 'the deal history closes it: 98.00 − 0.20 − 3.00 = 94.80', c555);

    console.log('\n[sign in with cTrader]');
    const o1 = (await ui('POST', '/api/desk/broker/oauth', {})).json;
    const au = new URL(o1.url);
    ok(au.hostname === 'id.ctrader.com' && au.searchParams.get('client_id') === 'cid' && au.searchParams.get('redirect_uri') === `http://127.0.0.1:${PORT}/broker/callback` && au.searchParams.get('scope') === 'trading', 'the grant link names the app, scope and callback', o1);
    const wrong = await req('GET', `/broker/callback?code=good&state=nope`);
    ok(wrong.status === 400 && /does not match/.test(wrong.text), 'a callback with the wrong state is refused', wrong.status);
    const o2 = (await ui('POST', '/api/desk/broker/oauth', {})).json;
    const st2 = new URL(o2.url).searchParams.get('state');
    const good = await req('GET', `/broker/callback?code=good&state=${encodeURIComponent(st2)}`);
    ok(good.status === 200 && /connected/i.test(good.text) && ct.S.tokenCalls.some((q) => q.code === 'good' && q.grant_type === 'authorization_code'), 'the code is exchanged server-side', good.status);
    const again = await req('GET', `/broker/callback?code=good&state=${encodeURIComponent(st2)}`);
    ok(again.status === 400, 'the same sign-in cannot be used twice', again.status);
    s = await until(async () => {
      const x = await brokerStatus();
      return x.status === 'ready' && x.hints.accessToken === '…auth' ? x : null;
    });
    ok(s && s.configured.refreshToken === true, 'connected with the granted token', s && { hints: s.hints, status: s.status });

    console.log('\n[refresh, live switch]');
    await ui('POST', '/api/desk/broker/config', { accessToken: 'at_old', refreshToken: 'rt_good', expiresIn: 60 });
    s = await until(async () => {
      const x = await brokerStatus();
      return x.status === 'ready' && x.hints.accessToken === '…shed' ? x : null;
    });
    ok(s && ct.S.received.some((m) => m.pt === 2173 && m.payload.refreshToken === 'rt_good'), 'a token close to expiry is refreshed before use', s && s.hints);
    const live = (await ui('POST', '/api/desk/broker/config', { env: 'live' })).json;
    s = await ready();
    ok(live.armed === false && s && s.env === 'live' && s.account.id === '222' && s.armed === false, 'switching to live disarms and picks the live account', s && { env: s.env, account: s.account, armed: s.armed });
    const liveOrder = await ui('POST', '/api/desk/orders', { instrument: 'WTI', side: 'long', lots: 1, stop: 61.0 });
    ok(liveOrder.status === 400 && /not armed/.test(liveOrder.json.error), 'no live order until armed again', liveOrder.json);

    console.log('\n[secrets]');
    const raw = (await ui('GET', '/api/desk/broker')).text + (await ui('GET', '/api/state')).text + (await ui('GET', '/api/desk')).text;
    const leaked = ['csecret', 'at_good', 'at_oauth', 'rt_good', 'rt_next', 'at_refreshed', 'rt_oauth'].filter((x) => raw.includes(x) || log.includes(x));
    ok(leaked.length === 0, 'no client secret or token in any payload or the engine log', leaked);
    const mode = fs.statSync(path.join(DATA, 'secrets', 'ctrader.json')).mode & 0o777;
    ok(process.platform === 'win32' || mode === 0o600, 'broker secrets file is private to the engine (0600)', mode.toString(8));
    s = (await ui('POST', '/api/desk/broker/disconnect', {})).json;
    ok(s.status === 'off', 'disconnect');
  } finally {
    proc.kill('SIGTERM');
    await sleep(300);
    await ct.close();
  }
  if (fail) console.log('\n--- engine log ---\n' + log.slice(-4000));
  console.log(`\nv16 broker: ${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
