'use strict';
// A stand-in for cTrader's Open API proxy (JSON over WebSocket) and its OAuth token
// endpoint, for tests only. It speaks just enough RFC 6455 to carry text frames.
// Message numbers and shapes follow spotware/openapi-proto-messages.
const http = require('http');
const crypto = require('crypto');

const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const round2 = (x) => Math.round(x * 100) / 100;

function frame(op, data) {
  const payload = Buffer.isBuffer(data) ? data : Buffer.from(String(data));
  const len = payload.length;
  let head;
  if (len < 126) head = Buffer.from([0x80 | op, len]);
  else if (len < 65536) {
    head = Buffer.alloc(4);
    head[0] = 0x80 | op;
    head[1] = 126;
    head.writeUInt16BE(len, 2);
  } else {
    head = Buffer.alloc(10);
    head[0] = 0x80 | op;
    head[1] = 127;
    head.writeBigUInt64BE(BigInt(len), 2);
  }
  return Buffer.concat([head, payload]);
}

function reader(sock, onText) {
  let buf = Buffer.alloc(0);
  let parts = [];
  return (chunk) => {
    buf = Buffer.concat([buf, chunk]);
    for (;;) {
      if (buf.length < 2) return;
      const fin = (buf[0] & 0x80) !== 0;
      const op = buf[0] & 0x0f;
      const masked = (buf[1] & 0x80) !== 0;
      let len = buf[1] & 0x7f;
      let off = 2;
      if (len === 126) {
        if (buf.length < 4) return;
        len = buf.readUInt16BE(2);
        off = 4;
      } else if (len === 127) {
        if (buf.length < 10) return;
        len = Number(buf.readBigUInt64BE(2));
        off = 10;
      }
      const maskAt = off;
      if (masked) off += 4;
      if (buf.length < off + len) return;
      let data = Buffer.from(buf.subarray(off, off + len));
      if (masked) for (let i = 0; i < data.length; i++) data[i] ^= buf[maskAt + (i % 4)];
      buf = buf.subarray(off + len);
      if (op === 8) {
        try {
          sock.end(frame(8, Buffer.alloc(0)));
        } catch {}
        return;
      }
      if (op === 9) {
        sock.write(frame(10, data));
        continue;
      }
      if (op === 1 || op === 0) {
        parts.push(data);
        if (fin) {
          const text = Buffer.concat(parts).toString('utf8');
          parts = [];
          onText(text);
        }
      }
    }
  };
}

function start({ port = 0 } = {}) {
  const S = {
    sockets: new Set(),
    received: [],
    orders: [],
    amends: [],
    closes: [],
    accounts: [
      { ctidTraderAccountId: 111, isLive: false, traderLogin: 123456, brokerTitleShort: 'DemoBroker' },
      { ctidTraderAccountId: 222, isLive: true, traderLogin: 654321, brokerTitleShort: 'LiveBroker' },
    ],
    tokens: new Set(['at_good', 'at_oauth']),
    refresh: { rt_good: { accessToken: 'at_refreshed', refreshToken: 'rt_next' } },
    codes: { good: { accessToken: 'at_oauth', refreshToken: 'rt_oauth' } },
    positions: new Map(),
    deals: [],
    spots: { 101: { bid: 6148000, ask: 6150000 }, 102: { bid: 6480000, ask: 6482000 } },
    nextPos: 777,
    nextOrder: 9001,
    nextDeal: 5001,
    balance: 1000000,
    nextClose: null,
    tokenCalls: [],
  };
  S.positions.set(555, {
    positionId: 555,
    tradeData: { symbolId: 101, volume: 10000, tradeSide: 'BUY', openTimestamp: Date.now() - 3600000, label: 'manual' },
    positionStatus: 'POSITION_STATUS_OPEN',
    price: 60.5,
    stopLoss: 59.9,
    swap: 0,
    commission: -150,
    moneyDigits: 2,
  });
  const login = (acc) => (S.accounts.find((a) => a.ctidTraderAccountId === Number(acc)) || {}).traderLogin;

  const send = (sock, payloadType, payload, clientMsgId) => {
    try {
      sock.write(frame(1, JSON.stringify(clientMsgId ? { clientMsgId, payloadType, payload } : { payloadType, payload })));
    } catch {}
  };
  const fail = (sock, id, errorCode, description, acc) => send(sock, 2142, { ctidTraderAccountId: acc, errorCode, description }, id);

  function closeDeal(pos, vol, exit, swap = 0, commission = 0) {
    const buy = pos.tradeData.tradeSide === 'BUY';
    const gross = Math.round((buy ? exit - pos.price : pos.price - exit) * (vol / 100) * 100);
    S.balance += gross + swap + commission;
    const deal = {
      dealId: S.nextDeal++,
      orderId: S.nextOrder++,
      positionId: pos.positionId,
      volume: vol,
      filledVolume: vol,
      symbolId: pos.tradeData.symbolId,
      createTimestamp: Date.now(),
      executionTimestamp: Date.now(),
      executionPrice: exit,
      tradeSide: buy ? 'SELL' : 'BUY',
      dealStatus: 'FILLED',
      closePositionDetail: { entryPrice: pos.price, grossProfit: gross, swap, commission, balance: S.balance, closedVolume: vol, moneyDigits: 2 },
      moneyDigits: 2,
    };
    S.deals.push(deal);
    return deal;
  }

  function handle(sock, raw) {
    let msg;
    try {
      msg = JSON.parse(raw);
    } catch {
      return;
    }
    const pt = Number(msg.payloadType);
    const p = msg.payload || {};
    const id = msg.clientMsgId;
    if (pt === 51) return;
    S.received.push({ pt, payload: p });
    const acc = p.ctidTraderAccountId;
    switch (pt) {
      case 2100:
        return p.clientId === 'cid' && p.clientSecret === 'csecret' ? send(sock, 2101, {}, id) : fail(sock, id, 'CH_CLIENT_AUTH_FAILURE', 'Client authentication failed');
      case 2173: {
        const r = S.refresh[p.refreshToken];
        if (!r) return fail(sock, id, 'INVALID_REQUEST', 'Unknown refresh token');
        S.tokens.add(r.accessToken);
        return send(sock, 2174, { accessToken: r.accessToken, refreshToken: r.refreshToken, tokenType: 'bearer', expiresIn: 2628000 }, id);
      }
      case 2149:
        if (!S.tokens.has(p.accessToken)) return fail(sock, id, 'CH_ACCESS_TOKEN_INVALID', 'Invalid access token');
        return send(sock, 2150, { accessToken: p.accessToken, permissionScope: 'SCOPE_TRADE', ctidTraderAccount: S.accounts }, id);
      case 2102:
        if (!S.tokens.has(p.accessToken)) return fail(sock, id, 'CH_ACCESS_TOKEN_INVALID', 'Invalid access token', acc);
        return send(sock, 2103, { ctidTraderAccountId: acc }, id);
      case 2121:
        return send(sock, 2122, { ctidTraderAccountId: acc, trader: { ctidTraderAccountId: acc, balance: S.balance, depositAssetId: 15, moneyDigits: 2, leverageInCents: 10000, traderLogin: login(acc), brokerName: 'DemoBroker' } }, id);
      case 2112:
        return send(sock, 2113, { ctidTraderAccountId: acc, asset: [{ assetId: 15, name: 'USD', displayName: 'USD', digits: 2 }] }, id);
      case 2114:
        return send(sock, 2115, {
          ctidTraderAccountId: acc,
          symbol: [
            { symbolId: 1, symbolName: 'EURUSD', enabled: true, description: 'Euro vs US Dollar' },
            { symbolId: 101, symbolName: 'XTIUSD', enabled: true, description: 'US Crude Oil' },
            { symbolId: 102, symbolName: 'XBRUSD', enabled: true, description: 'Brent Crude Oil' },
          ],
        }, id);
      case 2116:
        return send(sock, 2117, { ctidTraderAccountId: acc, symbol: (p.symbolId || []).map((sid) => ({ symbolId: sid, digits: 2, pipPosition: 2, lotSize: 10000, minVolume: 100, maxVolume: 10000000, stepVolume: 100, measurementUnits: 'bbl' })) }, id);
      case 2124:
        return send(sock, 2125, { ctidTraderAccountId: acc, position: [...S.positions.values()], order: [] }, id);
      case 2127:
        send(sock, 2128, { ctidTraderAccountId: acc }, id);
        for (const sid of p.symbolId || []) if (S.spots[sid]) send(sock, 2131, { ctidTraderAccountId: acc, symbolId: sid, bid: S.spots[sid].bid, ask: S.spots[sid].ask, timestamp: Date.now() });
        return;
      case 2133:
        return send(sock, 2134, { ctidTraderAccountId: acc, deal: S.deals.filter((d) => d.executionTimestamp >= p.fromTimestamp && d.executionTimestamp <= p.toTimestamp), hasMore: false }, id);
      case 2106: {
        S.orders.push(p);
        const sym = Number(p.symbolId);
        const q = S.spots[sym];
        if (!q) return fail(sock, id, 'SYMBOL_NOT_FOUND', 'Symbol not found', acc);
        const buy = Number(p.tradeSide) === 1 || p.tradeSide === 'BUY';
        const price = (buy ? q.ask : q.bid) / 1e5;
        const orderId = S.nextOrder++;
        const positionId = S.nextPos++;
        const sl = p.relativeStopLoss ? round2(buy ? price - p.relativeStopLoss / 1e5 : price + p.relativeStopLoss / 1e5) : undefined;
        const tp = p.relativeTakeProfit ? round2(buy ? price + p.relativeTakeProfit / 1e5 : price - p.relativeTakeProfit / 1e5) : undefined;
        const tradeData = { symbolId: sym, volume: p.volume, tradeSide: buy ? 'BUY' : 'SELL', openTimestamp: Date.now(), label: p.label, comment: p.comment };
        const order = { orderId, tradeData, orderType: 'MARKET', orderStatus: 'ORDER_STATUS_ACCEPTED', clientOrderId: p.clientOrderId, positionId };
        send(sock, 2126, { ctidTraderAccountId: acc, executionType: 'ORDER_ACCEPTED', order, position: { positionId, tradeData, positionStatus: 'POSITION_STATUS_CREATED', price: 0, moneyDigits: 2 } }, id);
        setTimeout(() => {
          const position = { positionId, tradeData, positionStatus: 'POSITION_STATUS_OPEN', price, stopLoss: sl, takeProfit: tp, swap: 0, commission: -150, moneyDigits: 2 };
          S.positions.set(positionId, position);
          const deal = { dealId: S.nextDeal++, orderId, positionId, volume: p.volume, filledVolume: p.volume, symbolId: sym, createTimestamp: Date.now(), executionTimestamp: Date.now(), executionPrice: price, tradeSide: tradeData.tradeSide, dealStatus: 'FILLED', commission: -150, moneyDigits: 2 };
          S.deals.push(deal);
          // Numeric enum on purpose: real JSON from cTrader can carry either form.
          send(sock, 2126, { ctidTraderAccountId: acc, executionType: 3, order: { ...order, orderStatus: 'ORDER_STATUS_FILLED' }, position, deal });
        }, 30);
        return;
      }
      case 2110: {
        S.amends.push(p);
        const pos = S.positions.get(Number(p.positionId));
        if (!pos) return fail(sock, id, 'POSITION_NOT_FOUND', 'Position not found', acc);
        if ('stopLoss' in p) pos.stopLoss = p.stopLoss;
        if ('takeProfit' in p) pos.takeProfit = p.takeProfit;
        return send(sock, 2126, { ctidTraderAccountId: acc, executionType: 'ORDER_REPLACED', position: pos, order: { orderId: S.nextOrder++, orderType: 'STOP_LOSS_TAKE_PROFIT', positionId: pos.positionId } }, id);
      }
      case 2111: {
        S.closes.push(p);
        const pos = S.positions.get(Number(p.positionId));
        if (!pos) return fail(sock, id, 'POSITION_NOT_FOUND', 'Position not found', acc);
        const vol = Math.min(Number(p.volume), pos.tradeData.volume);
        const buy = pos.tradeData.tradeSide === 'BUY';
        const q = S.spots[pos.tradeData.symbolId];
        const plan = S.nextClose || {};
        S.nextClose = null;
        const exit = plan.price ?? (buy ? q.bid : q.ask) / 1e5;
        send(sock, 2126, { ctidTraderAccountId: acc, executionType: 'ORDER_ACCEPTED', order: { orderId: S.nextOrder, closingOrder: true, positionId: pos.positionId }, position: pos }, id);
        setTimeout(() => {
          const deal = closeDeal(pos, vol, exit, plan.swap || 0, plan.commission || 0);
          const left = pos.tradeData.volume - vol;
          let out;
          if (left > 0) {
            pos.tradeData = { ...pos.tradeData, volume: left };
            out = pos;
          } else {
            S.positions.delete(pos.positionId);
            out = { ...pos, positionStatus: 'POSITION_STATUS_CLOSED', tradeData: { ...pos.tradeData, volume: 0 } };
          }
          send(sock, 2126, { ctidTraderAccountId: acc, executionType: 'ORDER_FILLED', order: { orderId: deal.orderId, closingOrder: true, positionId: pos.positionId }, position: out, deal });
        }, 30);
        return;
      }
      default:
        return fail(sock, id, 'UNSUPPORTED_MESSAGE', `The mock has no handler for ${pt}`, acc);
    }
  }

  const server = http.createServer((req, res) => {
    const u = new URL(req.url, 'http://x');
    if (u.pathname === '/apps/token') {
      const q = Object.fromEntries(u.searchParams);
      S.tokenCalls.push(q);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      const grant = q.grant_type === 'authorization_code' && q.client_id === 'cid' && q.client_secret === 'csecret' ? S.codes[q.code] : null;
      if (!grant) return res.end(JSON.stringify({ accessToken: null, errorCode: 'ACCESS_DENIED', description: 'The code is not valid' }));
      S.tokens.add(grant.accessToken);
      return res.end(JSON.stringify({ accessToken: grant.accessToken, tokenType: 'bearer', expiresIn: 2628000, refreshToken: grant.refreshToken, errorCode: null, description: null }));
    }
    res.writeHead(404);
    res.end();
  });
  server.on('upgrade', (req, sock) => {
    const key = req.headers['sec-websocket-key'];
    if (!key) return sock.destroy();
    const accept = crypto.createHash('sha1').update(key + GUID).digest('base64');
    sock.write(`HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ${accept}\r\n\r\n`);
    S.sockets.add(sock);
    sock.on('data', reader(sock, (text) => handle(sock, text)));
    sock.on('close', () => S.sockets.delete(sock));
    sock.on('error', () => S.sockets.delete(sock));
  });

  return new Promise((resolve) => {
    server.listen(port, '127.0.0.1', () => {
      const api = {
        S,
        port: server.address().port,
        url: `ws://127.0.0.1:${server.address().port}`,
        tokenUrl: `http://127.0.0.1:${server.address().port}/apps/token`,
        // Close a position at the broker while the engine is away (no events sent).
        closeOffline(positionId, { price, swap = 0, commission = 0 }) {
          const pos = S.positions.get(Number(positionId));
          if (!pos) throw new Error('no such position');
          const deal = closeDeal(pos, pos.tradeData.volume, price, swap, commission);
          S.positions.delete(pos.positionId);
          return deal;
        },
        // Push an event to every connected client (spot moves, server-side changes).
        broadcast(payloadType, payload) {
          for (const s of S.sockets) send(s, payloadType, payload);
        },
        kick() {
          for (const s of S.sockets) s.destroy();
        },
        close: () => new Promise((r) => {
          for (const s of S.sockets) s.destroy();
          server.close(() => r());
        }),
      };
      resolve(api);
    });
  });
}

module.exports = { start };
