'use strict';
// Test double for Ollama's native API — lets the engine be exercised end to end
// without a GPU or a downloaded model. Not shipped to users as a runtime piece.
const http = require('http');

const models = [{ name: 'hf.co/unsloth/Qwen3.5-9B-GGUF:Q4_K_M', size: 5.7e9, details: { family: 'qwen35', parameter_size: '9.0B', quantization_level: 'Q4_K_M' } }];
let lastChat = null;
const chats = []; // the last 50 chat bodies, newest first (v18 tests pick theirs by system prompt)
let lastHf = null;
const sol = { balance: 1.5e9, sigs: ['oldSig111', 'oldSig222'], vault: 'Vau1tAddr3ss1111111111111111111111111111111' };
let loaded = null;

function fromSchema(schema, name = 'value') {
  if (!schema || typeof schema !== 'object') return `mock ${name}`;
  if (schema.enum) return schema.enum[0];
  switch (schema.type) {
    case 'object': {
      const out = {};
      for (const [k, v] of Object.entries(schema.properties || {})) out[k] = fromSchema(v, k);
      return out;
    }
    case 'array':
      return [fromSchema(schema.items, `${name} 1`), fromSchema(schema.items, `${name} 2`)];
    case 'number':
    case 'integer':
      return 49;
    case 'boolean':
      return true;
    default:
      return `mock ${name}`;
  }
}

function body(req) {
  return new Promise((resolve) => {
    let s = '';
    req.on('data', (c) => (s += c));
    req.on('end', () => resolve(s ? JSON.parse(s) : {}));
  });
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  const json = (status, obj) => {
    res.writeHead(status, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(obj));
  };
  if (url.pathname === '/__last') return json(200, lastChat);
  if (url.pathname === '/__chats') return json(200, chats);
  if (url.pathname === '/__lasthf') return json(200, lastHf);
  // ── fake Hugging Face router (OpenAI-compatible) ──
  if (url.pathname === '/v1/models') return json(200, { object: 'list', data: [{ id: 'meta-llama/Llama-3.3-70B-Instruct' }, { id: 'openai/gpt-oss-120b' }] });
  if (url.pathname === '/v1/chat/completions') {
    if (!/^Bearer hf_/.test(req.headers.authorization || '')) return json(401, { error: { message: 'Invalid credentials' } });
    const b = await body(req);
    lastHf = b;
    const lastUser = [...b.messages].reverse().find((m) => m.role === 'user');
    const said = (lastUser && lastUser.content) || '';
    let content = `HF 70B mock reply (${b.model}): ${said.slice(0, 40)}`;
    const mark = said.indexOf('JSON Schema:\n');
    if (mark >= 0) content = JSON.stringify(fromSchema(JSON.parse(said.slice(mark + 13))));
    res.writeHead(200, { 'Content-Type': 'text/event-stream' });
    for (const part of content.match(/[\s\S]{1,12}/g)) {
      res.write(`data: ${JSON.stringify({ choices: [{ delta: { content: part } }] })}\n\n`);
      await sleep(2);
    }
    res.write(`data: ${JSON.stringify({ choices: [], usage: { prompt_tokens: 120, completion_tokens: 30 } })}\n\n`);
    res.write('data: [DONE]\n\n');
    return res.end();
  }
  // ── fake Solana JSON-RPC ──
  if (url.pathname === '/__solana') {
    const b = await body(req);
    sol.sigs.unshift(b.sig);
    return json(200, { ok: true });
  }
  if (url.pathname === '/solana') {
    const b = await body(req);
    const r = (result) => json(200, { jsonrpc: '2.0', id: b.id, result });
    if (b.method === 'getBalance') return r({ context: { slot: 1 }, value: sol.balance });
    if (b.method === 'getSignaturesForAddress') return r(sol.sigs.map((signature) => ({ signature, err: null, slot: 1 })));
    if (b.method === 'getTransaction') return r({ blockTime: Math.floor(Date.now() / 1000), meta: { preBalances: [5e9, 1e9], postBalances: [3.9e9, 2.1e9] }, transaction: { message: { accountKeys: [{ pubkey: 'Sender1111111111111111111111111111111111111' }, { pubkey: b.params[0] && sol.vault ? sol.vault : 'x' }] } } });
    return json(200, { jsonrpc: '2.0', id: b.id, error: { message: 'unknown method' } });
  }
  if (url.pathname === '/api/version') return json(200, { version: '0.40.4' });
  if (url.pathname === '/api/tags') return json(200, { models: models.map((m) => ({ ...m, model: m.name, modified_at: new Date().toISOString() })) });
  if (url.pathname === '/api/ps') return json(200, { models: loaded ? [{ name: loaded, model: loaded, size: 6.2e9, size_vram: 6.2e9, context_length: 8192 }] : [] });
  if (url.pathname === '/api/show') {
    const b = await body(req);
    if (!models.find((m) => m.name === b.model)) return json(404, { error: `model '${b.model}' not found` });
    return json(200, { capabilities: ['completion', 'tools', 'thinking'], details: {} });
  }
  if (url.pathname === '/api/delete') {
    const b = await body(req);
    const i = models.findIndex((m) => m.name === b.model);
    if (i < 0) return json(404, { error: 'not found' });
    models.splice(i, 1);
    return json(200, {});
  }
  if (url.pathname === '/api/pull') {
    const b = await body(req);
    res.writeHead(200, { 'Content-Type': 'application/x-ndjson' });
    res.write(JSON.stringify({ status: 'pulling manifest' }) + '\n');
    for (let i = 1; i <= 4; i++) {
      await sleep(10);
      res.write(JSON.stringify({ status: 'pulling layer', total: 4000, completed: i * 1000 }) + '\n');
    }
    res.write(JSON.stringify({ status: 'success' }) + '\n');
    if (!models.find((m) => m.name === b.model)) models.push({ name: b.model, size: 3e9, details: { family: 'qwen35', parameter_size: '4B', quantization_level: 'UD-Q4_K_XL' } });
    return res.end();
  }
  if (url.pathname === '/api/chat') {
    const b = await body(req);
    lastChat = b;
    chats.unshift(b);
    chats.length = Math.min(chats.length, 50);
    loaded = b.model;
    const lastUser = [...(b.messages || [])].reverse().find((m) => m.role === 'user');
    const said = (lastUser && lastUser.content) || '';
    const stats = { done: true, done_reason: 'stop', eval_count: 42, eval_duration: 1.2e9, prompt_eval_count: 300, total_duration: 1.5e9, load_duration: 2e8 };
    let content = `Hello from the mock model. You said: ${said.slice(0, 60)}`;
    let thinking = b.think === true ? 'Considering the live state first.' : '';
    let toolCalls = null;
    if (b.format && typeof b.format === 'object') content = JSON.stringify(fromSchema(b.format));
    else if (b.format === 'json') content = JSON.stringify({ assessment: 'Mock assessment from the local brain', risks: ['r1', 'r2'], moves: ['m1', 'm2'] });
    else if (Array.isArray(b.tools) && b.tools.length && /use a tool/i.test(said) && (b.messages[b.messages.length - 1] || {}).role === 'user') {
      const pick = b.tools.find((t) => /get_money_snapshot/.test(t.function.name)) || b.tools[0];
      toolCalls = [{ function: { name: pick.function.name, arguments: {} } }];
      content = '';
    } else if (/tagtest/.test(said)) content = '<think>inner reasoning</think>Visible answer.';
    if (b.stream === false) {
      return json(200, { model: b.model, message: { role: 'assistant', content, ...(thinking ? { thinking } : {}), ...(toolCalls ? { tool_calls: toolCalls } : {}) }, ...stats });
    }
    res.writeHead(200, { 'Content-Type': 'application/x-ndjson' });
    const send = (o) => res.write(JSON.stringify({ model: b.model, done: false, ...o }) + '\n');
    if (thinking) for (const part of thinking.match(/.{1,12}/g)) {
      send({ message: { role: 'assistant', content: '', thinking: part } });
      await sleep(3);
    }
    if (toolCalls) send({ message: { role: 'assistant', content: '', tool_calls: toolCalls } });
    for (const part of content.match(/[\s\S]{1,9}/g) || []) {
      send({ message: { role: 'assistant', content: part } });
      await sleep(3);
    }
    res.write(JSON.stringify({ model: b.model, message: { role: 'assistant', content: '' }, ...stats }) + '\n');
    return res.end();
  }
  json(404, { error: 'not found' });
});

const port = Number(process.env.MOCK_PORT || 11555);
server.listen(port, '127.0.0.1', () => console.log(`mock ollama on ${port}`));
