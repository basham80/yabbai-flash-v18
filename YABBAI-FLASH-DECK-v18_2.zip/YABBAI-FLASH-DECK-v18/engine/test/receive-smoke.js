'use strict';
// YABBAI — RECEIVE smoke test. No network: every rail is exercised through its
// pure reducer, and the invoice lifecycle runs against a throwaway data folder.
//   node engine/test/receive-smoke.js
const fs = require('fs');
const os = require('os');
const path = require('path');
const assert = require('assert');

const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'yabbai-receive-'));
process.env.YABBAI_DATA = TMP;

const store = require('../lib/store');
store.load();

const bs58 = require('../lib/rails/bs58');
const bank = require('../lib/rails/bank');
const solana = require('../lib/rails/solana');
const cryptoRail = require('../lib/rails/crypto');
const paypal = require('../lib/rails/paypal');
const paypage = require('../lib/paypage');
const invoices = require('../lib/invoices');

let pass = 0;
const fails = [];
function ok(name, fn) {
  try {
    fn();
    pass++;
    console.log(`  ✓ ${name}`);
  } catch (e) {
    fails.push(`${name}: ${e.message}`);
    console.log(`  ✗ ${name}\n      ${e.message}`);
  }
}
async function okAsync(name, fn) {
  try {
    await fn();
    pass++;
    console.log(`  ✓ ${name}`);
  } catch (e) {
    fails.push(`${name}: ${e.message}`);
    console.log(`  ✗ ${name}\n      ${e.message}`);
  }
}

(async () => {
  console.log('\nRECEIVE — rails\n');

  ok('base58 round-trips 32 bytes', () => {
    const raw = Buffer.alloc(32, 7);
    raw[0] = 0;
    raw[1] = 1;
    const enc = bs58.encode(raw);
    assert.strictEqual(bs58.decode(enc).toString('hex'), raw.toString('hex'));
    assert.ok(bs58.isPubkey(enc));
    assert.ok(!bs58.isPubkey('not-an-address'));
  });

  ok('solana pay uri carries amount, reference and memo', () => {
    const vault = bs58.encode(Buffer.from('11'.repeat(32), 'hex'));
    const ref = solana.referenceKey();
    const uri = solana.payUri({ vault, amountSol: 0.123456789, reference: ref, label: 'YABBAI', memo: 'INV-0001' });
    assert.ok(uri.startsWith(`solana:${vault}?`), uri);
    assert.ok(uri.includes(`reference=${ref}`));
    assert.ok(uri.includes('memo=INV-0001'));
    assert.ok(!uri.includes('0.1234567890'), 'amount must be trimmed, not padded');
  });

  ok('solana reducer credits only inbound balance deltas', () => {
    const vault = 'Vault1111111111111111111111111111111111111111';
    const tx = {
      slot: 1,
      blockTime: 1700000000,
      meta: { preBalances: [0, 1_000_000_000], postBalances: [0, 1_500_000_000] },
      transaction: { message: { accountKeys: [{ pubkey: 'Payer111' }, { pubkey: vault }], instructions: [{ program: 'spl-memo', parsed: 'INV-0007' }] } },
    };
    const t = solana.reduceTransfer({ tx, keys: ['Payer111', vault], vault, signature: 'sig1' });
    assert.ok(t, 'should reduce');
    assert.strictEqual(t.sol, 0.5);
    assert.strictEqual(t.memo, 'INV-0007');
    assert.strictEqual(solana.reduceTransfer({ tx: { meta: { preBalances: [0, 5], postBalances: [0, 1] } }, keys: ['a', vault], vault, signature: 's' }), null, 'outflow must not credit');
  });

  ok('bitcoin reducer only credits the watched address', () => {
    const addr = 'bc1qexampleaddressxxxxxxxxxxxxxxxxxxxxxxxxxx';
    const tx = {
      txid: 'btc1',
      fee: 800,
      status: { confirmed: true, block_time: 1700000000 },
      vin: [{ prevout: { scriptpubkey_address: 'bc1qsender' } }],
      vout: [
        { scriptpubkey_address: 'bc1qsender', value: 50000 },
        { scriptpubkey_address: addr, value: 123456 },
      ],
    };
    const r = cryptoRail.reduceBtcTx(tx, addr);
    assert.ok(r);
    assert.strictEqual(r.sats, 123456);
    assert.strictEqual(r.confirmed, true);
    assert.strictEqual(cryptoRail.reduceBtcTx(tx, 'bc1qother'), null);
  });

  ok('ethereum reducer ignores contract errors and non-matching recipients', () => {
    const addr = '0xAbC0000000000000000000000000000000000001';
    const good = { hash: '0x1', to: addr.toLowerCase(), value: String(2e17), from: '0xsender', isError: '0', confirmations: '3', timeStamp: '1700000000' };
    const r = cryptoRail.reduceEthTx(good, addr);
    assert.ok(r);
    assert.strictEqual(r.eth, 0.2);
    assert.strictEqual(cryptoRail.reduceEthTx({ ...good, isError: '1' }, addr), null);
    assert.strictEqual(cryptoRail.reduceEthTx({ ...good, to: '0xdead000000000000000000000000000000000002' }, addr), null);
  });

  ok('unique-amount quotes are deterministic per invoice', () => {
    const inv = { id: 'inv_abc123', totalAud: 970 };
    const a = cryptoRail.quote({ invoice: inv, audPerUnit: 100000, unit: 'BTC' });
    const b = cryptoRail.quote({ invoice: inv, audPerUnit: 100000, unit: 'BTC' });
    assert.strictEqual(a.amount, b.amount, 'same invoice must quote the same amount');
    assert.ok(a.amount > 970 / 100000, 'tag must be added, never subtracted');
    assert.ok(cryptoRail.matches(a.amount, a.amount, 0.005).ok);
    assert.ok(!cryptoRail.matches(a.amount, a.amount * 1.02, 0.005).ok, '2% over is not a match');
  });

  console.log('\nRECEIVE — bank\n');

  const commbank = `Date,Amount,Description,Balance
24/10/2026,97.00,NPP INV-0001 MARCUS VANCE,1204.55
23/10/2026,-12.50,CARD FEE,1107.55
22/10/2026,"1,250.00",NPP INV-0002 NEXUS HEALTH,1120.05
21/10/2026,40.00,TRANSFER FROM SAVINGS,` + `
`;

  ok('parses a CommBank statement, quoted thousands and debits', () => {
    const rows = bank.parseStatement(commbank);
    assert.strictEqual(rows.length, 4);
    assert.strictEqual(rows[0].date, '2026-10-24');
    assert.strictEqual(rows[0].amount, 97);
    assert.strictEqual(rows[2].amount, 1250);
    assert.strictEqual(rows[1].amount, -12.5);
  });

  ok('parses a debit/credit column pair', () => {
    const csv = `Date,Narrative,Debit,Credit,Balance
2026-10-24,INV-0003 deposit,,97.00,100
2026-10-25,coffee,4.50,,95.50`;
    const rows = bank.parseStatement(csv);
    assert.strictEqual(rows.length, 2);
    assert.strictEqual(rows[0].amount, 97);
    assert.strictEqual(rows[1].amount, -4.5);
  });

  ok('european decimals survive the parser', () => {
    assert.strictEqual(bank.parseAmount('1.234,56'), 1234.56);
    assert.strictEqual(bank.parseAmount('$1,234.56'), 1234.56);
    assert.strictEqual(bank.parseAmount('(45.00)'), -45);
  });

  ok('reference matching is case-insensitive and bounded', () => {
    assert.strictEqual(bank.matchReference({ reference: 'inv-0009', description: '' }), 'INV-0009');
    assert.strictEqual(bank.matchReference({ reference: '', description: 'NPP INV 12 X' }), 'INV-0012');
    assert.strictEqual(bank.matchReference({ reference: '', description: 'random transfer' }), null);
  });

  console.log('\nRECEIVE — invoice lifecycle (proof required)\n');

  let inv;
  await okAsync('draft → send → credit → part → paid', async () => {
    inv = invoices.addInvoice({ client: 'Marcus Vance', items: [{ desc: 'SEO audit', qty: 1, unitAud: 970 }], rails: ['bank', 'paypal'] });
    assert.match(inv.number, /^INV-\d{4}$/);
    assert.strictEqual(inv.status, 'draft');
    assert.strictEqual(inv.totalAud, 970);
    assert.strictEqual(inv.reference, `INV-${inv.number.slice(4)}`);
    invoices.sendInvoice(inv.id);
    assert.strictEqual(invoices.getInvoice(inv.id).status, 'sent');

    const c1 = invoices.applyCredit({ invoice: inv, amountAud: 600, kind: 'bank', externalId: 'txn-1', proof: 'director', note: 'part' });
    assert.strictEqual(c1.duplicate, false);
    assert.strictEqual(invoices.getInvoice(inv.id).status, 'part');
    assert.strictEqual(invoices.getInvoice(inv.id).paidAud, 600);

    const dup = invoices.applyCredit({ invoice: inv, amountAud: 600, kind: 'bank', externalId: 'txn-1', proof: 'director' });
    assert.strictEqual(dup.duplicate, true, 'same id must never double-credit');
    assert.strictEqual(store.db.payments.length, 1);

    invoices.applyCredit({ invoice: inv, amountAud: 370, kind: 'paypal', externalId: 'cap-1', proof: 'paypal' });
    const paid = invoices.getInvoice(inv.id);
    assert.strictEqual(paid.status, 'paid');
    assert.strictEqual(paid.paidAud, 970);
    assert.ok(paid.paidAt);
    const entry = store.db.ledger.find((e) => e.id === paid.ledgerIds[0]);
    assert.ok(entry, 'ledger entry must exist');
    assert.ok(entry.ref.includes(inv.number), 'ledger ref must carry the invoice number');
  });

  ok('a credit without proof is refused', () => {
    const inv2 = invoices.addInvoice({ client: 'No Proof Pty', items: [{ desc: 'x', unitAud: 50 }], rails: ['bank'] });
    assert.throws(() => invoices.applyCredit({ invoice: inv2, amountAud: 50, kind: 'bank', externalId: 'nope' }), /proof/i);
  });

  ok('claims never credit; confirmation needs a reference', () => {
    const inv3 = invoices.addInvoice({ client: 'Claimer', items: [{ desc: 'work', unitAud: 100 }], rails: ['bank'] });
    invoices.sendInvoice(inv3.id);
    const { claim } = invoices.claim(inv3.token, { rail: 'bank', amountAud: 100, ref: '' });
    assert.strictEqual(claim.status, 'pending');
    assert.strictEqual(invoices.getInvoice(inv3.id).paidAud, 0, 'claim must not touch the ledger');
    assert.throws(() => invoices.settleClaim(claim.id, 'confirm'), /reference/i);
    invoices.claim(inv3.token, { rail: 'bank', amountAud: 100, ref: 'NPP-778812' });
    const withRef = store.db.claims.find((c) => c.invoiceId === inv3.id && c.ref);
    assert.ok(withRef);
    invoices.settleClaim(withRef.id, 'confirm');
    assert.strictEqual(invoices.getInvoice(inv3.id).status, 'paid');
  });

  ok('statement import matches by reference and is idempotent', () => {
    const inv4 = invoices.addInvoice({ client: 'Bulk Co', items: [{ desc: 'build', unitAud: 500 }], rails: ['bank'] });
    invoices.sendInvoice(inv4.id);
    const csv = `Date,Amount,Description,Balance\n24/10/2026,500.00,NPP ${inv4.reference} BULK CO,500.00\n24/10/2026,15.00,unrelated,515.00`;
    const b1 = invoices.importStatement(csv, { filename: 'oct.csv' });
    assert.strictEqual(b1.rows, 2);
    assert.strictEqual(b1.credits, 1, `no match for ${inv4.number}: ${JSON.stringify(b1.skipped)}`);
    assert.strictEqual(b1.skipped.length, 1, 'unreferenced credit must be skipped, not guessed');
    assert.strictEqual(invoices.getInvoice(inv4.id).status, 'paid');
    const b2 = invoices.importStatement(csv, { filename: 'oct-again.csv' });
    assert.strictEqual(b2.credits, 0);
    assert.strictEqual(b2.duplicates, 1);
  });

  ok('bank webhook HMAC is enforced', () => {
    const secret = 'whsec_test';
    store.db.settings.receive.bank.webhookSecret = secret;
    const body = JSON.stringify({ data: { id: 'txn-9', amount: 25, description: 'INV-9999 x' } });
    const ts = Math.floor(Date.now() / 1000);
    const sig = require('crypto').createHmac('sha256', secret).update(`${ts}.${body}`).digest('hex');
    assert.ok(bank.verifyHmac({ rawBody: body, header: `t=${ts},v1=${sig}`, secret }));
    assert.throws(() => bank.verifyHmac({ rawBody: body, header: `t=${ts},v1=${'0'.repeat(64)}`, secret }), /mismatch/i);
    assert.throws(() => bank.verifyHmac({ rawBody: body, header: `t=${ts - 4000},v1=${sig}`, secret }), /replay/i);
  });

  console.log('\nRECEIVE — pay page + PayPal\n');

  ok('pay page escapes payer-supplied text', () => {
    const inv5 = invoices.addInvoice({ client: '<img src=x onerror=alert(1)>', items: [{ desc: '"quoted" & <b>', unitAud: 10 }], rails: ['bank'] });
    invoices.sendInvoice(inv5.id);
    const html = paypage.page(invoices.publicView(inv5.token));
    assert.ok(!html.includes('<img src=x'), 'client name must not reach the page raw');
    assert.ok(html.includes('&lt;img src=x'));
    assert.ok(html.includes(`INV-${inv5.number.slice(4)}`), 'reference shown to payer');
    assert.strictEqual(invoices.publicView(inv5.token).token, inv5.token, 'public view must carry the token for the claim POST');
    assert.ok(html.includes(inv5.token), 'claim script needs the invoice token');
  });

  ok('paypal order reader extracts amount and invoice identity', () => {
    const read = paypal.readOrder({
      id: 'ORDER1',
      status: 'COMPLETED',
      payer: { email_address: 'payer@example.com' },
      purchase_units: [{ invoice_id: 'INV-0009', custom_id: 'inv_abc', amount: { currency_code: 'AUD', value: '97.00' }, payments: { captures: [{ id: 'CAP1', status: 'COMPLETED', amount: { currency_code: 'AUD', value: '97.00' } }] } }],
    });
    assert.strictEqual(read.completed, true);
    assert.strictEqual(read.amountAud, 97);
    assert.strictEqual(read.captureId, 'CAP1');
    assert.strictEqual(read.invoiceNumber, 'INV-0009');
  });

  ok('paypal capture event maps to an invoice credit', () => {
    const e = paypal.readEvent({ event_type: 'PAYMENT.CAPTURE.COMPLETED', resource: { id: 'CAP9', status: 'COMPLETED', amount: { value: '42.50', currency_code: 'AUD' }, custom_id: 'yb:inv_abc', invoice_id: 'INV-0042' } });
    assert.strictEqual(e.kind, 'capture');
    assert.strictEqual(e.completed, true);
    assert.strictEqual(e.amountAud, 42.5);
    assert.strictEqual(e.invoiceId, 'inv_abc');
  });

  console.log('\nRECEIVE — summary\n');
  ok('summary reconciles receivable and collected', () => {
    const s = invoices.summary();
    assert.ok(s.count >= 5);
    assert.ok(s.collectedAud >= 970 + 500);
    assert.strictEqual(typeof s.receivableAud, 'number');
    assert.ok(Array.isArray(s.rails) && s.rails.length === 5);
  });

  console.log(`\n${pass} passed, ${fails.length} failed\n`);
  try {
    store.flush();
  } catch {
    /* nothing */
  }
  fs.rmSync(TMP, { recursive: true, force: true });
  if (fails.length) {
    fails.forEach((f) => console.error('FAILED —', f));
    process.exit(1);
  }
})();
