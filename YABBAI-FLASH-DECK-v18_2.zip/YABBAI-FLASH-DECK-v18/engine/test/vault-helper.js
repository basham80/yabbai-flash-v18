'use strict';
// Test helper: sets up Director Vault v2 on a running engine and works the authenticator
// the way a phone app does (RFC 6238: HMAC-SHA1, 30-second steps, 6 digits).
//   const vault = require('./vault-helper');
//   VAULT = await vault.open(ui);            // { 'X-Yabbai-Vault': token }
//   ui('POST', path, body, vault.otp());      // adds a fresh X-Yabbai-Otp
// Each code is good once: the helper hands out the next unused time step.
const crypto = require('crypto');

const B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
function b32decode(s) {
  const clean = String(s || '').toUpperCase().replace(/[^A-Z2-7]/g, '');
  let bits = 0;
  let val = 0;
  const out = [];
  for (const ch of clean) {
    val = (val << 5) | B32.indexOf(ch);
    bits += 5;
    if (bits >= 8) {
      out.push((val >>> (bits - 8)) & 255);
      bits -= 8;
    }
  }
  return Buffer.from(out);
}
function hotp(secret, counter) {
  const buf = Buffer.alloc(8);
  buf.writeBigUInt64BE(BigInt(counter));
  const h = crypto.createHmac('sha1', b32decode(secret)).update(buf).digest();
  const o = h[h.length - 1] & 15;
  const n = ((h[o] & 127) << 24) | (h[o + 1] << 16) | (h[o + 2] << 8) | h[o + 3];
  return String(n % 1000000).padStart(6, '0');
}
const stepNow = (ms = Date.now()) => Math.floor(ms / 30000);

const PIN = '482913';
const people = {}; // name → { secret, principalId, pin, lastStep, token, recovery }

// The next code nobody has used yet (the server accepts now−1 … now+1).
function codeFor(name = 'Director') {
  const p = people[name];
  if (!p) throw new Error(`no vault person ${name}`);
  const now = stepNow();
  const s = Math.max(p.lastStep + 1, now - 1);
  if (s > now + 1) throw new Error('No fresh authenticator code until the next 30-second step');
  p.lastStep = s;
  return hotp(p.secret, s);
}
const otp = (name = 'Director') => ({ 'X-Yabbai-Otp': codeFor(name) });
const header = (name = 'Director') => ({ 'X-Yabbai-Vault': people[name].token });

async function open(ui, { name = 'Director', pin = PIN, legacyPin } = {}) {
  const start = await ui('POST', '/api/v2/vault/setup/start', { name, pin, legacyPin });
  if (start.status !== 200) throw new Error(`vault setup failed (${start.status}): ${start.text}`);
  people[name] = { secret: start.json.secret, principalId: start.json.principalId, pin, lastStep: 0, token: null, recovery: [] };
  const code = codeFor(name);
  const done = await ui('POST', '/api/v2/vault/setup/confirm', { principalId: start.json.principalId, code });
  if (done.status !== 200 || !done.json.session) throw new Error(`vault confirm failed (${done.status}): ${done.text}`);
  people[name].token = done.json.session.token;
  people[name].recovery = done.json.recoveryCodes;
  return header(name);
}

// A second person (needs the director's open vault and step-up). Returns their header.
async function addApprover(ui, directorHeaders, { name = 'Approver', pin = '739154' } = {}) {
  const start = await ui('POST', '/api/v2/vault/approvers', { name, pin }, directorHeaders);
  if (start.status !== 200) throw new Error(`approver start failed (${start.status}): ${start.text}`);
  people[name] = { secret: start.json.secret, principalId: start.json.principalId, pin, lastStep: 0, token: null, recovery: [] };
  const done = await ui('POST', '/api/v2/vault/approvers/confirm', { principalId: start.json.principalId, code: codeFor(name) }, directorHeaders);
  if (done.status !== 200) throw new Error(`approver confirm failed (${done.status}): ${done.text}`);
  people[name].recovery = done.json.recoveryCodes;
  return unlock(ui, name);
}

async function unlock(ui, name = 'Director') {
  const p = people[name];
  const r = await ui('POST', '/api/v2/vault/unlock', { name, pin: p.pin, code: codeFor(name) }, {});
  if (r.status !== 200) throw new Error(`unlock failed (${r.status}): ${r.text}`);
  p.token = r.json.token;
  return header(name);
}

module.exports = { open, addApprover, unlock, otp, codeFor, header, hotp, stepNow, people, PIN };
