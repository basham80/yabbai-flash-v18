'use strict';
// Render pins the engine token with generateValue, a base64 string that can hold "+", "/"
// and "=". The claude.ai connector URL must still be one clean path segment, and the
// connection details must reach a token holder on the public URL.
//   node engine/test/smoke15-token.js
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');

const PORT = 7892;
const TOKEN = 'Ab+cd/EFgh+ij/KLmn+op/QRst+uv/WXyz0123456=';
const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'yabbai15t-'));
let pass = 0;
let fail = 0;
const ok = (c, label, x) => (c ? (pass++, console.log(`  PASS  ${label}`)) : (fail++, console.log(`  FAIL  ${label}${x !== undefined ? ' → ' + JSON.stringify(x).slice(0, 300) : ''}`)));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function req(method, p, body, headers = {}) {
  return new Promise((resolve, reject) => {
    const data = body === undefined ? undefined : JSON.stringify(body);
    const r = http.request({ host: '127.0.0.1', port: PORT, method, path: p, headers: { ...(data ? { 'Content-Type': 'application/json' } : {}), ...headers } }, (res) => {
      let s = '';
      res.on('data', (c) => (s += c));
      res.on('end', () => {
        let json = null;
        try {
          json = JSON.parse(s);
        } catch {}
        resolve({ status: res.statusCode, text: s, json });
      });
    });
    r.on('error', reject);
    if (data) r.write(data);
    r.end();
  });
}
const tools = (seg) => req('POST', `/mcp/${seg}`, { jsonrpc: '2.0', id: 1, method: 'tools/list' });
// What the public URL looks like from the engine's side: a non-local Host header.
const PUBLIC = { Host: 'yabbai-flash-deck.onrender.com', 'X-Forwarded-Proto': 'https' };

async function main() {
  const env = { ...process.env, YABBAI_PORT: String(PORT), YABBAI_DATA: DATA, YABBAI_TOKEN: TOKEN, YABBAI_PUBLIC_URL: 'https://yabbai-flash-deck.onrender.com', OLLAMA_URL: 'http://127.0.0.1:9' };
  delete env.PORT;
  delete env.RENDER;
  delete env.RENDER_EXTERNAL_URL;
  const proc = spawn(process.execPath, [path.join(__dirname, '..', 'server.js')], { env, stdio: ['ignore', 'pipe', 'pipe'] });
  let log = '';
  proc.stdout.on('data', (c) => (log += c));
  proc.stderr.on('data', (c) => (log += c));
  try {
    let up = false;
    for (let i = 0; i < 60 && !up; i++) {
      await sleep(150);
      up = await req('GET', '/healthz').then((r) => r.status === 200, () => false);
    }
    ok(up, 'engine starts with a base64 token pinned');

    console.log('\n[connector URL]');
    const conn = await req('GET', '/api/connect', undefined, { ...PUBLIC, Authorization: `Bearer ${TOKEN}` });
    ok(conn.status === 200, 'a token holder on the public URL gets the connection details', conn.status);
    const url = (conn.json && conn.json.mcpConnectorUrl) || '';
    const seg = url.split('/mcp/')[1] || '';
    ok(url.startsWith('https://yabbai-flash-deck.onrender.com/mcp/'), 'connector URL uses the public address', url.slice(0, 50));
    ok(/^[A-Za-z0-9_-]{20,}$/.test(seg), 'connector URL is one clean path segment (no %, +, /, =)');
    ok((await tools(seg)).status === 200, 'that URL reaches the MCP server');
    ok((await tools(encodeURIComponent(TOKEN))).status === 200, 'the escaped raw token works too');
    const wrong = seg.slice(0, -1) + (seg.endsWith('A') ? 'B' : 'A');
    ok((await tools(wrong)).status === 401, 'a wrong path token is refused');

    console.log('\n[who sees the details]');
    ok((await req('GET', '/api/connect', undefined, PUBLIC)).status === 401, 'no token on the public URL: refused');
    ok((await req('GET', '/api/connect', undefined, { ...PUBLIC, Authorization: 'Bearer nope_nope_nope_nope_nope' })).status === 401, 'a wrong bearer: refused');
    ok((await req('GET', '/api/connect', undefined, { ...PUBLIC, Cookie: `yb_token=${encodeURIComponent(TOKEN)}` })).status === 200, 'the login cookie on the same origin works');
    ok((await req('GET', '/api/connect', undefined, { ...PUBLIC, Origin: 'https://evil.example', Cookie: `yb_token=${encodeURIComponent(TOKEN)}` })).status === 401, 'another site riding the cookie: refused');
    const st = await req('GET', '/api/state', undefined, { ...PUBLIC, Origin: 'https://aistudio.google.com', Authorization: `Bearer ${TOKEN}` });
    ok(st.status === 200, 'an AI Studio page with the raw token as bearer reads state', st.status);
    ok(!log.includes(TOKEN) && !log.includes(seg), 'the token never reaches the log');
  } finally {
    proc.kill('SIGTERM');
    await sleep(200);
    fs.rmSync(DATA, { recursive: true, force: true });
  }
  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
