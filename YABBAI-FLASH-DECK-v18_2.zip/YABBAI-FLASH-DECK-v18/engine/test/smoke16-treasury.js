'use strict';
// v16 Treasury release gate: the blueprint's section 13, run against a real engine on a throwaway
// data folder, with stand-in Solana RPC and PayPal APIs and a stand-in model.
//   node engine/test/smoke16-treasury.js
// Every check is tagged with the gate line(s) it proves; the summary at the end lists each line.
const { spawn, spawnSync } = require('child_process');
const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const vault = require('./vault-helper');
const WORDS = require('../lib/bip39-english');

const PORT = 7894;
const MOCK = 7895;
const TOKEN = 'yb_test_token_treasury_0123456789';
const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'yabbai16t-'));
const ROOT = path.join(__dirname, '..', '..');
const BANK_SECRET = 'whsec_bank_test_7f3a91c2';
const PP_SECRET = 'pp_secret_test_44b2e9';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const today = () => new Date().toISOString().slice(0, 10);

// ── gate bookkeeping ─────────────────────────────────────────
const GATES = {
  M1: 'Duplicate webhook, bank row or chain event never double-credits',
  M2: 'A payment claim never becomes cleared money without evidence',
  M3: 'Underpayment, overpayment, fee and refund are handled explicitly',
  M4: 'Double-entry postings balance for each transaction',
  M5: 'Internal transfers do not inflate revenue',
  M6: 'Reversals preserve original history',
  M7: 'All balances can be rebuilt from journal postings',
  M8: 'Pending and unconfirmed transactions are excluded from available cash',
  T1: 'A transfer cannot be submitted without an approved intent',
  T2: 'A new destination triggers step-up approval and cooling-off',
  T3: 'Per-transfer/daily/monthly limits are enforced server-side',
  T4: 'An agent cannot approve its own high-risk request',
  T5: 'Kill switch blocks submission immediately',
  T6: 'Duplicate submit requests do not broadcast twice',
  T7: 'Settlement requires external evidence and correct network/asset',
  T8: 'Reorgs, failed transfers and replaced transactions are represented correctly',
  S1: 'Money operations are disabled until strong auth is configured',
  S2: 'Lockout survives process restart',
  S3: 'No private key or seed phrase in database, logs, UI payloads or AI prompts',
  S4: 'Tokens and secrets are redacted',
  S5: 'Read-only agents cannot write; approval agents cannot sign',
  S6: 'Unauthorized origin, missing CSRF token and insufficient scopes are rejected',
  S7: 'Backup restore reproduces balances and audit history',
  O1: 'Stale provider/chain data is visibly stale',
  O2: 'A failed feed does not show a fabricated zero balance',
  O3: 'Every figure has source and timestamp',
  O4: 'Alerts are deduplicated and actionable',
  O5: 'Daily reconciliation reports opening, movement, closing and variance',
  O6: 'Migration totals match the v15 baseline',
};
const tally = Object.fromEntries(Object.keys(GATES).map((k) => [k, { pass: 0, fail: 0 }]));
let pass = 0;
let fail = 0;
function ok(cond, label, x, gates = '') {
  for (const g of gates.split(/\s+/).filter(Boolean)) tally[g][cond ? 'pass' : 'fail']++;
  if (cond) pass++, console.log(`  PASS  ${label}${gates ? `  [${gates}]` : ''}`);
  else fail++, console.log(`  FAIL  ${label}${gates ? `  [${gates}]` : ''}${x !== undefined ? ` → ${JSON.stringify(x).slice(0, 700)}` : ''}`);
}

// ── test secrets (never real) ────────────────────────────────
const B58 = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
function b58(buf) {
  let n = BigInt(`0x${buf.toString('hex') || '0'}`);
  let s = '';
  while (n > 0n) (s = B58[Number(n % 58n)] + s), (n /= 58n);
  for (const b of buf) {
    if (b !== 0) break;
    s = `1${s}`;
  }
  return s;
}
const dsha = (b) => crypto.createHash('sha256').update(crypto.createHash('sha256').update(b).digest()).digest();
const check58 = (p) => b58(Buffer.concat([p, dsha(p).subarray(0, 4)]));
const PHRASE = WORDS.slice(1500, 1512).join(' ');
const WIF = check58(Buffer.concat([Buffer.from([0x80]), crypto.randomBytes(32), Buffer.from([1])]));
const XPRV = check58(Buffer.concat([Buffer.from('0488ade4', 'hex'), crypto.randomBytes(74)]));
const SOLSECRET = b58(crypto.randomBytes(64));
const pub = () => b58(crypto.randomBytes(32));
const sig = () => b58(crypto.randomBytes(64));
const RECV = pub();
const HOT = pub();
const COLD = pub();
const PAYER = pub();

// ── stand-in Solana RPC and PayPal ───────────────────────────
const SOL = { bal: {}, failBal: new Set(), sigs: {}, txs: {}, statuses: {} };
function solRpc({ method, params = [] }) {
  if (method === 'getBalance') {
    const [addr, opt] = params;
    if (SOL.failBal.has(addr)) return { error: { code: -32005, message: 'node is behind by 3000 slots' } };
    const b = SOL.bal[addr] || { finalized: 0, confirmed: 0 };
    return { result: { context: { slot: 1000 }, value: b[(opt && opt.commitment) || 'finalized'] ?? b.finalized } };
  }
  if (method === 'getSignaturesForAddress') return { result: (SOL.sigs[params[0]] || []).map((s) => ({ signature: s, err: null, confirmationStatus: 'finalized' })) };
  if (method === 'getTransaction') return { result: SOL.txs[params[0]] || null };
  if (method === 'getSignatureStatuses') return { result: { context: { slot: 1000 }, value: params[0].map((s) => SOL.statuses[s] ?? null) } };
  return { error: { code: -32601, message: 'method not found' } };
}
const txOf = (from, to, lamports, { got = lamports, fee = 5000, fromBal = 3e9 } = {}) => ({
  slot: 2000,
  blockTime: Math.floor(Date.now() / 1000),
  meta: { fee, err: null, preBalances: [fromBal, 0], postBalances: [fromBal - lamports - fee, got] },
  transaction: { message: { accountKeys: [{ pubkey: from }, { pubkey: to }], instructions: [] } },
});
function startMocks() {
  return new Promise((resolve) => {
    const srv = http.createServer((req, res) => {
      let s = '';
      req.on('data', (c) => (s += c));
      req.on('end', () => {
        let b = {};
        try {
          b = JSON.parse(s || '{}');
        } catch {}
        const send = (code, obj) => (res.writeHead(code, { 'Content-Type': 'application/json' }), res.end(JSON.stringify(obj)));
        if (req.url === '/rpc') return send(200, { jsonrpc: '2.0', id: b.id || 1, ...solRpc(b) });
        if (req.url === '/v1/oauth2/token') return send(200, { access_token: 'pp-access-test', token_type: 'Bearer', expires_in: 3600 });
        if (req.url === '/v1/notifications/verify-webhook-signature') return send(200, { verification_status: b.transmission_sig === 'good' ? 'SUCCESS' : 'FAILURE' });
        return send(404, { error: 'not found' });
      });
    });
    srv.listen(0, '127.0.0.1', () => resolve({ srv, url: `http://127.0.0.1:${srv.address().port}` }));
  });
}

// ── HTTP helpers (every response body is kept for the final secret scan) ──
const SEEN = [];
function req(method, p, body, headers = {}) {
  return new Promise((resolve, reject) => {
    const data = body === undefined ? undefined : typeof body === 'string' ? body : JSON.stringify(body);
    const r = http.request({ host: '127.0.0.1', port: PORT, method, path: p, headers: { ...(data ? { 'Content-Type': 'application/json' } : {}), ...headers } }, (res) => {
      let s = '';
      res.on('data', (c) => (s += c));
      res.on('end', () => {
        SEEN.push(s);
        let json = null;
        try {
          json = JSON.parse(s);
        } catch {}
        resolve({ status: res.statusCode, headers: res.headers, text: s, json });
      });
    });
    r.on('error', reject);
    if (data) r.write(data);
    r.end();
  });
}
let VAULT = {};
let APPROVER = {};
const ui = (method, p, body, extra = {}) => req(method, p, body, method === 'GET' ? { ...VAULT, ...extra } : { 'X-Yabbai': '1', ...VAULT, ...extra });
const key = () => `k-${crypto.randomBytes(8).toString('hex')}`;
const T = '/api/v2/treasury';
const tw = (method, p, body = {}, extra = {}) => ui(method, `${T}${p}`, body, { 'Idempotency-Key': key(), ...extra });
const bearer = (method, p, body, extra = {}) => req(method, p, body, { Authorization: `Bearer ${TOKEN}`, 'X-Yabbai': '1', ...extra });
async function otp(name = 'Director') {
  for (;;) {
    try {
      return vault.otp(name);
    } catch {
      await sleep(1000);
    }
  }
}
async function mcp(method, params) {
  const r = await req('POST', '/mcp', { jsonrpc: '2.0', id: 1, method, params }, { Authorization: `Bearer ${TOKEN}`, Accept: 'application/json, text/event-stream' });
  const line = r.text.split('\n').find((l) => l.startsWith('data:'));
  try {
    return { ...r, rpc: line ? JSON.parse(line.slice(5)) : JSON.parse(r.text) };
  } catch {
    return { ...r, rpc: null };
  }
}
async function until(fn, ms = 8000) {
  const end = Date.now() + ms;
  let last;
  while (Date.now() < end) {
    last = await fn();
    if (last) return last;
    await sleep(80);
  }
  return last;
}

// ── engine process ───────────────────────────────────────────
let LOG = '';
let mocks;
function engineEnv() {
  const env = { ...process.env, YABBAI_PORT: String(PORT), YABBAI_DATA: DATA, YABBAI_TOKEN: TOKEN, YABBAI_SOL_RPC: `${mocks.url}/rpc`, YABBAI_PAYPAL_URL: mocks.url, YABBAI_TREASURY_SYNC_SEC: '0', OLLAMA_URL: `http://127.0.0.1:${MOCK}`, YABBAI_PUBLIC_URL: `http://127.0.0.1:${PORT}` };
  delete env.PORT;
  delete env.RENDER;
  delete env.YABBAI_IGNORE_LOCK;
  return env;
}
async function startEngine() {
  const proc = spawn(process.execPath, [path.join(__dirname, '..', 'server.js')], { env: engineEnv(), stdio: ['ignore', 'pipe', 'pipe'] });
  proc.stdout.on('data', (c) => (LOG += c));
  proc.stderr.on('data', (c) => (LOG += c));
  const up = await until(() => req('GET', '/healthz').then((r) => r.status === 200, () => false), 12000);
  if (!up) throw new Error(`engine did not start:\n${LOG.slice(-2000)}`);
  return proc;
}
function stopEngine(proc) {
  return new Promise((resolve) => {
    if (!proc || proc.exitCode !== null) return resolve();
    proc.once('exit', () => resolve());
    proc.kill('SIGTERM');
    setTimeout(() => proc.kill('SIGKILL'), 8000);
  });
}
const script = (name, args) => spawnSync(process.execPath, [path.join(ROOT, 'scripts', name), ...args], { env: { ...engineEnv() }, encoding: 'utf8', timeout: 60000 });

// ── journal checks ───────────────────────────────────────────
function balanced(tx) {
  const by = {};
  for (const p of tx.postings || []) {
    by[p.currency] = by[p.currency] || 0n;
    by[p.currency] += BigInt(p.debitMinor || 0) - BigInt(p.creditMinor || 0);
  }
  return Object.values(by).every((v) => v === 0n);
}
async function allTx() {
  const out = [];
  for (let off = 0; ; off += 500) {
    const r = await ui('GET', `${T}/journal?limit=500&offset=${off}`);
    out.push(...(r.json.items || []));
    if (out.length >= r.json.total || !(r.json.items || []).length) break;
  }
  return out;
}
const revenueMinor = (bals) => bals.filter((b) => b.accountId.startsWith('revenue:') && b.currency === 'AUD').reduce((s, b) => s + BigInt(b.minor), 0n);
const acctView = async (id) => (await ui('GET', `${T}/accounts/${id}`)).json;

// v15 data as it sat on disk before the upgrade (one note holds a pasted recovery phrase).
function seedV15() {
  const at = (d) => `${d}T02:00:00.000Z`;
  const db = {
    settings: { spine: { treasury: 30, pay: 30, reinvest: 20, fuel: 10, reserve: 10 }, solana: { address: RECV, rpc: `${mocks.url}/rpc` }, receive: { invoiceSeq: 1 } },
    ledger: [
      { id: 'e_v15a', amount: 550, ref: 'INV-0001 · bank tx-v15-1', note: 'Invoice INV-0001 — Acme', source: 'client', agent: 'none', date: '2026-10-01', createdAt: at('2026-10-01') },
      { id: 'e_v15b', amount: 120.5, ref: 'gumroad-v15-9', note: `Kit sale. My wallet words so I don't lose them: ${PHRASE}`, source: 'product', agent: 'none', date: '2026-10-03', createdAt: at('2026-10-03') },
      { id: 'e_v15c', amount: -45.25, ref: 'render-oct', note: 'Render bill', source: 'other', agent: 'none', date: '2026-10-05', createdAt: at('2026-10-05') },
    ],
    invoices: [{ id: 'inv_v15_1', number: 'INV-0001', client: 'Acme', items: [{ desc: 'Site', qty: 1, unitAud: 500 }], subtotalAud: 500, taxBps: 1000, taxAud: 50, totalAud: 550, paidAud: 550, status: 'paid', token: 'tok_v15_1_abcdefghijklmnop', ledgerIds: ['e_v15a'], rails: ['bank'], createdAt: at('2026-09-28'), updatedAt: at('2026-10-01') }],
    payments: [{ id: 'pay_v15_1', invoiceId: 'inv_v15_1', invoiceNumber: 'INV-0001', client: 'Acme', amountAud: 550, currency: 'AUD', kind: 'bank', proof: 'bank-webhook', externalId: 'tx-v15-1', date: '2026-10-01', at: at('2026-10-01'), status: 'settled', ledgerId: 'e_v15a' }],
    allocations: [
      { id: 'al_v15_1', entryId: 'e_v15a', amount: 550, splits: { treasury: 165, pay: 165, reinvest: 110, fuel: 55, reserve: 55 }, status: 'executed', date: '2026-10-01', note: 'INV-0001', ref: 'INV-0001', createdAt: at('2026-10-01') },
      { id: 'al_v15_2', entryId: 'e_v15b', amount: 120.5, splits: { treasury: 36.15, pay: 36.15, reinvest: 24.1, fuel: 12.05, reserve: 12.05 }, status: 'pending', date: '2026-10-03', note: 'Kit sale', ref: 'gumroad-v15-9', createdAt: at('2026-10-03') },
    ],
    payouts: [
      { id: 'po_v15_1', amount: 100, methodName: 'PayID', status: 'paid', note: 'October pay', ref: 'NPP-v15-1', createdAt: at('2026-10-10'), paidAt: at('2026-10-10') },
      { id: 'po_v15_2', amount: 50, methodName: 'PayID', status: 'requested', note: '', createdAt: at('2026-10-20') },
    ],
  };
  fs.writeFileSync(path.join(DATA, 'db.json'), JSON.stringify(db, null, 2));
}

function signBank(raw) {
  const t = Math.floor(Date.now() / 1000);
  return `t=${t},v1=${crypto.createHmac('sha256', BANK_SECRET).update(`${t}.${raw}`).digest('hex')}`;
}
async function bankHook(id, amount, ref, { sigOverride } = {}) {
  const raw = JSON.stringify({ data: { id, amount, description: `PAYMENT ${ref}`, reference: ref, settlementDate: today(), payerName: 'Beta Pty' } });
  return req('POST', '/webhooks/bank', raw, { 'Content-Type': 'application/json', 'x-yabbai-signature': sigOverride || signBank(raw) });
}
const ppHeaders = (s = 'good') => ({ 'paypal-auth-algo': 'SHA256withRSA', 'paypal-cert-url': 'https://api.sandbox.paypal.com/cert', 'paypal-transmission-id': crypto.randomUUID(), 'paypal-transmission-sig': s, 'paypal-transmission-time': new Date().toISOString() });
const ppHook = (event, s) => req('POST', '/webhooks/paypal', event, ppHeaders(s));
async function invoice(client, unitAud, taxBps, rails) {
  const r = await ui('POST', '/api/invoices', { client, items: [{ desc: 'Automation build', qty: 1, unitAud }], taxBps, rails });
  if (r.status !== 200) throw new Error(`invoice: ${r.text}`);
  const inv = r.json.invoice || r.json;
  await ui('POST', `/api/invoices/${inv.id}/send`, {});
  return inv;
}

async function main() {
  mocks = await startMocks();
  const ollama = spawn(process.execPath, [path.join(__dirname, 'mock-ollama.js')], { env: { ...process.env, MOCK_PORT: String(MOCK) }, stdio: 'ignore' });
  let proc = null;
  try {
    seedV15();

    console.log('\n[migration from v15]');
    const dry = script('v16-migrate.js', ['--data', DATA]);
    ok(dry.status === 0 && /dry run|plan/i.test(dry.stdout), 'migration dry run reads v15 and changes nothing', (dry.stdout + dry.stderr).slice(-400));
    const run = script('v16-migrate.js', ['--data', DATA, '--run']);
    ok(run.status === 0, 'migration --run succeeds', (run.stdout + run.stderr).slice(-600), 'O6');
    const repDir = path.join(DATA, 'treasury', 'migrations');
    const rep = fs.existsSync(repDir) ? JSON.parse(fs.readFileSync(path.join(repDir, fs.readdirSync(repDir).filter((f) => f.endsWith('.json')).sort().pop()), 'utf8')) : {};
    ok(rep.ok === true && rep.checks.every((c) => c.ok), 'income, costs and payouts journaled equal the v15 baseline', rep.checks, 'O6');
    ok(rep.before && rep.before.ledger.income === 670.5 && rep.before.ledger.costs === 45.25 && rep.before.payouts.paid === 100, 'baseline read from v15: A$670.50 in, A$45.25 out, A$100 paid out', rep.before && rep.before.ledger, 'O6');
    ok(rep.v15Untouched === true, 'v15 records are left exactly as they were', rep.v15Untouched, 'O6');
    ok(rep.secretsFound && rep.secretsFound.count === 1 && !JSON.stringify(rep).includes(PHRASE.split(' ').slice(0, 4).join(' ')), 'the report flags the saved recovery phrase without repeating it', rep.secretsFound, 'S3');

    proc = await startEngine();
    console.log('\n[before the vault]');
    let needs = (await ui('GET', `${T}/needs`)).json.needs.map((n) => n.key);
    ok(needs.includes('vault') && needs.includes('secrets') && needs.includes('limits') && needs.includes('quorum'), 'needs list: vault, limits, quorum and the saved secret', needs, 'S1');
    ok((await ui('POST', '/api/ledger', { amount: 10, source: 'other', ref: 'x-1' })).status === 423, 'income cannot be booked before the vault exists', null, 'S1');
    ok((await tw('POST', '/limits', { assets: { AUD: { perTransfer: 1, daily: 1, monthly: 1, highRiskOver: 1 } } })).status === 423, 'limits cannot be set before the vault exists', null, 'S1');
    ok((await tw('POST', '/transfers', { kind: 'internal', amount: '1', purpose: 'test' })).status === 423, 'no transfer can be drafted before the vault exists', null, 'S1');
    ok((await ui('POST', `${T}/transfers`, { kind: 'internal' })).status === 428, 'a treasury write without an Idempotency-Key is refused');
    ok((await ui('POST', '/api/receive/statement', { text: 'Date,Amount,Description\n2026-11-01,10,x' })).status === 423, 'a statement cannot be imported before the vault exists', null, 'S1');
    const st0 = await ui('GET', '/api/state');
    ok(!st0.text.includes(PHRASE) && st0.text.includes('[removed: looked like a wallet recovery phrase]'), 'the screen gets the v15 note with the phrase masked', null, 'S3');

    console.log('\n[secrets are refused at the door]');
    ok((await ui('POST', '/api/ledger', { amount: 10, source: 'other', ref: 'x-2', note: PHRASE })).status === 422, 'a recovery phrase in a ledger note → 422', null, 'S3');
    ok((await tw('POST', '/accounts', { kind: 'crypto_address', network: 'solana-mainnet', name: 'Oops', publicAddress: WIF })).status === 422, 'a WIF private key as an "address" → 422', null, 'S3');
    ok((await tw('POST', '/accounts', { kind: 'crypto_address', network: 'solana-mainnet', name: 'Oops', publicAddress: SOLSECRET })).status === 422, 'a 64-byte Solana secret key as an "address" → 422', null, 'S3');
    ok((await tw('POST', '/accounts', { kind: 'bank', name: 'Oops', keypair: Array.from(crypto.randomBytes(64)) })).status === 422, 'a pasted keypair file (64 numbers) → 422', null, 'S3');
    ok((await req('POST', '/pay/tok_v15_1_abcdefghijklmnop/claim', { rail: 'bank', note: XPRV }, { 'Content-Type': 'application/json' })).status === 422, 'an extended private key in a payer claim → 422', null, 'S3');
    const mcpSecret = await mcp('tools/call', { name: 'add_lead', arguments: { name: 'Lead', note: PHRASE } });
    ok(mcpSecret.rpc && (mcpSecret.rpc.error || (mcpSecret.rpc.result && mcpSecret.rpc.result.isError)) && !mcpSecret.text.includes(PHRASE), 'an AI client passing a phrase through MCP is refused, and it is not echoed back', mcpSecret.rpc, 'S3 S5');

    console.log('\n[vault and controls]');
    VAULT = await vault.open(ui);
    ok((await tw('POST', '/settings', { stepUpWindowSec: 600, entity: 'BASHAM Automations' }, await otp())).status === 200, 'director sets a 10-minute step-up window with a fresh code');
    const lim = await tw('POST', '/limits', { assets: { AUD: { perTransfer: 1000, daily: 1500, monthly: 10000, highRiskOver: 800 }, SOL: { perTransfer: 5, daily: 10, monthly: 50, highRiskOver: 4 } }, maxTransfersPerDay: 20, coolingHours: 24 });
    ok(lim.status === 200, 'limits set for AUD and SOL', lim.json, 'T3');
    ok((await tw('POST', '/quorum', { low: 1, medium: 1, high: 2 })).status === 200, 'quorum: high risk needs two people', null, 'T4');
    APPROVER = await vault.addApprover(ui, VAULT);
    ok(!!APPROVER['X-Yabbai-Vault'], 'a second person (approver) is enrolled with their own PIN and authenticator');

    console.log('\n[accounts and observations]');
    const rs = await ui('POST', '/api/receive/settings', { bank: { enabled: true, payId: 'pay@yabbai.example', bsb: '062000', accountNumber: '12345678', accountName: 'BASHAM AUTOMATIONS', bankName: 'CommBank', webhookSecret: BANK_SECRET }, paypal: { enabled: true, mode: 'sandbox', clientId: 'cid-test', webhookId: 'WH-TEST' }, paypalSecret: PP_SECRET });
    ok(rs.status === 200 && !rs.text.includes(BANK_SECRET) && !rs.text.includes(PP_SECRET), 'receive settings saved; the response never shows the webhook or PayPal secret', rs.status, 'S4');
    let accts = (await ui('GET', `${T}/accounts`)).json.accounts;
    const OPER = accts.find((a) => a.kind === 'bank');
    const PAYPAL = accts.find((a) => a.kind === 'payment_provider');
    const WATCH = accts.find((a) => a.publicAddress === RECV);
    ok(OPER && PAYPAL && WATCH, 'bank, PayPal and the watched Solana wallet are in the registry (watch-only)', accts.map((a) => a.name));
    const confirm = (id) => tw('PATCH', `/accounts/${id}`, { owner: 'BASHAM', businessEntity: 'BASHAM Automations', ownershipConfirmed: true });
    const add = async (body) => (await tw('POST', '/accounts', body)).json.account;
    const TAXR = await add({ kind: 'bank', name: 'Tax reserve', purpose: 'taxReserve', bsb: '062000', accountNumber: '99887766' });
    const HOTA = await add({ kind: 'crypto_address', network: 'solana-mainnet', name: 'Hot SOL', publicAddress: HOT, purpose: 'operating' });
    const COLDA = await add({ kind: 'crypto_address', network: 'solana-mainnet', name: 'Cold SOL', publicAddress: COLD, purpose: 'emergencyReserve' });
    for (const a of [OPER, PAYPAL, WATCH, TAXR, HOTA, COLDA]) await confirm(a.id);
    ok((await tw('POST', '/accounts', { kind: 'crypto_address', network: 'solana-mainnet', name: 'Again', publicAddress: HOT })).status === 409, 'the same address cannot be registered twice');

    SOL.bal[HOT] = { finalized: 3e9, confirmed: 3.5e9 };
    SOL.bal[COLD] = { finalized: 0, confirmed: 0 };
    SOL.bal[RECV] = { finalized: 0, confirmed: 0 };
    await tw('POST', '/accounts/observe', {});
    let hot = await acctView(HOTA.id);
    ok(hot.observed.minor === '3000000000' && hot.observed.pendingMinor === '500000000', 'Hot SOL: 3 SOL final, 0.5 SOL seen but not final', hot.observed, 'M8');
    ok(hot.observed.at && /finalized/.test(hot.observed.source) && hot.observed.freshness === 'fresh', 'the reading carries its source, time and freshness', hot.observed, 'O3');
    let ov = (await ui('GET', `${T}/overview`)).json;
    ok(ov.crypto.SOL && ov.crypto.SOL.observedMinor === '3000000000' && ov.crypto.SOL.pendingMinor === '500000000', 'the overview counts only the final 3 SOL; the 0.5 SOL pending is shown apart', ov.crypto.SOL, 'M8');
    ok(ov.cash.observed.sources.every((s) => s.at && s.source) && ov.cash.book.source === 'journal' && !!ov.at, 'every overview figure names its source and time', ov.cash.observed.sources, 'O3');
    SOL.failBal.add(COLD);
    const cold = (await tw('POST', `/accounts/${COLDA.id}/observe`, {})).json;
    ok(cold.observed.minor === null && cold.observed.freshness === 'failed' && /behind/.test(cold.observed.error), 'a failed feed shows no balance and the error, not A$0', cold.observed, 'O2');
    ov = (await ui('GET', `${T}/overview`)).json;
    const coldRow = ov.crypto.SOL.accounts.find((a) => a.id === COLDA.id);
    ok(coldRow && coldRow.observed === null && coldRow.freshness === 'failed' && coldRow.error, 'the overview row for the failed feed says failed, with the error', coldRow, 'O2');
    await tw('POST', `/accounts/${TAXR.id}/balance`, { balance: '0', at: new Date(Date.now() - 8 * 86400000).toISOString(), evidence: 'CommBank statement, 8 days old' });
    const taxv = await acctView(TAXR.id);
    ok(taxv.observed.freshness === 'stale' && taxv.needs.includes('balance is stale'), 'an 8-day-old statement balance is marked stale', taxv.observed, 'O1');
    await tw('POST', '/reconcile', {});
    await tw('POST', '/reconcile', {});
    let ex = (await ui('GET', `${T}/reconciliations`)).json.exceptions.filter((e) => e.status === 'open');
    const feedEx = ex.filter((e) => e.kind === 'feed-failed' && e.accountId === COLDA.id);
    const staleEx = ex.filter((e) => e.kind === 'stale' && e.accountId === TAXR.id);
    ok(feedEx.length === 1 && staleEx.length === 1, 'two reconciliation runs raise one alert each for the failed feed and the stale balance', ex.map((e) => e.kind), 'O4 O1');
    ok(feedEx[0] && feedEx[0].account && feedEx[0].detail, 'each alert names the account and what is wrong', feedEx[0], 'O4');
    SOL.failBal.delete(COLD);
    await tw('POST', `/accounts/${COLDA.id}/observe`, {});

    console.log('\n[money in: webhooks, statements, PayPal, refunds]');
    const before = (await ui('GET', `${T}/overview`)).json.cash;
    const inv2 = await invoice('Beta Pty', 100, 1000, ['bank']);
    let h = await bankHook('bk-1', 50, inv2.number);
    ok(h.status === 200 && h.json.payment && h.json.invoice.status === 'part', `A$50 of A$110 (${inv2.number}) is booked as a part payment`, h.json, 'M3');
    h = await bankHook('bk-1', 50, inv2.number);
    ok(h.status === 200 && h.json.duplicate === true, 'the same bank webhook again changes nothing', h.json, 'M1');
    ok((await bankHook('bk-9', 50, inv2.number, { sigOverride: 't=1,v1=00' })).status === 401, 'a bank webhook with a bad signature is refused', null, 'M1 S6');
    h = await bankHook('bk-2', 70, inv2.number);
    ok(h.status === 200 && h.json.invoice.status === 'paid', 'A$70 more pays it, A$10 over', h.json && h.json.invoice, 'M3');
    let txs = await allTx();
    const r2 = txs.find((t) => (t.evidenceRefs || []).some((e) => e.includes('bk-2')));
    const cc = r2 && r2.postings.find((p) => p.accountId === 'customer_credit');
    ok(cc && cc.creditMinor === '1000', 'the A$10 overpayment is held as customer credit, not revenue', r2 && r2.postings, 'M3');
    const gst = txs.filter((t) => (t.evidenceRefs || []).some((e) => /bk-[12]/.test(e))).flatMap((t) => t.postings).filter((p) => p.accountId === 'gst_payable').reduce((s, p) => s + BigInt(p.creditMinor || 0), 0n);
    ok(gst === 1000n, 'GST collected across both part payments is exactly A$10.00', gst.toString(), 'M3');
    const inv3 = await invoice('Gamma Ltd', 300, 0, ['bank']);
    await bankHook('bk-3', 100, inv3.number);
    const csv = `Date,Amount,Description\n${today()},100.00,PAYMENT ${inv3.number} GAMMA\n${today()},200.00,PAYMENT ${inv3.number} GAMMA REST`;
    const stmt = await ui('POST', '/api/receive/statement', { text: csv, filename: 'cba-nov.csv' });
    ok(stmt.status === 200 && stmt.json.duplicates === 1 && stmt.json.credits === 1, 'a statement row the webhook already booked is a duplicate; the new row is booked', stmt.json, 'M1');
    const inv4 = await invoice('Delta Co', 200, 0, ['paypal']);
    const cap = { event_type: 'PAYMENT.CAPTURE.COMPLETED', resource: { id: 'CAP-200-TEST', status: 'COMPLETED', amount: { currency_code: 'AUD', value: '200.00' }, custom_id: `yb:${inv4.id}`, invoice_id: inv4.number, seller_receivable_breakdown: { paypal_fee: { currency_code: 'AUD', value: '6.20' } } } };
    ok((await ppHook(cap, 'forged')).status === 401, 'a PayPal webhook that PayPal does not verify is refused', null, 'M1 S6');
    h = await ppHook(cap);
    ok(h.status === 200 && h.json.payment && h.json.payment.feeAud === 6.2, 'a PayPal capture is booked with its A$6.20 fee', h.json, 'M3');
    ok((await ppHook(cap)).json.duplicate === true, 'the same PayPal capture again changes nothing', null, 'M1');
    txs = await allTx();
    const ppTx = txs.find((t) => (t.evidenceRefs || []).some((e) => e.includes('CAP-200-TEST')));
    const ppAcct = ppTx && ppTx.postings.find((p) => p.accountId === `acct:${PAYPAL.id}`);
    const ppFee = ppTx && ppTx.postings.find((p) => p.accountId === 'fees');
    ok(ppAcct && ppAcct.debitMinor === '19380' && ppFee && ppFee.debitMinor === '620', 'PayPal: A$193.80 lands in the account, A$6.20 is a fee', ppTx && ppTx.postings, 'M3 M4');
    const inv5 = await invoice('Echo', 90, 0, ['paypal']);
    const usd = { event_type: 'PAYMENT.CAPTURE.COMPLETED', resource: { id: 'CAP-USD-TEST', status: 'COMPLETED', amount: { currency_code: 'USD', value: '60.00' }, custom_id: `yb:${inv5.id}`, invoice_id: inv5.number } };
    h = await ppHook(usd);
    ok(h.json.unmatched === true, 'a capture in USD is set aside for review instead of guessing an AUD amount', h.json, 'M3');
    const refund = { event_type: 'PAYMENT.CAPTURE.REFUNDED', resource: { id: 'REF-50-TEST', status: 'COMPLETED', amount: { currency_code: 'AUD', value: '50.00' }, custom_id: `yb:${inv4.id}`, invoice_id: inv4.number, links: [{ rel: 'up', href: 'https://api.paypal.com/v2/payments/captures/CAP-200-TEST' }] } };
    h = await ppHook(refund);
    ok(h.status === 200 && h.json.refund && h.json.refund.amountAud === 50, 'a PayPal refund of A$50 is recorded', h.json, 'M3');
    ok((await ppHook(refund)).json.duplicate === true, 'the same refund event again changes nothing', null, 'M1');
    const dr = await tw('POST', '/refunds', { invoiceId: inv2.number, amount: 10, rail: 'bank', externalId: 'RF-BANK-0001', reason: 'overpaid' });
    ok(dr.status === 200 && dr.json.refund && dr.json.refund.fromCreditAud === 10, 'the A$10 overpayment is refunded from customer credit', dr.json, 'M3');
    ok((await tw('POST', '/refunds', { invoiceId: inv2.number, amount: 10, rail: 'bank', externalId: 'RF-BANK-0001', reason: 'again' })).json.duplicate === true, 'the same refund id twice is one refund', null, 'M1');
    txs = await allTx();
    const rfTx = txs.find((t) => t.type === 'refund' && (t.evidenceRefs || []).some((e) => e.includes('RF-BANK-0001')));
    ok(rfTx && rfTx.postings.some((p) => p.accountId === 'customer_credit' && p.debitMinor === '1000') && !rfTx.postings.some((p) => p.accountId === 'refunds'), 'refunding credit touches customer credit only, not revenue or refunds', rfTx && rfTx.postings, 'M3');

    console.log('\n[claims stay claims]');
    const inv6 = await invoice('Foxtrot', 80, 0, ['bank']);
    const cleared0 = (await ui('GET', `${T}/overview`)).json.cash.cleared.minor;
    const c1 = await req('POST', `/pay/${inv6.token}/claim`, { rail: 'bank', amountAud: 80, ref: 'NPP-CLAIM-0001' }, { 'Content-Type': 'application/json' });
    const c2 = await req('POST', `/pay/${inv6.token}/claim`, { rail: 'bank', amountAud: 80 }, { 'Content-Type': 'application/json' });
    ov = (await ui('GET', `${T}/overview`)).json;
    ok(c1.status === 200 && ov.cash.pending.claims >= 2 && ov.cash.cleared.minor === cleared0, 'payer claims show as pending and add nothing to cleared cash', ov.cash.pending, 'M2 M8');
    ok((await req('POST', `/api/claims/${c1.json.claim.id}/confirm`, {}, { 'X-Yabbai': '1' })).status === 423, 'confirming a claim needs the open vault', null, 'M2 S1');
    ok((await ui('POST', `/api/claims/${c2.json.claim.id}/confirm`, {})).status === 400, 'a claim without a transaction reference cannot be confirmed', null, 'M2');
    const cf = await ui('POST', `/api/claims/${c1.json.claim.id}/confirm`, {});
    ok(cf.status === 200 && cf.json.status === 'confirmed', 'the director confirms the claim with its bank reference', cf.json, 'M2');
    const rep1 = await mcp('tools/call', { name: 'log_income', arguments: { amount: 25, source: 'product', ref: 'gumroad-r-88', note: 'kit sale' } });
    ov = (await ui('GET', `${T}/overview`)).json;
    ok(/waiting for the director/.test(rep1.text) && ov.cash.pending.reported >= 1, 'income an AI client reports is a claim waiting for the director', ov.cash.pending, 'M2 S5');
    const claim = (await ui('GET', '/api/state')).json;
    const ic = ((claim.incomeClaims || claim.queue || []).find ? (claim.incomeClaims || []).find((x) => x.ref === 'gumroad-r-88') : null);
    if (ic) ok((await req('POST', `/api/queue/income/${ic.id}`, { action: 'confirm' }, { 'X-Yabbai': '1' })).status === 423, 'confirming AI-reported income needs the open vault', null, 'M2 S1');

    console.log('\n[chain deposits]');
    const OLD = sig();
    SOL.sigs[RECV] = [OLD];
    await ui('POST', '/api/solana/scan', {});
    const NEW = sig();
    SOL.sigs[RECV] = [NEW, OLD];
    SOL.txs[NEW] = { slot: 1500, blockTime: Math.floor(Date.now() / 1000), meta: { fee: 5000, err: null, preBalances: [2e9, 0], postBalances: [1.5e9 - 5000, 5e8] }, transaction: { message: { accountKeys: [{ pubkey: PAYER }, { pubkey: RECV }], instructions: [] } } };
    await ui('POST', '/api/solana/scan', {});
    await ui('POST', '/api/solana/scan', {});
    let deps = ((await ui('GET', '/api/state')).json.deposits || []).filter((d) => d.sig === NEW);
    ok(deps.length === 1 && deps[0].sol === 0.5, 'a new 0.5 SOL deposit is flagged once, however often the wallet is scanned', deps, 'M1');
    const depId = deps[0] && deps[0].id;
    const lg = await ui('POST', `/api/queue/deposit/${encodeURIComponent(depId)}`, { action: 'log', amount: 75, source: 'client' });
    ok(lg.status === 200, 'the director books the deposit once', lg.json);
    ok((await ui('POST', `/api/queue/deposit/${encodeURIComponent(depId)}`, { action: 'log', amount: 75 })).status === 409, 'booking the same chain deposit again → 409', null, 'M1');
    ov = (await ui('GET', `${T}/overview`)).json;
    ok(BigInt(ov.cash.available.minor) <= BigInt(ov.cash.cleared.minor), 'available = cleared − reserved − committed; claims and pending never add to it', ov.cash.available, 'M8');

    console.log('\n[allocations]');
    const prop = await tw('POST', '/allocations/propose', {});
    const allocs = (await ui('GET', `${T}/allocations`)).json.allocations || [];
    ok(prop.status === 200 && allocs.length >= 2, 'allocations are proposed from cleared receipts (and v15 carried over)', prop.json);
    // Gross minus the provider's fee is split in full: GST to the tax reserve, the rest by policy.
    const off = allocs.filter((a) => a.grossMinor && a.shares && Object.values(a.shares).reduce((s, v) => s + BigInt(v), 0n) !== BigInt(a.grossMinor) - BigInt(a.feesMinor || 0));
    ok(allocs.length && !off.length, 'every allocation splits exactly what landed (gross − fee), GST to the tax reserve', off.map((a) => ({ gross: a.grossMinor, fee: a.feesMinor, shares: a.shares })), 'M4');
    const gstAl = allocs.find((a) => a.taxMinor && a.taxMinor !== '0');
    ok(gstAl && gstAl.shares.taxReserve === gstAl.taxMinor && gstAl.shares.tradingCapital === '0', 'GST collected goes to the tax reserve; trading capital gets nothing until its cap is set', gstAl && { tax: gstAl.taxMinor, shares: gstAl.shares }, 'M3');

    console.log('\n[transfers: approval, limits, kill switch, evidence]');
    const operBook = BigInt((await acctView(OPER.id)).book.minor);
    await tw('POST', `/accounts/${OPER.id}/balance`, { balance: (Number(operBook + 200000n) / 100).toFixed(2), evidence: 'CommBank statement today' });
    await tw('POST', '/reconcile', { accountId: OPER.id });
    ex = (await ui('GET', `${T}/reconciliations`)).json.exceptions.filter((e) => e.status === 'open' && e.kind === 'balance-difference' && e.accountId === OPER.id);
    ok(ex.length === 1 && ex[0].differenceMinor === '200000', 'reconciliation finds A$2,000 in the bank the books do not know about', ex, 'O4');
    const cl = await tw('POST', `/exceptions/${ex[0].id}/classify`, { as: 'owner_capital', evidence: 'owner loan, CBA ref OL-1' });
    ok(cl.status === 200 && (await acctView(OPER.id)).difference.minor === '0', 'classified as owner capital with evidence: books and bank agree', cl.json);
    const balsBefore = (await ui('GET', `${T}/journal/balances`)).json.balances;
    const tA = (await tw('POST', '/transfers', { kind: 'internal', sourceAccountId: OPER.id, destinationAccountId: TAXR.id, amount: '600', purpose: 'GST set-aside' })).json.transfer;
    ok(tA && tA.status === 'awaiting_approval' && tA.policy.risk === 'medium', 'an A$600 internal transfer waits for approval', tA && { s: tA.status, p: tA.policy });
    ok((await tw('POST', `/transfers/${tA.id}/submit`, {})).status === 409, 'submitting before approval → 409', null, 'T1');
    const ck = key();
    const body = { kind: 'internal', sourceAccountId: OPER.id, destinationAccountId: TAXR.id, amount: '50', purpose: 'idempotency check' };
    const i1 = await tw('POST', '/transfers', body, { 'Idempotency-Key': ck });
    const i2 = await tw('POST', '/transfers', body, { 'Idempotency-Key': ck });
    ok(i2.headers['idempotent-replay'] === 'true' && i2.json.transfer.id === i1.json.transfer.id, 'the same request with the same key is answered from the record, not re-run', i2.headers, 'T6');
    ok((await tw('POST', '/transfers', { ...body, amount: '51' }, { 'Idempotency-Key': ck })).status === 409, 'the same key with a different body → 409', null, 'T6');
    await tw('POST', `/transfers/${i1.json.transfer.id}/cancel`, { reason: 'test' });
    ok((await tw('POST', `/transfers/${tA.id}/approve`, {})).json.status === 'approved', 'the director approves (medium risk, quorum 1)');
    const s1 = (await tw('POST', `/transfers/${tA.id}/submit`, {})).json;
    const s2 = (await tw('POST', `/transfers/${tA.id}/submit`, {})).json;
    ok(s1.transfer.status === 'submitted_to_signer' && s2.duplicate === true && s2.transfer.signer.requestId === s1.transfer.signer.requestId, 'a second submit is the same hand-off, not a second payment', { a: s1.transfer.signer.requestId, b: s2.transfer.signer.requestId }, 'T6');
    ok(s1.transfer.signer.adapter === 'manual' && s1.transfer.signer.instructions.length > 0, 'the signer is you: YABBAI hands over instructions and holds no key', s1.transfer.signer, 'S5');
    ok((await tw('POST', `/transfers/${tA.id}/broadcast`, { ref: 'NPP-OUT-0001' })).json.status === 'broadcast', 'the bank reference is recorded');
    ok((await tw('POST', `/transfers/${tA.id}/broadcast`, { ref: 'NPP-OUT-0002' })).status === 409, 'a second, different reference for the same transfer → 409', null, 'T6');
    const noRc = await tw('POST', `/transfers/${tA.id}/attest`, { receipt: '' });
    ok(noRc.status === 422, 'settling without the bank receipt → 422', noRc.status, 'T7');
    const at = (await tw('POST', `/transfers/${tA.id}/attest`, { receipt: 'CBA-RCPT-77' })).json;
    ok(at.status === 'settled' && at.settlement.evidence.kind === 'director-attestation', 'settled on the bank receipt you attested', at.settlement, 'T7');
    const balsAfter = (await ui('GET', `${T}/journal/balances`)).json.balances;
    ok(revenueMinor(balsAfter) === revenueMinor(balsBefore), 'moving money between your own accounts does not change revenue', { before: revenueMinor(balsBefore).toString(), after: revenueMinor(balsAfter).toString() }, 'M5');

    const tB = (await tw('POST', '/transfers', { kind: 'internal', sourceAccountId: OPER.id, destinationAccountId: TAXR.id, amount: '950', purpose: 'big set-aside' })).json.transfer;
    ok(tB.policy.risk === 'high', 'A$950 is over the A$800 high-risk line');
    const selfA = await tw('POST', `/transfers/${tB.id}/approve`, {});
    ok(selfA.status === 403, 'the person who asked cannot be the first yes on a high-risk transfer', selfA.json, 'T4');
    const apB = await tw('POST', `/transfers/${tB.id}/approve`, {}, { ...APPROVER, ...(await otp('Approver')) });
    ok(apB.status === 200 && apB.json.status === 'awaiting_approval', 'the approver says yes (with their own code); one more needed', apB.json && apB.json.status, 'T4');
    ok((await tw('POST', `/transfers/${tB.id}/approve`, {})).json.status === 'approved', 'the director adds the second yes');
    const subB = await tw('POST', `/transfers/${tB.id}/submit`, {});
    ok(subB.status === 422 && subB.json.blockers.some((b) => /today's AUD limit/.test(b)), 'A$600 + A$950 today is over the A$1,500 daily limit → blocked at submit', subB.json, 'T3');
    await tw('POST', `/transfers/${tB.id}/cancel`, { reason: 'over limit' });
    const tC = (await tw('POST', '/transfers', { kind: 'internal', sourceAccountId: OPER.id, destinationAccountId: TAXR.id, amount: '1200', purpose: 'too big' })).json.transfer;
    ok(tC.policy.blockers.some((b) => /per-transfer limit/.test(b)), 'A$1,200 is over the per-transfer limit from the first check', tC.policy.blockers, 'T3');
    await tw('POST', `/transfers/${tC.id}/cancel`, { reason: 'over limit' });

    const tD = (await tw('POST', '/transfers', { kind: 'internal', sourceAccountId: OPER.id, destinationAccountId: TAXR.id, amount: '300', purpose: 'kill switch check' })).json.transfer;
    await tw('POST', `/transfers/${tD.id}/approve`, {});
    const kill = await req('POST', `${T}/kill-switch`, { engaged: true, reason: 'gate test' }, { 'X-Yabbai': '1', 'Idempotency-Key': key() });
    ok(kill.status === 200 && kill.json.engaged === true, 'anyone on the cockpit can pull the kill switch', kill.json, 'T5');
    const subD = await tw('POST', `/transfers/${tD.id}/submit`, {});
    ok(subD.status === 423 && /Kill switch/.test(subD.text), 'an approved transfer cannot be submitted while it is on', subD.json, 'T5');
    ok((await tw('POST', '/kill-switch', { engaged: false }, APPROVER)).status === 403, 'the approver cannot release it', null, 'T5');
    ok((await tw('POST', '/kill-switch', { engaged: false })).json.engaged === false, 'the director releases it (step-up)', null, 'T5');
    ok((await tw('POST', `/transfers/${tD.id}/submit`, {})).json.transfer.status === 'submitted_to_signer', 'after release the same transfer goes through', null, 'T5');
    await tw('POST', `/transfers/${tD.id}/cancel`, { reason: 'test only' });

    const destBody = { label: 'My personal CommBank', kind: 'bank', ownership: 'mine', bsb: '063000', accountNumber: '87654321', accountName: 'T BASHAM' };
    ok((await req('POST', `${T}/destinations`, { ...destBody, confirmedOutOfBand: true }, { 'X-Yabbai': '1', 'Idempotency-Key': key() })).status === 423, 'adding a destination needs the open vault', null, 'T2 S1');
    const noOob = await tw('POST', '/destinations', destBody);
    ok(noOob.status === 422, 'a destination needs your out-of-band check of its details', noOob.status, 'T2');
    const dest = (await tw('POST', '/destinations', { ...destBody, confirmedOutOfBand: true })).json;
    ok(dest.status === 'cooling' && Date.parse(dest.coolingUntil) > Date.now() + 23 * 3600000, 'a new destination cools off for 24 hours', dest, 'T2');
    const masked = (await bearer('GET', `${T}/destinations`)).json.destinations[0];
    ok(masked.accountNumber === '••321', 'without the vault the account number is masked', masked, 'S4');
    const tP = (await tw('POST', '/transfers', { kind: 'drawing', sourceAccountId: OPER.id, destinationId: dest.id, amount: '200', purpose: 'Owner pay November' })).json.transfer;
    ok(tP.policy.risk === 'high' && tP.policy.warnings.some((w) => /First payment/.test(w)), 'the first payment to a new destination is high risk', tP.policy, 'T2');
    await tw('POST', `/transfers/${tP.id}/approve`, {}, { ...APPROVER, ...(await otp('Approver')) });
    await tw('POST', `/transfers/${tP.id}/approve`, {});
    const subP = await tw('POST', `/transfers/${tP.id}/submit`, {});
    ok(subP.status === 422 && subP.json.blockers.some((b) => /added recently/.test(b)), 'approved owner pay to the cooling destination is blocked at submit', subP.json, 'T2');
    await tw('POST', `/transfers/${tP.id}/cancel`, { reason: 'cooling' });

    console.log('\n[chain transfers: confirmations, forks, failures]');
    await tw('POST', '/reconcile', { accountId: HOTA.id });
    const hx = (await ui('GET', `${T}/reconciliations`)).json.exceptions.find((e) => e.status === 'open' && e.kind === 'balance-difference' && e.accountId === HOTA.id);
    await tw('POST', `/exceptions/${hx.id}/classify`, { as: 'owner_capital', evidence: 'opening SOL' });
    const solT = async (amount, purpose) => {
      const t = (await tw('POST', '/transfers', { kind: 'internal', sourceAccountId: HOTA.id, destinationAccountId: COLDA.id, amount, maxFee: '0.00001', purpose })).json.transfer;
      await tw('POST', `/transfers/${t.id}/approve`, {});
      await tw('POST', `/transfers/${t.id}/submit`, {});
      return t;
    };
    const S1 = await solT('1', 'cold storage');
    const SIG1 = sig();
    const badRef = await tw('POST', `/transfers/${S1.id}/broadcast`, { ref: 'not-a-signature' });
    ok(badRef.status === 422, 'a chain transfer needs a real signature as its reference', badRef.status, 'T7');
    await tw('POST', `/transfers/${S1.id}/broadcast`, { ref: SIG1 });
    SOL.statuses[SIG1] = { confirmationStatus: 'confirmed', confirmations: 12, err: null };
    SOL.txs[SIG1] = txOf(HOT, COLD, 1e9);
    let v = (await tw('POST', `/transfers/${S1.id}/verify`, {})).json;
    ok(v.status === 'confirming' && v.confirmations === 12, 'seen on chain but not final: confirming, not settled', { s: v.status, c: v.confirmations }, 'T8 M8');
    SOL.statuses[SIG1] = null;
    v = (await tw('POST', `/transfers/${S1.id}/verify`, {})).json;
    ok(v.status === 'confirming' && /fork|replaced/.test(v.verification.problem || ''), 'gone from the chain after being seen: still confirming, flagged as a possible fork', v.verification, 'T8');
    SOL.statuses[SIG1] = { confirmationStatus: 'finalized', confirmations: null, err: null };
    v = (await tw('POST', `/transfers/${S1.id}/verify`, {})).json;
    ok(v.status === 'settled' && v.feeMinor === '5000' && v.settlement.evidence.kind === 'chain', 'finalized: settled on the chain evidence, network fee recorded', { s: v.status, fee: v.feeMinor, ev: v.settlement && v.settlement.evidence }, 'T7');
    ok((await tw('POST', `/transfers/${S1.id}/attest`, { receipt: 'trust me' })).status === 409, 'a chain transfer cannot be settled by attestation', null, 'T7');
    ok((await acctView(COLDA.id)).book.minor === '1000000000', 'Cold SOL book: 1 SOL');
    const S2 = await solT('0.5', 'wrong amount check');
    const SIG2 = sig();
    await tw('POST', `/transfers/${S2.id}/broadcast`, { ref: SIG2 });
    SOL.statuses[SIG2] = { confirmationStatus: 'finalized', confirmations: null, err: null };
    SOL.txs[SIG2] = txOf(HOT, COLD, 5e8, { got: 4e8 });
    v = (await tw('POST', `/transfers/${S2.id}/verify`, {})).json;
    ok(v.status === 'failed' && /received/.test(v.history.slice(-1)[0].note || ''), 'the chain shows 0.4 SOL arriving, not 0.5: failed, never settled', v.history && v.history.slice(-1), 'T7 T8');
    const S3 = await solT('0.25', 'failed on chain');
    const SIG3 = sig();
    await tw('POST', `/transfers/${S3.id}/broadcast`, { ref: SIG3 });
    SOL.statuses[SIG3] = { confirmationStatus: 'confirmed', confirmations: 3, err: { InstructionError: [0, 'Custom'] } };
    v = (await tw('POST', `/transfers/${S3.id}/verify`, {})).json;
    ok(v.status === 'failed', 'a transaction that failed on chain is failed here too', v.status, 'T8');
    const mm = (await tw('POST', '/transfers', { kind: 'internal', sourceAccountId: HOTA.id, destinationAccountId: OPER.id, amount: '1', purpose: 'mismatch' })).json.transfer;
    ok(mm.policy.blockers.some((b) => /holds AUD, not SOL/.test(b)) && mm.policy.blockers.some((b) => /Network mismatch/.test(b)), 'SOL cannot go to an AUD bank account: asset and network blockers', mm.policy.blockers, 'T7');
    await tw('POST', `/transfers/${mm.id}/cancel`, { reason: 'mismatch' });

    console.log('\n[reversal and rebuild]');
    const revd = (await tw('POST', `/transfers/${tA.id}/reverse`, { reason: 'bank returned it' })).json;
    const origTx = (await ui('GET', `${T}/journal/${at.settlement.journalTxId}`)).json;
    ok(revd.status === 'reversed' && origTx.id && origTx.reversed && revd.reversal.journalTxId !== origTx.id, 'a reversal is a new entry; the original stays, marked reversed', { orig: origTx.id, rev: revd.reversal }, 'M6');
    const rev2 = await tw('POST', `/journal/${origTx.id}/reverse`, { reason: 'again' });
    ok(rev2.status === 409, 'the same entry cannot be reversed twice', { s: rev2.status, b: rev2.json }, 'M6');
    txs = await allTx();
    ok(txs.length >= 15 && txs.every(balanced), `all ${txs.length} journal entries balance, per currency`, txs.filter((t) => !balanced(t)).map((t) => t.id), 'M4');
    const jv = (await ui('GET', `${T}/journal/verify`)).json;
    ok(jv.journal.ok && jv.rebuild.ok && jv.audit.ok, 'hash chains intact; every balance rebuilt from the journal file matches', jv, 'M7');
    const daily = (await ui('GET', `${T}/reconcile/daily`)).json;
    const opRow = daily.rows.find((r) => r.accountId === OPER.id);
    ok(opRow && ['opening', 'inflow', 'outflow', 'closing', 'observed', 'variance'].every((k) => k in opRow) && opRow.observedAt, 'daily report: opening, money in, money out, closing, observed and variance', opRow, 'O5');

    console.log('\n[agents and the outside]');
    const tools = await mcp('tools/list', {});
    const names = ((tools.rpc && tools.rpc.result && tools.rpc.result.tools) || []).map((t) => t.name);
    ok(names.length > 5 && !names.some((n) => /approve|transfer|sign|send|withdraw|kill|limit|destination|refund/i.test(n)), 'AI clients get no tool that approves, signs, moves money or changes controls', names, 'S5');
    const agentApprove = await bearer('POST', `${T}/transfers/${tP.id}/approve`, {}, { 'Idempotency-Key': key() });
    ok([423, 409].includes(agentApprove.status), 'the engine token alone (no vault) cannot approve anything', agentApprove.status, 'S5 S6');
    ok((await req('POST', `${T}/kill-switch`, { engaged: true }, { 'X-Yabbai': '1', Origin: 'https://evil.example', 'Idempotency-Key': key() })).status === 401, 'a page on another origin without the token → 401', null, 'S6');
    ok((await req('POST', `${T}/kill-switch`, { engaged: true }, { 'Idempotency-Key': key() })).status === 403, 'a state change without the cockpit header (CSRF) → 403', null, 'S6');
    ok((await req('GET', `${T}/overview`, undefined, { Origin: 'https://evil.example' })).status === 401, 'reading the treasury from another origin without the token → 401', null, 'S6');
    const brief = await ui('POST', '/api/brief', {});
    const last = await new Promise((resolve) => http.get(`http://127.0.0.1:${MOCK}/__last`, (r) => { let s = ''; r.on('data', (c) => (s += c)); r.on('end', () => resolve(s)); }).on('error', () => resolve('')));
    ok(brief.status === 200 && last.length > 50 && !last.includes(PHRASE) && !last.includes(WIF), 'the prompt sent to the model carries no phrase or key', { status: brief.status, sent: last.length }, 'S3');
    const sec = (await ui('GET', `${T}/secrets`)).json;
    ok(sec.count === 1 && sec.found[0].collection === 'ledger', 'the saved phrase is found in one v15 ledger note', sec, 'S3');
    const scrub = await tw('POST', '/secrets/scrub', {});
    ok(scrub.json.removed === 1 && (await ui('GET', `${T}/secrets`)).json.count === 0, 'the director removes it from the records (step-up)', scrub.json, 'S3');
    needs = (await ui('GET', `${T}/needs`)).json.needs.map((n) => n.key);
    ok(!needs.includes('secrets') && !needs.includes('vault') && !needs.includes('limits'), 'the needs list drops what is now configured', needs);

    console.log('\n[lockout survives a restart]');
    let locked = false;
    for (let i = 0; i < 7 && !locked; i++) locked = (await req('POST', '/api/v2/vault/unlock', { name: 'Approver', pin: '000000', code: '000000' }, { 'X-Yabbai': '1' })).status === 429;
    ok(locked, 'five wrong PINs lock the approver', null, 'S2');
    ok(script('v16-migrate.js', ['--data', DATA, '--run']).status !== 0, 'the migration script refuses to run while the engine is running');
    await stopEngine(proc);
    proc = await startEngine();
    const after = await req('POST', '/api/v2/vault/unlock', { name: 'Approver', pin: vault.people.Approver.pin, code: await otp('Approver').then((h) => h['X-Yabbai-Otp']) }, { 'X-Yabbai': '1' });
    ok(after.status === 429, 'after a restart the right PIN and code are still refused until the lock ends', after.json, 'S2');
    ok((await ui('GET', '/api/v2/vault/approvers')).status === 200, 'the director session survives the restart');

    console.log('\n[backup, drill and restore]');
    const bk = (await tw('POST', '/backup', { note: 'release gate' })).json;
    const balsAtBackup = (await ui('GET', `${T}/journal/balances`)).json.balances;
    const drill = (await tw('POST', `/backups/${bk.id}/verify`, {})).json;
    ok(drill.ok && drill.checks.every((c) => c.ok), 'the drill: every file hash, both chains, every balance rebuilt', drill.checks, 'S7');
    const inv7 = await invoice('Golf', 40, 0, ['bank']);
    await bankHook('bk-7', 40, inv7.number);
    const changed = (await ui('GET', `${T}/journal/balances`)).json.balances;
    ok(JSON.stringify(changed) !== JSON.stringify(balsAtBackup), 'money booked after the backup changes the balances');
    ok(script('v16-restore.js', [bk.id, '--yes', '--data', DATA]).status !== 0, 'a restore is refused while the engine is running', null, 'S7');
    await stopEngine(proc);
    const rs2 = script('v16-restore.js', [bk.id, '--yes', '--data', DATA]);
    ok(rs2.status === 0, 'restore with the engine stopped', (rs2.stdout + rs2.stderr).slice(-500), 'S7');
    proc = await startEngine();
    const balsRestored = (await ui('GET', `${T}/journal/balances`)).json.balances;
    ok(JSON.stringify(balsRestored) === JSON.stringify(balsAtBackup), 'after restore every balance equals the backup', null, 'S7');
    const jv2 = (await ui('GET', `${T}/journal/verify`)).json;
    const aud = (await ui('GET', `${T}/audit?limit=500`)).json;
    const audItems = aud.events || aud.items || aud;
    ok(jv2.journal.ok && jv2.rebuild.ok && jv2.audit.ok && Array.isArray(audItems) && audItems.some((a) => a.action === 'backup.restored'), 'audit history is back, intact, with the restore itself recorded', { jv2, n: Array.isArray(audItems) ? audItems.length : audItems }, 'S7');

    console.log('\n[step-up when the window is off]');
    await tw('POST', '/settings', { stepUpWindowSec: 0 }, await otp());
    ok((await tw('POST', '/destinations', { ...destBody, label: 'Second', accountNumber: '11223344', confirmedOutOfBand: true })).status === 428, 'with no step-up window, a destination needs a fresh code', null, 'T2');
    ok((await tw('POST', '/limits', { assets: { AUD: { perTransfer: 1000, daily: 1500, monthly: 10000, highRiskOver: 800 } } })).status === 428, 'and so do limits', null, 'T3');
    ok((await tw('POST', '/destinations', { ...destBody, label: 'Second', accountNumber: '11223344', confirmedOutOfBand: true }, await otp())).status === 200, 'with the code it goes through, and cools off', null, 'T2');
  } catch (e) {
    fail++;
    console.log(`  FAIL  test crashed: ${e.stack}`);
  } finally {
    await stopEngine(proc);
    ollama.kill();
    mocks.srv.close();
  }

  console.log('\n[nothing secret anywhere]');
  const preScrub = new Set();
  const bkRoot = path.join(DATA, 'backups');
  if (fs.existsSync(bkRoot)) for (const d of fs.readdirSync(bkRoot)) {
    try {
      if (/before v16-migrate/.test(JSON.parse(fs.readFileSync(path.join(bkRoot, d, 'manifest.json'), 'utf8')).note)) preScrub.add(path.join(bkRoot, d));
    } catch {}
  }
  const files = [];
  const walk = (dir) => {
    for (const f of fs.readdirSync(dir, { withFileTypes: true })) {
      const p = path.join(dir, f.name);
      if (f.isDirectory()) {
        if (!preScrub.has(p)) walk(p);
      } else files.push(p);
    }
  };
  walk(DATA);
  const NEEDLES = { phrase: PHRASE, wif: WIF, xprv: XPRV, solSecret: SOLSECRET };
  const hits = [];
  for (const f of files) {
    const s = fs.readFileSync(f, 'utf8');
    for (const [k, n] of Object.entries(NEEDLES)) if (s.includes(n)) hits.push(`${path.relative(DATA, f)}: ${k}`);
    if (!f.includes(`${path.sep}secrets${path.sep}`) && !f.endsWith('receive-secrets.json') && (s.includes(BANK_SECRET) || s.includes(PP_SECRET)) && /audit|journal|db\.json|backups/.test(f)) hits.push(`${path.relative(DATA, f)}: provider secret`);
  }
  ok(hits.length === 0, `no phrase or key in ${files.length} data files, logs, journal, audit or later backups`, hits, 'S3');
  const seen = SEEN.join('\n');
  ok(!Object.values(NEEDLES).some((n) => seen.includes(n)) && !seen.includes(BANK_SECRET) && !seen.includes(PP_SECRET) && !seen.includes(TOKEN), `no phrase, key, provider secret or engine token in ${SEEN.length} responses`, null, 'S3 S4');
  ok(!Object.values(NEEDLES).some((n) => LOG.includes(n)) && !LOG.includes(BANK_SECRET) && !LOG.includes(PP_SECRET), 'none in the engine log either', null, 'S3 S4');

  console.log('\n[in-process: what an agent cannot do]');
  await inProcess();

  console.log('\nSECTION 13 RELEASE GATE');
  let missing = 0;
  for (const [k, text] of Object.entries(GATES)) {
    const t = tally[k];
    const state = t.fail ? 'FAIL' : t.pass ? 'PASS' : 'NOT TESTED';
    if (!t.pass) missing++;
    console.log(`  ${state.padEnd(10)} ${k}  ${text}  (${t.pass} checks${t.fail ? `, ${t.fail} failed` : ''})`);
  }
  console.log(`\n${pass} passed, ${fail} failed${missing ? `, ${missing} gate lines without a passing check` : ''}`);
  try {
    fs.rmSync(DATA, { recursive: true, force: true });
  } catch {}
  process.exit(fail || missing ? 1 : 0);
}

// Library-level checks with an agent as the actor, on a separate data folder.
async function inProcess() {
  const D2 = fs.mkdtempSync(path.join(os.tmpdir(), 'yabbai16t-lib-'));
  const m2 = await startMocks();
  process.env.YABBAI_DATA = D2;
  process.env.YABBAI_SOL_RPC = `${m2.url}/rpc`;
  try {
    const store = require('../lib/store');
    store.load();
    const tstore = require('../lib/tstore');
    tstore.load();
    const audit = require('../lib/audit');
    audit.load();
    const journal = require('../lib/journal');
    journal.load();
    require('../lib/vault').load();
    const approvals = require('../lib/approvals');
    const risk = require('../lib/risk');
    const wallets = require('../lib/wallets');
    const transfers = require('../lib/transfers');
    const agent = { type: 'agent', id: 'mcp', label: 'AI client' };
    const status = (fn) => {
      try {
        fn();
        return 200;
      } catch (e) {
        return e.status || 500;
      }
    };
    const ap = approvals.request({ kind: 'allocation', targetId: 'x1', title: 'agent asks', summary: 'test', risk: 'high' }, agent);
    ok(!!ap.id, 'an agent can ask for approval');
    ok(status(() => approvals.decide(ap.id, 'approve', agent)) === 403, 'an agent cannot approve anything, its own request included', null, 'T4 S5');
    ok(status(() => risk.addDestination({ label: 'x', kind: 'payid', payId: 'a@b.co', confirmedOutOfBand: true }, agent)) === 403, 'an agent cannot add a destination', null, 'S5');
    ok(status(() => risk.setLimits({ assets: { AUD: { perTransfer: 1, daily: 1, monthly: 1, highRiskOver: 1 } } }, agent)) === 403, 'an agent cannot change limits', null, 'S5');
    risk.engage(agent, 'agent saw something odd');
    ok(tstore.state.killSwitch.engaged && status(() => risk.release(agent)) === 403, 'an agent can stop everything, never restart it', null, 'T5 S5');
    const SYS = { type: 'system', id: 'test', label: 'test' };
    const h = wallets.add({ kind: 'crypto_address', network: 'solana-mainnet', name: 'Hot', publicAddress: pub() }, SYS).account;
    const c = wallets.add({ kind: 'crypto_address', network: 'solana-mainnet', name: 'Cold', publicAddress: pub() }, SYS).account;
    const old = { id: 'tr_lost', kind: 'internal', status: 'broadcast', network: 'solana-mainnet', asset: 'SOL', amountMinor: '1000', sourceAccountId: h.id, destination: { accountId: c.id }, broadcast: { ref: sig(), at: new Date(Date.now() - 2 * 3600000).toISOString() }, history: [], createdAt: new Date().toISOString(), policy: { ok: true, blockers: [], warnings: [], risk: 'low' } };
    tstore.state.transfers.unshift(old);
    const out = await transfers.verify('tr_lost');
    ok(out.status === 'failed' && /never showed/.test(out.history.slice(-1)[0].note), 'never seen on chain an hour after broadcast: failed (dropped or replaced)', out.history.slice(-1), 'T8');
    tstore.flush && tstore.flush();
    journal.close && journal.close();
    audit.close && audit.close();
  } catch (e) {
    fail++;
    console.log(`  FAIL  in-process section crashed: ${e.stack}`);
  } finally {
    m2.srv.close();
    try {
      fs.rmSync(D2, { recursive: true, force: true });
    } catch {}
  }
}

main();
