'use strict';
// v15 suite: lead intake (Pancake / CSV / pasted tables / MCP), the oil desk journal and
// guardian, cross-origin rules for AI Studio, Render-style env.   node engine/test/smoke15.js
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');

const PORT = 7891;
const TOKEN = 'yb_test_token_0123456789abcdef';
const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'yabbai15-'));
const FIXTURE = path.join(DATA, 'desk-fixture.json');
let pass = 0;
let fail = 0;
const ok = (c, label, x) => (c ? (pass++, console.log(`  PASS  ${label}`)) : (fail++, console.log(`  FAIL  ${label}${x !== undefined ? ' → ' + JSON.stringify(x).slice(0, 500) : ''}`)));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function req(method, p, body, headers = {}) {
  return new Promise((resolve, reject) => {
    const data = body === undefined ? undefined : typeof body === 'string' ? body : JSON.stringify(body);
    const r = http.request({ host: '127.0.0.1', port: PORT, method, path: p, headers: { ...(data ? { 'Content-Type': 'application/json' } : {}), ...headers } }, (res) => {
      let s = '';
      res.on('data', (c) => (s += c));
      res.on('end', () => {
        let json = null;
        try {
          json = JSON.parse(s);
        } catch {}
        resolve({ status: res.statusCode, headers: res.headers, text: s, json });
      });
    });
    r.on('error', reject);
    if (data) r.write(data);
    r.end();
  });
}
const ui = (method, p, body) => req(method, p, body, method === 'GET' ? {} : { 'X-Yabbai': '1' });
const mcp = (tokenPath, method, params, id = 1) => req('POST', `/mcp/${tokenPath}`, { jsonrpc: '2.0', id, method, params });

function writeFixture(wti, brent) {
  fs.writeFileSync(FIXTURE, JSON.stringify({
    WTI: { price: wti, prevClose: 60, at: new Date().toISOString(), spark: [[Date.now() - 600000, 59.8], [Date.now(), wti]] },
    BRENT: { price: brent, prevClose: 64, at: new Date().toISOString() },
  }));
}

async function main() {
  writeFixture(61.5, 65.2);
  const env = { ...process.env, YABBAI_PORT: String(PORT), YABBAI_DATA: DATA, YABBAI_TOKEN: TOKEN, YABBAI_DESK_FIXTURE: FIXTURE, OLLAMA_URL: 'http://127.0.0.1:9' };
  delete env.PORT;
  delete env.RENDER;
  const proc = spawn(process.execPath, [path.join(__dirname, '..', 'server.js')], { env, stdio: ['ignore', 'pipe', 'pipe'] });
  let log = '';
  proc.stdout.on('data', (c) => (log += c));
  proc.stderr.on('data', (c) => (log += c));
  try {
    let up = false;
    for (let i = 0; i < 60 && !up; i++) {
      await sleep(150);
      up = await req('GET', '/healthz').then((r) => r.status === 200, () => false);
    }
    ok(up, 'engine boots and /healthz answers without a token');
    const hz = await req('GET', '/healthz');
    ok(hz.json && hz.json.version === require('../lib/util').VERSION && !('token' in hz.json), '/healthz reports the version and nothing else', hz.json);

    console.log('\n[front door]');
    const root = await req('GET', '/');
    ok(root.status === 302 && root.headers.location === '/studio/', '/ sends you to the deck (studio)', { status: root.status, loc: root.headers.location });
    const consolePage = await req('GET', '/console');
    ok(consolePage.status === 200 && /<html/i.test(consolePage.text), 'engine console still served at /console', consolePage.status);

    console.log('\n[cross-origin rules: AI Studio and everything else]');
    const evil = 'https://evil.example';
    const pre = await req('OPTIONS', '/api/state', undefined, { Origin: evil, 'Access-Control-Request-Method': 'GET', 'Access-Control-Request-Headers': 'authorization' });
    ok(pre.status === 204 && pre.headers['access-control-allow-origin'] === evil && !pre.headers['access-control-allow-credentials'], 'preflight from another origin is answered, never with credentials', pre.headers);
    const noTok = await req('GET', '/api/state', undefined, { Origin: evil });
    ok(noTok.status === 401, 'a foreign page on this machine gets 401 without the token (loopback trust does not apply)', noTok.status);
    const withTok = await req('GET', '/api/state', undefined, { Origin: evil, Authorization: `Bearer ${TOKEN}` });
    ok(withTok.status === 200 && withTok.headers['access-control-allow-origin'] === evil && withTok.json.version === require('../lib/util').VERSION, 'foreign origin with the bearer token reads state', withTok.status);
    const foreignPost = await req('POST', '/api/leads', { business: 'Cross Origin Co' }, { Origin: evil, Authorization: `Bearer ${TOKEN}`, 'X-Yabbai': '1' });
    ok(foreignPost.status === 200 && foreignPost.json.business === 'Cross Origin Co', 'foreign origin with bearer can write (CSRF is impossible without the token)', foreignPost.json);
    const foreignNoTok = await req('POST', '/api/leads', { business: 'Nope' }, { Origin: evil, 'X-Yabbai': '1' });
    ok(foreignNoTok.status === 401, 'foreign write without the token is refused', foreignNoTok.status);
    const local = await req('GET', '/api/state');
    ok(local.status === 200, 'same machine, no Origin: the cockpit still works without a token', local.status);
    const wrongBearer = await req('GET', '/api/state', undefined, { Origin: evil, Authorization: 'Bearer yb_wrong_token_0000000000' });
    ok(wrongBearer.status === 401, 'wrong bearer from a foreign origin is refused', wrongBearer.status);

    console.log('\n[lead intake]');
    const v14bug = await ui('POST', '/api/leads', { business: 'Smith & Co Lawyers', contact: 'hello@smithco.com.au' });
    ok(v14bug.json.contact === 'hello@smithco.com.au' && v14bug.json.name === '' && v14bug.json.channel === 'email', 'cockpit "Email / phone / handle" lands in contact, not in the name (v14 bug)', v14bug.json);
    const csv = [
      'Company Name,First Name,Last Name,Work Email,Job Title,City,Industry,Lead Score,Pancake ID,Signal',
      'Acme Plumbing,Jane,Doe,jane@acmeplumbing.com.au,Owner,Melbourne,Plumbing,0.82,pk_001,"Hiring 3 apprentices, site says ""call us"""',
      'Bright Dental,Sam,Lee,sam@brightdental.com.au,Practice Manager,Geelong,Dental,64,pk_002,Slow reply times in reviews',
      ',,,,,,,,,',
      ',Solo,Trader,solo@gmail.com,,Ballarat,,,pk_003,',
      ',,,,,,,,pk_004,no identity at all',
    ].join('\n');
    const imp = await ui('POST', '/api/leads/import', { text: csv, source: 'Pancake' });
    ok(imp.status === 200 && imp.json.added === 3 && imp.json.source === 'pancake', 'CSV export: 3 leads added (blank row dropped)', imp.json);
    ok(imp.json.skipped.length === 1 && /no business/.test(imp.json.skipped[0].reason), 'a row with no business, site, work email or person is skipped with the reason', imp.json.skipped);
    let st = (await ui('GET', '/api/state')).json;
    const acme = st.leads.find((l) => l.business === 'Acme Plumbing');
    ok(acme && acme.name === 'Jane Doe' && acme.contact === 'jane@acmeplumbing.com.au' && acme.score === 82 && acme.source === 'pancake' && acme.externalId === 'pk_001' && /apprentices/.test(acme.notes) && acme.title === 'Owner', 'columns mapped: name, email, title, 0.82 score → 82, source id, signal into notes', acme);
    const solo = st.leads.find((l) => l.name === 'Solo Trader');
    ok(solo && solo.business === 'Solo Trader', 'a freemail person with no company becomes their own account', solo);
    const again = await ui('POST', '/api/leads/import', { text: csv, source: 'pancake' });
    ok(again.json.added === 0 && again.json.duplicates === 3, 're-importing the same export adds nothing (3 duplicates)', again.json);
    const md = '| Company | Contact Name | Email | Website |\n|---|---|---|---|\n| Harbour Cafe | Mia Ross | mia@harbourcafe.com.au | harbourcafe.com.au |\n| Peak Physio | Tom Ng | tom@peakphysio.au | https://www.peakphysio.au |';
    const impMd = await ui('POST', '/api/leads/import', { text: md, source: 'claude-table' });
    ok(impMd.json.added === 2, 'a markdown table pasted from a chat imports (2 leads)', impMd.json);
    const nested = JSON.stringify({ data: [{ id: 'p-9', person: { name: 'Ava Tran', email: 'ava@northsidefit.com', title: 'Founder' }, company: { name: 'Northside Fitness', domain: 'northsidefit.com', industry: 'Fitness' }, signal: 'Opened a second gym' }] });
    const impJson = await ui('POST', '/api/leads/import', { text: nested, source: 'pancake' });
    st = (await ui('GET', '/api/state')).json;
    const ava = st.leads.find((l) => l.name === 'Ava Tran');
    ok(impJson.json.added === 1 && ava && ava.business === 'Northside Fitness' && ava.website === 'northsidefit.com' && ava.niche === 'Fitness', 'nested API JSON ({ data: [{ person, company }] }) maps', ava);
    const badJson = await ui('POST', '/api/leads/import', { text: '[{"company": "x",' });
    ok(badJson.status === 400 && /JSON/.test(badJson.json.error), 'broken JSON gets a plain explanation', badJson.json);
    const quietActivity = st.activity.filter((a) => /^Lead added: (Acme|Bright)/.test(a.text)).length;
    ok(quietActivity === 0 && st.activity.some((a) => /Imported 3 leads from pancake/.test(a.text)), 'bulk import writes one activity line, not one per lead', st.activity.slice(0, 5));

    console.log('\n[MCP for claude.ai: /mcp/<token>]');
    const listed = await mcp(TOKEN, 'tools/list', {});
    const names = (listed.json && listed.json.result && listed.json.result.tools || []).map((t) => t.name);
    ok(listed.status === 200 && names.includes('import_leads') && names.includes('list_leads') && names.includes('get_oil_desk'), 'MCP lists import_leads, list_leads, get_oil_desk', names);
    const call = await mcp(TOKEN, 'tools/call', { name: 'import_leads', arguments: { source: 'pancake', leads: [{ company: 'Coastal Roofing', name: 'Liam Hart', email: 'liam@coastalroofing.com.au', score: 91, id: 'pk_100', notes: 'Storm season, ads running' }, { company: 'Acme Plumbing', email: 'jane@acmeplumbing.com.au' }] } }, 2);
    const callOut = call.json && call.json.result && JSON.parse(call.json.result.content[0].text);
    ok(callOut && callOut.added === 1 && callOut.duplicates === 1, 'Pancake-style MCP import: 1 new, 1 duplicate by email', callOut);
    const listLeads = await mcp(TOKEN, 'tools/call', { name: 'list_leads', arguments: { source: 'pancake', limit: 3 } }, 3);
    const ll = listLeads.json && JSON.parse(listLeads.json.result.content[0].text);
    ok(ll && ll.total === 5 && ll.leads.length === 3 && ll.leads[0].business === 'Coastal Roofing', 'list_leads filters by source, newest first', ll);
    const badTok = await mcp('yb_not_the_token_000000000000', 'tools/list', {});
    ok(badTok.status === 401, 'wrong token in the connector URL is refused', badTok.status);
    const nested2 = await req('POST', `/mcp/${TOKEN}/extra`, {});
    ok(nested2.status !== 200, '/mcp/<token>/anything is not the MCP endpoint', nested2.status);

    console.log('\n[oil desk: live quotes, real-trade journal, guardian]');
    let desk = (await ui('GET', '/api/desk?force=1')).json;
    const wti = desk.instruments.find((q) => q.id === 'WTI');
    ok(wti.ok && wti.price === 61.5 && wti.source === 'test fixture' && wti.changePct === 2.5, 'WTI quote carries price, change and its source label', wti);
    ok(desk.broker.connected === false && /cannot place orders/.test(desk.broker.note), 'desk says plainly that no broker is connected', desk.broker);
    ok(desk.guard === null, 'no guardian numbers until the account size is set', desk.guard);
    const noTicket = await ui('POST', '/api/desk/trades', { instrument: 'WTI', side: 'long', lots: 1, entry: 61.2, stop: 60.7 });
    ok(noTicket.status === 400 && /ticket/.test(noTicket.json.error), 'a trade without a broker ticket is refused', noTicket.json);
    const badStop = await ui('POST', '/api/desk/trades', { instrument: 'WTI', side: 'long', lots: 1, entry: 61.2, stop: 61.9, ticket: 'SAB-1001' });
    ok(badStop.status === 400 && /below the entry/.test(badStop.json.error), 'a long with its stop above entry is refused', badStop.json);
    await ui('POST', '/api/desk/account', { name: 'SabioTrade', sizeUsd: 10000, dailyLossPct: 5, maxDrawdownPct: 10, riskPct: 1, bblPerLot: 100 });
    const t1 = await ui('POST', '/api/desk/trades', { instrument: 'WTI', side: 'long', lots: 1, entry: 61.2, stop: 60.7, target: 62.5, ticket: 'SAB-1001' });
    ok(t1.status === 200 && t1.json.bbl === 100 && t1.json.broker === 'SabioTrade', 'journal row: 1 lot = 100 bbl at the account default, broker filled in', t1.json);
    const dup = await ui('POST', '/api/desk/trades', { instrument: 'WTI', side: 'long', lots: 1, entry: 61.2, ticket: 'sab-1001' });
    ok(dup.status === 400 && /already in the journal/.test(dup.json.error), 'the same broker ticket cannot be logged twice', dup.json);
    desk = (await ui('GET', '/api/desk')).json;
    const open = desk.open[0];
    ok(open && open.openPnlUsd === 30 && open.riskUsd === 50 && open.markLive, 'open row marked to the live price: +US$30.00, risk to stop US$50.00', open);
    ok(desk.guard.dailyLimitUsd === 500 && desk.guard.headroomUsd === 500 && desk.guard.riskPerTradeUsd === 100 && desk.guard.equityUsd === 10030, 'guardian: daily limit 500, headroom 500, 1% risk = 100, equity 10,030', desk.guard);
    const s1 = await ui('POST', '/api/desk/trades', { instrument: 'BRENT', side: 'short', lots: 2, entry: 65.0, stop: 65.6, ticket: 'SAB-1002' });
    ok(s1.status === 200, 'short Brent journaled');
    writeFixture(60.6, 65.9);
    desk = (await ui('GET', '/api/desk?force=1')).json;
    const wtiRow = desk.open.find((t) => t.ticket === 'SAB-1001');
    const brentRow = desk.open.find((t) => t.ticket === 'SAB-1002');
    ok(wtiRow.alert && /through your stop/.test(wtiRow.alert) && brentRow.alert && /through your stop/.test(brentRow.alert), 'price through the stop flags the row (the desk never closes it on its own)', [wtiRow.alert, brentRow.alert]);
    ok(desk.guard.headroomUsd === 500 - 60 - 180, 'floating losses eat into today\'s headroom (500 − 60 − 180 = 260)', desk.guard);
    const close1 = await ui('POST', `/api/desk/trades/${t1.json.id}/close`, { exit: 60.7, fees: 3.5 });
    ok(close1.json.pnlUsd === -53.5 && close1.json.pnlSource === 'computed', 'close at the broker exit: (60.70 − 61.20) × 100 − 3.50 fees = −53.50', close1.json);
    const close2 = await ui('POST', `/api/desk/trades/${s1.json.id}/close`, { exit: 65.6, pnl: -121.4 });
    ok(close2.json.pnlUsd === -121.4 && close2.json.pnlSource === 'broker', 'the broker\'s own P&L figure wins when given', close2.json);
    desk = (await ui('GET', '/api/desk')).json;
    ok(desk.stats.closed === 2 && desk.stats.losses === 2 && desk.stats.realizedTodayUsd === -174.9 && desk.guard.headroomUsd === 325.1, 'stats and headroom from closed trades only: −174.90 today, 325.10 left', { stats: desk.stats, guard: desk.guard });
    const future = await ui('POST', '/api/desk/trades', { instrument: 'WTI', side: 'long', lots: 1, entry: 60, ticket: 'SAB-2000', openedAt: '2099-01-01T00:00:00Z' });
    ok(future.status === 400 && /future/.test(future.json.error), 'a fill time in the future is refused', future.json);
    st = (await ui('GET', '/api/state')).json;
    ok(st.desk && st.desk.stats.closed === 2 && st.loop.settings.paper === false, '/api/state carries the desk; crypto paper trading is off by default', { desk: !!st.desk, paper: st.loop.settings.paper });
    const ledgerTouched = st.ledger.some((e) => /oil|desk|SAB-/i.test(`${e.ref} ${e.note}`));
    ok(!ledgerTouched, 'journal P&L never enters the income ledger', st.ledger.slice(0, 3));

    console.log('\n[connect info]');
    const conn = (await ui('GET', '/api/connect')).json;
    ok(conn && conn.mcpConnectorUrl === `http://127.0.0.1:${PORT}/mcp/${TOKEN}`, 'connect info gives the claude.ai connector URL', conn && conn.mcpConnectorUrl);
  } finally {
    proc.kill('SIGTERM');
    await sleep(300);
  }
  if (fail) console.log('\n--- engine log ---\n' + log.slice(-3000));
  console.log(`\nv15: ${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
