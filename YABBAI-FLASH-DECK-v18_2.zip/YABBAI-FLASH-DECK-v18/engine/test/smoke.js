'use strict';
// End-to-end test: boots a mock Ollama + the real engine on spare ports and drives
// every surface the cockpit, Open WebUI and MCP clients use.  `node engine/test/smoke.js`
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const vault = require('./vault-helper');

const ENGINE = path.resolve(__dirname, '..', 'server.js');
const MOCK = path.resolve(__dirname, 'mock-ollama.js');
const PORT = 7871;
const MOCK_PORT = 11555;
const BASE = `http://127.0.0.1:${PORT}`;
const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'yabbai-test-'));
let pass = 0;
let fail = 0;
const procs = [];

function ok(cond, label, extra) {
  if (cond) {
    pass++;
    console.log(`  PASS  ${label}`);
  } else {
    fail++;
    console.log(`  FAIL  ${label}${extra !== undefined ? ' → ' + JSON.stringify(extra).slice(0, 300) : ''}`);
  }
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function raw(method, p, { headers = {}, body, host } = {}) {
  return new Promise((resolve, reject) => {
    const data = body === undefined ? undefined : typeof body === 'string' ? body : JSON.stringify(body);
    const req = http.request({ host: '127.0.0.1', port: PORT, method, path: p, headers: { ...(data ? { 'Content-Type': 'application/json' } : {}), ...(host ? { Host: host } : {}), ...headers } }, (res) => {
      let s = '';
      res.on('data', (c) => (s += c));
      res.on('end', () => {
        let json = null;
        try {
          json = JSON.parse(s);
        } catch {}
        resolve({ status: res.statusCode, headers: res.headers, text: s, json });
      });
    });
    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
}
let VAULT = {}; // v16: money writes carry the Director vault session
const ui = (method, p, body) => raw(method, p, { headers: method === 'GET' ? { ...VAULT } : { 'X-Yabbai': '1', ...VAULT }, body });
const sseEvents = (text) =>
  text
    .split('\n\n')
    .map((b) => b.split('\n').filter((l) => l.startsWith('data:')).map((l) => l.slice(5).trim()).join(''))
    .filter(Boolean);

function startEngine() {
  const p = spawn(process.execPath, [ENGINE], { env: { ...process.env, YABBAI_PORT: String(PORT), YABBAI_DATA: DATA, OLLAMA_URL: `http://127.0.0.1:${MOCK_PORT}`, OPENWEBUI_URL: 'http://127.0.0.1:18089' }, stdio: ['ignore', 'pipe', 'pipe'] });
  p.stdout.on('data', (d) => process.env.VERBOSE && process.stdout.write(`[engine] ${d}`));
  p.stderr.on('data', (d) => process.stdout.write(`[engine:err] ${d}`));
  procs.push(p);
  return p;
}
async function waitUp() {
  for (let i = 0; i < 80; i++) {
    try {
      const r = await raw('GET', '/api/health');
      if (r.status === 200) return true;
    } catch {}
    await sleep(150);
  }
  throw new Error('engine did not start');
}
async function until(fn, ms = 12000) {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) {
    const v = await fn();
    if (v) return v;
    await sleep(200);
  }
  return null;
}
const state = async () => (await ui('GET', '/api/state')).json;
const lastChat = () => new Promise((r) => http.get(`http://127.0.0.1:${MOCK_PORT}/__last`, (res) => { let s = ''; res.on('data', (c) => (s += c)); res.on('end', () => r(JSON.parse(s))); }));

async function marketsUnit() {
  console.log('\n[markets] spread maths with canned order books');
  const realFetch = global.fetch;
  const reply = (obj, status = 200) => ({ ok: status < 400, status, text: async () => JSON.stringify(obj) });
  global.fetch = async (url) => {
    const u = String(url);
    if (u.includes('binance')) return reply([{ symbol: 'BTCUSDT', bidPrice: '100000', askPrice: '100010' }, { symbol: 'SOLUSDT', bidPrice: '150.00', askPrice: '150.05' }]);
    if (u.includes('coinbase') && u.includes('BTC-USD')) return reply({ bid: '100200', ask: '100210' });
    if (u.includes('coinbase') && u.includes('SOL-USD')) return reply({ bid: '151.00', ask: '151.10' });
    if (u.includes('coinbase')) return reply({ message: 'NotFound' }, 404);
    if (u.includes('kraken')) return reply({ error: [], result: { XXBTZUSD: { a: ['100100', '1', '1'], b: ['100090', '1', '1'] }, SOLUSD: { a: ['149.50', '1', '1'], b: ['149.40', '1', '1'] } } });
    if (u.includes('coinspot')) return reply({ status: 'ok', prices: { btc: { bid: '152000', ask: '152100', last: '152050' }, sol: { bid: '230', ask: '231', last: '230.5' } } });
    if (u.includes('frankfurter')) return reply({ rates: { USD: 0.66 } });
    return reply({}, 500);
  };
  const markets = require('../lib/markets');
  const board = await markets.scan({ coins: ['BTC', 'ETH', 'SOL'], venues: { BINANCE: true, COINBASE: true, KRAKEN: true, COINSPOT: true }, fees: { BINANCE: 10, COINBASE: 60, KRAKEN: 40, COINSPOT: 10 }, bufferBps: 10, alertNetBps: 15, notionalAud: 1000 });
  global.fetch = realFetch;
  const sol = board.rows.find((r) => r.coin === 'SOL');
  const btc = board.rows.find((r) => r.coin === 'BTC');
  ok(board.rows[0].coin === 'SOL', 'rows sorted by net, SOL first', board.rows.map((r) => r.coin));
  ok(sol && sol.buyVenue === 'KRAKEN' && sol.sellVenue === 'COINSPOT', 'SOL: buy Kraken ask, sell CoinSpot bid (AUD×FX)', sol);
  ok(sol && Math.abs(sol.grossBps - 153.8) < 0.2 && Math.abs(sol.netBps - 93.8) < 0.2, 'SOL gross 153.8 / net 93.8 bps after 60 bps fees+buffer', sol);
  ok(btc && btc.buyVenue === 'BINANCE' && btc.sellVenue === 'COINSPOT' && Math.abs(btc.netBps - 1.0) < 0.2, 'BTC net ≈ +1.0 bps (gross 31 − 30)', btc);
  ok(board.verdict === 'OPPORTUNITY', 'verdict OPPORTUNITY when net ≥ alert', board.verdict);
  ok(!board.rows.find((r) => r.coin === 'ETH'), 'coin with no quotes is skipped, not invented');
  ok(board.venues.KRAKEN.ok && board.venues.COINSPOT.ok, 'Kraken renamed keys + CoinSpot parsed');
  const ostub = require('../lib/ollama');
  const sp = ostub.thinkSplitter();
  const parts = [...sp.push('<thi'), ...sp.push('nk>abc</th'), ...sp.push('ink>Hello'), ...sp.flush()];
  ok(parts.filter((p) => p.think).map((p) => p.text).join('') === 'abc' && parts.filter((p) => !p.think).map((p) => p.text).join('') === 'Hello', 'think-tag splitter survives tags split across chunks', parts);
}

(async () => {
  await marketsUnit();
  const mock = spawn(process.execPath, [MOCK], { env: { ...process.env, MOCK_PORT: String(MOCK_PORT) }, stdio: 'ignore' });
  procs.push(mock);
  await sleep(300);
  let engine = startEngine();
  await waitUp();
  const token = JSON.parse(fs.readFileSync(path.join(DATA, 'secret.json'), 'utf8')).token;
  const auth = { Authorization: `Bearer ${token}` };

  console.log('\n[boot & security]');
  const h = (await raw('GET', '/api/health')).json;
  ok(h.ok && h.ollama.up && h.model === 'hf.co/unsloth/Qwen3.5-9B-GGUF:Q4_K_M', 'health: engine up, Ollama up, HF model resolved', h);
  ok(h.openwebui.up === false, 'health: reports Open WebUI down honestly');
  ok((await raw('GET', '/console')).text.includes('YABBAI'), 'cockpit page served (v15: /console; / opens the deck)');
  ok((await raw('GET', '/classic/')).text.includes("fetch('/api/brain'"), 'classic v11 served with local-brain patch');
  ok((await raw('GET', '/api/state', { host: 'evil.example:7871' })).status === 401, 'foreign Host header refused (DNS-rebinding guard)');
  ok((await raw('POST', '/api/leads', { body: { business: 'X' } })).status === 403, 'state change without cockpit header refused (CSRF guard)');
  ok((await raw('GET', '/v1/models')).status === 401, 'gateway needs the token');
  ok((await raw('GET', '/v1/models', { headers: { Authorization: 'Bearer nope' } })).status === 401, 'wrong token refused');
  ok((await raw('GET', '/api/connect', { host: 'evil.example' })).status === 401, 'connect info never served to a foreign host');
  const login = await raw('GET', `/login?token=${encodeURIComponent(token)}`, { host: 'tunnel.example.com' });
  ok(login.status === 302 && /yb_token=/.test(login.headers['set-cookie'] || ''), 'remote login sets an HttpOnly cookie');
  ok((await raw('GET', '/api/state', { host: 'tunnel.example.com', headers: { Cookie: `yb_token=${encodeURIComponent(token)}` } })).status === 200, 'tunnel access works with the cookie');

  console.log('\n[ledger rules]');
  ok((await ui('POST', '/api/ledger', { amount: 49, source: 'product', ref: 'x-1' })).status === 423, 'v16: no money is recorded until the Director vault is set up');
  VAULT = await vault.open(ui);
  let st = await state();
  ok(st.settings.offers.length === 3 && st.forge.ideas.length === 8, 'defaults: 3 offers, 8 v11 product ideas queued');
  const noRef = await ui('POST', '/api/ledger', { amount: 49, source: 'product' });
  ok(noRef.status === 400 && /ref is required/.test(noRef.json.error), 'income without a reference is refused', noRef.json);
  ok((await ui('POST', '/api/ledger', { amount: 49, source: 'product', ref: 'https://gumroad.com/r/abc', agent: 'forge', note: 'AOS sale' })).status === 200, 'income with a receipt is logged');
  ok((await ui('POST', '/api/ledger', { amount: -10, source: 'cost', note: 'domain' })).status === 200, 'cost logged without a reference');
  st = await state();
  ok(st.ledgerTotals.all === 39 && st.ledgerTotals.byAgent.forge === 49, 'totals: A$39 net, A$49 attributed to Forge', st.ledgerTotals);
  ok((await ui('GET', '/api/ledger.csv')).text.includes('gumroad.com/r/abc'), 'CSV export');

  console.log('\n[Closer agent]');
  const lead = (await ui('POST', '/api/leads', { business: 'Smith & Co Lawyers', niche: 'family law', location: 'Richmond VIC', offerId: 'capital-colony' })).json;
  ok(lead.stage === 'new' && lead.offerId === 'capital-colony', 'lead added');
  await ui('POST', '/api/agents/closer/run', {});
  const draft = await until(async () => (await state()).outbox.find((d) => d.leadId === lead.id));
  ok(draft && draft.subject.startsWith('mock') && draft.status === 'draft', 'Closer wrote a draft for the lead', draft);
  let lc = await lastChat();
  ok(lc.think === false && lc.format && lc.format.required.includes('message'), 'Closer used a JSON schema with thinking off', { think: lc.think });
  ok(/Capital Colony/.test(lc.messages[1].content) && /Smith & Co Lawyers/.test(lc.messages[1].content), 'prompt carried the offer and the lead');
  await ui('POST', `/api/outbox/${draft.id}`, { status: 'sent' });
  st = await state();
  ok(st.leads.find((l) => l.id === lead.id).stage === 'sent', 'marking sent advances the lead');
  const won = await ui('POST', `/api/leads/${lead.id}/won`, { amount: 97, ref: 'INV-0001' });
  ok(won.status === 200 && won.json.entry.agent === 'closer', 'won lead lands in the ledger, credited to Closer');

  console.log('\n[Forge agent]');
  await ui('POST', '/api/agents/forge/run', {});
  const kit = await until(async () => (await state()).forge.kits[0]);
  ok(kit && kit.content.title && kit.content.price_aud === 49, 'Forge built a kit', kit && kit.content);
  ok(kit && fs.existsSync(path.join(DATA, 'forge', kit.file)), 'kit saved as Markdown in data/forge');
  ok(kit && (await ui('GET', `/api/forge/kits/${kit.id}/md`)).text.includes('## Ship checklist'), 'kit download includes the ship checklist');
  ok((await ui('PATCH', `/api/forge/kits/${kit.id}`, { status: 'listed', listingUrl: 'https://gumroad.com/l/x' })).json.status === 'listed', 'kit marked listed');

  console.log('\n[Scout agent — sandbox has no exchange access]');
  await ui('POST', '/api/agents/scout/run', {});
  const b = await until(async () => (await state()).board, 20000);
  ok(b && b.verdict === 'OFFLINE' && b.rows.length === 0, 'unreachable feeds → OFFLINE board, no invented prices', b && b.verdict);
  ok(b && (await state()).briefs.length === 0, 'no brief written from an offline board');

  console.log('\n[cockpit chat]');
  let r = await ui('POST', '/api/chat', { message: 'hello there', persona: 'director' });
  let ev = sseEvents(r.text).map((x) => JSON.parse(x));
  const meta = ev.find((e) => e.type === 'meta');
  ok(meta && meta.threadId && ev.some((e) => e.type === 'token') && ev.some((e) => e.type === 'done'), 'chat streams tokens', ev.slice(0, 3));
  lc = await lastChat();
  ok(lc.messages[0].role === 'system' && lc.messages.some((m) => /LIVE STATE/.test(m.content)), 'Director gets the live state');
  ok(/A\$136\.00/.test(lc.messages.map((m) => m.content).join('\n')), 'live state shows verified A$136 (49 − 10 + 97)');
  const thread = (await ui('GET', `/api/threads/${meta.threadId}`)).json;
  ok(thread.messages.length === 2 && thread.messages[1].role === 'assistant', 'thread saved on disk');
  r = await ui('POST', '/api/chat', { message: 'think please', threadId: meta.threadId, think: true });
  ev = sseEvents(r.text).map((x) => JSON.parse(x));
  ok(ev.some((e) => e.type === 'thinking'), 'Think first streams reasoning separately');
  r = await ui('POST', '/api/chat', { message: 'tagtest', persona: 'lite' });
  ev = sseEvents(r.text).map((x) => JSON.parse(x));
  const vis = ev.filter((e) => e.type === 'token').map((e) => e.text).join('');
  ok(vis === 'Visible answer.' && ev.filter((e) => e.type === 'thinking').map((e) => e.text).join('') === 'inner reasoning', '<think> tags split out of visible text', vis);
  lc = await lastChat();
  ok(!lc.messages.some((m) => m.role === 'system'), 'Plain model persona sends no context');

  console.log('\n[OpenAI gateway for Open WebUI]');
  const models = (await raw('GET', '/v1/models', { headers: auth })).json;
  ok(models.data.length === 5 && models.data.some((m) => m.id === 'yabbai-director' && m.name), 'lists Director, Scout, Closer, Forge, Lite', models.data.map((m) => m.id));
  r = await raw('POST', '/v1/chat/completions', { headers: auth, body: { model: 'yabbai-director', stream: true, messages: [{ role: 'user', content: 'hi' }] } });
  let chunks = sseEvents(r.text);
  ok(chunks[chunks.length - 1] === '[DONE]', 'stream ends with [DONE]');
  let parsed = chunks.filter((c) => c !== '[DONE]').map((c) => JSON.parse(c));
  ok(parsed[0].choices[0].delta.role === 'assistant' && parsed.some((c) => c.choices[0]?.delta?.content), 'OpenAI chunk format with content deltas');
  ok(parsed[parsed.length - 1].choices[0].finish_reason === 'stop', 'finish_reason stop');
  lc = await lastChat();
  ok(lc.messages.some((m) => m.role === 'system' && /LIVE STATE/.test(m.content)), 'gateway injects live state');
  r = await raw('POST', '/v1/chat/completions', { headers: auth, body: { model: 'yabbai-closer', messages: [{ role: 'user', content: 'hi' }] } });
  ok(r.json.object === 'chat.completion' && r.json.choices[0].message.content.length > 0 && r.json.usage.total_tokens === 342, 'non-streaming response + usage', r.json);
  await raw('POST', '/v1/chat/completions', { headers: auth, body: { model: 'yabbai-director', messages: [{ role: 'user', content: '### Task:\nGenerate a concise title' }] } });
  lc = await lastChat();
  ok(!lc.messages.some((m) => m.role === 'system') && lc.think === false, 'Open WebUI background tasks skip the heavy context');
  r = await raw('POST', '/v1/chat/completions', { headers: auth, body: { model: 'yabbai-scout', stream: true, reasoning_effort: 'high', messages: [{ role: 'user', content: 'go' }] } });
  ok(sseEvents(r.text).some((c) => c.includes('reasoning_content')), 'reasoning_effort → streamed reasoning_content');
  const toolsDef = [{ type: 'function', function: { name: 'list_drafts', description: 'x', parameters: { type: 'object', properties: { limit: { type: 'integer' } } } } }];
  r = await raw('POST', '/v1/chat/completions', { headers: auth, body: { model: 'yabbai-director', stream: true, tools: toolsDef, messages: [{ role: 'user', content: 'please use a tool' }] } });
  parsed = sseEvents(r.text).filter((c) => c !== '[DONE]').map((c) => JSON.parse(c));
  const tc = parsed.find((c) => c.choices[0]?.delta?.tool_calls);
  ok(tc && tc.choices[0].delta.tool_calls[0].function.name === 'list_drafts' && typeof tc.choices[0].delta.tool_calls[0].function.arguments === 'string', 'tool calls pass through in OpenAI format');
  ok(parsed[parsed.length - 1].choices[0].finish_reason === 'tool_calls', 'finish_reason tool_calls');
  await raw('POST', '/v1/chat/completions', { headers: auth, body: { model: 'yabbai-director', tools: toolsDef, messages: [{ role: 'user', content: 'x' }, { role: 'assistant', content: '', tool_calls: [{ id: 'call_1', type: 'function', function: { name: 'list_drafts', arguments: '{"limit":2}' } }] }, { role: 'tool', tool_call_id: 'call_1', content: '{"drafts":[]}' }] } });
  lc = await lastChat();
  ok(lc.messages.some((m) => m.role === 'tool' && m.tool_name === 'list_drafts') && lc.messages.some((m) => m.tool_calls && m.tool_calls[0].function.arguments.limit === 2), 'tool results map back to Ollama format');

  console.log('\n[OpenAPI tool server]');
  const spec = (await raw('GET', '/openapi.json', { headers: auth })).json;
  const ops = Object.values(spec.paths).flatMap((p) => Object.values(p).map((o) => o.operationId));
  ok(spec.openapi === '3.1.0' && ops.length === 13, '13 tools described (v15 adds import_leads, list_leads, get_oil_desk; v16 adds get_treasury, read-only)', ops);
  fs.writeFileSync(path.join(DATA, 'openapi.json'), JSON.stringify(spec));
  ok((await raw('GET', '/tools/snapshot', { headers: auth })).json.verified.allTime === 136, 'get_money_snapshot returns verified totals');
  ok((await raw('POST', '/tools/ledger', { headers: auth, body: { amount: 10, source: 'other' } })).status === 400, 'log_income without ref → 400 with reason');
  const reported = await raw('POST', '/tools/ledger', { headers: auth, body: { amount: 25, source: 'product', ref: 'gumroad-r-77' } });
  ok(reported.status === 200 && reported.json.claim && reported.json.claim.status === 'pending' && !reported.json.entry, 'v16: income an AI client reports is a claim waiting for the director, not money', reported.json);
  ok((await raw('GET', '/tools/snapshot', { headers: auth })).json.verified.allTime === 136, 'the reported income is not counted');
  ok((await raw('POST', '/tools/leads', { headers: auth, body: { business: 'Joe’s Plumbing', niche: 'plumbing' } })).json.lead.business === 'Joe’s Plumbing', 'add_lead via tool');
  ok((await raw('GET', '/tools/outbox?limit=3', { headers: auth })).status === 200, 'list_drafts via query params');

  console.log('\n[MCP endpoint]');
  const rpc = (body) => raw('POST', '/mcp', { headers: { ...auth, Accept: 'application/json, text/event-stream' }, body });
  r = await rpc({ jsonrpc: '2.0', id: 1, method: 'initialize', params: { protocolVersion: '2025-06-18', capabilities: {}, clientInfo: { name: 't', version: '1' } } });
  ok(r.json.result.protocolVersion === '2025-06-18' && r.json.result.capabilities.tools, 'initialize');
  ok((await rpc({ jsonrpc: '2.0', method: 'notifications/initialized' })).status === 202, 'notification → 202');
  r = await rpc({ jsonrpc: '2.0', id: 2, method: 'tools/list' });
  ok(r.json.result.tools.length === 13 && r.json.result.tools.every((t) => t.inputSchema && t.inputSchema.type === 'object') && !r.json.result.tools.some((t) => /approve|transfer|payout|sign|withdraw/i.test(t.name)), 'tools/list (no tool can approve, transfer or sign)');
  r = await rpc({ jsonrpc: '2.0', id: 3, method: 'tools/call', params: { name: 'log_income', arguments: { amount: 5, source: 'other' } } });
  ok(r.json.result.isError === true, 'tool error reported as isError, not a crash');
  ok((await rpc({ jsonrpc: '2.0', id: 4, method: 'nope' })).json.error.code === -32601, 'unknown method → -32601');
  ok((await raw('GET', '/mcp', { headers: auth })).status === 405, 'GET /mcp → 405 (stateless server)');

  console.log('\n[models, brain, settings, doctor]');
  r = await ui('POST', '/api/brain', { prompt: 'brief me' });
  ok(JSON.parse(r.json.content[0].text).assessment, 'classic v11 brain gets Anthropic-shaped JSON');
  r = await ui('POST', '/api/model/pull', { model: 'hf.co/unsloth/Qwen3.5-4B-GGUF:UD-Q4_K_XL' });
  ev = sseEvents(r.text).map((x) => JSON.parse(x));
  ok(ev.some((e) => e.type === 'progress' && e.total) && ev[ev.length - 1].type === 'done', 'pull streams progress');
  ok((await ui('POST', '/api/model/pull', { model: 'bad name; rm -rf' })).status === 400, 'bad model name refused');
  ok((await ui('POST', '/api/model/select', { model: 'hf.co/unsloth/Qwen3.5-4B-GGUF:UD-Q4_K_XL' })).status === 200, 'switch active model');
  ok((await raw('GET', '/api/health')).json.model === 'hf.co/unsloth/Qwen3.5-4B-GGUF:UD-Q4_K_XL', 'engine now uses the selected model');
  await ui('POST', '/api/model/select', { model: 'hf.co/unsloth/Qwen3.5-9B-GGUF:Q4_K_M' });
  ok((await ui('POST', '/api/settings', { numCtx: 9999 })).status === 400, 'odd context size refused');
  ok((await ui('POST', '/api/settings', { numCtx: 16384, signoff: 'Thomas' })).json.numCtx === 16384, 'settings saved');
  const doc = (await ui('GET', '/api/doctor?warm=1')).json;
  const gpu = doc.checks.find((c) => c.name === 'GPU offload');
  ok(gpu && gpu.ok && /100%/.test(gpu.detail), 'doctor measures GPU offload', doc.checks);

  console.log('\n[persistence across restart]');
  engine.kill('SIGTERM');
  await sleep(600);
  engine = startEngine();
  await waitUp();
  st = await state();
  ok(st.ledger.length === 3 && st.leads.length === 2 && st.forge.kits.length === 1 && st.settings.signoff === 'Thomas', 'ledger, leads, kits and settings survive a restart');
  ok(JSON.parse(fs.readFileSync(path.join(DATA, 'secret.json'), 'utf8')).token === token, 'token is stable across restarts');

  console.log(`\n${pass} passed, ${fail} failed · data dir ${DATA}`);
  fs.writeFileSync(path.join(__dirname, '.last-token'), token);
  for (const p of procs) p.kill();
  process.exit(fail ? 1 : 0);
})().catch((e) => {
  console.error(e);
  for (const p of procs) p.kill();
  process.exit(1);
});
