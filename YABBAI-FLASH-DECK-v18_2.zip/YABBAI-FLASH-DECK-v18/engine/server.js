'use strict';
// YABBAI LOCAL — engine entry point. Zero npm dependencies: `node engine/server.js`.
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const U = require('./lib/util');
const store = require('./lib/store');
const ollama = require('./lib/ollama');
const markets = require('./lib/markets');
const agents = require('./lib/agents');
const ops = require('./lib/ops');
const P = require('./lib/prompts');
const gateway = require('./lib/gateway');
const tools = require('./lib/tools');
const secretguard = require('./lib/secretguard');
const enginelock = require('./lib/enginelock');
const brains = require('./lib/brains');
const money = require('./lib/money');
const loop = require('./lib/loop');
const queue = require('./lib/queue');
const invoices = require('./lib/invoices');
const paypage = require('./lib/paypage');
const leadimport = require('./lib/leadimport');
const desk = require('./lib/desk');
const broker = require('./lib/broker');
// v16 treasury: the Director vault, the journal, the control plane.
const vault = require('./lib/vault');
const tstore = require('./lib/tstore');
const audit = require('./lib/audit');
const journal = require('./lib/journal');
const wallets = require('./lib/wallets');
const treasury = require('./lib/treasury');
const transfers = require('./lib/transfers');
const reconcile = require('./lib/reconcile');
const bookkeeper = require('./lib/bookkeeper');
const treasuryApi = require('./lib/treasury-api');
// v18: the operations store, the event bus, the agent runtime, the first workflow and /api/v1.
const opsstore = require('./lib/opsstore');
const events = require('./lib/events');
const agentops = require('./lib/agentops');
const salesflow = require('./lib/salesflow');
const apiV1 = require('./lib/api-v1');

const PORT = Number(process.env.YABBAI_PORT || process.env.PORT || 7860);
// On a host such as Render (PORT / RENDER set) the engine listens on every
// interface; on a laptop it stays on loopback unless YABBAI_HOST says otherwise.
const HOST = process.env.YABBAI_HOST || (process.env.RENDER || process.env.PORT ? '0.0.0.0' : '127.0.0.1');
const PUBLIC_URL = String(process.env.YABBAI_PUBLIC_URL || process.env.RENDER_EXTERNAL_URL || '').replace(/\/+$/, '');
const OWUI_URL = String(process.env.OPENWEBUI_URL || 'http://127.0.0.1:8080').replace(/\/+$/, '');
const PUBLIC = path.join(__dirname, 'public');
const SECRET_FILE = path.join(U.DATA_DIR, 'secret.json');
const INSTALL_FILE = path.join(U.DATA_DIR, 'install.json');
const STARTED = Date.now();

const RECOMMENDED = [
  { model: 'hf.co/unsloth/Qwen3.5-9B-GGUF:Q4_K_M', label: 'Qwen3.5 9B · Q4_K_M', size: '5.7 GB', fit: '8 GB GPUs (RTX 5050 / 4060 / 3070) and 16 GB Macs', note: 'Best all-rounder for 8 GB of VRAM' },
  { model: 'hf.co/unsloth/Qwen3.5-9B-GGUF:UD-Q4_K_XL', label: 'Qwen3.5 9B · Unsloth Dynamic 4-bit', size: '≈6 GB', fit: '8 GB GPUs with a little headroom', note: 'Slightly sharper, slightly heavier' },
  { model: 'hf.co/unsloth/Qwen3.5-4B-GGUF:UD-Q4_K_XL', label: 'Qwen3.5 4B', size: '≈3 GB', fit: '4–6 GB GPUs, 8 GB Macs, CPU-only', note: 'Fastest; lighter writing' },
  { model: 'hf.co/unsloth/Qwen3.6-27B-GGUF:UD-Q4_K_XL', label: 'Qwen3.6 27B', size: '≈17 GB', fit: '20 GB+ VRAM or 32 GB+ Macs', note: 'Strongest; too big for 8 GB cards' },
  { model: 'qwen3.5:9b', label: 'Qwen3.5 9B (Ollama library copy)', size: '6.6 GB', fit: 'Fallback if a HuggingFace GGUF will not load', note: 'Same model, packaged by Ollama' },
];

// ── secret token: guards the gateway, tool server, MCP and remote access ──
function loadToken() {
  // A host can pin the token (Render: YABBAI_TOKEN, generated in its dashboard).
  const pinned = String(process.env.YABBAI_TOKEN || '').trim();
  if (pinned.length >= 20) return pinned;
  let s = U.readJsonFile(SECRET_FILE, null);
  if (!s || typeof s.token !== 'string' || s.token.length < 20) {
    s = { token: `yb_${crypto.randomBytes(24).toString('base64url')}`, createdAt: U.iso() };
    U.writeFileAtomic(SECRET_FILE, JSON.stringify(s, null, 2));
  }
  return s.token;
}

// ── model resolution ─────────────────────────────────────────
let tagsCache = { at: 0, ok: false, models: [], error: '' };
async function installed(force = false) {
  if (!force && Date.now() - tagsCache.at < 30000) return tagsCache;
  try {
    const models = await ollama.tags();
    tagsCache = { at: Date.now(), ok: true, models, error: '' };
  } catch (err) {
    tagsCache = { at: Date.now(), ok: false, models: [], error: err.message };
  }
  return tagsCache;
}

async function resolveModel() {
  const { models } = await installed();
  const names = models.map((m) => m.name || m.model);
  if (!names.length) return null;
  const install = U.readJsonFile(INSTALL_FILE, {}) || {};
  for (const want of [store.db.settings.model, process.env.YABBAI_MODEL, install.model]) {
    if (!want) continue;
    const hit = names.find((n) => n === want || n === `${want}:latest` || n.replace(/:latest$/, '') === want);
    if (hit) return hit;
  }
  return names.find((n) => /qwen/i.test(n)) || names[0];
}

// ── security ────────────────────────────────────────────────
function isLoopback(req) {
  const a = req.socket.remoteAddress || '';
  return a === '127.0.0.1' || a === '::1' || a === '::ffff:127.0.0.1';
}
function hostIsLocal(req) {
  return /^(localhost|127\.0\.0\.1|\[::1\])(:\d+)?$/i.test(String(req.headers.host || ''));
}
function bearer(req) {
  const m = /^Bearer\s+(.+)$/i.exec(String(req.headers.authorization || ''));
  return m ? m[1].trim() : '';
}
function cookie(req, name) {
  const m = new RegExp(`(?:^|;\\s*)${name}=([^;]+)`).exec(String(req.headers.cookie || ''));
  return m ? decodeURIComponent(m[1]) : '';
}
const tokenOk = (t) => U.timingSafeEqualStr(t, TOKEN);
// A page on another origin (AI Studio, a deployed copy of the studio) is never
// trusted by where it runs: it must carry the token as a bearer header. That keeps
// any other website open in the same browser from driving the local engine.
function isForeign(req) {
  const origin = req.headers.origin;
  if (!origin) return false;
  const host = String(req.headers.host || '');
  return origin !== `http://${host}` && origin !== `https://${host}`;
}
// The cockpit is trusted on this machine; anywhere else (e.g. through a tunnel) needs the token.
const uiAllowed = (req) =>
  isForeign(req) ? tokenOk(bearer(req)) : (isLoopback(req) && hostIsLocal(req)) || tokenOk(cookie(req, 'yb_token')) || tokenOk(bearer(req));
const machineAllowed = (req) => tokenOk(bearer(req));

// CORS: any origin may ask; only a valid bearer token gets an answer (uiAllowed /
// machineAllowed). Credentials are never allowed cross-origin, so the cockpit
// cookie never rides along with a foreign request.
function corsFor(req) {
  const origin = String(req.headers.origin || '');
  if (!origin) return {};
  return {
    'Access-Control-Allow-Origin': origin,
    'Access-Control-Allow-Headers': 'Authorization, Content-Type, X-Yabbai, X-Yabbai-Vault, X-Yabbai-Otp, Idempotency-Key, Mcp-Session-Id, MCP-Protocol-Version',
    'Access-Control-Expose-Headers': 'Idempotent-Replay',
    'Access-Control-Allow-Methods': 'GET, POST, PATCH, DELETE, OPTIONS',
    'Access-Control-Max-Age': '600',
    Vary: 'Origin',
  };
}

// ── static files (whitelist) ────────────────────────────────
const STATIC = {
  '/console': ['index.html', 'text/html; charset=utf-8'],
  '/index.html': ['index.html', 'text/html; charset=utf-8'],
  '/app.js': ['app.js', 'text/javascript; charset=utf-8'],
  '/v13.js': ['v13.js', 'text/javascript; charset=utf-8'],
  '/receive.js': ['receive.js', 'text/javascript; charset=utf-8'],
  '/favicon.svg': ['favicon.svg', 'image/svg+xml'],
  '/classic': ['classic/index.html', 'text/html; charset=utf-8'],
  '/classic/': ['classic/index.html', 'text/html; charset=utf-8'],
};
function serveStatic(res, pathname) {
  const hit = STATIC[pathname];
  if (!hit) return false;
  const file = path.join(PUBLIC, hit[0]);
  if (!fs.existsSync(file)) return U.sendText(res, 404, 'Not found'), true;
  res.writeHead(200, { 'Content-Type': hit[1], 'Cache-Control': 'no-cache', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer' });
  fs.createReadStream(file).pipe(res);
  return true;
}

// ── STUDIO: the React cockpit, served from public/studio ────
// Same origin as the API, so the bundle never needs a CORS story. The engine
// token is injected ONLY when the request is loopback + local Host: a tunnelled
// visitor must supply their own token, or they could drive the ledger.
const STUDIO_DIR = path.join(PUBLIC, 'studio');
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.map': 'application/json; charset=utf-8',
};
function studioAsset(p) {
  const rel = p.replace(/^\/studio\/?/, '');
  const file = path.resolve(STUDIO_DIR, rel || 'index.html');
  if (!file.startsWith(path.resolve(STUDIO_DIR))) return null; // traversal refused
  return file;
}
function serveStudio(req, res, p, { injectToken }) {
  if (!fs.existsSync(STUDIO_DIR)) {
    return U.sendText(res, 404, 'The studio bundle is not built yet. In the app folder run: npm install && npm run build:studio', 'text/plain; charset=utf-8');
  }
  let file = studioAsset(p);
  const reqExt = path.extname(p).toLowerCase();
  const wantsHtml = !reqExt || p.endsWith('/');
  // A missing asset is a 404 — never index.html. Serving HTML as JavaScript is
  // how you get "Unexpected token '<'" instead of a readable failure.
  if (!wantsHtml && (!file || !fs.existsSync(file))) {
    return U.sendText(res, 404, 'Not found');
  }
  if (!file || !fs.existsSync(file) || wantsHtml) file = path.join(STUDIO_DIR, 'index.html');
  if (!fs.existsSync(file)) return U.sendText(res, 404, 'Studio bundle missing index.html');
  const ext = path.extname(file).toLowerCase();
  const headers = {
    'Content-Type': MIME[ext] || 'application/octet-stream',
    'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=31536000, immutable',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
  };
  if (ext !== '.html') {
    res.writeHead(200, headers);
    return fs.createReadStream(file).pipe(res);
  }
  let html = fs.readFileSync(file, 'utf8');
  if (injectToken) {
    const cfg = { base: '', token: TOKEN, model: `yabbai-${store.db.settings.brains?.chat === 'hf' ? 'hf' : 'director'}` };
    const payload = JSON.stringify(cfg).replace(/</g, '\\u003c');
    html = html.replace('</head>', `<script>window.__YABBAI_CFG__=${payload};</script></head>`);
  }
  res.writeHead(200, headers);
  return res.end(html);
}

// ── cockpit state ───────────────────────────────────────────
// What a screen may see of the settings: no PIN hash, no webhook secret, no API key.
function publicSettings() {
  const out = U.maskSecrets(store.db.settings);
  out.vault = { legacyPin: money.hasLegacyPin() };
  return out;
}
const publicReceive = () => U.maskSecrets(invoices.cfg());
// A short treasury line for the deck header (the full view is /api/v2/treasury/overview).
function treasuryBrief() {
  try {
    const o = treasury.overview();
    const pending = require('./lib/approvals').list({ status: 'pending' }).length;
    return { currency: o.currency, available: o.cash.available, cleared: o.cash.cleared, reserved: o.cash.reserved.display, pending: o.cash.pending.display, needs: o.needs.length, killSwitch: o.killSwitch.engaged, approvalsPending: pending };
  } catch (e) {
    return { error: e.message };
  }
}

// v18: what is waiting in the operations layer (the full view is /api/v1).
function opsBrief() {
  try {
    const s = opsstore.raw();
    const all = (c) => Object.values(s[c]);
    return { proposalsWaiting: all('proposals').filter((p) => p.status === 'awaiting_approval').length, needsAttention: all('workflowRuns').filter((r) => r.status === 'needs_attention').length, deadLetters: Object.keys(s.deadLetters).length, tasksOpen: all('tasks').filter((t) => !['completed', 'cancelled'].includes(t.status)).length };
  } catch (e) {
    return { error: e.message };
  }
}
function uiState() {
  const db = store.db;
  const t = P.ledgerTotals(db.ledger);
  return {
    version: U.VERSION,
    settings: publicSettings(),
    agents: agents.publicState(),
    queue: agents.state.queue.map((j) => j.id),
    snapshot: ops.snapshot(),
    board: db.scout.boards[0] || null,
    history: db.scout.boards.slice(0, 48).map((b) => ({ at: b.at, net: b.best ? b.best.netBps : null })).reverse(),
    briefs: db.scout.briefs.slice(0, 12),
    alerts: db.scout.alerts.slice(0, 12),
    leads: db.leads,
    outbox: db.outbox.slice(0, 150),
    forge: db.forge,
    ledger: db.ledger,
    ledgerTotals: t,
    activity: db.activity.slice(0, 120),
    openwebuiUrl: OWUI_URL,
    dataDir: U.DATA_DIR,
    queue: queue.items(),
    pools: money.pools(),
    spine: money.spine(),
    mrr: money.mrr(),
    vault: money.vaultStatus(),
    treasury: treasuryBrief(),
    ops: opsBrief(),
    loop: { settings: db.settings.loop, state: db.loopState, paper: loop.paperSummary() },
    solana: { address: db.settings.solana.address, balanceSol: db.solanaState.balanceSol, priceAud: db.solanaState.priceAud, lastScanAt: db.solanaState.lastScanAt, error: db.solanaState.error, baselined: db.solanaState.baselined },
    desk: desk.cached(),
    deposits: db.deposits.slice(0, 40),
    invoices: db.invoices.slice(0, 200),
    payments: db.payments.slice(0, 200),
    claims: db.claims.slice(0, 100),
    unmatched: db.unmatched.slice(0, 100),
    statements: db.statements.slice(0, 20),
    receive: { summary: invoices.summary(), settings: publicReceive(), paypal: invoices.paypalInfo() },
    payouts: db.payouts.slice(0, 60),
    allocations: db.allocations.slice(0, 60),
    followups: db.followups.slice(0, 60),
    replies: db.replies.slice(0, 60),
    findings: db.findings.filter((f) => f.status === 'open').concat(db.findings.filter((f) => f.status !== 'open').slice(0, 20)),
    deep: { jobs: db.deep.jobs.slice(0, 30) },
    brains: { ...db.settings.brains, hf: brains.hfTokenInfo() },
    brief: db.brief,
  };
}

async function health() {
  const [ver, model, owui] = await Promise.all([ollama.version(), resolveModel(), U.fetchJson(`${OWUI_URL}/health`, { timeout: 1500 })]);
  return {
    ok: true,
    version: U.VERSION,
    uptimeSec: Math.round((Date.now() - STARTED) / 1000),
    ollama: { up: !!ver, version: ver, url: ollama.BASE },
    model,
    openwebui: { up: owui.ok, url: OWUI_URL },
    autopilot: store.db.settings.autopilot,
  };
}

const NUM_CTX = [2048, 4096, 8192, 12288, 16384, 24576, 32768, 65536];
function patchSettings(p = {}) {
  const s = store.db.settings;
  const str = (v, max) => String(v ?? '').slice(0, max);
  if ('numCtx' in p) {
    const n = Number(p.numCtx);
    if (!NUM_CTX.includes(n)) throw Object.assign(new Error(`numCtx must be one of ${NUM_CTX.join(', ')}`), { status: 400 });
    s.numCtx = n;
  }
  if ('temperature' in p) s.temperature = U.clamp(Number(p.temperature) || 0, 0, 1.5);
  if ('directorNotes' in p) s.directorNotes = str(p.directorNotes, 4000);
  if ('signoff' in p) s.signoff = str(p.signoff, 80);
  if ('autopilot' in p) s.autopilot = !!p.autopilot;
  if ('minScore' in p) s.minScore = U.clamp(Number(p.minScore) || 0, 0, 100);
  if ('offers' in p) {
    if (!Array.isArray(p.offers) || p.offers.length > 12) throw Object.assign(new Error('offers must be a list of up to 12'), { status: 400 });
    const seen = new Set();
    s.offers = p.offers
      .map((o) => ({
        id: U.slug(o.id || o.name, 40),
        name: str(o.name, 160),
        audience: str(o.audience, 300),
        promise: str(o.promise, 600),
        price: str(o.price, 200),
        proof: str(o.proof, 600),
        cta: str(o.cta, 200),
        link: str(o.link, 300),
      }))
      .filter((o) => o.name && !seen.has(o.id) && seen.add(o.id));
  }
  if (p.scout && typeof p.scout === 'object') {
    const sc = s.scout;
    const q = p.scout;
    if (Array.isArray(q.coins)) sc.coins = q.coins.map((c) => String(c).toUpperCase()).filter((c) => markets.ALL_COINS.includes(c));
    if (q.venues && typeof q.venues === 'object') for (const v of Object.keys(sc.venues)) if (v in q.venues) sc.venues[v] = !!q.venues[v];
    if (q.fees && typeof q.fees === 'object') for (const v of Object.keys(sc.fees)) if (v in q.fees) sc.fees[v] = U.clamp(Number(q.fees[v]) || 0, 0, 500);
    if ('bufferBps' in q) sc.bufferBps = U.clamp(Number(q.bufferBps) || 0, 0, 500);
    if ('alertNetBps' in q) sc.alertNetBps = U.clamp(Number(q.alertNetBps) || 15, 1, 2000);
    if ('notionalAud' in q) sc.notionalAud = U.clamp(Number(q.notionalAud) || 1000, 10, 10000000);
  }
  store.save();
  U.bus.emit('event', { type: 'changed', what: 'settings' });
  return s;
}

function trimHistory(messages, budgetChars) {
  const out = [];
  let used = 0;
  for (let i = messages.length - 1; i >= 0; i--) {
    const m = messages[i];
    const len = (m.content || '').length + 20;
    if (out.length && used + len > budgetChars) break;
    out.unshift({ role: m.role, content: m.content || '' });
    used += len;
  }
  return out;
}

// ── chat (cockpit) ──────────────────────────────────────────
async function chatStream(req, res, body) {
  const message = String(body.message || '').slice(0, 200000);
  if (!message.trim()) return U.sendJson(res, 400, { error: 'message is required' });
  const role = ['director', 'scout', 'closer', 'forge', 'lite'].includes(body.persona) ? body.persona : 'director';
  const brain = ['local', 'hf'].includes(body.brain) ? body.brain : store.db.settings.brains.chat || 'local';
  const model = brain === 'hf' ? store.db.settings.brains.hfModel : await resolveModel();
  if (!model) return U.sendJson(res, 503, { error: 'No local model is reachable — start Ollama (START-YABBAI) or pull a model in the Brains tab.' });
  if (brain === 'hf' && !brains.hfToken()) return U.sendJson(res, 400, { error: 'Add your Hugging Face token in the Brains tab first.' });
  let thread = body.threadId ? store.threads.get(body.threadId) : null;
  if (body.threadId && !thread) return U.sendJson(res, 404, { error: 'Thread not found' });
  if (!thread) thread = store.threads.create(role);
  thread.persona = role;

  thread.messages.push({ role: 'user', content: message, at: U.iso() });
  if (thread.title === 'New chat') thread.title = message.replace(/\s+/g, ' ').slice(0, 60);
  store.threads.save(thread);

  const ctx = body.context !== false && role !== 'lite';
  const system = ctx ? P.personaSystem(role, store.db, { model, agentsState: agents.publicState() }) : [];
  const numCtx = Number(store.db.settings.numCtx) || 8192;
  const budget = Math.max(4000, numCtx * 3 * 0.7 - system.join('').length);
  const messages = [...system.map((content) => ({ role: 'system', content })), ...trimHistory(thread.messages, budget)];

  const ctrl = new AbortController();
  res.on('close', () => {
    if (!res.writableFinished) ctrl.abort();
  });
  U.sseStart(res);
  U.sseSend(res, { type: 'meta', threadId: thread.id, title: thread.title, model, context: ctx });
  agents.chatStart();
  let content = '';
  let thinking = '';
  try {
    const out = await brains.chat({
      brain,
      messages,
      think: !!body.think,
      options: { num_ctx: numCtx, temperature: Number(store.db.settings.temperature) || 0.6 },
      signal: ctrl.signal,
      onDelta: (d) => {
        if (d.thinking) {
          thinking += d.thinking;
          U.sseSend(res, { type: 'thinking', text: d.thinking });
        }
        if (d.content) {
          content += d.content;
          U.sseSend(res, { type: 'token', text: d.content });
        }
      },
    });
    thread.messages.push({ role: 'assistant', content: out.content, thinking: out.thinking || undefined, at: U.iso(), model, stats: out.stats });
    store.threads.save(thread);
    U.sseSend(res, { type: 'done', stats: out.stats });
    res.end();
  } catch (err) {
    if (ctrl.signal.aborted) {
      if (content) {
        thread.messages.push({ role: 'assistant', content, thinking: thinking || undefined, at: U.iso(), model, stopped: true });
        store.threads.save(thread);
      }
      return;
    }
    U.sseSend(res, { type: 'error', message: err.message });
    res.end();
  } finally {
    agents.chatEnd();
  }
}

// ── model manager ───────────────────────────────────────────
async function modelInfo() {
  const [ver, tags, running, active] = await Promise.all([ollama.version(), installed(true), ollama.ps(), resolveModel()]);
  return {
    ollama: { up: !!ver, version: ver, url: ollama.BASE, error: tags.ok ? null : tags.error },
    active,
    selected: store.db.settings.model || null,
    installed: tags.models.map((m) => ({ name: m.name || m.model, size: m.size, family: m.details?.family, params: m.details?.parameter_size, quant: m.details?.quantization_level, modifiedAt: m.modified_at })),
    running,
    recommended: RECOMMENDED,
    install: U.readJsonFile(INSTALL_FILE, null),
    numCtx: store.db.settings.numCtx,
  };
}

const MODEL_NAME = /^[A-Za-z0-9._\-/:]{2,200}$/;

async function pullStream(req, res, body) {
  const model = String(body.model || '').trim();
  if (!MODEL_NAME.test(model)) return U.sendJson(res, 400, { error: 'Model name looks wrong. Example: hf.co/unsloth/Qwen3.5-9B-GGUF:Q4_K_M' });
  U.sseStart(res);
  store.activity('model', `Pulling ${model}`);
  try {
    await ollama.pull(model, (evt) => U.sseSend(res, { type: 'progress', status: evt.status, total: evt.total || 0, completed: evt.completed || 0 }));
    await installed(true);
    if (!store.db.settings.model) store.db.settings.model = model;
    store.save();
    store.activity('model', `Model ready: ${model}`);
    U.sseSend(res, { type: 'done', model });
  } catch (err) {
    store.activity('error', `Pull failed for ${model}: ${err.message}`);
    U.sseSend(res, { type: 'error', message: err.message });
  }
  res.end();
}

async function doctor(warm) {
  const checks = [];
  const add = (name, ok, detail, fix) => checks.push({ name, ok, detail, fix: ok ? null : fix || null });
  const major = Number(process.versions.node.split('.')[0]);
  add('Node.js', major >= 18, `v${process.versions.node}`, 'Install Node.js 18 or newer (the installer does this).');
  const inOneDrive = /onedrive/i.test(U.DATA_DIR);
  add('Data folder', !inOneDrive, U.DATA_DIR, 'Move the YABBAI folder out of OneDrive (e.g. C:\\yabbai) — sync locks break saves.');
  const ver = await ollama.version();
  add('Ollama', !!ver, ver ? `v${ver} at ${ollama.BASE}` : `not reachable at ${ollama.BASE}`, 'Start Ollama (START-YABBAI does it) or reinstall it from ollama.com.');
  const model = ver ? await resolveModel() : null;
  add('Local model', !!model, model || 'none installed', 'Model tab → pull hf.co/unsloth/Qwen3.5-9B-GGUF:Q4_K_M');
  if (warm && model) {
    try {
      const out = await ollama.chat({ model, messages: [{ role: 'user', content: 'Reply with exactly: ready' }], think: false, options: { num_ctx: Number(store.db.settings.numCtx) || 8192, num_predict: 12 } });
      const running = (await ollama.ps()).find((m) => m.name === model);
      const pct = running ? running.gpuPct : null;
      add('Model runs', true, `${out.stats?.tokensPerSec ?? '?'} tokens/s, load ${out.stats?.loadMs ?? '?'} ms`);
      add('GPU offload', pct === null ? false : pct >= 90, pct === null ? 'unknown' : `${pct}% of the model is on the GPU`, pct === 0 ? 'Ollama is running on CPU: update the NVIDIA driver and Ollama, then restart Ollama. On laptops set ollama.exe to "High performance" in Windows Graphics settings.' : 'Part of the model spills to system RAM: lower the context size (Model tab) or use the 4B model for speed.');
    } catch (err) {
      add('Model runs', false, err.message, /architecture/i.test(err.message) ? 'Update Ollama (winget upgrade Ollama.Ollama) or switch to qwen3.5:9b in the Model tab.' : 'Check the Ollama window/logs.');
    }
  }
  const owui = await U.fetchJson(`${OWUI_URL}/health`, { timeout: 2000 });
  add('Open WebUI', owui.ok, owui.ok ? OWUI_URL : `not reachable at ${OWUI_URL}`, 'Run START-YABBAI (first start downloads it, which takes a few minutes).');
  const board = store.db.scout.boards[0];
  if (board) {
    const up = Object.entries(board.venues).filter(([, v]) => v.ok).map(([k]) => k);
    add('Exchange feeds', up.length >= 2, `${up.length ? up.join(', ') : 'none'} answering (last scan ${P.ago(board.at)})`, 'Check your internet connection; Scout retries on its schedule.');
  }
  return { checks, ok: checks.every((c) => c.ok) };
}

function connectInfo(req) {
  const base = PUBLIC_URL || `http://127.0.0.1:${PORT}`;
  return {
    token: TOKEN,
    openwebuiUrl: OWUI_URL,
    openaiBase: `${base}/v1`,
    openapiUrl: `${base}/openapi.json`,
    mcpUrl: `${base}/mcp`,
    // For clients that take only a URL (a claude.ai custom connector). Keep it secret.
    mcpConnectorUrl: `${base}/mcp/${TOKEN_PATH}`,
    toolServer: {
      type: 'openapi',
      url: base,
      path: 'openapi.json',
      auth_type: 'bearer',
      key: TOKEN,
      config: { enable: true },
      info: { id: 'yabbai', name: 'YABBAI', description: 'Money snapshot, spread board, leads, drafts, product kits, verified ledger' },
    },
    mcpClientConfig: { mcpServers: { yabbai: { type: 'streamable-http', url: `${base}/mcp`, headers: { Authorization: `Bearer ${TOKEN}` } } } },
    remoteLogin: `${req.headers['x-forwarded-proto'] || 'http'}://${req.headers.host}/login?token=${encodeURIComponent(TOKEN)}`,
  };
}

// ── router ──────────────────────────────────────────────────
function err(status, message) {
  return Object.assign(new Error(message), { status });
}

// The address a browser uses to reach this engine (for redirects back from a provider).
function publicOrigin(req) {
  if (PUBLIC_URL) return PUBLIC_URL;
  const proto = req.headers['x-forwarded-proto'] === 'https' ? 'https' : 'http';
  return `${proto}://${req.headers.host || `127.0.0.1:${PORT}`}`;
}
const callbackPage = (ok, text) =>
  `<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>YABBAI · cTrader</title><body style="font:15px system-ui,sans-serif;background:#020814;color:#e2e8f0;display:grid;place-items:center;min-height:100vh;margin:0;padding:16px"><div style="max-width:420px"><h1 style="font-size:18px;color:${ok ? '#14F195' : '#F5A623'}">${ok ? 'cTrader connected' : 'cTrader sign-in did not finish'}</h1><p>${text.replace(/[<>&"]/g, (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;' })[c])}</p><p><a style="color:#f5c518" href="/studio/#desk">Back to the oil desk</a></p></div></body>`;

function refuseSecrets(body, where) {
  const hit = secretguard.scan(body);
  if (!hit) return;
  audit.record(vault.actor(), 'secret.refused', where, { kind: hit.kind, field: hit.path });
  throw secretguard.refusal(hit.kind, hit.path);
}

async function route(req, res) {
  const url = new URL(req.url, 'http://localhost');
  const p = url.pathname;
  const method = req.method;
  const seg = p.split('/').filter(Boolean); // ['api', ...] / ['pay', token, ...]

  // Machine routes: Open WebUI and other clients (bearer token)
  // /mcp/<token>: the same MCP server for clients that cannot send headers (a
  // claude.ai custom connector takes only a URL). The token in the path is the key.
  let pathToken = '';
  if (seg[0] === 'mcp' && seg[1] && !seg[2]) {
    try {
      pathToken = decodeURIComponent(seg[1]);
    } catch {
      pathToken = '';
    }
  }
  const machine = p === '/openapi.json' || p.startsWith('/v1/') || p.startsWith('/tools/') || p === '/mcp' || !!pathToken;
  if (machine) {
    // Machine clients are agents: they never carry a vault session.
    const ctx = vault.context.getStore();
    if (ctx) Object.assign(ctx, { token: '', otp: '', actor: { type: 'agent', id: p.startsWith('/v1/') ? 'gateway' : 'mcp', label: 'Connected AI client' } });
    const cors = corsFor(req);
    for (const [k, v] of Object.entries(cors)) res.setHeader(k, v);
    if (method === 'OPTIONS') return res.writeHead(204), res.end();
    if (!machineAllowed(req) && !(pathToken && pathTokenOk(pathToken))) return U.sendJson(res, 401, { error: 'Missing or wrong bearer token (see data/secret.json or cockpit → Settings → Connect)' });
    if (p === '/openapi.json' && method === 'GET') return U.sendJson(res, 200, tools.openapi(PUBLIC_URL || `http://127.0.0.1:${PORT}`));
    if (p === '/v1/models' && method === 'GET') return U.sendJson(res, 200, gateway.listModels());
    if (p === '/v1/chat/completions' && method === 'POST') return gateway.chatCompletions(req, res, await U.readJson(req, 32 * 1024 * 1024));
    if (p === '/mcp' || pathToken) {
      if (method !== 'POST') return U.sendJson(res, 405, { error: 'Use POST (stateless Streamable HTTP; no SSE stream)' }, { Allow: 'POST' });
      return tools.handleMcp(req, res, await U.readJson(req));
    }
    if (p.startsWith('/tools/')) {
      const body = method === 'GET' ? null : await U.readJson(req);
      if (await tools.handleRoute(req, res, method, p, url.searchParams, body)) return;
    }
    return U.sendJson(res, 404, { error: 'Not found' });
  }

  // Remote login: sets a cookie so the cockpit works through a tunnel
  if (p === '/login' && method === 'GET') {
    if (!tokenOk(url.searchParams.get('token'))) return U.sendText(res, 401, 'Wrong token.');
    const secure = req.headers['x-forwarded-proto'] === 'https' ? '; Secure' : '';
    res.writeHead(302, { 'Set-Cookie': `yb_token=${encodeURIComponent(TOKEN)}; Path=/; HttpOnly; SameSite=Strict; Max-Age=2592000${secure}`, Location: '/' });
    return res.end();
  }

  // ── PUBLIC: the pay page and the rails that settle it ──
  // No cockpit login here by design — a payer has no token. Each route is scoped
  // to one invoice token and can do exactly one thing.
  if (seg[0] === 'pay' && seg[1]) {
    if (method === 'GET' && !seg[2]) {
      const inv = invoices.getByToken(seg[1]);
      if (inv.status !== 'paid') {
        try {
          await invoices.requote(inv);
        } catch (e) {
          U.log('[pay] requote failed:', e.message);
        }
      }
      return U.sendText(res, 200, paypage.page(invoices.publicView(seg[1])), 'text/html; charset=utf-8', {
        'Referrer-Policy': 'no-referrer',
        'X-Frame-Options': 'DENY',
        'Content-Security-Policy': "default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; form-action 'self'; base-uri 'none'",
      });
    }
    if (method === 'POST' && seg[2] === 'paypal') {
      const inv = invoices.getByToken(seg[1]);
      if (inv.status === 'paid') throw err(400, 'That invoice is already paid');
      const proto = req.headers['x-forwarded-proto'] === 'https' ? 'https' : 'http';
      return U.sendJson(res, 200, await invoices.paypalPay(inv, { origin: `${proto}://${req.headers.host}` }));
    }
    if (method === 'POST' && seg[2] === 'paypal-return') {
      const inv = invoices.getByToken(seg[1]);
      const orderId = String(url.searchParams.get('order') || '').trim();
      if (!/^[A-Z0-9]{8,32}$/i.test(orderId)) throw err(400, 'Missing PayPal order id');
      const out = await invoices.paypalReturn(inv, orderId);
      return U.sendJson(res, 200, { ok: true, status: out.invoice.status });
    }
    if (method === 'POST' && seg[2] === 'claim') {
      const body = await U.readJson(req, 32 * 1024);
      refuseSecrets(body, '/pay/claim');
      return U.sendJson(res, 200, invoices.claim(seg[1], body));
    }
    return U.sendText(res, 404, 'Not found');
  }

  // ── PUBLIC: provider webhooks. Signature checked before a cent is credited. ──
  if (seg[0] === 'webhooks' && method === 'POST') {
    const raw = await U.readBody(req, 512 * 1024);
    if (seg[1] === 'paypal') {
      let event;
      try {
        event = JSON.parse(raw || '{}');
      } catch {
        throw err(400, 'Webhook body is not JSON');
      }
      const out = await invoices.paypalWebhook({ headers: req.headers, event });
      U.log('[webhook] paypal', JSON.stringify(out).slice(0, 200));
      return U.sendJson(res, 200, { ok: true, ...out });
    }
    if (seg[1] === 'bank') {
      const out = await invoices.bankWebhook({ rawBody: raw, headers: req.headers });
      U.log('[webhook] bank', JSON.stringify(out).slice(0, 200));
      return U.sendJson(res, 200, { ok: true, ...out });
    }
    return U.sendText(res, 404, 'Not found');
  }

  // Health probe for hosts (Render): no token, no data, only "the process is up".
  if ((p === '/healthz' || p === '/health') && method === 'GET') return U.sendJson(res, 200, { ok: true, version: U.VERSION });
  // v18 readiness for hosts: stores readable, journal consistent, events flowing. No data.
  if ((p === '/readyz' || p === '/ready') && method === 'GET') {
    const r = apiV1.readiness();
    return U.sendJson(res, r.ready ? 200 : 503, { ready: r.ready, version: U.VERSION });
  }
  // PUBLIC: cTrader sends the browser back here after you grant access. The one-use
  // state the desk issued (10 minutes) is the key; the code is exchanged server-side.
  if (p === '/broker/callback' && method === 'GET') {
    const headers = { 'Referrer-Policy': 'no-referrer', 'X-Frame-Options': 'DENY', 'Cache-Control': 'no-store', 'Content-Security-Policy': "default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'" };
    try {
      await broker.oauthCallback(url.searchParams);
      return U.sendText(res, 200, callbackPage(true, 'Access granted. The desk is connecting to your account now.'), 'text/html; charset=utf-8', headers);
    } catch (e) {
      return U.sendText(res, e.status && e.status < 500 ? e.status : 502, callbackPage(false, e.message || 'Something went wrong'), 'text/html; charset=utf-8', headers);
    }
  }
  // Cross-origin cockpit (the studio in AI Studio or on another host): answer the
  // preflight, then require the bearer token on the real request (uiAllowed).
  if (isForeign(req) && p.startsWith('/api/')) {
    for (const [k, v] of Object.entries(corsFor(req))) res.setHeader(k, v);
    if (method === 'OPTIONS') return res.writeHead(204), res.end();
  }
  if (!uiAllowed(req)) {
    return U.sendText(res, 401, 'YABBAI is private. Open it on this computer at http://127.0.0.1:' + PORT + ' — or, for remote access, visit /login?token=YOUR_TOKEN (token is in data/secret.json).');
  }
  // v15: the deck (studio) is the front door; the engine console lives at /console.
  if (method === 'GET' && p === '/') {
    if (fs.existsSync(path.join(STUDIO_DIR, 'index.html'))) return res.writeHead(302, { Location: '/studio/' }), res.end();
    return serveStatic(res, '/console');
  }
  if (method === 'GET' && serveStatic(res, p)) return;
  if (method === 'GET' && (p === '/studio' || p.startsWith('/studio/'))) {
    // The token is handed to the studio only when the caller already proved it:
    // the machine itself, or the login cookie set by /login?token=…
    return serveStudio(req, res, p, { injectToken: (isLoopback(req) && hostIsLocal(req)) || tokenOk(cookie(req, 'yb_token')) });
  }

  if (!p.startsWith('/api/')) return U.sendText(res, 404, 'Not found');
  // CSRF guard: state changes need the cockpit's custom header (a cross-site page can't add it)
  if (method !== 'GET') {
    const origin = req.headers.origin;
    const viaBearer = tokenOk(bearer(req)); // a bearer token cannot be forged by a cross-site page
    if (req.headers['x-yabbai'] !== '1' || (origin && !viaBearer && origin !== `http://${req.headers.host}` && origin !== `https://${req.headers.host}`)) {
      return U.sendJson(res, 403, { error: 'Blocked: request did not come from the YABBAI cockpit' });
    }
  }

  const body = method === 'GET' || method === 'DELETE' ? {} : await U.readJson(req, 4 * 1024 * 1024);
  // v16: a private key or wallet recovery phrase is refused before any handler sees it,
  // so it never reaches the database, a log line, the audit trail or an AI prompt.
  refuseSecrets(body, p);

  // v18: the operating API (CRM, sales, tasks, agents, workflows, events, executive).
  if (p.startsWith('/api/v1/') && (await apiV1.handle(req, res, { method, p, body, url }))) return;
  // v16: the Director vault and the treasury control plane.
  if (p.startsWith('/api/v2/') && (await treasuryApi.handle(req, res, { method, p, body, url }))) return;

  if (p === '/api/health') return U.sendJson(res, 200, await health());
  if (p === '/api/state') return U.sendJson(res, 200, uiState());
  if (p === '/api/events') {
    U.sseStart(res);
    U.sseSend(res, { type: 'hello', version: U.VERSION });
    const onEvent = (evt) => U.sseSend(res, evt);
    U.bus.on('event', onEvent);
    const beat = setInterval(() => res.write(': beat\n\n'), 25000);
    res.on('close', () => {
      clearInterval(beat);
      U.bus.off('event', onEvent);
    });
    return;
  }
  if (p === '/api/doctor') return U.sendJson(res, 200, await doctor(url.searchParams.get('warm') === '1'));
  if (p === '/api/connect') {
    // The details carry the token: shown on this computer, or to a caller that already holds
    // it (a bearer header, or the login cookie, which only rides same-origin requests).
    if (!((isLoopback(req) && hostIsLocal(req)) || tokenOk(bearer(req)) || tokenOk(cookie(req, 'yb_token')))) throw err(403, 'Connection details are only shown on this computer, or to a caller holding the token');
    return U.sendJson(res, 200, connectInfo(req));
  }
  if (p === '/api/autopilot' && method === 'POST') {
    patchSettings({ autopilot: !!body.on });
    store.activity('system', `Autopilot ${body.on ? 'on' : 'off'}`);
    if (body.on) agents.tick();
    return U.sendJson(res, 200, { autopilot: store.db.settings.autopilot });
  }
  if (seg[1] === 'agents' && seg[2] && method === 'POST') {
    if (seg[3] === 'run') return U.sendJson(res, 200, { queued: agents.enqueue(seg[2], 'manual') });
    if (seg[3] === 'config') return U.sendJson(res, 200, agents.configure(seg[2], body));
  }
  if (p === '/api/settings') {
    if (method === 'GET') return U.sendJson(res, 200, publicSettings());
    if (method === 'POST') {
      patchSettings(body);
      return U.sendJson(res, 200, publicSettings());
    }
  }

  // leads & outbox
  if (p === '/api/leads/import' && method === 'POST') return U.sendJson(res, 200, leadimport.importAny(body));
  if (p === '/api/leads' && method === 'POST') return U.sendJson(res, 200, ops.addLead(body));
  if (seg[1] === 'leads' && seg[2]) {
    if (method === 'PATCH') return U.sendJson(res, 200, ops.updateLead(seg[2], body));
    if (method === 'DELETE') return U.sendJson(res, 200, { ok: ops.deleteLead(seg[2]) });
    if (method === 'POST' && seg[3] === 'won') {
      money.requireVault(); // a won deal books income: a person with the vault
      return U.sendJson(res, 200, ops.winLead(seg[2], body));
    }
    if (method === 'POST' && seg[3] === 'redraft') return U.sendJson(res, 200, ops.redraftLead(seg[2]));
  }
  if (seg[1] === 'outbox' && seg[2] && method === 'POST') return U.sendJson(res, 200, ops.setDraftStatus(seg[2], body.status));

  // forge
  if (p === '/api/forge/ideas' && method === 'POST') return U.sendJson(res, 200, ops.addIdea(body));
  if (seg[1] === 'forge' && seg[2] === 'ideas' && seg[3] && method === 'DELETE') return U.sendJson(res, 200, { ok: ops.deleteIdea(seg[3]) });
  if (seg[1] === 'forge' && seg[2] === 'kits' && seg[3]) {
    if (method === 'PATCH') return U.sendJson(res, 200, ops.updateKit(seg[3], body));
    if (method === 'DELETE') return U.sendJson(res, 200, { ok: ops.deleteKit(seg[3]) });
    if (method === 'GET' && seg[4] === 'md') {
      const kit = store.db.forge.kits.find((k) => k.id === seg[3]);
      if (!kit) throw err(404, 'Kit not found');
      const md = store.writeKitMarkdown(kit);
      return U.sendText(res, 200, md.markdown, 'text/markdown; charset=utf-8', { 'Content-Disposition': `attachment; filename="${md.file}"` });
    }
  }

  // ledger
  // v16: money becomes real only by a person with the vault (or a rail with its own proof).
  if (p === '/api/ledger' && method === 'POST') {
    money.requireVault();
    return U.sendJson(res, 200, ops.addLedger(body));
  }
  if (p === '/api/ledger.csv' && method === 'GET') return U.sendText(res, 200, ops.ledgerCsv(), 'text/csv; charset=utf-8', { 'Content-Disposition': 'attachment; filename="yabbai-ledger.csv"' });
  if (seg[1] === 'ledger' && seg[2] && method === 'DELETE') {
    money.requireVault();
    return U.sendJson(res, 200, { ok: ops.deleteLedger(seg[2]) });
  }

  // oil desk broker link (v16): cTrader Open API. An order goes out only from a person
  // on the deck, armed, inside the guardian's limits. Agents and MCP tools have no route here.
  if (seg[1] === 'desk' && (seg[2] === 'broker' || seg[2] === 'orders' || seg[2] === 'positions')) {
    if (p === '/api/desk/broker' && method === 'GET') return U.sendJson(res, 200, broker.status());
    if (p === '/api/desk/broker/config' && method === 'POST') {
      vault.requireSession(); // credentials and the demo/live switch
      if (body.env === 'live') vault.stepUp(); // real money: a fresh authenticator code
      return U.sendJson(res, 200, await broker.configure(body));
    }
    if (p === '/api/desk/broker/connect' && method === 'POST') return U.sendJson(res, 200, await broker.connectNow());
    if (p === '/api/desk/broker/disconnect' && method === 'POST') return U.sendJson(res, 200, broker.disconnect());
    if (p === '/api/desk/broker/arm' && method === 'POST') {
      if (body.armed === true) {
        vault.requireSession();
        if (broker.status().env === 'live') vault.stepUp();
      }
      return U.sendJson(res, 200, broker.arm(body.armed === true));
    }
    if (p === '/api/desk/broker/oauth' && method === 'POST') return U.sendJson(res, 200, broker.oauthStart(`${publicOrigin(req)}/broker/callback`));
    if (p === '/api/desk/orders/preview' && method === 'POST') return U.sendJson(res, 200, await broker.preview(body));
    if (p === '/api/desk/orders' && method === 'POST') return U.sendJson(res, 200, await broker.placeOrder(body));
    if (seg[2] === 'positions' && seg[3] && method === 'POST' && seg[4] === 'close') return U.sendJson(res, 200, await broker.closePosition(seg[3], body));
    if (seg[2] === 'positions' && seg[3] && method === 'POST' && seg[4] === 'protect') return U.sendJson(res, 200, await broker.protect(seg[3], body));
    return U.sendJson(res, 404, { error: 'Not found' });
  }
  // oil desk (v15): live quotes, a journal of real broker trades, the guardian.
  if (p === '/api/desk' && method === 'GET') return U.sendJson(res, 200, await desk.summary({ force: url.searchParams.get('force') === '1' }));
  if (p === '/api/desk/trades' && method === 'POST') return U.sendJson(res, 200, desk.addTrade(body));
  if (p === '/api/desk/account' && method === 'POST') return U.sendJson(res, 200, desk.configure(body));
  if (seg[1] === 'desk' && seg[2] === 'trades' && seg[3]) {
    if (method === 'POST' && seg[4] === 'close') return U.sendJson(res, 200, desk.closeTrade(seg[3], body));
    if (method === 'DELETE') return U.sendJson(res, 200, { ok: desk.deleteTrade(seg[3]) });
  }

  // chat
  if (p === '/api/threads') {
    if (method === 'GET') return U.sendJson(res, 200, store.threads.list());
    if (method === 'POST') return U.sendJson(res, 200, store.threads.create(body.persona || 'director'));
  }
  if (seg[1] === 'threads' && seg[2]) {
    if (method === 'GET') {
      const t = store.threads.get(seg[2]);
      if (!t) throw err(404, 'Thread not found');
      return U.sendJson(res, 200, t);
    }
    if (method === 'DELETE') {
      store.threads.remove(seg[2]);
      return U.sendJson(res, 200, { ok: true });
    }
  }
  if (p === '/api/chat' && method === 'POST') return chatStream(req, res, body);

  // classic v11 brain (Anthropic-shaped response so v11's parser works unchanged)
  if (p === '/api/brain' && method === 'POST') {
    const model = await resolveModel();
    if (!model) throw err(503, 'No local model');
    const out = await ollama.chat({
      model,
      messages: [{ role: 'user', content: String(body.prompt || body.messages?.[0]?.content || '').slice(0, 20000) }],
      think: false,
      format: 'json',
      options: { num_ctx: Number(store.db.settings.numCtx) || 8192, temperature: 0.4, num_predict: Math.min(1200, Number(body.max_tokens) || 500) },
    });
    return U.sendJson(res, 200, { content: [{ type: 'text', text: out.content }], model });
  }

  // models
  if (p === '/api/model' && method === 'GET') return U.sendJson(res, 200, await modelInfo());
  if (p === '/api/model/select' && method === 'POST') {
    const model = String(body.model || '');
    const { models } = await installed(true);
    if (!models.some((m) => (m.name || m.model) === model)) throw err(400, 'That model is not installed');
    store.db.settings.model = model;
    store.save();
    store.activity('model', `Active model → ${model}`);
    return U.sendJson(res, 200, { active: model });
  }
  if (p === '/api/model/pull' && method === 'POST') return pullStream(req, res, body);
  if (p === '/api/model/delete' && method === 'POST') {
    const model = String(body.model || '');
    if (!MODEL_NAME.test(model)) throw err(400, 'Bad model name');
    await ollama.remove(model);
    if (store.db.settings.model === model) store.db.settings.model = '';
    store.save();
    await installed(true);
    store.activity('model', `Removed ${model}`);
    return U.sendJson(res, 200, { ok: true });
  }

  // ── v13: queue, money, loop, Solana, vault, brains, deep brain ──
  if (p === '/api/queue' && method === 'GET') return U.sendJson(res, 200, queue.items());
  if (seg[1] === 'queue' && seg[2] && seg[3] && method === 'POST') return U.sendJson(res, 200, queue.act(seg[2], seg[3], body.action, body));
  if (seg[1] === 'leads' && seg[2] && seg[3] === 'reply' && method === 'POST') return U.sendJson(res, 200, ops.logReply(seg[2], body));
  if (p === '/api/brief' && method === 'POST') {
    const out = await brains.text({ brain: store.db.settings.brains.chat, system: P.DIRECTOR, prompt: `${P.liveState(store.db, { model: await resolveModel(), agentsState: agents.publicState() })}\n\nGive me the executive posture: 3 short bullets on where things really stand (only from the live state — verified money first), then the 3 highest-value moves for today. Under 170 words. Markdown.`, options: { num_ctx: Number(store.db.settings.numCtx) || 8192, temperature: 0.4, num_predict: 500 } });
    store.db.brief = { at: U.iso(), text: out.text, brain: store.db.settings.brains.chat };
    store.save();
    return U.sendJson(res, 200, store.db.brief);
  }
  if (p === '/api/money/spine' && method === 'POST') return U.sendJson(res, 200, money.setSpine(body));
  if (p === '/api/payouts' && method === 'POST') return U.sendJson(res, 200, money.requestPayout(body));

  // ── RECEIVE: invoices, rails, matching ──
  if (p === '/api/receive' && method === 'GET') return U.sendJson(res, 200, { summary: invoices.summary(), settings: publicReceive(), paypal: invoices.paypalInfo() });
  if (p === '/api/receive/settings' && method === 'POST') {
    const secretIn = (v) => v !== undefined && v !== U.SECRET_MASK;
    if (secretIn(body.paypalSecret) || secretIn(body.bank && body.bank.webhookSecret) || secretIn(body.webhookSecret)) money.requireVault();
    invoices.patchReceive(body);
    bookkeeper.seedAccounts(); // new receive addresses join the treasury registry (watch-only)
    return U.sendJson(res, 200, { settings: publicReceive(), summary: invoices.summary() });
  }
  if (p === '/api/receive/reconcile' && method === 'POST') return U.sendJson(res, 200, await invoices.reconcileAll());
  if (p === '/api/receive/statement' && method === 'POST') {
    money.requireVault();
    const text = String(body.text || '');
    if (text.length < 10) throw err(400, 'Paste the statement CSV or choose the exported file');
    return U.sendJson(res, 200, invoices.importStatement(text, { filename: body.filename }));
  }
  if (p === '/api/invoices' && method === 'POST') return U.sendJson(res, 200, invoices.addInvoice(body));
  if (seg[1] === 'invoices' && seg[2] && method === 'GET' && seg[3] === 'link') {
    const inv = invoices.getInvoice(seg[2]);
    const base = (store.db.settings.receive?.publicBase || PUBLIC_URL || `http://127.0.0.1:${PORT}`).replace(/\/+$/, '');
    return U.sendJson(res, 200, { url: `${base}/pay/${inv.token}`, token: inv.token, number: inv.number });
  }
  if (seg[1] === 'invoices' && seg[2] && method === 'PATCH') return U.sendJson(res, 200, invoices.updateInvoice(seg[2], body));
  if (seg[1] === 'invoices' && seg[2] && method === 'POST') {
    if (seg[3] === 'send') return U.sendJson(res, 200, invoices.sendInvoice(seg[2]));
    if (seg[3] === 'void') return U.sendJson(res, 200, invoices.voidInvoice(seg[2]));
    if (seg[3] === 'requote') return U.sendJson(res, 200, await invoices.requote(invoices.getInvoice(seg[2])));
    if (seg[3] === 'paypal') {
      const inv = invoices.getInvoice(seg[2]);
      const proto = req.headers['x-forwarded-proto'] === 'https' ? 'https' : 'http';
      return U.sendJson(res, 200, await invoices.paypalPay(inv, { origin: `${proto}://${req.headers.host}` }));
    }
    if (seg[3] === 'credit') {
      money.requireVault();
      return U.sendJson(res, 200, invoices.confirmManual({ invoice: seg[2], ...body }));
    }
  }
  if (seg[1] === 'claims' && seg[2] && method === 'POST') {
    money.requireVault();
    if (seg[3] === 'confirm') return U.sendJson(res, 200, invoices.settleClaim(seg[2], 'confirm'));
    if (seg[3] === 'dismiss') return U.sendJson(res, 200, invoices.settleClaim(seg[2], 'dismiss'));
  }
  if (p === '/api/loop' && method === 'POST') return U.sendJson(res, 200, loop.configure(body));
  if (p === '/api/loop/cycle' && method === 'POST') {
    await loop.cycle();
    return U.sendJson(res, 200, { state: store.db.loopState, paper: loop.paperSummary() });
  }
  if (p === '/api/loop/reset-paper' && method === 'POST') return U.sendJson(res, 200, loop.resetPaper());
  if (p === '/api/solana/address' && method === 'POST') return U.sendJson(res, 200, loop.setAddress(body.address));
  if (p === '/api/solana/scan' && method === 'POST') return U.sendJson(res, 200, await loop.solanaScan());
  if (p === '/api/solana/rpc' && method === 'POST') {
    const rpc = String(body.rpc || '').trim();
    if (!/^https?:\/\/[\w.\-:]+(\/[\w.\-\/]*)?$/.test(rpc)) throw err(400, 'RPC must be an http(s) URL');
    store.db.settings.solana.rpc = rpc;
    store.save();
    return U.sendJson(res, 200, { rpc });
  }
  // v15 vault routes, kept for older screens: they speak to Director Vault v2.
  if (p === '/api/vault' && method === 'GET') return U.sendJson(res, 200, money.vaultStatus());
  if (p === '/api/vault/pin' && method === 'POST') return U.sendJson(res, 200, money.setPin());
  if (p === '/api/vault/unlock' && method === 'POST') {
    if (!body.code) return U.sendJson(res, 200, money.unlock());
    return U.sendJson(res, 200, vault.unlock({ pin: body.pin, code: body.code }, { ua: String(req.headers['user-agent'] || ''), ip: req.socket.remoteAddress || '' }));
  }
  if (p === '/api/vault/lock' && method === 'POST') return U.sendJson(res, 200, money.lock(String(req.headers['x-yabbai-vault'] || '')));
  if (p === '/api/brains' && method === 'GET') {
    const [hfModels, deep, local] = await Promise.all([brains.hfModels().catch((e) => ({ curated: brains.HF_MODELS, error: e.message })), brains.deepHealth(), resolveModel()]);
    return U.sendJson(res, 200, { settings: store.db.settings.brains, hf: brains.hfTokenInfo(), hfModels, deep, local });
  }
  if (p === '/api/brains' && method === 'POST') {
    const b = store.db.settings.brains;
    if ('hfToken' in body) {
      money.requireVault();
      brains.setHfToken(body.hfToken);
      store.activity('system', body.hfToken ? 'Hugging Face token saved' : 'Hugging Face token removed');
    }
    if (['local', 'hf'].includes(body.chat)) b.chat = body.chat;
    if (['local', 'hf'].includes(body.agents)) b.agents = body.agents;
    if (typeof body.hfModel === 'string' && /^[\w.\-]+\/[\w.\-:]+$/.test(body.hfModel)) b.hfModel = body.hfModel;
    if ('deepEnabled' in body) b.deepEnabled = !!body.deepEnabled;
    if (typeof body.deepUrl === 'string' && /^http:\/\/(127\.0\.0\.1|localhost):\d+$/.test(body.deepUrl)) b.deepUrl = body.deepUrl;
    if ('deepMaxTokens' in body) b.deepMaxTokens = U.clamp(Number(body.deepMaxTokens) || 400, 16, 2000);
    store.save();
    return U.sendJson(res, 200, { settings: b, hf: brains.hfTokenInfo() });
  }
  if (p === '/api/brains/test' && method === 'POST') {
    const t0 = Date.now();
    const out = await brains.text({ brain: body.brain === 'hf' ? 'hf' : 'local', prompt: 'Reply with exactly: ready', options: { num_predict: 16 } });
    return U.sendJson(res, 200, { ok: true, text: out.text, ms: Date.now() - t0, stats: out.stats });
  }
  if (p === '/api/deep/jobs' && method === 'POST') {
    const question = String(body.prompt || '').slice(0, 8000);
    if (!question.trim()) throw err(400, 'Ask the deep brain something');
    const messages = [{ role: 'system', content: P.DIRECTOR }];
    if (body.context !== false) messages.push({ role: 'user', content: P.liveState(store.db, { model: 'deep brain' }) }, { role: 'assistant', content: 'Understood. I have the live state.' });
    messages.push({ role: 'user', content: question });
    return U.sendJson(res, 200, await brains.deepSubmit({ title: body.title || question.slice(0, 80), messages, maxTokens: body.maxTokens }));
  }
  if (seg[1] === 'deep' && seg[2] === 'jobs' && seg[3] && seg[4] === 'cancel' && method === 'POST') return U.sendJson(res, 200, await brains.deepCancel(seg[3]));

  return U.sendJson(res, 404, { error: 'Not found' });
}

// ── boot ────────────────────────────────────────────────────
U.ensureDir(U.DATA_DIR);
const TOKEN = loadToken();
// /mcp/<token> as one clean path segment. A generated base64 token (Render's
// generateValue) can hold "+", "/" and "=", which a path would have to escape, so the
// connector URL uses the base64url spelling of the same token. Both spellings work.
const TOKEN_PATH = /^[A-Za-z0-9+\/=_.~-]+$/.test(TOKEN) ? TOKEN.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '') : encodeURIComponent(TOKEN);
const pathTokenOk = (t) => tokenOk(t) || U.timingSafeEqualStr(t, TOKEN_PATH);
store.load();
invoices.moveLegacySecrets(); // v16: provider secrets leave db.json for data/secrets
// v16: one engine per data folder. A second engine on the same books would book the same
// money twice, so it stops here instead (see lib/enginelock.js).
try {
  enginelock.acquire({ port: PORT });
} catch (e) {
  console.error(`[engine] ${e.message}`);
  process.exit(1);
}
// v16 treasury state, journal, audit trail and vault, then the v15 → v16 migration (once,
// and again for anything v15 booked that the journal has not seen).
tstore.load();
audit.load();
journal.load();
vault.load();
try {
  opsstore.load();
} catch (e) {
  console.error(`[engine] ${e.message}`);
  process.exit(1);
}
ops.setLedgerHooks({ added: bookkeeper.onLedger, deleted: bookkeeper.onLedgerDeleted, duplicate: bookkeeper.onDuplicate });
try {
  const mig = bookkeeper.boot();
  if (mig) U.log(`[treasury] v15 data migrated: ${mig.carried.ledgerEntries} ledger entries, ${mig.carried.allocations} allocations, ${mig.carried.payoutsPaid} paid payouts · checks ${mig.ok ? 'pass' : 'FAIL (see Treasury → Migration)'}`);
} catch (e) {
  U.log('[treasury] migration failed:', e.stack || e.message);
}
// v18: a run that was in flight when the engine stopped is failed (and retried); a proposal
// decision the ops store missed is recorded now.
try {
  const stuck = agentops.recover();
  const settled = salesflow.settle();
  if (stuck || settled) U.log(`[ops] recovered ${stuck} interrupted agent run(s), recorded ${settled} proposal decision(s)`);
} catch (e) {
  U.log('[ops] recovery failed:', e.message);
}
// store.save() is debounced by 300 ms. A restart inside that window used to drop
// the last write (settings you just changed, a payment just booked). Flush on the
// way out, and make an interrupted exit flush too.
let exiting = false;
function graceful() {
  if (exiting) return;
  exiting = true;
  try {
    events.stop();
    store.flush();
    tstore.flush();
  } catch (e) {
    U.log('[exit] flush failed:', e.message);
  }
  enginelock.release();
}
process.on('SIGINT', () => {
  graceful();
  process.exit(0);
});
process.on('SIGTERM', () => {
  graceful();
  process.exit(0);
});
process.on('exit', graceful);
agents.setModelResolver(resolveModel);
gateway.setModelResolver(resolveModel);
brains.setLocalResolver(resolveModel);
brains.setEngineToken(TOKEN);
// v18: every new lead is a lead.created fact on the event bus. Leads added through
// POST /api/v1/crm/leads carry autoStart, which starts the lead-to-proposal workflow.
ops.setLeadHook((lead, opts = {}) => {
  if (opts.redraft) return;
  U.bus.emit('fact', { type: 'lead.created', id: lead.id, source: 'crm', correlationId: opts.correlationId, payload: { leadId: lead.id, source: lead.source, channel: lead.channel, autoStart: opts.autoStart === true } });
});
// The v15 autopilot hook, unchanged: a new lead or a redraft queues the drafting agents.
ops.setLeadHook(() => {
  if (!store.db.settings.autopilot) return;
  setTimeout(() => {
    if (store.db.agents.qualifier.enabled) agents.enqueue('qualifier', 'new-lead');
    if (store.db.agents.closer.enabled) agents.enqueue('closer', 'new-lead');
  }, 3000);
});
ops.setReplyHook(() => {
  if (store.db.settings.autopilot && store.db.agents.supporter.enabled) setTimeout(() => agents.enqueue('supporter', 'reply'), 1500);
});

const server = http.createServer(async (req, res) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  try {
    // The request's vault session (X-Yabbai-Vault) and step-up code (X-Yabbai-Otp) travel
    // with everything this request does, so every money check sees the same person.
    const ctx = { token: String(req.headers['x-yabbai-vault'] || ''), otp: String(req.headers['x-yabbai-otp'] || ''), ua: String(req.headers['user-agent'] || '').slice(0, 160), ip: String(req.socket.remoteAddress || '') };
    await vault.context.run(ctx, () => route(req, res));
  } catch (e) {
    const status = e.status || 500;
    const safeUrl = String(req.url).replace(/\/mcp\/[^/?#]+/, '/mcp/***').replace(/token=[^&]+/, 'token=***');
    if (status >= 500) U.log('[error]', req.method, safeUrl, e.stack || e.message);
    if (!res.headersSent) U.sendJson(res, status, { error: e.message || 'Server error' });
    else if (!res.writableEnded) res.end();
  }
});
server.requestTimeout = 0; // long generations and model pulls
server.headersTimeout = 60000;
server.on('error', (e) => {
  if (e.code === 'EADDRINUSE') {
    console.error(`Port ${PORT} is already in use — YABBAI may already be running (open http://127.0.0.1:${PORT}). Set YABBAI_PORT to use another port.`);
    process.exit(2);
  }
  throw e;
});
// Treasury sync: read every watched balance, check broadcast transfers against their chain,
// reconcile. Read-only: nothing here moves money or approves anything.
const SYNC_SEC = Number(process.env.YABBAI_TREASURY_SYNC_SEC ?? 300);
let syncing = false;
async function treasurySync() {
  if (syncing) return;
  syncing = true;
  try {
    await wallets.observeAll();
    await transfers.verifyAll();
    reconcile.run({}, { type: 'agent', id: 'reconciler', label: 'Reconciler' });
  } catch (e) {
    U.log('[treasury] sync:', e.message);
  } finally {
    syncing = false;
  }
}
server.listen(PORT, HOST, async () => {
  events.start();
  agents.start();
  loop.start();
  broker.start();
  if (SYNC_SEC > 0) {
    setTimeout(treasurySync, 15000).unref();
    setInterval(treasurySync, Math.max(60, SYNC_SEC) * 1000).unref();
  }
  brains.startDeepPolling();
  const model = await resolveModel().catch(() => null);
  U.log(`YABBAI engine ${U.VERSION} → http://${HOST === '0.0.0.0' ? '127.0.0.1' : HOST}:${PORT}`);
  U.log(`Ollama: ${ollama.BASE} · model: ${model || 'none yet'} · data: ${U.DATA_DIR}`);
  U.log(`Deck → ${PUBLIC_URL || `http://127.0.0.1:${PORT}`}/studio/ · engine console /console · claude.ai connector: /mcp/<token>`);
  U.log(`Open WebUI expected at ${OWUI_URL} · gateway ${`http://127.0.0.1:${PORT}/v1`} · tools /openapi.json · MCP /mcp`);
  store.activity('system', `Engine started (${model || 'no model yet'})`);
});

function shutdown() {
  events.stop();
  broker.stop();
  store.flush();
  tstore.flush();
  process.exit(0);
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
process.on('uncaughtException', (e) => {
  U.log('[uncaught]', e.stack || e.message);
});
process.on('unhandledRejection', (e) => {
  U.log('[unhandled]', e && (e.stack || e.message));
});
