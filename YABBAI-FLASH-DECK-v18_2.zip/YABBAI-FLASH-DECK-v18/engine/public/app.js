'use strict';
/* YABBAI cockpit — vanilla JS, no build step. Talks only to the local engine. */
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const aud = (n) => {
  const v = Number(n) || 0;
  return (v < 0 ? '−' : '') + 'A$' + Math.abs(v).toLocaleString('en-AU', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
};
const bps = (n) => (n === null || n === undefined ? '—' : `${n > 0 ? '+' : ''}${Number(n).toFixed(1)} bps`);
function ago(t) {
  const ms = typeof t === 'number' ? t : Date.parse(t);
  if (!ms) return 'never';
  const s = Math.max(0, Math.round((Date.now() - ms) / 1000));
  if (s < 60) return 'just now';
  if (s < 3600) return `${Math.round(s / 60)} min ago`;
  if (s < 86400) return `${Math.round(s / 3600)} h ago`;
  return `${Math.round(s / 86400)} d ago`;
}
function until(ms) {
  if (!ms) return 'manual only';
  const s = Math.round((ms - Date.now()) / 1000);
  if (s <= 0) return 'due now';
  return s < 3600 ? `in ${Math.max(1, Math.round(s / 60))} min` : `in ${Math.round(s / 3600)} h`;
}
const hhmm = (iso) => new Date(iso).toLocaleTimeString('en-AU', { hour: '2-digit', minute: '2-digit', hour12: false });
const price = (n) => (!Number.isFinite(n) ? '—' : n >= 100 ? n.toFixed(2) : n >= 1 ? n.toFixed(4) : n.toPrecision(4));
function shortModel(n) {
  const m = /([^/]+?)(?:-GGUF)?(?::(.+))?$/i.exec(String(n || ''));
  return m ? (m[2] && m[2] !== 'latest' ? `${m[1]} · ${m[2]}` : m[1]) : n;
}

const S = { st: null, health: null, model: null, view: 'agents', inited: {}, threads: [], thread: null, streaming: null, refreshTimer: null, pulls: {} };

// ── plumbing ────────────────────────────────────────────────
async function api(path, { method = 'GET', body } = {}) {
  const res = await fetch(path, {
    method,
    headers: { 'X-Yabbai': '1', ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}) },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
}

async function streamPost(path, body, onEvent, signal) {
  const res = await fetch(path, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Yabbai': '1' }, body: JSON.stringify(body), signal });
  const type = res.headers.get('content-type') || '';
  if (!res.ok || !type.includes('text/event-stream')) {
    const data = await res.json().catch(() => ({}));
    throw new Error(data.error || `HTTP ${res.status}`);
  }
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let buf = '';
  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let i;
    while ((i = buf.indexOf('\n\n')) >= 0) {
      const block = buf.slice(0, i);
      buf = buf.slice(i + 2);
      const data = block
        .split('\n')
        .filter((l) => l.startsWith('data:'))
        .map((l) => l.slice(5).trimStart())
        .join('\n');
      if (!data) continue;
      let evt;
      try {
        evt = JSON.parse(data);
      } catch {
        continue;
      }
      onEvent(evt);
    }
  }
}

let toastTimer;
function toast(text, bad = false) {
  const el = $('#toast');
  el.textContent = text;
  el.className = `show${bad ? ' bad' : ''}`;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (el.className = ''), bad ? 6000 : 2600);
}

async function copy(text) {
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    const ta = document.createElement('textarea');
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    ta.remove();
  }
  toast('Copied');
}

function ask(title, fields, okLabel = 'Save') {
  return new Promise((resolve) => {
    const dlg = $('#dlg');
    const form = $('#dlg-form');
    form.innerHTML = `<h2>${esc(title)}</h2>${fields
      .map(
        (f) => `<label>${esc(f.label)}${
          f.type === 'textarea'
            ? `<textarea name="${f.name}" rows="3" placeholder="${esc(f.placeholder || '')}">${esc(f.value || '')}</textarea>`
            : `<input name="${f.name}" type="${f.type || 'text'}" value="${esc(f.value ?? '')}" placeholder="${esc(f.placeholder || '')}"${f.required ? ' required' : ''}${f.step ? ` step="${f.step}"` : ''}>`
        }</label>${f.hint ? `<span class="hint">${esc(f.hint)}</span>` : ''}`,
      )
      .join('')}<div class="row" style="justify-content:flex-end"><button class="btn ghost" value="cancel" formnovalidate>Cancel</button><button class="btn primary" value="ok">${esc(okLabel)}</button></div>`;
    dlg.onclose = () => resolve(dlg.returnValue === 'ok' ? Object.fromEntries(new FormData(form)) : null);
    dlg.returnValue = '';
    dlg.showModal();
    const first = form.querySelector('input,textarea');
    if (first) first.focus();
  });
}

// Keeps <details data-id> open across re-renders.
function keepOpen(el, fn) {
  const open = new Set($$('details[open][data-id]', el).map((d) => d.dataset.id));
  fn();
  $$('details[data-id]', el).forEach((d) => {
    if (open.has(d.dataset.id)) d.open = true;
  });
}

// Small, safe Markdown renderer (escapes first).
function md(src) {
  const blocks = [];
  const s = esc(src).replace(/```[^\n]*\n([\s\S]*?)(?:```|$)/g, (m, code) => {
    blocks.push(`<pre><code>${code.replace(/\n$/, '')}</code></pre>`);
    return `\n\u0001${blocks.length - 1}\u0001\n`;
  });
  const inline = (t) =>
    t
      .replace(/`([^`]+)`/g, '<code>$1</code>')
      .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
      .replace(/(^|[\s(])\*([^*\s][^*]*)\*/g, '$1<em>$2</em>')
      .replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
  let out = '';
  let list = null;
  let table = null;
  let para = [];
  const flushPara = () => {
    if (para.length) out += `<p>${inline(para.join('<br>'))}</p>`;
    para = [];
  };
  const closeList = () => {
    if (list) out += `</${list}>`;
    list = null;
  };
  const flushTable = () => {
    if (!table) return;
    const rows = table.filter((r) => !/^\|?\s*:?-{2,}/.test(r)).map((r) => r.replace(/^\||\|$/g, '').split('|').map((c) => inline(c.trim())));
    if (rows.length) out += `<div class="tablewrap"><table><thead><tr>${rows[0].map((c) => `<th>${c}</th>`).join('')}</tr></thead><tbody>${rows.slice(1).map((r) => `<tr>${r.map((c) => `<td>${c}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
    table = null;
  };
  for (const line of s.split('\n')) {
    const block = /^\u0001(\d+)\u0001$/.exec(line.trim());
    if (block) {
      flushPara();
      closeList();
      flushTable();
      out += blocks[Number(block[1])];
      continue;
    }
    if (/^\s*\|.*\|\s*$/.test(line)) {
      flushPara();
      closeList();
      (table = table || []).push(line.trim());
      continue;
    }
    flushTable();
    let m;
    if ((m = /^(#{1,6})\s+(.*)$/.exec(line))) {
      flushPara();
      closeList();
      const lvl = Math.min(6, m[1].length + 2);
      out += `<h${lvl}>${inline(m[2])}</h${lvl}>`;
    } else if ((m = /^\s*[-*•]\s+(.*)$/.exec(line))) {
      flushPara();
      if (list !== 'ul') {
        closeList();
        out += '<ul>';
        list = 'ul';
      }
      out += `<li>${inline(m[1])}</li>`;
    } else if ((m = /^\s*\d+[.)]\s+(.*)$/.exec(line))) {
      flushPara();
      if (list !== 'ol') {
        closeList();
        out += '<ol>';
        list = 'ol';
      }
      out += `<li>${inline(m[1])}</li>`;
    } else if (/^\s*(-{3,}|\*{3,})\s*$/.test(line)) {
      flushPara();
      closeList();
      out += '<hr>';
    } else if (!line.trim()) {
      flushPara();
      closeList();
    } else if (/^&gt;\s?/.test(line)) {
      flushPara();
      closeList();
      out += `<blockquote class="dim">${inline(line.replace(/^&gt;\s?/, ''))}</blockquote>`;
    } else para.push(line);
  }
  flushPara();
  closeList();
  flushTable();
  return out;
}

// ── state & live updates ────────────────────────────────────
async function refresh() {
  S.st = await api('/api/state');
  renderTop();
  const v = VIEWS[S.view];
  if (v && S.inited[S.view]) v.render();
}
function scheduleRefresh() {
  clearTimeout(S.refreshTimer);
  S.refreshTimer = setTimeout(() => refresh().catch(() => {}), 500);
}
function connectEvents() {
  const es = new EventSource('/api/events');
  es.onmessage = (e) => {
    let evt;
    try {
      evt = JSON.parse(e.data);
    } catch {
      return;
    }
    if (evt.type === 'hello') return;
    if (evt.type === 'agent' && S.st) S.st.agents[evt.id] = evt.agent;
    if (evt.type === 'activity' && evt.entry.kind === 'alert') toast(evt.entry.text);
    scheduleRefresh();
  };
  es.onerror = () => {
    S.health = null;
    renderChips();
  };
}
async function pollHealth() {
  try {
    S.health = await api('/api/health');
  } catch {
    S.health = null;
  }
  renderChips();
}
async function pollModel() {
  try {
    S.model = await api('/api/model');
  } catch {
    /* engine down */
  }
  renderChips();
}

function renderChips() {
  const h = S.health;
  const run = h && S.model && (S.model.running || []).find((r) => r.name === h.model);
  const dotModel = !h || !h.model ? 'bad' : run ? (run.gpuPct >= 90 ? 'ok' : 'warn') : 'ok';
  $('#chips').innerHTML = [
    `<span class="chip"><span class="dot ${h ? 'ok' : 'bad'}"></span>${h ? 'Engine' : 'Engine offline'}</span>`,
    `<span class="chip" title="${esc(h && h.ollama ? h.ollama.url : '')}"><span class="dot ${h && h.ollama.up ? 'ok' : 'bad'}"></span>${h && h.ollama.up ? `Ollama ${esc(h.ollama.version)}` : 'Ollama down'}</span>`,
    `<span class="chip" title="${esc(h && h.model ? h.model : 'No model installed')}"><span class="dot ${dotModel}"></span>${h && h.model ? esc(shortModel(h.model)) + (run ? ` · GPU ${run.gpuPct}%` : '') : 'No model'}</span>`,
    `<a class="chip" href="${esc(h ? h.openwebui.url : '#')}" target="_blank" rel="noopener"><span class="dot ${h && h.openwebui.up ? 'ok' : ''}"></span>${h && h.openwebui.up ? 'Open WebUI ↗' : 'Open WebUI starting…'}</a>`,
  ].join('');
}

function renderTop() {
  const st = S.st;
  if (!st) return;
  const t = st.ledgerTotals;
  $('#t-month').textContent = aud(t.month);
  $('#t-sub').textContent = t.count ? `${aud(t.all)} all time · ${aud(t.week)} last 7 days · ${t.count} receipt${t.count === 1 ? '' : 's'}` : 'Nothing logged yet — income counts once it has a receipt';
  const b = st.board;
  $('#o-spread').textContent = b && b.best ? `${bps(b.best.netBps)} ${b.best.coin}` : b ? b.verdict.replace('_', ' ').toLowerCase() : '—';
  $('#o-spread').className = b && b.best ? (b.best.netBps > 0 ? 'pos' : '') : '';
  const drafts = st.outbox.filter((d) => d.status === 'draft').length;
  const kits = st.forge.kits.filter((k) => k.status !== 'retired').length;
  $('#o-drafts').textContent = drafts;
  $('#o-kits').textContent = kits;
  const bd = $('#b-drafts');
  bd.hidden = !drafts;
  bd.textContent = drafts;
  const bk = $('#b-kits');
  bk.hidden = !kits;
  bk.textContent = kits;
  const ap = $('#autopilot');
  ap.setAttribute('aria-pressed', String(!!st.settings.autopilot));
}

function sec(view) {
  return $(`main > section[data-view="${view}"]`);
}
function show(view) {
  if (!VIEWS[view]) view = 'agents';
  S.view = view;
  if (location.hash !== `#${view}`) history.replaceState(null, '', `#${view}`);
  $$('#rail button').forEach((b) => b.setAttribute('aria-current', b.dataset.view === view ? 'page' : 'false'));
  $$('main > section').forEach((s) => (s.hidden = s.dataset.view !== view));
  const el = sec(view);
  if (!S.inited[view]) {
    VIEWS[view].init(el);
    S.inited[view] = true;
  }
  if (VIEWS[view].onShow) VIEWS[view].onShow();
  if (S.st) VIEWS[view].render();
}

// ── Agents ──────────────────────────────────────────────────
const AGENT_META = {
  scout: { c: 'var(--green)', role: 'Reads Binance, Coinbase, Kraken and CoinSpot order books and works out spreads after fees. Writes a brief. Never trades.', every: [2, 5, 10, 15, 30, 60] },
  closer: { c: 'var(--purple)', role: 'Writes personalised outreach for every new lead in Pipeline, matched to your offers. You send it.', every: [5, 10, 15, 30, 60] },
  forge: { c: 'var(--orange)', role: 'Turns product ideas into Gumroad-ready kits: contents, build steps, price, listing copy and launch posts.', every: [60, 180, 360, 720, 1440] },
};

function initAgents(el) {
  el.innerHTML = `<h1>Agents</h1>
  <p class="lede">Three agents share your local model one job at a time and pause while you chat. They find and prepare the money; closing it is yours.</p>
  <div class="grid g3" id="agent-cards"></div>
  <div class="grid g2" style="margin-top:16px">
    <div class="panel"><h2>Best moves right now</h2><div id="moves"></div></div>
    <div class="panel"><h2>Activity</h2><ul class="feed" id="feed"></ul></div>
  </div>`;
  el.addEventListener('click', async (e) => {
    const b = e.target.closest('[data-act]');
    if (!b) return;
    const id = b.dataset.id;
    try {
      if (b.dataset.act === 'run') {
        const r = await api(`/api/agents/${id}/run`, { method: 'POST', body: {} });
        toast(r.queued ? `${id[0].toUpperCase() + id.slice(1)} queued` : 'Already queued or running');
      }
      if (b.dataset.act === 'toggle') await api(`/api/agents/${id}/config`, { method: 'POST', body: { enabled: b.dataset.on !== 'true' } });
      if (b.dataset.act === 'go') show(b.dataset.view);
      scheduleRefresh();
    } catch (err) {
      toast(err.message, true);
    }
  });
  el.addEventListener('change', async (e) => {
    if (!e.target.matches('select[data-every]')) return;
    await api(`/api/agents/${e.target.dataset.every}/config`, { method: 'POST', body: { everyMin: Number(e.target.value) } }).catch((err) => toast(err.message, true));
    scheduleRefresh();
  });
}

function agentOutput(id, st) {
  if (id === 'scout') {
    const brief = st.briefs[0];
    const b = st.board;
    const best = b && b.best ? `<div class="num ${b.best.netBps > 0 ? 'pos' : 'dim'}">${esc(b.best.coin)} ${esc(b.best.buyVenue)} → ${esc(b.best.sellVenue)} · net ${bps(b.best.netBps)}</div>` : `<div class="dim">${b ? esc(b.verdict) : 'No scan yet'}</div>`;
    return `${best}${brief ? `<div style="margin-top:6px">${esc(brief.headline)}</div><div class="hint">${ago(brief.at)}</div>` : ''}`;
  }
  if (id === 'closer') {
    const waiting = st.outbox.filter((d) => d.status === 'draft');
    const fresh = st.leads.filter((l) => l.stage === 'new').length;
    return `<div><b class="num">${waiting.length}</b> draft${waiting.length === 1 ? '' : 's'} to send · <b class="num">${fresh}</b> lead${fresh === 1 ? '' : 's'} waiting</div>${waiting[0] ? `<div class="dim" style="margin-top:6px">Latest: ${esc(waiting[0].business)} — “${esc(waiting[0].subject)}”</div>` : `<div class="hint" style="margin-top:6px">Add leads in Pipeline and Closer writes to them.</div>`}`;
  }
  const kit = st.forge.kits[0];
  const queued = st.forge.ideas.filter((i) => i.status === 'queued').length;
  return `<div><b class="num">${queued}</b> idea${queued === 1 ? '' : 's'} queued · <b class="num">${st.forge.kits.length}</b> kit${st.forge.kits.length === 1 ? '' : 's'}</div>${kit ? `<div class="dim" style="margin-top:6px">Latest: ${esc(kit.content?.title || kit.ideaName)}${kit.content?.price_aud ? ` · A$${esc(kit.content.price_aud)}` : ''}</div>` : ''}`;
}

function moves(st) {
  const out = [];
  const drafts = st.outbox.filter((d) => d.status === 'draft').length;
  if (drafts) out.push([`Send ${drafts} outreach draft${drafts === 1 ? '' : 's'}`, 'pipeline', 'Written and waiting in Pipeline. Mark each one sent so follow-ups stay on track.']);
  const replied = st.leads.filter((l) => l.stage === 'replied').length;
  if (replied) out.push([`Answer ${replied} repl${replied === 1 ? 'y' : 'ies'}`, 'pipeline', 'Warm leads go cold fast. Ask the Closer in Chat for a reply.']);
  if (!st.leads.length) out.push(['Add your first five leads', 'pipeline', 'Business name and niche is enough; Closer drafts the outreach.']);
  const kit = st.forge.kits.find((k) => k.status === 'drafted' || k.status === 'building');
  if (kit) out.push([`Ship “${kit.content?.title || kit.ideaName}”`, 'forge', `Build the files, upload to Gumroad at A$${kit.content?.price_aud ?? '?'}, then mark it listed.`]);
  const b = st.board;
  if (b && b.verdict === 'OPPORTUNITY') out.push([`Check the ${b.best.coin} spread`, 'markets', `Net ${bps(b.best.netBps)} after fees. Confirm transfer times and limits before acting.`]);
  if (!st.ledger.length) out.push(['Log your first real income', 'ledger', 'Only entries with a receipt count, so you can see what actually works.']);
  return out.slice(0, 5);
}

function renderAgents() {
  const st = S.st;
  $('#agent-cards').innerHTML = ['scout', 'closer', 'forge']
    .map((id) => {
      const a = st.agents[id];
      const meta = AGENT_META[id];
      const status = !a.enabled ? ['', 'Off'] : a.running || a.status === 'running' ? ['busy', 'Working…'] : a.status === 'queued' ? ['warn', 'Queued'] : a.status === 'error' ? ['bad', 'Needs attention'] : ['ok', 'Idle'];
      const opts = meta.every.map((m) => `<option value="${m}"${Number(a.everyMin) === m ? ' selected' : ''}>${m < 60 ? `${m} min` : `${m / 60} h`}</option>`).join('');
      return `<article class="panel agent" style="--c:${meta.c}">
        <div class="row spread"><h2 style="margin:0">${esc(a.name)}</h2><span class="chip"><span class="dot ${status[0]}"></span>${status[1]}</span></div>
        <p class="role">${esc(meta.role)}</p>
        <div class="out">${agentOutput(id, st)}</div>
        ${a.lastError ? `<p class="hint neg" style="margin:8px 0 0">${esc(a.lastError)}</p>` : ''}
        <div class="kv" style="margin:10px 0"><span>Runs</span><b class="num">${a.runs || 0}</b><span>Last run</span><b>${ago(a.lastRunAt)}</b><span>Next</span><b>${st.settings.autopilot && a.enabled ? until(a.nextRunAt) : 'manual only'}</b></div>
        <div class="row"><button class="btn sm primary" data-act="run" data-id="${id}">Run now</button>
          <button class="btn sm" data-act="toggle" data-id="${id}" data-on="${a.enabled}">${a.enabled ? 'Turn off' : 'Turn on'}</button>
          <label class="row" style="flex-direction:row;gap:6px;margin-left:auto">every <select data-every="${id}">${opts}</select></label></div>
      </article>`;
    })
    .join('');
  const mv = moves(st);
  $('#moves').innerHTML = mv.length
    ? mv.map(([title, view, why]) => `<div class="card"><div class="row spread"><b>${esc(title)}</b><button class="btn sm" data-act="go" data-view="${view}">Open</button></div><div class="dim" style="font-size:14px">${esc(why)}</div></div>`).join('')
    : '<div class="empty">Nothing urgent. Add leads or ideas to give the agents more to do.</div>';
  $('#feed').innerHTML = st.activity
    .slice(0, 40)
    .map((a) => `<li><time>${hhmm(a.at)}</time><span class="k-${esc(a.kind)}">${esc(a.text)}</span></li>`)
    .join('') || '<li><span></span><span class="dim">No activity yet.</span></li>';
}

// ── Markets ─────────────────────────────────────────────────
function initMarkets(el) {
  el.innerHTML = `<div class="row spread"><div><h1>Markets</h1><p class="lede">Live public order books. Net = gross spread − both taker fees − a transfer buffer. Nothing here is income until you trade it and log it in the Ledger.</p></div><button class="btn" data-act="scan">Scan now</button></div>
  <div class="panel" id="mk-verdict"></div>
  <div class="grid g2" style="margin-top:16px">
    <div class="panel"><h2>Best net spread, recent scans</h2><div id="mk-spark"></div></div>
    <div class="panel"><h2>Scout’s brief</h2><div id="mk-brief"></div></div>
  </div>
  <h2 style="margin-top:20px">Board</h2><div class="tablewrap" id="mk-table"></div><p class="hint" id="mk-fees"></p>`;
  el.addEventListener('click', async (e) => {
    if (!e.target.closest('[data-act="scan"]')) return;
    await api('/api/agents/scout/run', { method: 'POST', body: {} }).catch((err) => toast(err.message, true));
    toast('Scanning…');
  });
}

function spark(points) {
  const vals = points.map((p) => p.net).filter((v) => v !== null && v !== undefined);
  if (vals.length < 2) return '<div class="empty">Needs a few scans.</div>';
  const lo = Math.min(0, ...vals);
  const hi = Math.max(0, ...vals);
  const span = hi - lo || 1;
  const W = 600;
  const H = 70;
  const xs = (i) => (i / (vals.length - 1)) * W;
  const ys = (v) => H - 6 - ((v - lo) / span) * (H - 12);
  const line = vals.map((v, i) => `${xs(i).toFixed(1)},${ys(v).toFixed(1)}`).join(' ');
  return `<svg class="spark" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" role="img" aria-label="Best net spread over the last ${vals.length} scans">
    <line x1="0" x2="${W}" y1="${ys(0)}" y2="${ys(0)}" stroke="#25385c" stroke-dasharray="4 4"/>
    <polyline points="${line}" fill="none" stroke="#14f195" stroke-width="2" vector-effect="non-scaling-stroke"/></svg>
    <div class="row spread hint"><span>${vals.length} scans</span><span class="num">low ${bps(Math.min(...vals))} · high ${bps(Math.max(...vals))}</span></div>`;
}

function renderMarkets() {
  const st = S.st;
  const b = st.board;
  const words = { OPPORTUNITY: 'Opportunity', THIN: 'Thin edge', NO_EDGE: 'No edge after fees', OFFLINE: 'Feeds offline' };
  if (!b) {
    $('#mk-verdict').innerHTML = '<div class="empty">No scan yet. Press Scan now — Scout also scans on its schedule.</div>';
  } else {
    const venues = Object.entries(b.venues)
      .map(([k, v]) => `<span class="chip" title="${esc(v.error || v.note || '')}"><span class="dot ${v.ok ? 'ok' : 'bad'}"></span>${esc(k)}${v.ms ? ` <span class="num faint">${v.ms}ms</span>` : ''}</span>`)
      .join(' ');
    $('#mk-verdict').innerHTML = `<div class="verdict"><span class="v v-${esc(b.verdict)}">${esc(words[b.verdict] || b.verdict)}</span>
      <div>${b.best ? `<div><b>${esc(b.best.coin)}</b>: buy on ${esc(b.best.buyVenue)} at <span class="num">${price(b.best.buyAsk)}</span>, sell on ${esc(b.best.sellVenue)} at <span class="num">${price(b.best.sellBid)}</span></div>
      <div class="dim">Net <span class="num ${b.best.netBps > 0 ? 'pos' : ''}">${bps(b.best.netBps)}</span> ≈ <span class="num">${aud(b.best.estAud)}</span> on ${aud(b.notionalAud)} · alert at ${bps(b.alertNetBps)}</div>` : '<div class="dim">Fewer than two venues answered.</div>'}
      <div class="hint">Scanned ${ago(b.at)}. Prices move while coins transfer between exchanges.</div></div></div>
      <div class="row" style="margin-top:12px">${venues}</div>`;
    $('#mk-table').innerHTML = b.rows.length
      ? `<table><thead><tr><th>Coin</th><th>Buy on</th><th class="r">Ask</th><th>Sell on</th><th class="r">Bid</th><th class="r">Gross</th><th class="r">Fees</th><th class="r">Net</th><th class="r">≈ on ${aud(b.notionalAud)}</th></tr></thead><tbody>${b.rows
          .map(
            (r) =>
              `<tr><td><b>${esc(r.coin)}</b></td><td>${esc(r.buyVenue)}</td><td class="r num">${price(r.buyAsk)}</td><td>${esc(r.sellVenue)}</td><td class="r num">${price(r.sellBid)}</td><td class="r num">${bps(r.grossBps)}</td><td class="r num dim">${r.feeBps.toFixed(1)}</td><td class="r num ${r.netBps > 0 ? 'pos' : 'neg'}">${bps(r.netBps)}</td><td class="r num">${aud(r.estAud)}</td></tr>`,
          )
          .join('')}</tbody></table>`
      : '<div class="empty">No coin was quoted on two venues this scan.</div>';
  }
  $('#mk-spark').innerHTML = spark(st.history || []);
  const brief = st.briefs[0];
  $('#mk-brief').innerHTML = brief
    ? `<p style="margin-top:0"><b>${esc(brief.headline)}</b></p>${brief.notes.length ? `<ul>${brief.notes.map((n) => `<li>${esc(n)}</li>`).join('')}</ul>` : ''}${brief.watch.length ? `<p class="dim" style="margin-bottom:0">Watch: ${brief.watch.map((w) => `<b>${esc(w.coin)}</b> — ${esc(w.why)}`).join('; ')}</p>` : ''}<p class="hint">${ago(brief.at)} · <span class="ai">written by ${esc(shortModel(brief.model))}</span></p>`
    : '<div class="empty">Scout writes a brief every half hour, and straight away when a spread clears your alert level.</div>';
  const f = st.settings.scout;
  $('#mk-fees').textContent = `Fees used (taker, bps): ${Object.entries(f.fees).map(([k, v]) => `${k} ${v}`).join(' · ')} · buffer ${f.bufferBps} bps. Binance quotes are USDT pairs; CoinSpot is converted from AUD at the live rate. Change these in Settings to match your fee tier.`;
}

// ── Pipeline ────────────────────────────────────────────────
function initPipeline(el) {
  el.innerHTML = `<h1>Pipeline</h1>
  <p class="lede">Add a lead → Closer writes the outreach → you send it and mark it. When a deal closes, mark it won with the invoice or receipt and it lands in the Ledger.</p>
  <div class="grid g2">
    <div><h2>Drafts to send</h2><div id="pl-drafts"></div></div>
    <div class="stack">
      <div class="panel"><h2>Add a lead</h2>
        <form id="lead-form" class="form">
          <label>Business *<input name="business" required placeholder="Smith & Co Lawyers"></label>
          <label>Contact person<input name="name" placeholder="Sarah Smith"></label>
          <label>Niche<input name="niche" placeholder="family law"></label>
          <label>Location<input name="location" placeholder="Richmond, VIC"></label>
          <label>Website<input name="website" placeholder="smithco.com.au"></label>
          <label>Email / phone / handle<input name="contact"></label>
          <label>Channel<select name="channel"><option value="email">Email</option><option value="phone">Phone</option><option value="instagram">Instagram</option><option value="linkedin">LinkedIn</option><option value="facebook">Facebook</option><option value="walk-in">Walk-in</option><option value="other">Other</option></select></label>
          <label>Offer<select name="offerId" id="lead-offer"></select></label>
          <label class="full">Notes for personalising<textarea name="notes" rows="2" placeholder="Their Google reviews mention slow replies…"></textarea></label>
          <div class="full row"><button class="btn primary">Add lead</button><span class="hint">Closer drafts it within a few minutes.</span></div>
        </form></div>
      <div><h2>Leads</h2><div id="pl-leads"></div></div>
    </div>
  </div>`;
  $('#lead-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const body = Object.fromEntries(new FormData(e.target));
    try {
      await api('/api/leads', { method: 'POST', body });
      e.target.reset();
      toast(`Lead added: ${body.business}`);
      scheduleRefresh();
    } catch (err) {
      toast(err.message, true);
    }
  });
  el.addEventListener('click', async (e) => {
    const b = e.target.closest('[data-act]');
    if (!b) return;
    const id = b.dataset.id;
    const draft = S.st.outbox.find((d) => d.id === id);
    try {
      switch (b.dataset.act) {
        case 'copy-msg':
          return copy(draft.message);
        case 'copy-subj':
          return copy(draft.subject);
        case 'copy-f1':
          return copy(draft.followup_1);
        case 'copy-f2':
          return copy(draft.followup_2);
        case 'sent':
        case 'skipped':
          await api(`/api/outbox/${id}`, { method: 'POST', body: { status: b.dataset.act } });
          toast(b.dataset.act === 'sent' ? 'Marked sent' : 'Skipped');
          break;
        case 'won': {
          const lead = S.st.leads.find((l) => l.id === id);
          const v = await ask(`Won: ${lead.business}`, [
            { name: 'amount', label: 'Amount received (A$)', type: 'number', step: '0.01', required: true },
            { name: 'ref', label: 'Receipt, invoice number or payment link', required: true, hint: 'Required. This is what makes the money count.' },
            { name: 'note', label: 'Note', value: `Won: ${lead.business}` },
          ], 'Log the win');
          if (!v) return;
          await api(`/api/leads/${id}/won`, { method: 'POST', body: v });
          toast('Win logged in the Ledger');
          break;
        }
        case 'reply': {
          const lead = S.st.leads.find((l) => l.id === id);
          const v = await ask(`${lead.business} replied`, [{ name: 'text', label: 'Paste what they wrote', type: 'textarea', placeholder: 'Thanks — what would the audit cost for two offices?' }], 'Draft my answer');
          if (!v || !v.text.trim()) return;
          await api(`/api/leads/${id}/reply`, { method: 'POST', body: { text: v.text } });
          toast('Supporter is drafting your answer — it’ll be in Mission Control');
          break;
        }
        case 'redraft':
          await api(`/api/leads/${id}/redraft`, { method: 'POST', body: {} });
          toast('Closer will rewrite it');
          break;
        case 'del-lead':
          if (!confirm('Delete this lead?')) return;
          await api(`/api/leads/${id}`, { method: 'DELETE' });
          break;
        default:
          return;
      }
      scheduleRefresh();
    } catch (err) {
      toast(err.message, true);
    }
  });
  el.addEventListener('change', async (e) => {
    if (!e.target.matches('select[data-stage]')) return;
    await api(`/api/leads/${e.target.dataset.stage}`, { method: 'PATCH', body: { stage: e.target.value } }).catch((err) => toast(err.message, true));
    scheduleRefresh();
  });
}

function renderPipeline() {
  const st = S.st;
  const sel = $('#lead-offer');
  const offerKey = st.settings.offers.map((o) => o.id).join('|');
  if (sel.dataset.key !== offerKey) {
    sel.innerHTML = st.settings.offers.map((o) => `<option value="${esc(o.id)}">${esc(o.name)}</option>`).join('');
    sel.dataset.key = offerKey;
  }
  const drafts = st.outbox.filter((d) => d.status === 'draft' || d.status === 'approved');
  keepOpen($('#pl-drafts'), () => {
    $('#pl-drafts').innerHTML = drafts.length
      ? drafts
          .map(
            (d) => `<div class="card">
          <div class="row spread"><b>${esc(d.business)}</b>${d.status === 'approved' ? '<span class="pill ok">approved — send it</span>' : '<span class="pill ai">AI draft · approve in Mission Control</span>'}</div>
          <div class="hint">${esc(d.offerName || '')} · ${esc(d.best_channel || d.channel || '')} · ${ago(d.createdAt)}</div>
          <h3 style="margin:10px 0 6px">${esc(d.subject)}</h3>
          <div class="msg">${esc(d.message)}</div>
          <details data-id="${d.id}" style="margin-top:8px"><summary class="dim">Follow-ups and angle</summary>
            <p class="hint">Angle: ${esc(d.personal_hook || '—')}</p>
            <div class="msg">${esc(d.followup_1)}</div><div class="row" style="margin:6px 0 10px"><button class="btn sm ghost" data-act="copy-f1" data-id="${d.id}">Copy follow-up 1</button></div>
            <div class="msg">${esc(d.followup_2)}</div><div class="row" style="margin-top:6px"><button class="btn sm ghost" data-act="copy-f2" data-id="${d.id}">Copy follow-up 2</button></div>
          </details>
          <div class="row" style="margin-top:10px"><button class="btn sm" data-act="copy-subj" data-id="${d.id}">Copy subject</button><button class="btn sm" data-act="copy-msg" data-id="${d.id}">Copy message</button><button class="btn sm primary" data-act="sent" data-id="${d.id}">Mark sent</button><button class="btn sm ghost" data-act="skipped" data-id="${d.id}">Skip</button></div>
        </div>`,
          )
          .join('')
      : '<div class="empty">No drafts waiting. Add a lead and Closer writes the first message.</div>';
  });
  const offerName = (id) => (st.settings.offers.find((o) => o.id === id) || {}).name || '—';
  const stages = ['new', 'drafted', 'sent', 'replied', 'won', 'lost'];
  $('#pl-leads').innerHTML = st.leads.length
    ? `<div class="tablewrap"><table><thead><tr><th>Business</th><th>Offer</th><th>Stage</th><th></th></tr></thead><tbody>${st.leads
        .map(
          (l) => `<tr><td><b>${esc(l.business)}</b>${l.score != null ? ` <span class="pill ${l.score >= 70 ? 'ok' : l.score >= 40 ? 'gold' : 'bad'}" title="${esc((l.qualReason || '') + (l.qualMissing ? ' · missing: ' + l.qualMissing : ''))}">${l.score}</span>` : ''}${l.name ? ` <span class="dim">· ${esc(l.name)}</span>` : ''}<div class="hint">${esc([l.niche, l.location].filter(Boolean).join(' · '))}</div></td>
        <td class="dim">${esc(offerName(l.offerId))}</td>
        <td><select data-stage="${l.id}">${stages.map((s) => `<option${s === l.stage ? ' selected' : ''}>${s}</option>`).join('')}</select></td>
        <td><div class="row" style="justify-content:flex-end">${l.stage !== 'won' ? `<button class="btn sm gold" data-act="won" data-id="${l.id}">Won…</button>` : '<span class="pill gold">won</span>'}<button class="btn sm ghost" data-act="reply" data-id="${l.id}" title="Paste what they wrote — Supporter drafts your answer">Reply…</button><button class="btn sm ghost" data-act="redraft" data-id="${l.id}" title="Ask Closer for a fresh draft">Redraft</button><button class="btn sm ghost danger" data-act="del-lead" data-id="${l.id}">Delete</button></div></td></tr>`,
        )
        .join('')}</tbody></table></div>`
    : '<div class="empty">No leads yet.</div>';
}

// ── Forge ───────────────────────────────────────────────────
function initForge(el) {
  el.innerHTML = `<h1>Forge</h1>
  <p class="lede">Queue an idea → Forge builds a Gumroad-ready kit: what's inside, how to build it, price, listing copy, FAQ and launch posts. Each kit is also saved as Markdown in the data/forge folder.</p>
  <div class="grid g2">
    <div class="panel"><h2>Queue an idea</h2>
      <form id="idea-form" class="form">
        <label class="full">Idea *<input name="name" required placeholder="AOS — Real Estate Agency Edition"></label>
        <label>Price hint (A$)<input name="priceHint" type="number" step="1" min="0"></label>
        <label>Notes<input name="notes" placeholder="who it's for, angle"></label>
        <div class="full row"><button class="btn primary">Queue it</button><button class="btn" type="button" data-act="forge-now">Build next kit now</button></div>
      </form></div>
    <div class="panel"><h2>Queue</h2><div id="fg-ideas"></div></div>
  </div>
  <h2 style="margin-top:20px">Kits</h2><div id="fg-kits"></div>`;
  $('#idea-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      await api('/api/forge/ideas', { method: 'POST', body: Object.fromEntries(new FormData(e.target)) });
      e.target.reset();
      toast('Idea queued');
      scheduleRefresh();
    } catch (err) {
      toast(err.message, true);
    }
  });
  el.addEventListener('click', async (e) => {
    const b = e.target.closest('[data-act]');
    if (!b) return;
    const id = b.dataset.id;
    const kit = S.st.forge.kits.find((k) => k.id === id);
    try {
      switch (b.dataset.act) {
        case 'forge-now':
          await api('/api/agents/forge/run', { method: 'POST', body: {} });
          toast('Forge queued');
          return;
        case 'del-idea':
          await api(`/api/forge/ideas/${id}`, { method: 'DELETE' });
          break;
        case 'copy-listing':
          return copy(kit.content.listing);
        case 'copy-post':
          return copy(kit.content.launch_posts[Number(b.dataset.i)]);
        case 'kit-status': {
          let body = { status: b.dataset.status };
          if (b.dataset.status === 'listed') {
            const v = await ask('Where is it listed?', [{ name: 'listingUrl', label: 'Gumroad (or store) link', value: kit.listingUrl || '', placeholder: 'https://…' }], 'Mark listed');
            if (!v) return;
            body = { ...body, ...v };
          }
          await api(`/api/forge/kits/${id}`, { method: 'PATCH', body });
          break;
        }
        case 'del-kit':
          if (!confirm('Delete this kit? The Markdown file stays in data/forge.')) return;
          await api(`/api/forge/kits/${id}`, { method: 'DELETE' });
          break;
        default:
          return;
      }
      scheduleRefresh();
    } catch (err) {
      toast(err.message, true);
    }
  });
}

function renderForge() {
  const st = S.st;
  const ideas = st.forge.ideas.filter((i) => i.status !== 'drafted');
  $('#fg-ideas').innerHTML = ideas.length
    ? `<ul class="feed">${ideas.map((i) => `<li style="grid-template-columns:1fr auto"><span>${esc(i.name)}${i.priceHint ? ` <span class="dim num">A$${esc(i.priceHint)}</span>` : ''} ${i.status === 'working' ? '<span class="pill ai">building now</span>' : ''}</span><button class="btn sm ghost danger" data-act="del-idea" data-id="${i.id}">Remove</button></li>`).join('')}</ul>`
    : '<div class="empty">Queue is empty.</div>';
  const pill = { drafted: 'ai', building: 'gold', built: 'gold', ready: 'gold', 'ship-ready': 'ok', listed: 'ok', retired: '' };
  keepOpen($('#fg-kits'), () => {
    $('#fg-kits').innerHTML = st.forge.kits.length
      ? st.forge.kits
          .map((k) => {
            const c = k.content || {};
            return `<details class="card kit" data-id="${k.id}"><summary><span><b>${esc(c.title || k.ideaName)}</b> <span class="dim">— ${esc(c.tagline || '')}</span></span><span class="row"><span class="num">${c.price_aud ? `A$${esc(c.price_aud)}` : ''}</span><span class="pill ${pill[k.status] || ''}">${esc(k.status)}</span><span class="hint">${ago(k.createdAt)}</span></span></summary>
          <div class="grid g2">
            <div class="stack">
              <div><h3>Who it's for</h3><div class="dim">${esc(c.who_for)}</div></div>
              <div><h3>Problem</h3><div class="dim">${esc(c.problem)}</div></div>
              <div><h3>What's inside</h3><ul>${(c.whats_inside || []).map((x) => `<li>${esc(x)}</li>`).join('')}</ul></div>
              <div><h3>Build it</h3><ol>${(c.build_steps || []).map((x) => `<li>${esc(x)}</li>`).join('')}</ol></div>
              <div class="hint">Price: A$${esc(c.price_aud ?? '?')} — ${esc(c.price_reason || '')}</div>
            </div>
            <div class="stack">
              <div><div class="row spread"><h3>Listing copy</h3><button class="btn sm" data-act="copy-listing" data-id="${k.id}">Copy</button></div><div class="msg">${esc(c.listing)}</div></div>
              <div><h3>FAQ</h3>${(c.faq || []).map((f) => `<p style="margin:4px 0"><b>${esc(f.q)}</b><br><span class="dim">${esc(f.a)}</span></p>`).join('')}</div>
              <div><h3>Launch posts</h3>${(c.launch_posts || []).map((p, i) => `<div class="msg" style="margin-bottom:6px">${esc(p)}</div><button class="btn sm ghost" data-act="copy-post" data-id="${k.id}" data-i="${i}">Copy post ${i + 1}</button>`).join('')}</div>
            </div>
          </div>
          ${k.listingUrl ? `<p>Listed: <a href="${esc(k.listingUrl)}" target="_blank" rel="noopener">${esc(k.listingUrl)}</a></p>` : ''}
          ${k.built && k.built.length ? `<div class="card" style="margin-top:10px"><b>Builder’s files</b>${k.built.map((f) => `<div class="hint">• ${esc(f.title)} — data/forge/${esc(f.file)} (${f.words} words)</div>`).join('')}${k.shipPack ? `<div class="hint pos">Ship pack: data/forge/${esc(k.shipPack)}/ — BUNDLE.md, LISTING.md, LAUNCH.md</div>` : ''}</div>` : ''}
          <div class="row" style="margin-top:12px"><a class="btn sm" href="/api/forge/kits/${k.id}/md" download>Download .md</a>
            <button class="btn sm" data-act="kit-status" data-status="building" data-id="${k.id}" title="Builder writes the product files">Build files</button>
            <button class="btn sm primary" data-act="kit-status" data-status="listed" data-id="${k.id}">Mark listed…</button>
            <button class="btn sm ghost" data-act="kit-status" data-status="retired" data-id="${k.id}">Retire</button>
            <button class="btn sm ghost danger" data-act="del-kit" data-id="${k.id}">Delete</button>
            <span class="hint">File: data/forge/${esc(k.file || '')} · <span class="ai">drafted by ${esc(shortModel(k.model))}</span></span></div>
        </details>`;
          })
          .join('')
      : '<div class="empty">No kits yet. Forge builds one from the queue on its schedule, or press “Build next kit now”.</div>';
  });
}

// ── Ledger ──────────────────────────────────────────────────
function initLedger(el) {
  const today = new Date().toISOString().slice(0, 10);
  el.innerHTML = `<div class="row spread"><div><h1>Ledger</h1><p class="lede">The only place money is real in YABBAI. Income needs a reference — a receipt link, invoice number or transaction signature — so the totals up top can be trusted.</p></div><a class="btn" href="/api/ledger.csv" download>Export CSV</a></div>
  <div class="grid g2">
    <div class="panel"><h2>Log money</h2>
      <form id="ledger-form" class="form">
        <label>Amount (A$) *<input name="amount" type="number" step="0.01" required placeholder="49.00"></label>
        <label>Date<input name="date" type="date" value="${today}"></label>
        <label>Source<select name="source"><option value="client">Client work</option><option value="product">Product sale</option><option value="flip">Crypto flip</option><option value="other">Other</option><option value="cost">Cost (negative)</option></select></label>
        <label>Came from<select name="agent"><option value="none">No agent</option><option value="closer">Closer (outreach)</option><option value="forge">Forge (product)</option><option value="scout">Scout (spread)</option></select></label>
        <label class="full">Reference *<input name="ref" placeholder="Gumroad receipt link, invoice #, Stripe payout id or tx signature"></label>
        <label class="full">Note<input name="note"></label>
        <label class="check full"><input type="checkbox" name="recurring" value="1"> Monthly retainer (counts toward MRR)</label>
        <div class="full row"><button class="btn gold">Log it</button><span class="hint">Costs: enter a negative amount; reference optional.</span></div>
      </form></div>
    <div class="panel"><h2>Totals</h2><div id="lg-totals"></div></div>
  </div>
  <h2 style="margin-top:20px">Entries</h2><div id="lg-table"></div>`;
  $('#ledger-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const body = Object.fromEntries(new FormData(e.target));
    try {
      await api('/api/ledger', { method: 'POST', body });
      e.target.reset();
      e.target.date.value = today;
      toast('Logged');
      scheduleRefresh();
    } catch (err) {
      toast(err.message, true);
    }
  });
  el.addEventListener('click', async (e) => {
    const b = e.target.closest('[data-act="del-entry"]');
    if (!b || !confirm('Remove this entry?')) return;
    await api(`/api/ledger/${b.dataset.id}`, { method: 'DELETE' }).catch((err) => toast(err.message, true));
    scheduleRefresh();
  });
}

function renderLedger() {
  const st = S.st;
  const t = st.ledgerTotals;
  const agentRows = ['closer', 'forge', 'scout', 'none'].map((a) => [a, t.byAgent[a] || 0]);
  const max = Math.max(1, ...agentRows.map(([, v]) => Math.abs(v)));
  const label = { closer: 'Closer', forge: 'Forge', scout: 'Scout', none: 'No agent' };
  $('#lg-totals').innerHTML = `<div class="kv" style="font-size:15px"><span>This month</span><b class="num" style="color:var(--gold)">${aud(t.month)}</b><span>Last 7 days</span><b class="num">${aud(t.week)}</b><span>All time</span><b class="num">${aud(t.all)}</b><span>Entries</span><b class="num">${t.count}</b></div>
    <h3 style="margin-top:16px">Where it came from</h3>${agentRows
      .map(([a, v]) => `<div class="row" style="gap:10px;margin:6px 0"><span style="width:80px" class="dim">${label[a]}</span><div class="bar" style="flex:1"><i style="width:${(Math.abs(v) / max) * 100}%;background:${v < 0 ? 'var(--red)' : 'var(--gold)'}"></i></div><span class="num" style="width:110px;text-align:right">${aud(v)}</span></div>`)
      .join('')}`;
  $('#lg-table').innerHTML = st.ledger.length
    ? `<div class="tablewrap"><table><thead><tr><th>Date</th><th class="r">Amount</th><th>Source</th><th>Agent</th><th>Reference</th><th>Note</th><th></th></tr></thead><tbody>${st.ledger
        .map((e) => {
          const ref = /^https?:\/\//.test(e.ref) ? `<a href="${esc(e.ref)}" target="_blank" rel="noopener">${esc(e.ref.slice(0, 48))}</a>` : esc(e.ref || '—');
          return `<tr><td class="num">${esc(e.date)}</td><td class="r num ${e.amount < 0 ? 'neg' : ''}">${aud(e.amount)}</td><td>${esc(e.source)}${e.recurring ? ' <span class="pill ok">monthly</span>' : ''}</td><td class="dim">${esc(e.agent)}</td><td style="max-width:280px;overflow-wrap:anywhere">${ref}</td><td class="dim">${esc(e.note)}</td><td><button class="btn sm ghost danger" data-act="del-entry" data-id="${e.id}">Remove</button></td></tr>`;
        })
        .join('')}</tbody></table></div>`
    : '<div class="empty">No entries yet. The first real sale or client payment goes here, with its receipt.</div>';
}

// ── Chat ────────────────────────────────────────────────────
const SUGGESTIONS = [
  ['How are we tracking?', 'verified money and today’s best moves', 'How are we tracking this month? Use the live state and give me the three highest-value moves for today.'],
  ['Work the pipeline', 'which drafts to send first', 'Which outreach drafts should I send first and why? Then tell me who to follow up.'],
  ['Read the market', 'is any spread worth it after fees?', 'Walk me through the current spread board. Is anything worth acting on after fees and transfer time?'],
  ['Ship a product', 'pick a kit and launch it today', 'Pick the Forge kit most likely to sell this week and give me a step-by-step plan to list it on Gumroad today.'],
];

function initChat(el) {
  el.innerHTML = `<div class="chat">
    <aside class="threads"><button class="btn primary" data-act="new-chat">New chat</button><div id="thread-list"></div></aside>
    <div class="convo">
      <div class="messages" id="messages"></div>
      <form class="composer" id="composer">
        <textarea id="prompt" rows="3" placeholder="Ask anything. Enter sends · Shift+Enter for a new line"></textarea>
        <div class="row spread">
          <div class="row">
            <select id="persona" title="Who answers"><option value="director">Director</option><option value="scout">Scout</option><option value="closer">Closer</option><option value="forge">Forge</option><option value="lite">Plain model</option></select>
            <select id="brain" title="Which brain answers"><option value="">Default brain</option><option value="local">Local 9B</option><option value="hf">HF 70B+</option></select>
            <label class="check" title="Give the model your live ledger, pipeline, kits and spreads"><input type="checkbox" id="ctx" checked> Live state</label>
            <label class="check" title="Let the model reason before answering (slower)"><input type="checkbox" id="think"> Think first</label>
          </div>
          <div class="row"><span class="hint" id="chat-model"></span><a class="btn sm ghost" id="owui-link" target="_blank" rel="noopener">Open WebUI ↗</a><button class="btn primary" id="send">Send</button></div>
        </div>
      </form>
    </div></div>`;
  $('#composer').addEventListener('submit', (e) => {
    e.preventDefault();
    if (S.streaming) S.streaming.abort();
    else sendChat();
  });
  $('#prompt').addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) {
      e.preventDefault();
      if (!S.streaming) sendChat();
    }
  });
  el.addEventListener('click', async (e) => {
    const b = e.target.closest('[data-act]');
    if (!b) return;
    if (b.dataset.act === 'new-chat') {
      S.thread = null;
      renderMessages();
      renderThreadList();
      $('#prompt').focus();
    }
    if (b.dataset.act === 'open-thread') await openThread(b.dataset.id);
    if (b.dataset.act === 'del-thread') {
      if (!confirm('Delete this chat?')) return;
      await api(`/api/threads/${b.dataset.id}`, { method: 'DELETE' });
      if (S.thread && S.thread.id === b.dataset.id) S.thread = null;
      await loadThreads();
      renderMessages();
    }
    if (b.dataset.act === 'suggest') {
      $('#prompt').value = b.dataset.text;
      sendChat();
    }
  });
}

async function loadThreads() {
  S.threads = await api('/api/threads').catch(() => []);
  renderThreadList();
}
function renderThreadList() {
  const list = $('#thread-list');
  if (!list) return;
  list.innerHTML = S.threads
    .map((t) => `<div class="row" style="flex-wrap:nowrap;gap:4px"><button class="t" data-act="open-thread" data-id="${t.id}" aria-current="${S.thread && S.thread.id === t.id}">${esc(t.title)}<small>${esc(t.persona)} · ${ago(t.updatedAt)}</small></button><button class="btn sm ghost" data-act="del-thread" data-id="${t.id}" aria-label="Delete chat" title="Delete">×</button></div>`)
    .join('') || '<p class="hint">Chats are saved on this machine.</p>';
}
async function openThread(id) {
  S.thread = await api(`/api/threads/${id}`);
  $('#persona').value = S.thread.persona || 'director';
  renderMessages();
  renderThreadList();
}

function msgHtml(m) {
  if (m.role === 'user') return `<div class="m user">${esc(m.content)}</div>`;
  const think = m.thinking ? `<details class="think"${m._live && !m.content ? ' open' : ''}><summary>Thinking</summary><div>${esc(m.thinking)}</div></details>` : '';
  const meta = m.error ? `<span class="neg">${esc(m.error)}</span>` : m.stats ? `${esc(m.stats.tokensPerSec ?? '?')} tokens/s · ${esc(m.stats.outputTokens)} tokens${m.stats.brain === 'hf' ? ` · HF ${esc(m.stats.model || '')}` : ''}` : m.stopped ? 'stopped' : '';
  return `<div class="m assistant">${think}<div class="body">${md(m.content || (m._live ? '…' : ''))}</div>${meta ? `<div class="meta">${meta}</div>` : ''}</div>`;
}

function renderMessages() {
  const box = $('#messages');
  if (!box) return;
  const msgs = S.thread ? S.thread.messages : [];
  if (!msgs.length) {
    box.innerHTML = `<div class="suggest">${SUGGESTIONS.map(([t, s, text]) => `<button data-act="suggest" data-text="${esc(text)}">${esc(t)}<small>${esc(s)}</small></button>`).join('')}</div>`;
    return;
  }
  box.innerHTML = msgs.map(msgHtml).join('');
  box.scrollTop = box.scrollHeight;
}

async function sendChat() {
  const input = $('#prompt');
  const text = input.value.trim();
  if (!text) return;
  input.value = '';
  if (!S.thread) S.thread = { id: null, title: 'New chat', messages: [] };
  S.thread.messages.push({ role: 'user', content: text });
  const live = { role: 'assistant', content: '', thinking: '', _live: true };
  S.thread.messages.push(live);
  renderMessages();
  const box = $('#messages');
  let nodeRef = box.lastElementChild;
  let frame = 0;
  const schedule = () => {
    if (frame) return;
    frame = requestAnimationFrame(() => {
      frame = 0;
      const nearBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 80;
      nodeRef.outerHTML = msgHtml(live);
      nodeRef = box.lastElementChild;
      if (nearBottom) box.scrollTop = box.scrollHeight;
    });
  };
  const ctrl = new AbortController();
  S.streaming = ctrl;
  $('#send').textContent = 'Stop';
  try {
    await streamPost(
      '/api/chat',
      { threadId: S.thread.id, message: text, persona: $('#persona').value, think: $('#think').checked, context: $('#ctx').checked, brain: $('#brain').value || undefined },
      (evt) => {
        if (evt.type === 'meta') {
          if (!S.thread.id) {
            S.thread.id = evt.threadId;
            S.thread.title = evt.title;
            loadThreads();
          }
          $('#chat-model').textContent = shortModel(evt.model);
        } else if (evt.type === 'token') live.content += evt.text;
        else if (evt.type === 'thinking') live.thinking += evt.text;
        else if (evt.type === 'done') live.stats = evt.stats;
        else if (evt.type === 'error') live.error = evt.message;
        schedule();
      },
      ctrl.signal,
    );
  } catch (err) {
    if (ctrl.signal.aborted) live.stopped = true;
    else live.error = err.message;
  } finally {
    live._live = false;
    S.streaming = null;
    $('#send').textContent = 'Send';
    if (frame) cancelAnimationFrame(frame);
    nodeRef.outerHTML = msgHtml(live);
    nodeRef = box.lastElementChild;
    loadThreads();
  }
}

// ── Model ───────────────────────────────────────────────────
function initModel(el) {
  el.innerHTML = `<h1>Model</h1>
  <p class="lede">Your AI runs on this machine through Ollama, pulled straight from Hugging Face. No message caps, no API bill, and it keeps working offline once downloaded.</p>
  <div class="grid g2">
    <div class="panel" id="md-status"></div>
    <div class="panel"><h2>Health check</h2><p class="hint" style="margin-top:0">Loads the model, measures speed and how much of it sits on the GPU.</p><button class="btn" data-act="doctor">Run checks</button><ul class="checks" id="md-checks" style="margin-top:10px"></ul></div>
  </div>
  <h2 style="margin-top:20px">Installed</h2><div id="md-installed"></div>
  <h2 style="margin-top:20px">Get a model from Hugging Face</h2><div class="grid g2" id="md-recs"></div>
  <div class="panel" style="margin-top:16px"><h3>Any GGUF on Hugging Face</h3>
    <form class="row" id="pull-form"><input id="pull-name" placeholder="hf.co/unsloth/Qwen3.5-9B-GGUF:Q4_K_M" style="flex:1;min-width:260px"><button class="btn primary">Pull</button></form>
    <p class="hint">Format: hf.co/&lt;user&gt;/&lt;repo&gt;:&lt;quant&gt;. Pick a quant whose file is smaller than your GPU memory.</p><div id="pull-custom"></div></div>`;
  $('#pull-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const name = $('#pull-name').value.trim();
    if (name) pull(name, 'pull-custom');
  });
  el.addEventListener('click', async (e) => {
    const b = e.target.closest('[data-act]');
    if (!b) return;
    try {
      if (b.dataset.act === 'pull') pull(b.dataset.model, `pull-${b.dataset.i}`);
      if (b.dataset.act === 'use') {
        await api('/api/model/select', { method: 'POST', body: { model: b.dataset.model } });
        toast(`Using ${shortModel(b.dataset.model)}`);
        await loadModel();
        pollHealth();
      }
      if (b.dataset.act === 'remove') {
        if (!confirm(`Remove ${b.dataset.model} from disk?`)) return;
        await api('/api/model/delete', { method: 'POST', body: { model: b.dataset.model } });
        await loadModel();
      }
      if (b.dataset.act === 'doctor') {
        b.disabled = true;
        $('#md-checks').innerHTML = '<li><span></span><span class="dim">Running… the first load can take a minute.</span><span></span></li>';
        const r = await api('/api/doctor?warm=1');
        $('#md-checks').innerHTML = r.checks.map((c) => `<li><span class="${c.ok ? 'pos' : 'neg'}">${c.ok ? '✓' : '✗'}</span><b>${esc(c.name)}</b><span>${esc(c.detail)}${c.fix ? `<br><span class="hint">${esc(c.fix)}</span>` : ''}</span></li>`).join('');
        b.disabled = false;
        loadModel();
      }
    } catch (err) {
      b.disabled = false;
      toast(err.message, true);
    }
  });
  el.addEventListener('change', async (e) => {
    if (e.target.id !== 'num-ctx') return;
    await api('/api/settings', { method: 'POST', body: { numCtx: Number(e.target.value) } }).then(() => toast('Context size saved')).catch((err) => toast(err.message, true));
  });
}

async function loadModel() {
  try {
    S.model = await api('/api/model');
  } catch (err) {
    toast(err.message, true);
    return;
  }
  renderModel();
  renderChips();
}

function gb(bytes) {
  return bytes ? `${(bytes / 1024 ** 3).toFixed(1)} GB` : '—';
}

function renderModel() {
  const m = S.model;
  if (!m || !$('#md-status')) return;
  const ctxOpts = [4096, 8192, 12288, 16384, 24576, 32768].map((n) => `<option value="${n}"${n === m.numCtx ? ' selected' : ''}>${n.toLocaleString()} tokens</option>`).join('');
  const run = m.running.find((r) => r.name === m.active);
  $('#md-status').innerHTML = `<h2>Status</h2><div class="kv" style="font-size:14.5px">
    <span>Ollama</span><b>${m.ollama.up ? `v${esc(m.ollama.version)} · ${esc(m.ollama.url)}` : `<span class="neg">not reachable</span> — run START-YABBAI`}</b>
    <span>Active model</span><b>${m.active ? esc(m.active) : '<span class="neg">none installed</span>'}</b>
    <span>On GPU</span><b>${run ? `${run.gpuPct}% of ${gb(run.size)}` : 'not loaded right now'}</b>
    ${m.install ? `<span>This machine</span><b>${esc(m.install.hardware?.gpu ? `${m.install.hardware.gpu.name} · ${Math.round(m.install.hardware.gpu.vramMB / 1024)} GB VRAM` : m.install.hardware?.apple ? 'Apple Silicon' : 'CPU only')} · ${esc(m.install.hardware?.ramGB)} GB RAM</b>` : ''}
    </div><label style="margin-top:12px">Context size (memory per chat)<select id="num-ctx">${ctxOpts}</select></label><p class="hint">8,192 keeps a 9B model fully on an 8 GB GPU. Bigger contexts spill into RAM and slow down.</p>`;
  $('#md-installed').innerHTML = m.installed.length
    ? `<div class="tablewrap"><table><thead><tr><th>Model</th><th>Size</th><th>Quant</th><th></th></tr></thead><tbody>${m.installed
        .map((x) => `<tr><td><b>${esc(x.name)}</b><div class="hint">${esc([x.family, x.params].filter(Boolean).join(' · '))}</div></td><td class="num">${gb(x.size)}</td><td class="num">${esc(x.quant || '')}</td><td><div class="row" style="justify-content:flex-end">${x.name === m.active ? '<span class="pill ok">active</span>' : `<button class="btn sm" data-act="use" data-model="${esc(x.name)}">Use</button>`}<button class="btn sm ghost danger" data-act="remove" data-model="${esc(x.name)}">Remove</button></div></td></tr>`)
        .join('')}</tbody></table></div>`
    : '<div class="empty">Nothing installed yet. Pull a model below — the 9B is the right pick for an 8 GB GPU.</div>';
  const have = new Set(m.installed.map((x) => x.name));
  $('#md-recs').innerHTML = m.recommended
    .map((r, i) => `<div class="card"><div class="row spread"><b>${esc(r.label)}</b><span class="num dim">${esc(r.size)}</span></div><div class="hint num">${esc(r.model)}</div><p class="dim" style="margin:6px 0">${esc(r.note)}. Fits: ${esc(r.fit)}.</p>
      <div class="row">${have.has(r.model) ? '<span class="pill ok">installed</span>' : `<button class="btn sm primary" data-act="pull" data-i="${i}" data-model="${esc(r.model)}">Pull</button>`}</div><div id="pull-${i}"></div></div>`)
    .join('');
}

async function pull(model, slot) {
  const el = $(`#${slot}`);
  if (S.pulls[model]) return toast('Already downloading');
  S.pulls[model] = true;
  el.innerHTML = '<div class="bar" style="margin-top:10px"><i></i></div><div class="hint" data-status>Starting…</div>';
  try {
    let failed = null;
    await streamPost('/api/model/pull', { model }, (evt) => {
      if (evt.type === 'progress') {
        const pct = evt.total ? Math.round((evt.completed / evt.total) * 100) : null;
        if (pct !== null) $('i', el).style.width = `${pct}%`;
        $('[data-status]', el).textContent = `${evt.status}${pct !== null ? ` · ${pct}% of ${gb(evt.total)}` : ''}`;
      }
      if (evt.type === 'error') failed = evt.message;
    });
    if (failed) throw new Error(failed);
    el.innerHTML = '<div class="hint pos">Ready.</div>';
    toast(`${shortModel(model)} is ready`);
    loadModel();
    pollHealth();
  } catch (err) {
    el.innerHTML = `<div class="hint neg">${esc(err.message)}</div>`;
  } finally {
    delete S.pulls[model];
  }
}

// ── Classic ─────────────────────────────────────────────────
function initClassic(el) {
  el.innerHTML = `<div class="row spread"><div><h1>Classic v11</h1><p class="lede">Your original YABBAI FLASH v11 cockpit with four fixes: its AI brief runs on your local model, simulated trade “wins” no longer count as real money, its demo leads and drafts are labelled as demos, and mock and real balances are kept apart. Real money lives in Ledger.</p></div><a class="btn" href="/classic/" target="_blank" rel="noopener">Open full screen ↗</a></div>
  <iframe class="classic" src="/classic/" title="YABBAI FLASH v11"></iframe>`;
}

// ── Settings ────────────────────────────────────────────────
function offerFields(o, i) {
  const f = (name, label, type = 'input') =>
    type === 'textarea' ? `<label class="full">${label}<textarea data-o="${i}" data-k="${name}" rows="2">${esc(o[name])}</textarea></label>` : `<label>${label}<input data-o="${i}" data-k="${name}" value="${esc(o[name])}"></label>`;
  return `<fieldset class="card form" style="margin:0 0 10px"><legend class="dim" style="padding:0 6px">Offer ${i + 1}</legend><input type="hidden" data-k="id" value="${esc(o.id || '')}">
    ${f('name', 'Name')}${f('audience', 'Who it’s for')}${f('promise', 'What they get', 'textarea')}${f('price', 'Price')}${f('cta', 'Call to action')}${f('proof', 'Proof (real results only)', 'textarea')}${f('link', 'Link')}
    <div class="full"><button class="btn sm ghost danger" type="button" data-act="del-offer" data-i="${i}">Remove offer</button></div></fieldset>`;
}

async function renderSettings() {
  const el = sec('settings');
  const s = S.st.settings;
  const sc = s.scout;
  const coins = ['BTC', 'ETH', 'SOL', 'XRP', 'ADA', 'AVAX', 'LINK', 'DOGE'];
  el.innerHTML = `<h1>Settings</h1><p class="lede">Everything is stored on this machine in the data folder: <span class="num">${esc(S.st.dataDir)}</span></p>
  <div class="grid g2">
    <div class="stack">
      <div class="panel"><h2>What Closer sells</h2><p class="hint" style="margin-top:0">Closer only claims what's written here. Add real proof (results, testimonials) when you have it.</p><div id="offers">${s.offers.map(offerFields).join('')}</div>
        <div class="row"><button class="btn sm" data-act="add-offer">Add offer</button><button class="btn sm primary" data-act="save-offers">Save offers</button></div></div>
      <div class="panel"><h2>Voice</h2><div class="form">
        <label>Sign outreach as<input id="signoff" value="${esc(s.signoff)}" placeholder="Your first name"></label>
        <label>Model temperature<input id="temperature" type="number" min="0" max="1.5" step="0.1" value="${esc(s.temperature)}"></label>
        <label class="full">Standing notes for the Director<textarea id="notes" rows="4" placeholder="Goals, rules, what to focus on this month…">${esc(s.directorNotes)}</textarea></label>
        <div class="full"><button class="btn sm primary" data-act="save-voice">Save</button></div></div></div>
    </div>
    <div class="stack">
      <div class="panel"><h2>Scout</h2><div class="form">
        <div class="full"><span class="hint">Coins</span><div class="row">${coins.map((c) => `<label class="check"><input type="checkbox" data-coin="${c}"${sc.coins.includes(c) ? ' checked' : ''}> ${c}</label>`).join('')}</div></div>
        ${Object.keys(sc.fees).map((v) => `<label><span><input type="checkbox" data-venue="${v}"${sc.venues[v] ? ' checked' : ''}> ${v} taker fee (bps)</span><input type="number" min="0" max="500" step="1" data-fee="${v}" value="${esc(sc.fees[v])}"></label>`).join('')}
        <label>Transfer + slippage buffer (bps)<input id="buffer" type="number" min="0" step="1" value="${esc(sc.bufferBps)}"></label>
        <label>Alert when net ≥ (bps)<input id="alert" type="number" min="1" step="1" value="${esc(sc.alertNetBps)}"></label>
        <label>Example trade size (A$)<input id="notional" type="number" min="10" step="10" value="${esc(sc.notionalAud)}"></label>
        <div class="full"><button class="btn sm primary" data-act="save-scout">Save</button> <span class="hint">100 bps = 1%.</span></div></div></div>
      <div class="panel" id="connect"><h2>Connect</h2><p class="dim">Loading…</p></div>
    </div>
  </div>`;
  el.onclick = async (e) => {
    const b = e.target.closest('[data-act]');
    if (!b) return;
    const offers = () =>
      $$('#offers fieldset').map((fs) => Object.fromEntries($$('[data-k]', fs).map((i) => [i.dataset.k, i.value])));
    try {
      if (b.dataset.act === 'add-offer') {
        const list = offers();
        list.push({ name: '', audience: '', promise: '', price: '', proof: '', cta: '', link: '' });
        $('#offers').innerHTML = list.map(offerFields).join('');
        return;
      }
      if (b.dataset.act === 'del-offer') {
        const list = offers();
        list.splice(Number(b.dataset.i), 1);
        $('#offers').innerHTML = list.map(offerFields).join('');
        return;
      }
      if (b.dataset.act === 'save-offers') {
        await api('/api/settings', { method: 'POST', body: { offers: offers().map((o) => ({ ...o, id: o.id || o.name })) } });
      }
      if (b.dataset.act === 'save-voice') await api('/api/settings', { method: 'POST', body: { signoff: $('#signoff').value, temperature: Number($('#temperature').value), directorNotes: $('#notes').value } });
      if (b.dataset.act === 'save-scout') {
        await api('/api/settings', {
          method: 'POST',
          body: {
            scout: {
              coins: $$('[data-coin]').filter((c) => c.checked).map((c) => c.dataset.coin),
              venues: Object.fromEntries($$('[data-venue]').map((c) => [c.dataset.venue, c.checked])),
              fees: Object.fromEntries($$('[data-fee]').map((c) => [c.dataset.fee, Number(c.value)])),
              bufferBps: Number($('#buffer').value),
              alertNetBps: Number($('#alert').value),
              notionalAud: Number($('#notional').value),
            },
          },
        });
      }
      if (b.dataset.act === 'reveal') $('#token').classList.toggle('show');
      if (b.dataset.act === 'copy') return copy(b.dataset.text);
      if (b.dataset.act.startsWith('save')) {
        toast('Saved');
        await refresh();
      }
    } catch (err) {
      toast(err.message, true);
    }
  };
  try {
    const c = await api('/api/connect');
    const ts = JSON.stringify([c.toolServer], null, 2);
    const mcp = JSON.stringify(c.mcpClientConfig, null, 2);
    $('#connect').innerHTML = `<h2>Connect</h2>
      <p class="dim" style="margin-top:0">START-YABBAI wires Open WebUI to YABBAI automatically on its first launch. These are here if you connect something else, or set it up by hand.</p>
      <div class="kv" style="font-size:14px;margin-bottom:10px"><span>Open WebUI</span><b><a href="${esc(c.openwebuiUrl)}" target="_blank" rel="noopener">${esc(c.openwebuiUrl)}</a></b>
      <span>OpenAI-style URL</span><b class="num">${esc(c.openaiBase)}</b><span>Tool server</span><b class="num">${esc(c.openapiUrl)}</b><span>MCP</span><b class="num">${esc(c.mcpUrl)}</b>
      <span>Token</span><b><span class="num secret" id="token">${esc(c.token)}</span> <button class="btn sm ghost" data-act="reveal">Show</button> <button class="btn sm ghost" data-act="copy" data-text="${esc(c.token)}">Copy</button></b></div>
      <div class="row"><button class="btn sm" data-act="copy" data-text="${esc(ts)}">Copy Open WebUI tool-server JSON</button><button class="btn sm" data-act="copy" data-text="${esc(mcp)}">Copy MCP client config</button></div>
      <p class="hint">Exposing YABBAI through a tunnel (e.g. cloudflared)? Only the token unlocks it: open <span class="num">/login?token=…</span> on the tunnel address once per device. Never share the token.</p>`;
  } catch (err) {
    $('#connect').innerHTML = `<h2>Connect</h2><p class="dim">${esc(err.message)}</p>`;
  }
}

// ── boot ────────────────────────────────────────────────────
const VIEWS = {
  agents: { init: initAgents, render: renderAgents },
  markets: { init: initMarkets, render: renderMarkets },
  pipeline: { init: initPipeline, render: renderPipeline },
  forge: { init: initForge, render: renderForge },
  ledger: { init: initLedger, render: renderLedger },
  chat: {
    init: initChat,
    render: () => {
      const link = $('#owui-link');
      if (link && S.st) link.href = S.st.openwebuiUrl;
    },
    onShow: () => {
      loadThreads();
      if (!S.streaming) renderMessages();
    },
  },
  model: { init: initModel, render: () => {}, onShow: () => loadModel() },
  classic: { init: initClassic, render: () => {} },
  settings: { init: () => {}, render: () => {}, onShow: () => S.st && renderSettings() },
};

async function boot() {
  $$('#rail button').forEach((b) => b.addEventListener('click', () => show(b.dataset.view)));
  $('#autopilot').addEventListener('click', async () => {
    const on = $('#autopilot').getAttribute('aria-pressed') !== 'true';
    try {
      await api('/api/autopilot', { method: 'POST', body: { on } });
      toast(on ? 'Autopilot on — agents run on their schedules' : 'Autopilot off — agents only run when you press Run');
      refresh();
    } catch (err) {
      toast(err.message, true);
    }
  });
  try {
    await refresh();
  } catch (err) {
    toast(`Engine not reachable: ${err.message}`, true);
  }
  const start = (location.hash || '').slice(1);
  show(VIEWS[start] ? start : 'cosmos');
  pollHealth();
  pollModel();
  setInterval(pollHealth, 15000);
  setInterval(pollModel, 60000);
  setInterval(() => {
    if (S.view === 'agents' && S.st) renderAgents(); // keeps "next run" countdowns fresh
  }, 30000);
  connectEvents();
}
window.addEventListener('hashchange', () => {
  const v = location.hash.slice(1);
  if (VIEWS[v] && v !== S.view) show(v);
});
// boot() is called by v13.js
