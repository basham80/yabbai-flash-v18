'use strict';
/* YABBAI v13 — the YABBAI FLASH cockpit surfaces, wired to real data only. Loaded after app.js. */
const ORDER12 = ['scout', 'qualifier', 'closer', 'caller', 'builder', 'shipper', 'supporter', 'diagnost', 'configurator', 'auditor', 'treasurer', 'forge'];
const ICON = { scout: '🔭', qualifier: '🎯', closer: '✉️', caller: '📞', builder: '🔨', shipper: '🚀', supporter: '🛟', diagnost: '🩺', configurator: '🧩', auditor: '🛡️', treasurer: '💰', forge: '⚒️' };
const ROLE = {
  scout: 'Live order books → spread board and brief',
  qualifier: 'Scores new leads 0–100 for fit',
  closer: 'Writes outreach for qualified leads',
  caller: 'Follow-ups and call scripts for quiet leads',
  builder: 'Writes the real product files for kits you’re building',
  shipper: 'Packs approved kits: bundle, listing, launch plan',
  supporter: 'Drafts replies when a lead writes back',
  diagnost: 'Health: model, GPU, feeds, deep brain, disk',
  configurator: 'Spots settings that weaken your results',
  auditor: 'Ledger and queue hygiene: duplicates, stale items',
  treasurer: 'Splits verified income by the 30% treasury law',
  forge: 'Turns ideas into Gumroad-ready kits',
};
const EVERY = [5, 10, 15, 30, 60, 180, 360, 720, 1440];
const POOLS = [
  ['treasury', 'TREASURY', '30% minimum · untouchable'],
  ['reserve', 'RESERVE', 'Safety buffer'],
  ['reinvest', 'REINVEST', 'Tools, ads, growth'],
  ['pay', 'PAY YOURSELF', 'Your income'],
  ['fuel', 'TRADING FUEL', 'Capital for real flips'],
];
const fmtMin = (m) => (m < 60 ? `${m} min` : `${m / 60} h`);

// ── header, vault, badges ───────────────────────────────────
function renderTop() {
  const st = S.st;
  if (!st) return;
  $('#m-total').textContent = aud(st.ledgerTotals.all);
  $('#m-total').title = `${st.ledgerTotals.count} ledger entries with receipts · this month ${aud(st.ledgerTotals.month)}`;
  $('#m-mrr').textContent = aud(st.mrr.amount);
  $('#m-mrr').title = `${st.mrr.count} monthly retainer payment(s) logged in the last 31 days`;
  const q = st.queue.length;
  $('#m-queue').textContent = `${q} Pending`;
  $('#m-queue').className = q ? 'num warnc' : 'num';
  $('#autopilot').setAttribute('aria-pressed', String(!!st.settings.autopilot));
  const v = st.vault;
  const vb = $('#vault-btn');
  vb.textContent = !v.set ? '🔓 VAULT · NO PIN' : v.open ? '🔓 VAULT OPEN' : '🔒 VAULT SEALED';
  vb.className = `lane vault ${!v.set ? '' : v.open ? 'open' : 'sealed'}`;
  const b = st.brains || {};
  $('#brain-chip').textContent = `BRAIN: ${b.chat === 'hf' ? 'HF 70B+' : 'LOCAL'} · AGENTS: ${b.agents === 'hf' ? 'HF 70B+' : 'LOCAL'}`;
  const set = (id, n) => {
    const e = $(id);
    if (!e) return;
    e.hidden = !n;
    e.textContent = n;
  };
  set('#b-queue', q);
  set('#b-kits', st.forge.kits.filter((k) => !['retired', 'listed'].includes(k.status)).length);
  set('#b-findings', st.findings.filter((f) => f.status === 'open').length);
}

async function vaultDialog() {
  const v = S.st.vault;
  try {
    if (!v.set) {
      const r = await ask('Set a Director vault PIN', [{ name: 'pin', label: 'New PIN (4–12 digits)', type: 'password', required: true, hint: 'Money actions — approving splits, payouts, logging deposits, deleting ledger entries — will need it. Stays unlocked 30 minutes.' }], 'Set PIN');
      if (r) await api('/api/vault/pin', { method: 'POST', body: { pin: r.pin } });
    } else if (!v.open) {
      const r = await ask('Unseal the Director vault', [{ name: 'pin', label: 'PIN', type: 'password', required: true }], 'Unlock');
      if (r) await api('/api/vault/unlock', { method: 'POST', body: { pin: r.pin } });
    } else if (await confirmBox('Seal the vault now?', 'Seal')) await api('/api/vault/lock', { method: 'POST', body: {} });
    await refresh();
  } catch (err) {
    toast(err.message, true);
  }
}
async function withVault(fn) {
  try {
    return await fn();
  } catch (err) {
    if (/vault is sealed/i.test(err.message)) {
      await vaultDialog();
      if (S.st.vault.open) return fn();
    }
    throw err;
  }
}
async function confirmBox(text, okLabel = 'Yes') {
  return (await ask(text, [], okLabel)) !== null;
}

// ── COSMOS ──────────────────────────────────────────────────
function initCosmos(el) {
  el.innerHTML = `<div class="grid cosmos">
    <div class="panel"><div class="row spread"><h2>Money spine</h2><span class="hint">Moved splits of verified income · gold = real money</span></div><div class="pools" id="cz-pools"></div><div class="pulse" id="cz-pulse"></div></div>
    <div class="panel"><div class="row spread"><h2>Agent clan</h2><button class="btn sm" data-go="agents">Agent Hub</button></div><div class="clan" id="cz-clan"></div><div class="lastact" id="cz-last"></div></div>
  </div>
  <div class="panel" style="margin-top:16px"><div class="row spread"><h2>Live cockpit telemetry</h2><span class="hint">latest events</span></div><ul class="feed tele" id="cz-tele"></ul></div>`;
  el.addEventListener('click', (e) => {
    const b = e.target.closest('[data-go]');
    if (b) show(b.dataset.go);
  });
}
function renderCosmos() {
  const st = S.st;
  const p = st.pools;
  $('#cz-pools').innerHTML =
    POOLS.map(([k, name, sub]) => {
      const x = p[k];
      const extra = k === 'pay' ? ` · A$${(x.available || 0).toFixed(2)} available` : '';
      return `<div class="pool"><div class="pn">${name} <span>${st.spine[k]}%</span></div><div class="pv num">${aud(x.executed)}</div><div class="ps">${x.pending ? `+${aud(x.pending)} waiting for approval` : esc(sub)}${extra}</div></div>`;
    }).join('') +
    `<div class="pool sol"><div class="pn">SOL VAULT</div><div class="pv num">${p.sol.sol != null ? `${p.sol.sol.toFixed(4)} SOL` : '—'}</div><div class="ps">${p.sol.address ? (p.sol.aud != null ? `≈ ${aud(p.sol.aud)} · on-chain, read-only` : 'on-chain balance') : 'Set your address in Payout Bridge'}</div></div>`;
  const ps = st.loop.paper;
  $('#cz-pulse').innerHTML = `<span>Live edge pulse:</span> <b class="${ps.todayAud >= 0 ? 'pos' : 'neg'}">PAPER ${ps.todayAud >= 0 ? '+' : ''}${aud(ps.todayAud)} today</b> <span class="sep">|</span> <b class="${st.queue.length ? 'warnc' : ''}">${st.queue.length} awaiting the Director</b> <span class="sep">|</span> <span>MRR ${aud(st.mrr.amount)}</span>`;
  $('#cz-clan').innerHTML = ORDER12.map((id) => {
    const a = st.agents[id];
    const dot = !a.enabled ? '' : a.running || a.status === 'running' ? 'busy' : a.status === 'error' ? 'bad' : 'ok';
    return `<button class="clanc" data-go="agents" title="${esc(ROLE[id])}"><span class="dot ${dot}"></span><span class="ci">${ICON[id]}</span><span class="cn">${esc(a.name.toUpperCase())}</span><span class="cc">${a.runs || 0} runs</span></button>`;
  }).join('');
  const agentKinds = new Set([...ORDER12, 'closer', 'paper', 'autopilot']);
  const last = st.activity.find((x) => agentKinds.has(x.kind));
  $('#cz-last').innerHTML = last ? `<span class="hint">LAST CLAN ACTION</span><div><b class="gold">[${esc(last.kind.toUpperCase())}]</b> ${esc(last.text)}</div>` : '';
  $('#cz-tele').innerHTML = st.activity.slice(0, 12).map((a) => `<li><time>${hhmm(a.at)}</time><span><b class="k-${esc(a.kind)}">[${esc(a.kind.toUpperCase())}]</b> ${esc(a.text)}</span></li>`).join('') || '<li><span></span><span class="dim">No events yet.</span></li>';
}

// ── MISSION CONTROL ─────────────────────────────────────────
function initMission(el) {
  el.innerHTML = `<div class="grid g2">
    <div class="panel"><div class="row spread"><h2>Executive posture</h2><button class="btn sm primary" data-act="brief">Brief me</button></div><div id="mc-brief"></div></div>
    <div class="panel"><h2>Today’s operator missions</h2><div id="mc-moves"></div></div>
  </div>
  <div class="panel" style="margin-top:16px"><div class="row spread"><h2>Lead pipeline funnel</h2><button class="btn sm" data-go="pipeline">Income Core</button></div><div class="funnel" id="mc-funnel"></div></div>
  <div class="row spread" style="margin-top:20px"><h2 style="margin:0">Approval queue (Director governance)</h2><span class="hint" id="mc-qcount"></span></div>
  <div id="mc-queue"></div>
  <h2 style="margin-top:20px">Authorized — ready for you to send</h2><div id="mc-ready"></div>`;
  el.addEventListener('click', async (e) => {
    const go = e.target.closest('[data-go]');
    if (go) return show(go.dataset.go);
    const b = e.target.closest('[data-act],[data-q]');
    if (!b) return;
    try {
      if (b.dataset.act === 'brief') {
        b.disabled = true;
        $('#mc-brief').innerHTML = '<p class="dim">Thinking…</p>';
        await api('/api/brief', { method: 'POST', body: {} });
        b.disabled = false;
        return refresh();
      }
      if (b.dataset.act === 'copy') return copy(b.dataset.text);
      if (b.dataset.q) {
        const [kind, id, action] = b.dataset.q.split('|');
        let extra = {};
        if (action === 'listed') {
          const v = await ask('Where is it listed?', [{ name: 'listingUrl', label: 'Gumroad (or store) link', placeholder: 'https://…' }], 'Mark listed');
          if (!v) return;
          extra = v;
        }
        if (action === 'paid') {
          const v = await ask('Payout done?', [{ name: 'ref', label: 'Bank / wallet reference (optional)' }], 'Mark paid');
          if (!v) return;
          extra = v;
        }
        if (action === 'log') {
          const item = S.st.queue.find((x) => x.id === id);
          const dep = S.st.deposits.find((x) => x.id === id) || {};
          const v = await ask(item ? item.title : 'Log deposit', [{ name: 'amount', label: 'Amount in A$', type: 'number', step: '0.01', value: dep.aud || '', required: true }, { name: 'source', label: 'Source (client, product, flip or other)', value: 'other' }, { name: 'note', label: 'Note', value: `On-chain deposit ${dep.sol || ''} SOL` }], 'Log as income');
          if (!v) return;
          extra = v;
        }
        await withVault(() => api(`/api/queue/${kind}/${id}`, { method: 'POST', body: { action, ...extra } }));
        toast('Done');
        scheduleRefresh();
      }
    } catch (err) {
      b.disabled = false;
      toast(err.message, true);
    }
  });
}
function renderMission() {
  const st = S.st;
  $('#mc-brief').innerHTML = st.brief ? `<div class="m assistant"><div class="body">${md(st.brief.text)}</div><div class="meta">${ago(st.brief.at)} · ${st.brief.brain === 'hf' ? 'Hugging Face 70B+' : 'local brain'}</div></div>` : '<div class="empty">Press “Brief me” for a posture read built only from your verified numbers.</div>';
  const mv = moves(st);
  $('#mc-moves').innerHTML = mv.length ? mv.map(([t, view, why]) => `<div class="card"><div class="row spread"><b>${esc(t)}</b><button class="btn sm" data-go="${view}">Open</button></div><div class="dim" style="font-size:14px">${esc(why)}</div></div>`).join('') : '<div class="empty">Nothing urgent.</div>';
  const c = { new: 0, drafted: 0, sent: 0, replied: 0, won: 0, lost: 0 };
  for (const l of st.leads) c[l.stage] = (c[l.stage] || 0) + 1;
  $('#mc-funnel').innerHTML = Object.entries(c).map(([k, v]) => `<div><b class="num">${v}</b><span>${k.toUpperCase()}</span></div>`).join('') + `<div><b class="num gold">${aud(st.ledgerTotals.byAgent.closer || 0)}</b><span>WON (VERIFIED)</span></div>`;
  $('#mc-qcount').textContent = `${st.queue.length} item${st.queue.length === 1 ? '' : 's'} waiting${st.vault.set && !st.vault.open ? ' · money actions need the vault PIN' : ''}`;
  $('#mc-queue').innerHTML = st.queue.length
    ? st.queue.map((q) => `<div class="card qitem"><div class="row spread"><div class="row" style="gap:8px"><span class="risk ${q.risk}">${q.risk === 'high' ? 'HIGH RISK' : q.risk === 'med' ? 'MED RISK' : 'LOW RISK'}</span><span class="hint">Agent: ${esc(q.agent)}</span><b>${esc(q.title)}</b>${q.money && st.vault.set && !st.vault.open ? '<span class="hint">🔒</span>' : ''}</div><span class="hint">${ago(q.createdAt)}</span></div><div class="row spread" style="align-items:flex-start;margin-top:8px"><div class="msg qbody">${esc(q.body)}</div><div class="qacts">${q.actions.map((a) => `<button class="btn sm ${a.style === 'gold' ? 'gold' : a.style === 'danger' ? 'ghost danger' : ''}" data-q="${q.kind}|${q.id}|${a.act}">${esc(a.label)}</button>`).join('')}</div></div></div>`).join('')
    : '<div class="empty">Queue clear. Agents put drafts, splits, deposits and findings here for your sign-off.</div>';
  const ready = [
    ...st.outbox.filter((d) => d.status === 'approved').map((d) => ({ kind: 'draft', id: d.id, who: d.business, what: 'Outreach', text: `${d.subject}\n\n${d.message}`, done: null })),
    ...st.followups.filter((f) => f.status === 'approved').map((f) => ({ kind: 'followup', id: f.id, who: f.business, what: 'Follow-up', text: f.message, script: f.script, done: 'done' })),
    ...st.replies.filter((r) => r.status === 'approved').map((r) => ({ kind: 'reply', id: r.id, who: r.business, what: 'Reply', text: r.draft, done: 'done' })),
  ];
  $('#mc-ready').innerHTML = ready.length
    ? ready.map((r) => `<div class="card"><div class="row spread"><b>${esc(r.what)} → ${esc(r.who)}</b><div class="row"><button class="btn sm" data-act="copy" data-text="${esc(r.text)}">Copy</button>${r.script ? `<button class="btn sm ghost" data-act="copy" data-text="${esc(r.script)}">Copy call script</button>` : ''}${r.done ? `<button class="btn sm primary" data-q="${r.kind}|${r.id}|done">Mark sent</button>` : '<button class="btn sm" data-go="pipeline">Send from Income Core</button>'}</div></div><div class="msg" style="margin-top:8px">${esc(r.text)}</div></div>`).join('')
    : '<div class="empty">Nothing authorized and unsent.</div>';
}

// ── MONEY DESK ──────────────────────────────────────────────
function initMoney(el) {
  el.innerHTML = `<h1>The money spine — 30% treasury law</h1>
  <p class="lede">Every dollar of verified income (Ledger, with a receipt) gets split by these percentages. Treasurer proposes each split; you move the money between your accounts and approve it in Mission Control. YABBAI never moves money itself.</p>
  <div class="grid g2">
    <div class="panel"><h2>Split rules</h2><div class="form" id="md-spine"></div><div class="row" style="margin-top:10px"><button class="btn sm primary" data-act="spine">Save split</button><span class="hint">Treasury ≥ 30%. Total must be 100%.</span></div></div>
    <div class="panel"><h2>Recurring revenue</h2><div id="md-mrr"></div></div>
  </div>
  <h2 style="margin-top:20px">Pools</h2><div class="tablewrap" id="md-pools"></div>
  <h2 style="margin-top:20px">Recent splits</h2><div id="md-allocs"></div>`;
  el.addEventListener('click', async (e) => {
    const b = e.target.closest('[data-act]');
    if (!b) return;
    if (b.dataset.act === 'spine') {
      const body = Object.fromEntries($$('#md-spine input').map((i) => [i.name, Number(i.value)]));
      try {
        await withVault(() => api('/api/money/spine', { method: 'POST', body }));
        toast('Split saved');
        refresh();
      } catch (err) {
        toast(err.message, true);
      }
    }
    if (b.dataset.act === 'go') show(b.dataset.view);
  });
}
function renderMoney() {
  const st = S.st;
  const box = $('#md-spine');
  if (!box.dataset.ready || document.activeElement?.closest('#md-spine') == null) {
    box.innerHTML = POOLS.map(([k, name]) => `<label>${name} %<input type="number" min="0" max="100" step="1" name="${k}" value="${st.spine[k]}"></label>`).join('');
    box.dataset.ready = '1';
  }
  $('#md-mrr').innerHTML = `<div class="big num pos">${aud(st.mrr.amount)}</div><p class="dim">${st.mrr.count} monthly retainer payment${st.mrr.count === 1 ? '' : 's'} logged in the last 31 days. Tick “Monthly retainer” when you log a retainer in Ledger and it counts here — nothing else does.</p><button class="btn sm" data-act="go" data-view="ledger">Open Ledger</button>`;
  const p = st.pools;
  $('#md-pools').innerHTML = `<table><thead><tr><th>Pool</th><th class="r">Share</th><th class="r">Moved</th><th class="r">Waiting for approval</th><th>Notes</th></tr></thead><tbody>${POOLS.map(([k, name, sub]) => `<tr><td><b>${name}</b></td><td class="r num">${st.spine[k]}%</td><td class="r num gold">${aud(p[k].executed)}</td><td class="r num dim">${aud(p[k].pending)}</td><td class="dim">${k === 'pay' ? `${aud(p.pay.paidOut)} paid out · ${aud(p.pay.requested)} requested · ${aud(p.pay.available)} available` : esc(sub)}</td></tr>`).join('')}</tbody></table>`;
  $('#md-allocs').innerHTML = st.allocations.length ? `<div class="tablewrap"><table><thead><tr><th>Income</th><th class="r">Amount</th><th>Split</th><th>Status</th></tr></thead><tbody>${st.allocations.slice(0, 30).map((a) => `<tr><td>${esc(a.date)} · ${esc(a.note)}</td><td class="r num">${aud(a.amount)}</td><td class="dim" style="font-size:13px">${POOLS.map(([k, n]) => `${n.split(' ')[0]} ${aud(a.splits[k])}`).join(' · ')}</td><td><span class="pill ${a.status === 'executed' ? 'ok' : a.status === 'pending' ? 'gold' : ''}">${a.status === 'executed' ? 'moved' : esc(a.status)}</span></td></tr>`).join('')}</tbody></table></div>` : '<div class="empty">No verified income yet — log your first sale in Ledger and Treasurer proposes its split.</div>';
}

// ── AUTONOMY CORE ───────────────────────────────────────────
function initAutonomy(el) {
  el.innerHTML = `<div class="panel loopc" id="au-loop"></div>
  <div class="grid g2" style="margin-top:16px">
    <div class="panel"><div class="row spread"><h2>Loop interval cadence</h2><b class="num gold" id="au-cad"></b></div><input type="range" min="10" max="120" step="5" id="au-slider" style="width:100%"><div class="row spread hint"><span>Fast (10s)</span><span>Default (25s)</span><span>Relaxed (120s)</span></div><h3 style="margin-top:14px">Strategy (paper lane)</h3><div class="row" id="au-strat"></div><p class="hint">SPREAD paper-buys the best cross-exchange spread and sells after a realistic transfer delay. MOMENTUM paper-buys the coin moving fastest over 10 minutes (stop −1%, take +1.5%). Real prices, simulated money.</p></div>
    <div class="panel" id="au-judgepanel"><div class="row spread"><h2>Self-upgrade judge (dial 0.50× – 1.50×)</h2><b class="num pos" id="au-dial"></b></div><p class="dim" style="margin-top:0">Looks at the last 10 closed paper trades. Net &gt; 0 with ≥ 6 wins nudges paper size +0.1× (cap 1.5×); net &lt; 0 with ≤ 2 wins nudges −0.1× (floor 0.5×). Needs ≥ 4 closed trades.</p><div class="bar"><i id="au-dialbar"></i></div><div class="row spread hint"><span>Conservative 0.50×</span><span>Baseline 1.00×</span><span>Maximum 1.50×</span></div><h3 style="margin-top:14px">Recent upgrade nudges</h3><div id="au-nudges"></div></div>
  </div>
  <div class="panel" id="au-paperpanel" style="margin-top:16px"><div class="row spread"><h2>PAPER book — BANG lane</h2><div class="row"><button class="btn sm" data-act="cycle">Run a cycle now</button><button class="btn sm ghost danger" data-act="reset">Reset paper book</button></div></div><div id="au-paper"></div></div>
  <div class="panel" style="margin-top:16px"><h2>Agent schedules</h2><div id="au-agents"></div></div>`;
  $('#au-slider').addEventListener('change', (e) => api('/api/loop', { method: 'POST', body: { cadenceSec: Number(e.target.value) } }).then(refresh).catch((err) => toast(err.message, true)));
  el.addEventListener('click', async (e) => {
    const b = e.target.closest('[data-act]');
    if (!b) return;
    try {
      if (b.dataset.act === 'engage') await api('/api/autopilot', { method: 'POST', body: { on: b.dataset.on !== 'true' } });
      if (b.dataset.act === 'strategy') await api('/api/loop', { method: 'POST', body: { strategy: b.dataset.s } });
      if (b.dataset.act === 'cycle') {
        b.disabled = true;
        await api('/api/loop/cycle', { method: 'POST', body: {} });
        b.disabled = false;
        toast('Cycle complete');
      }
      if (b.dataset.act === 'reset' && (await confirmBox('Reset the paper book? (Paper only — the ledger is untouched.)', 'Reset'))) await api('/api/loop/reset-paper', { method: 'POST', body: {} });
      if (b.dataset.act === 'run') await api(`/api/agents/${b.dataset.id}/run`, { method: 'POST', body: {} });
      if (b.dataset.act === 'toggle') await api(`/api/agents/${b.dataset.id}/config`, { method: 'POST', body: { enabled: b.dataset.on !== 'true' } });
      refresh();
    } catch (err) {
      b.disabled = false;
      toast(err.message, true);
    }
  });
  el.addEventListener('change', (e) => {
    if (e.target.matches('select[data-every]')) api(`/api/agents/${e.target.dataset.every}/config`, { method: 'POST', body: { everyMin: Number(e.target.value) } }).then(refresh).catch((err) => toast(err.message, true));
  });
}
function renderAutonomy() {
  const st = S.st;
  const L = st.loop;
  const on = !!st.settings.autopilot;
  $('#au-loop').innerHTML = `<div class="row spread"><div class="row" style="gap:16px"><div class="loopicon ${on ? 'on' : ''}"><span></span></div><div><h2 style="margin:0">AUTONOMOUS OPERATOR LOOP <span class="pill ${on ? 'ok' : ''}">${on ? 'ACTIVE (PULSING)' : 'PAUSED'}</span></h2><div class="dim">Scans live markets, runs the paper book and checks your Solana vault every cycle; agents run on their own schedules.</div></div></div><button class="btn ${on ? 'danger big' : 'primary'}" data-act="engage" data-on="${on}">${on ? '■ DISENGAGE AUTOPILOT' : '▶ ENGAGE AUTOPILOT'}</button></div>
    <div class="grid g4" style="margin-top:14px"><div class="stat"><span>TOTAL CYCLES COMPLETED</span><b class="num">#${L.state.cycles || 0}</b></div><div class="stat"><span>CYCLE FREQUENCY</span><b class="num gold">Every ${L.settings.cadenceSec}s</b></div><div class="stat"><span>SELECTED STRATEGY</span><b class="num pos">${esc(L.settings.strategy)}</b></div><div class="stat"><span>LAST CYCLE</span><b class="num">${L.state.lastCycleAt ? new Date(L.state.lastCycleAt).toLocaleTimeString('en-AU', { hour12: false }) : '—'}</b></div></div>${L.state.lastError ? `<p class="hint warnc">${esc(L.state.lastError)}</p>` : ''}`;
  const sl = $('#au-slider');
  if (document.activeElement !== sl) sl.value = L.settings.cadenceSec;
  $('#au-cad').textContent = `${L.settings.cadenceSec} seconds`;
  $('#au-strat').innerHTML = ['SPREAD', 'MOMENTUM', 'MIXED'].map((s) => `<button class="btn ${s === L.settings.strategy ? 'gold' : ''}" data-act="strategy" data-s="${s}" style="flex:1">${s}</button>`).join('');
  const p = L.paper;
  // v15: paper trading is off unless settings.loop.paper is true, and then its panels stay hidden.
  const paperOn = L.settings.paper === true;
  for (const id of ['#au-paperpanel', '#au-judgepanel']) if ($(id)) $(id).style.display = paperOn ? '' : 'none';
  $('#au-dial').textContent = `v1 · ${p.dial.toFixed(2)}×`;
  $('#au-dialbar').style.width = `${((p.dial - 0.5) / 1) * 100}%`;
  $('#au-nudges').innerHTML = p.nudges.length ? p.nudges.map((n) => `<div class="hint">${ago(n.at)} · ${n.from}× → ${n.to}× (${n.wins}/${n.of} wins, net ${aud(n.net)} paper)</div>`).join('') : '<div class="hint">No automated tuning adjustments yet (requires ≥ 4 closed paper trades).</div>';
  const row = (t) => `<tr><td><span class="pill">${t.kind}</span></td><td><b>${esc(t.coin)}</b></td><td class="dim">${esc(t.buyVenue)}${t.kind === 'SPREAD' ? ` → ${esc(t.sellVenue)}` : ''}</td><td class="r num">${price(t.entry)}</td><td class="r num">${t.exit ? price(t.exit) : '—'}</td><td class="r num">${aud(t.sizeAud)}</td><td class="r num ${t.status === 'open' ? 'dim' : t.pnlAud >= 0 ? 'pos' : 'neg'}">${t.status === 'open' ? `due ${until(Date.parse(t.closeDue))}` : `${t.pnlAud >= 0 ? '+' : ''}${aud(t.pnlAud)}`}</td></tr>`;
  $('#au-paper').innerHTML = `<div class="grid g4"><div class="stat"><span>PAPER BALANCE</span><b class="num">${aud(p.balanceAud)}</b></div><div class="stat"><span>REALISED (PAPER)</span><b class="num ${p.realisedAud >= 0 ? 'pos' : 'neg'}">${aud(p.realisedAud)}</b></div><div class="stat"><span>TODAY (PAPER)</span><b class="num">${aud(p.todayAud)}</b></div><div class="stat"><span>WIN RATE</span><b class="num">${p.count ? Math.round((p.wins / p.count) * 100) : 0}% of ${p.count}</b></div></div>
    <p class="hint">Paper money on real prices. It never touches the Ledger or the money spine — it’s practice and strategy testing.</p>
    ${p.open.length || p.closed.length ? `<div class="tablewrap"><table><thead><tr><th>Type</th><th>Coin</th><th>Route</th><th class="r">Entry</th><th class="r">Exit</th><th class="r">Size</th><th class="r">P&amp;L (paper)</th></tr></thead><tbody>${[...p.open, ...p.closed.slice(0, 15)].map(row).join('')}</tbody></table></div>` : '<div class="empty">No paper trades yet. The loop opens one when a spread clears your alert level or a coin moves fast.</div>'}`;
  $('#au-agents').innerHTML = `<div class="tablewrap"><table><thead><tr><th>Agent</th><th>Kind</th><th>Every</th><th>Last run</th><th>Next</th><th></th></tr></thead><tbody>${ORDER12.map((id) => {
    const a = st.agents[id];
    const opts = EVERY.map((m) => `<option value="${m}"${Number(a.everyMin) === m ? ' selected' : ''}>${fmtMin(m)}</option>`).join('');
    return `<tr><td>${ICON[id]} <b>${esc(a.name)}</b><div class="hint">${esc(ROLE[id])}</div></td><td><span class="pill ${a.ai ? 'ai' : ''}">${a.ai ? 'AI' : 'RULES'}</span></td><td><select data-every="${id}">${opts}</select></td><td class="dim">${ago(a.lastRunAt)}</td><td class="dim">${on && a.enabled ? until(a.nextRunAt) : 'paused'}</td><td><div class="row" style="justify-content:flex-end"><button class="btn sm" data-act="run" data-id="${id}">Run</button><button class="btn sm ghost" data-act="toggle" data-id="${id}" data-on="${a.enabled}">${a.enabled ? 'Off' : 'On'}</button></div></td></tr>`;
  }).join('')}</tbody></table></div>`;
}

// ── PAYOUT BRIDGE ───────────────────────────────────────────
function initPayout(el) {
  el.innerHTML = `<div class="panel"><div class="row spread"><div><h2 style="margin:0">On-chain deposit rail (keyless Solana monitor) <span class="pill" id="pb-rpc"></span></h2><div class="dim">Watches your vault address through public mainnet RPC. Nothing to sign, no keys. New incoming SOL lands in Mission Control for you to log as income or ignore.</div></div><div class="row"><button class="btn" data-act="phantom">Connect Phantom</button><button class="btn primary" data-act="scan">Scan deposits now</button></div></div>
    <div class="row" style="margin-top:12px"><span class="hint">DESIGNATED VAULT</span><input id="pb-addr" placeholder="Your Solana address" style="flex:1;min-width:280px"><button class="btn" data-act="setaddr">Set vault</button></div><div id="pb-bal" style="margin-top:10px"></div>
    <h3 style="margin-top:14px">Recent on-chain deposits</h3><div id="pb-deps"></div></div>
  <div class="grid g2" style="margin-top:16px">
    <div class="panel"><div class="row spread"><h2>Request director withdrawal</h2><span class="hint gold" id="pb-avail"></span></div>
      <div class="row" id="pb-methods"></div>
      <div class="form" style="margin-top:10px"><label>Amount (A$)<input id="pb-amt" type="number" min="1" step="0.01"></label><label>Note<input id="pb-note" placeholder="Weekly pay"></label></div>
      <div class="row" style="margin-top:10px"><button class="btn gold" data-act="request">Request payout</button></div>
      <p class="hint">YABBAI never moves money and never holds keys or bank details. A request is a reminder with a paper trail: pay yourself in your bank or wallet, then mark it paid.</p></div>
    <div class="panel"><h2>Payouts &amp; withdrawals audit ledger</h2><div id="pb-payouts"></div></div>
  </div>`;
  S.payMethod = S.payMethod || 'bank';
  el.addEventListener('click', async (e) => {
    const b = e.target.closest('[data-act]');
    if (!b) return;
    try {
      switch (b.dataset.act) {
        case 'method':
          S.payMethod = b.dataset.m;
          return renderPayout();
        case 'setaddr':
          await api('/api/solana/address', { method: 'POST', body: { address: $('#pb-addr').value.trim() } });
          toast('Vault address saved — first scan sets the baseline');
          await api('/api/solana/scan', { method: 'POST', body: {} });
          break;
        case 'phantom': {
          const prov = window.phantom?.solana || (window.solana?.isPhantom ? window.solana : null);
          if (!prov) return toast('Phantom isn’t installed in this browser', true);
          const r = await prov.connect();
          $('#pb-addr').value = r.publicKey.toString();
          await api('/api/solana/address', { method: 'POST', body: { address: r.publicKey.toString() } });
          toast('Phantom address set (read-only — nothing to sign)');
          await api('/api/solana/scan', { method: 'POST', body: {} });
          break;
        }
        case 'scan':
          b.disabled = true;
          await api('/api/solana/scan', { method: 'POST', body: {} });
          b.disabled = false;
          toast('Scanned');
          break;
        case 'request':
          await withVault(() => api('/api/payouts', { method: 'POST', body: { amount: Number($('#pb-amt').value), method: S.payMethod, note: $('#pb-note').value } }));
          $('#pb-amt').value = '';
          toast('Payout requested — it’s in Mission Control');
          break;
        case 'q': {
          const [kind, id, action] = b.dataset.q.split('|');
          let extra = {};
          if (action === 'paid') {
            const v = await ask('Payout done?', [{ name: 'ref', label: 'Bank / wallet reference (optional)' }], 'Mark paid');
            if (!v) return;
            extra = v;
          }
          await withVault(() => api(`/api/queue/${kind}/${id}`, { method: 'POST', body: { action, ...extra } }));
          break;
        }
        default:
          return;
      }
      refresh();
    } catch (err) {
      b.disabled = false;
      toast(err.message, true);
    }
  });
}
function renderPayout() {
  const st = S.st;
  const s = st.solana;
  const addr = $('#pb-addr');
  if (document.activeElement !== addr) addr.value = s.address || '';
  $('#pb-rpc').textContent = !s.address ? 'NO VAULT SET' : s.error ? 'RPC: UNREACHABLE' : s.lastScanAt ? 'RPC: OK' : 'NOT SCANNED';
  $('#pb-rpc').className = `pill ${!s.address ? '' : s.error ? 'bad' : 'ok'}`;
  $('#pb-bal').innerHTML = s.address ? `<span class="num gold">${s.balanceSol != null ? `${s.balanceSol.toFixed(4)} SOL` : '—'}</span>${s.balanceSol != null && s.priceAud ? ` <span class="dim">≈ ${aud(s.balanceSol * s.priceAud)} at ${aud(s.priceAud)}/SOL</span>` : ''} <span class="hint">· scanned ${ago(s.lastScanAt)}${s.error ? ` · ${esc(s.error)}` : ''}</span>` : '';
  $('#pb-deps').innerHTML = st.deposits.length ? `<div class="tablewrap"><table><thead><tr><th>When</th><th class="r">SOL</th><th class="r">≈ A$</th><th>From</th><th>Status</th></tr></thead><tbody>${st.deposits.map((d) => `<tr><td class="dim">${ago(d.at)}</td><td class="r num">${d.sol}</td><td class="r num">${d.aud != null ? aud(d.aud) : '—'}</td><td class="dim" style="font-size:12px">${esc(d.from.slice(0, 6))}…${esc(d.from.slice(-4))}</td><td><span class="pill ${d.status === 'logged' ? 'ok' : d.status === 'detected' ? 'gold' : ''}">${esc(d.status)}</span></td></tr>`).join('')}</tbody></table></div>` : `<div class="empty">${s.address ? 'No new deposits since the vault was set. Send SOL to it and the next scan picks it up.' : 'Set your Solana address (or Connect Phantom) to start watching.'}</div>`;
  $('#pb-avail').textContent = `Pay yourself: ${aud(st.pools.pay.available)} available`;
  $('#pb-methods').innerHTML = [['phantom', 'PHANTOM', '0% fee'], ['bank', 'BANK AU', '≈0.75%'], ['card', 'CARD', '≈1.75%']].map(([m, n, f]) => `<button class="btn method ${S.payMethod === m ? 'gold' : ''}" data-act="method" data-m="${m}" style="flex:1;flex-direction:column"><b>${n}</b><small>${f}</small></button>`).join('');
  $('#pb-payouts').innerHTML = st.payouts.length ? st.payouts.map((p) => `<div class="card"><div class="row spread"><div><span class="pill ${p.status === 'paid' ? 'ok' : p.status === 'requested' ? 'gold' : ''}">${esc(p.status.toUpperCase())}</span> <b class="num">${aud(p.amount)}</b> <span class="dim">via ${esc(p.methodName)}</span></div>${p.status === 'requested' ? `<div class="row"><button class="btn sm gold" data-act="q" data-q="payout|${p.id}|paid">Mark paid…</button><button class="btn sm ghost danger" data-act="q" data-q="payout|${p.id}|cancel">Cancel</button></div>` : `<span class="hint">${ago(p.paidAt || p.createdAt)}</span>`}</div><div class="hint">${esc(p.note || '')} · est. fee ${aud(p.estFee)}${p.ref ? ` · ref ${esc(p.ref)}` : ''}</div></div>`).join('') : '<div class="empty">No payout requests yet.</div>';
}

// ── AGENT HUB (12 agents) ───────────────────────────────────
function initAgents(el) {
  el.innerHTML = `<h1>Agent Hub</h1><p class="lede">Twelve agents. The seven AI agents write; the five rule agents check and count, so the numbers can’t be made up. Everything that leaves YABBAI or touches money goes through Mission Control first.</p>
  <div class="hub" id="agent-cards"></div>
  <div class="grid g2" style="margin-top:16px"><div class="panel"><h2>Findings</h2><div id="ah-findings"></div></div><div class="panel"><h2>Activity</h2><ul class="feed" id="feed"></ul></div></div>`;
  el.addEventListener('click', async (e) => {
    const b = e.target.closest('[data-act]');
    if (!b) return;
    try {
      if (b.dataset.act === 'run') toast((await api(`/api/agents/${b.dataset.id}/run`, { method: 'POST', body: {} })).queued ? 'Queued' : 'Already running');
      if (b.dataset.act === 'toggle') await api(`/api/agents/${b.dataset.id}/config`, { method: 'POST', body: { enabled: b.dataset.on !== 'true' } });
      if (b.dataset.act === 'dismiss') await api(`/api/queue/finding/${b.dataset.id}`, { method: 'POST', body: { action: 'dismiss' } });
      scheduleRefresh();
    } catch (err) {
      toast(err.message, true);
    }
  });
}
function agentLine(id, st) {
  if (['scout', 'closer', 'forge'].includes(id)) return agentOutput(id, st);
  const n = (arr) => arr.length;
  const map = {
    qualifier: () => `<b class="num">${n(st.leads.filter((l) => l.score != null))}</b> leads scored · <b class="num">${n(st.leads.filter((l) => l.stage === 'new' && l.score == null))}</b> waiting`,
    caller: () => `<b class="num">${n(st.followups.filter((f) => f.status === 'pending'))}</b> follow-ups waiting for approval`,
    builder: () => `<b class="num">${n(st.forge.kits.filter((k) => k.status === 'building'))}</b> kits being built · <b class="num">${n(st.forge.kits.filter((k) => k.built && k.built.length))}</b> with files`,
    shipper: () => `<b class="num">${n(st.forge.kits.filter((k) => k.status === 'ship-ready'))}</b> ship packs ready`,
    supporter: () => `<b class="num">${n(st.replies.filter((r) => r.status === 'draft'))}</b> reply drafts waiting`,
    treasurer: () => `<b class="num">${n(st.allocations.filter((a) => a.status === 'pending'))}</b> splits to approve`,
  };
  if (map[id]) return map[id]();
  const f = st.findings.filter((x) => x.status === 'open' && x.agent.toLowerCase() === id);
  return f.length ? `<b class="num warnc">${f.length}</b> open finding${f.length === 1 ? '' : 's'}: ${esc(f[0].title)}` : '<span class="dim">All clear on the last check.</span>';
}
function renderAgents() {
  const st = S.st;
  $('#agent-cards').innerHTML = ORDER12.map((id) => {
    const a = st.agents[id];
    const s = !a.enabled ? ['', 'Off'] : a.running || a.status === 'running' ? ['busy', 'Working…'] : a.status === 'queued' ? ['warn', 'Queued'] : a.status === 'error' ? ['bad', 'Needs attention'] : ['ok', 'Ready'];
    return `<article class="panel hubc"><div class="row spread"><div class="row" style="gap:8px"><span class="ci">${ICON[id]}</span><b>${esc(a.name.toUpperCase())}</b><span class="pill ${a.ai ? 'ai' : ''}">${a.ai ? 'AI' : 'RULES'}</span></div><span class="chip"><span class="dot ${s[0]}"></span>${s[1]}</span></div>
      <p class="role">${esc(ROLE[id])}</p><div class="out">${agentLine(id, st)}</div>${a.lastError ? `<p class="hint neg" style="margin:6px 0 0">${esc(a.lastError)}</p>` : ''}
      <div class="row spread" style="margin-top:8px"><span class="hint">${a.runs || 0} runs · every ${fmtMin(a.everyMin)} · last ${ago(a.lastRunAt)}</span><div class="row"><button class="btn sm primary" data-act="run" data-id="${id}">Run</button><button class="btn sm ghost" data-act="toggle" data-id="${id}" data-on="${a.enabled}">${a.enabled ? 'Off' : 'On'}</button></div></div></article>`;
  }).join('');
  const open = st.findings.filter((f) => f.status === 'open');
  $('#ah-findings').innerHTML = open.length ? open.map((f) => `<div class="card"><div class="row spread"><div><span class="risk ${f.severity === 'risk' ? 'high' : f.severity === 'warn' ? 'med' : 'low'}">${esc(f.severity.toUpperCase())}</span> <b>${esc(f.title)}</b></div><button class="btn sm ghost" data-act="dismiss" data-id="${f.id}">Dismiss</button></div><div class="dim" style="font-size:14px">${esc(f.detail)} <span class="hint">— ${esc(f.agent)}</span></div></div>`).join('') : '<div class="empty">No open findings.</div>';
  $('#feed').innerHTML = st.activity.slice(0, 40).map((a) => `<li><time>${hhmm(a.at)}</time><span class="k-${esc(a.kind)}">${esc(a.text)}</span></li>`).join('') || '<li><span></span><span class="dim">No activity yet.</span></li>';
}

// ── BRAINS (local + Hugging Face 70B+ + AirLLM deep brain) ──
async function renderBrains() {
  const box = $('#br-panel');
  if (!box) return;
  let b;
  try {
    b = await api('/api/brains');
  } catch (err) {
    box.innerHTML = `<div class="empty">${esc(err.message)}</div>`;
    return;
  }
  const sel = (name, v) => `<select name="${name}"><option value="local"${v === 'local' ? ' selected' : ''}>Local · Qwen3.5 9B (fast, unlimited)</option><option value="hf"${v === 'hf' ? ' selected' : ''}>Hugging Face 70B+ (fast, billed by HF)</option></select>`;
  const models = (b.hfModels && b.hfModels.curated) || [];
  const d = b.deep || {};
  const jobs = (S.st && S.st.deep.jobs) || [];
  box.innerHTML = `<div class="grid g3">
    <div class="panel"><h2>Routing</h2><div class="form" id="br-route"><label class="full">Chat (cockpit)${sel('chat', b.settings.chat)}</label><label class="full">Agents${sel('agents', b.settings.agents)}</label></div><button class="btn sm primary" data-act="route" style="margin-top:8px">Save routing</button><p class="hint">Local: ${esc(b.local || 'no model')}. The deep brain is never used for chat or agents — it’s too slow; send it jobs below.</p></div>
    <div class="panel"><h2>Hugging Face 70B+</h2><p class="dim" style="margin-top:0">Llama 3.3 70B, GPT-OSS 120B, DeepSeek V3.2 through Inference Providers — fast, uses your HF credits.</p>
      <div class="kv"><span>Token</span><b>${b.hf.set ? `${esc(b.hf.hint)} (${esc(b.hf.source)})` : '<span class="neg">not set</span>'}</b></div>
      <div class="row" style="margin-top:8px"><input type="password" id="br-token" placeholder="hf_… (new token)" style="flex:1"><button class="btn sm" data-act="token">Save</button></div>
      <label style="margin-top:8px">Model<select id="br-model">${models.map((m) => `<option value="${esc(m.id)}"${m.id === b.settings.hfModel ? ' selected' : ''}>${esc(m.label)}${m.listed === false ? ' (not listed now)' : ''}</option>`).join('')}</select></label>
      <div class="row" style="margin-top:8px"><button class="btn sm" data-act="model">Use model</button><button class="btn sm ghost" data-act="test" data-b="hf">Test</button></div><p class="hint" id="br-test"></p></div>
    <div class="panel"><h2>Deep brain · AirLLM 70B</h2>
      <div class="kv"><span>Status</span><b>${d.up ? (d.loaded ? '<span class="pos">ready</span>' : d.loading ? 'loading model…' : 'running · model loads on first job') : d.enabled ? '<span class="neg">not running</span>' : 'off'}</b><span>Model</span><b>${esc(d.model || '—')}</b><span>Device</span><b>${esc(d.device || '—')}${d.compression ? ` · ${esc(d.compression)}` : ''}</b></div>
      ${d.note ? `<p class="hint warnc">${esc(d.note)}</p>` : ''}<p class="hint">Runs a 70B model on your 8 GB GPU by reading it off your SSD for every word: roughly 3–30 seconds per word. Great overnight, useless for chat. ${d.up ? '' : 'Install with INSTALL-DEEP-BRAIN.bat, then restart YABBAI.'}</p></div>
  </div>
  <div class="panel" style="margin-top:16px"><div class="row spread"><h2>Deep jobs</h2><span class="hint">One at a time · results land here and in telemetry</span></div>
    <div class="form"><label class="full">Question for the 70B<textarea id="dj-prompt" rows="3" placeholder="Review my offers and pipeline and write a 90-day plan to reach A$5k/month — be specific about which offer to push to whom."></textarea></label>
      <label>Max words (tokens)<input id="dj-max" type="number" min="16" max="2000" value="${b.settings.deepMaxTokens || 400}"></label><label class="check" style="margin-top:22px"><input type="checkbox" id="dj-ctx" checked> Include live state</label></div>
    <div class="row" style="margin-top:8px"><button class="btn primary" data-act="deep"${d.up ? '' : ' disabled'}>Send to the deep brain</button><span class="hint">${d.up ? 'At ~10 s/token, 400 tokens ≈ 70 minutes.' : 'Deep brain not running.'}</span></div>
    <div id="dj-list" style="margin-top:12px">${jobs.length ? jobs.map((j) => { const eta = j.secPerToken && j.status === 'running' ? ` · ~${Math.round(((j.max - j.tokens) * j.secPerToken) / 60)} min left` : ''; return `<div class="card"><div class="row spread"><b>${esc(j.title)}</b><div class="row"><span class="pill ${j.status === 'done' ? 'ok' : j.status === 'error' ? 'bad' : 'ai'}">${esc(j.status)}</span>${['queued', 'loading', 'running'].includes(j.status) ? `<button class="btn sm ghost danger" data-act="cancel" data-id="${j.id}">Cancel</button>` : ''}</div></div><div class="hint">${j.tokens}/${j.max} tokens${j.secPerToken ? ` · ${j.secPerToken}s/token` : ''}${eta} · ${ago(j.createdAt)}${j.message ? ` · ${esc(j.message)}` : ''}</div>${j.text ? `<div class="m assistant" style="margin-top:8px"><div class="body">${md(j.text)}</div></div>` : ''}${j.error ? `<p class="hint neg">${esc(j.error)}</p>` : ''}</div>`; }).join('') : '<div class="empty">No deep jobs yet.</div>'}</div></div>`;
}
function initBrainsHandlers(el) {
  el.addEventListener('click', async (e) => {
    const t = e.target.closest('[data-act]');
    if (!t || !t.closest('#br-panel')) return;
    try {
      switch (t.dataset.act) {
        case 'route':
          await api('/api/brains', { method: 'POST', body: Object.fromEntries($$('#br-route select').map((s) => [s.name, s.value])) });
          toast('Routing saved');
          break;
        case 'token':
          await withVault(() => api('/api/brains', { method: 'POST', body: { hfToken: $('#br-token').value.trim() } }));
          toast('Token saved on this machine');
          break;
        case 'model':
          await api('/api/brains', { method: 'POST', body: { hfModel: $('#br-model').value } });
          toast('Model set');
          break;
        case 'test': {
          $('#br-test').textContent = 'Testing…';
          const r = await api('/api/brains/test', { method: 'POST', body: { brain: t.dataset.b } });
          $('#br-test').textContent = `✓ “${r.text}” in ${(r.ms / 1000).toFixed(1)}s from ${r.stats.model || 'model'}`;
          return;
        }
        case 'deep':
          await api('/api/deep/jobs', { method: 'POST', body: { prompt: $('#dj-prompt').value, maxTokens: Number($('#dj-max').value), context: $('#dj-ctx').checked } });
          $('#dj-prompt').value = '';
          toast('Sent to the deep brain');
          break;
        case 'cancel':
          await api(`/api/deep/jobs/${t.dataset.id}/cancel`, { method: 'POST', body: {} });
          break;
        default:
          return;
      }
      await refresh();
      renderBrains();
    } catch (err) {
      if (t.dataset.act === 'test') $('#br-test').textContent = err.message;
      toast(err.message, true);
    }
  });
}

// ── register surfaces & boot ───────────────────────────────
Object.assign(VIEWS, {
  cosmos: { init: initCosmos, render: renderCosmos },
  mission: { init: initMission, render: renderMission },
  money: { init: initMoney, render: renderMoney },
  autonomy: { init: initAutonomy, render: renderAutonomy },
  payout: { init: initPayout, render: renderPayout },
  agents: { init: initAgents, render: renderAgents },
});
const baseModelInit = VIEWS.model.init;
VIEWS.model = {
  init: (el) => {
    baseModelInit(el);
    el.insertAdjacentHTML('afterbegin', '<div id="br-panel" style="margin-bottom:20px"></div>');
    initBrainsHandlers(el);
  },
  render: () => {},
  onShow: () => {
    loadModel();
    renderBrains();
  },
};
$('#vault-btn').addEventListener('click', vaultDialog);
window.removeEventListener('hashchange', () => {});
(async () => {
  await boot();
  if (!location.hash) show('cosmos');
})();
