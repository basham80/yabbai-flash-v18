/* YABBAI — RECEIVE surface. Invoices that can actually be paid across PayPal,
   bank transfer (AU) and crypto, with a proof engine behind every credit.
   Loaded after app.js/v13.js: shares $, api, toast, esc, aud, ago, withVault,
   S and VIEWS from the global lexical scope. */
'use strict';

const RECEIVE_RAILS = [
  ['paypal', 'PAYPAL', 'card, balance, pay in 4'],
  ['bank', 'BANK (AU)', 'PayID / BSB — reference matched'],
  ['sol', 'SOLANA', 'reference-key matched on-chain'],
  ['btc', 'BITCOIN', 'unique-amount matched'],
  ['eth', 'ETHEREUM', 'unique-amount matched'],
];

function rcvSummary() {
  const r = (S.st && S.st.receive) || {};
  return r.summary || { count: 0, open: 0, paid: 0, receivableAud: 0, collectedAud: 0, byRail: {}, claims: 0, unmatched: 0, rails: [] };
}
function rcvSettings() {
  const r = (S.st && S.st.receive) || {};
  return r.settings || {};
}
function rcvPaypal() {
  const r = (S.st && S.st.receive) || {};
  return r.paypal || { secret: { set: false } };
}
function rcvBadge(id) {
  const s = rcvSummary().rails.find((x) => x.id === id);
  return s && s.ready ? '<span class="pill ok">LIVE</span>' : '<span class="pill">NEEDS SETUP</span>';
}
function rcvMoney(n) {
  return aud(Number(n) || 0);
}
function rcvStatusPill(inv) {
  const map = { draft: '', sent: 'gold', part: 'gold', paid: 'ok', overdue: 'bad', void: '' };
  return `<span class="pill ${map[inv.status] || ''}">${esc(String(inv.status).toUpperCase())}</span>`;
}
function rcvPublicBase() {
  const s = rcvSettings();
  return (s.publicBase || location.origin || '').replace(/\/+$/, '');
}
function rcvLink(inv) {
  return `${rcvPublicBase()}/pay/${inv.token}`;
}

function initReceive(el) {
  el.innerHTML = `
  <div class="row spread" style="align-items:flex-end">
    <div>
      <h1 style="margin:0">RECEIVE</h1>
      <p class="lede" style="margin:6px 0 0">Invoices people can actually pay — PayPal, bank transfer, crypto. Every credit needs proof: a chain transaction, a verified PayPal capture, a statement line.</p>
    </div>
    <div class="row" style="gap:8px">
      <button class="btn" id="rcv-reconcile">Reconcile now</button>
      <button class="btn primary" id="rcv-new">New invoice</button>
    </div>
  </div>
  <div class="grid g4" id="rcv-stats" style="margin-top:18px"></div>
  <div class="panel" style="margin-top:18px">
    <div class="row spread"><h2 style="margin:0">Rails</h2><span class="hint">addresses are public facts · secrets stay in data/secrets</span></div>
    <div id="rcv-rails" style="margin-top:12px"></div>
    <details style="margin-top:12px"><summary class="hint" style="cursor:pointer">Rail settings</summary><div id="rcv-railform" style="margin-top:12px"></div></details>
  </div>
  <div class="panel" style="margin-top:18px">
    <div class="row spread"><h2 style="margin:0">Invoices</h2><span class="hint" id="rcv-invcount"></span></div>
    <div id="rcv-invoices" style="margin-top:12px"></div>
  </div>
  <div class="grid g2" style="margin-top:18px;gap:18px">
    <div class="panel"><div class="row spread"><h2 style="margin:0">Payment claims</h2><span class="hint">never a credit until proven</span></div><div id="rcv-claims" style="margin-top:12px"></div></div>
    <div class="panel"><div class="row spread"><h2 style="margin:0">Unmatched credits</h2><span class="hint">money seen, invoice unknown</span></div><div id="rcv-unmatched" style="margin-top:12px"></div></div>
  </div>
  <div class="panel" style="margin-top:18px">
    <div class="row spread"><h2 style="margin:0">Bank statement import</h2><span class="hint">CSV from online banking — matched by INV reference</span></div>
    <p class="dim" style="font-size:14px">Export the account the transfers land in, then paste or choose the CSV. Credits are matched on the <b>reference</b> field and booked with the statement date and a stable id. The same file twice changes nothing.</p>
    <input type="file" id="rcv-file" accept=".csv,.txt" style="margin-bottom:10px">
    <textarea id="rcv-stmt" rows="6" placeholder="Date,Amount,Description,Balance&#10;24/10/2026,97.00,NPP INV-0003 MARCUS VANCE,1204.55"></textarea>
    <div class="row" style="margin-top:10px"><button class="btn gold" id="rcv-import">Import statement</button><span class="hint" id="rcv-import-hint">Nothing is credited without an invoice reference.</span></div>
    <div id="rcv-batches" style="margin-top:12px"></div>
  </div>`;

  el.addEventListener('click', async (e) => {
    const t = e.target.closest('[data-act]');
    if (!t) return;
    const act = t.dataset.act;
    const id = t.dataset.id;
    try {
      if (act === 'new') return newInvoiceDialog();
      if (act === 'reconcile') {
        t.disabled = true;
        toast('Checking chains and rails…');
        const out = await api('/api/receive/reconcile', { method: 'POST', body: {} });
        const n = ['sol', 'btc', 'eth'].reduce((a, k) => a + (out[k] && out[k].credits ? out[k].credits : 0), 0);
        toast(n ? `${n} credit${n === 1 ? '' : 's'} booked` : 'Up to date — nothing new to book');
        await refresh();
        t.disabled = false;
        return;
      }
      if (act === 'copy') {
        const url = t.dataset.url;
        try {
          await navigator.clipboard.writeText(url);
          toast('Payment link copied');
        } catch {
          toast(url);
        }
        return;
      }
      if (act === 'open') return window.open(t.dataset.url, '_blank', 'noopener');
      if (act === 'send') {
        await api(`/api/invoices/${id}/send`, { method: 'POST', body: {} });
        toast('Invoice marked sent — copy its link and send it');
        return refresh();
      }
      if (act === 'requote') {
        await api(`/api/invoices/${id}/requote`, { method: 'POST', body: {} });
        toast('Crypto legs re-quoted');
        return refresh();
      }
      if (act === 'void') {
        if (!(await confirmBox('Void this invoice? It stops accepting payment.', 'Void'))) return;
        await api(`/api/invoices/${id}/void`, { method: 'POST', body: {} });
        toast('Invoice voided');
        return refresh();
      }
      if (act === 'credit') return creditDialog(id);
      if (act === 'claim-ok') {
        await withVault(() => api(`/api/claims/${id}/confirm`, { method: 'POST', body: {} }));
        toast('Claim confirmed and booked');
        return refresh();
      }
      if (act === 'claim-no') {
        await withVault(() => api(`/api/claims/${id}/dismiss`, { method: 'POST', body: {} }));
        toast('Claim dismissed');
        return refresh();
      }
      if (act === 'attach') return attachDialog(t.dataset.ext, Number(t.dataset.amount));
      if (act === 'save-rails') return saveRails(el);
      if (act === 'clear-pp') {
        await withVault(() => api('/api/receive/settings', { method: 'POST', body: { paypalSecret: '' } }));
        toast('PayPal secret removed');
        return refresh();
      }
    } catch (err) {
      toast(err.message, true);
    }
  });

  $('#rcv-file').addEventListener('change', async (e) => {
    const f = e.target.files && e.target.files[0];
    if (!f) return;
    if (f.size > 4 * 1024 * 1024) return toast('That file is too big for a statement', true);
    $('#rcv-stmt').value = await f.text();
    toast(`${f.name} loaded — press Import`);
  });

  $('#rcv-import').addEventListener('click', async () => {
    const text = $('#rcv-stmt').value.trim();
    if (!text) return toast('Paste or choose a statement first', true);
    try {
      const b = await withVault(() =>
        api('/api/receive/statement', { method: 'POST', body: { text, filename: ($('#rcv-file').files[0] || {}).name || 'pasted.csv' } })
      );
      $('#rcv-import-hint').textContent = `${b.rows} rows · ${b.credits} matched · ${b.duplicates} duplicate · ${b.skipped.length} skipped`;
      toast(b.credits ? `${b.credits} payment${b.credits === 1 ? '' : 's'} booked` : 'No new matches in that file');
      $('#rcv-stmt').value = '';
      await refresh();
    } catch (err) {
      toast(err.message, true);
    }
  });
}

function renderReceive() {
  const st = S.st;
  if (!st) return;
  const sum = rcvSummary();
  const rails = sum.rails || [];
  const set = (id, html) => {
    const n = $(id);
    if (n) n.innerHTML = html;
  };

  set(
    '#rcv-stats',
    `<div class="stat"><span>RECEIVABLE</span><b class="num gold">${rcvMoney(sum.receivableAud)}</b><small>${sum.open} open invoice${sum.open === 1 ? '' : 's'}</small></div>
     <div class="stat"><span>COLLECTED</span><b class="num pos">${rcvMoney(sum.collectedAud)}</b><small>${sum.paid} settled in full</small></div>
     <div class="stat"><span>CLAIMS WAITING</span><b class="num ${sum.claims ? 'warnc' : ''}">${sum.claims}</b><small>payer says they paid</small></div>
     <div class="stat"><span>UNMATCHED</span><b class="num ${sum.unmatched ? 'warnc' : ''}">${sum.unmatched}</b><small>credits with no invoice</small></div>`
  );

  set(
    '#rcv-rails',
    `<div class="tablewrap"><table><thead><tr><th>Rail</th><th>Status</th><th>Destination</th><th class="r">Collected</th></tr></thead><tbody>${rails
      .map(
        (r) =>
          `<tr><td><b>${esc(r.label)}</b></td><td><span class="pill ${r.ready ? 'ok' : ''}">${r.ready ? 'LIVE' : 'NEEDS SETUP'}</span></td><td class="dim">${esc(r.detail || '')}</td><td class="r num">${rcvMoney((sum.byRail || {})[r.id] || 0)}</td></tr>`
      )
      .join('')}</tbody></table></div>
     <p class="hint" style="margin-top:10px">Last reconcile: ${sum.lastReconcileAt ? ago(sum.lastReconcileAt) : 'never'}${sum.lastReconcile && sum.lastReconcile.sol ? ` · SOL ${sum.lastReconcile.sol.scanned} scanned` : ''}</p>`
  );

  const s = rcvSettings();
  const pp = rcvPaypal();
  const bank = s.bank || {};
  const sol = s.sol || {};
  const btc = s.btc || {};
  const eth = s.eth || {};
  const ppr = s.paypal || {};
  $('#rcv-railform').innerHTML = `
  <div class="grid g2" style="gap:14px">
    <div class="card"><b>PayPal</b> ${rcvBadge('paypal')}
      <label class="full" style="margin-top:8px">Mode<select name="pp-mode"><option value="sandbox"${ppr.mode === 'sandbox' ? ' selected' : ''}>sandbox</option><option value="live"${ppr.mode === 'live' ? ' selected' : ''}>live</option></select></label>
      <label class="full">Client ID<input name="pp-id" value="${esc(ppr.clientId || '')}" placeholder="AeA1…"></label>
      <label class="full">Client secret ${pp.secret.set ? `<span class="pill ok">SAVED ${esc(pp.secret.hint || '')}</span>` : '<span class="pill">NONE</span>'}<input name="pp-secret" type="password" placeholder="${pp.secret.set ? 'leave blank to keep saved secret' : 'paste to save'}"></label>
      <label class="full">Webhook ID<input name="pp-hook" value="${esc(ppr.webhookId || '')}" placeholder="8PT5… from the PayPal dashboard"></label>
      <label class="row" style="gap:8px;margin-top:6px"><input type="checkbox" name="pp-on"${ppr.enabled ? ' checked' : ''}> Accept PayPal on invoices</label>
      <p class="hint">Webhook URL: <span class="num">${esc(location.origin)}/webhooks/paypal</span></p>
    </div>
    <div class="card"><b>Bank (AU)</b> ${rcvBadge('bank')}
      <label class="full" style="margin-top:8px">PayID (email/phone/ABN)<input name="bk-payid" value="${esc(bank.payId || '')}" placeholder="pay@yourdomain.com.au"></label>
      <div class="row" style="gap:10px"><label class="full">BSB<input name="bk-bsb" value="${esc(bank.bsb || '')}" placeholder="062-000"></label><label class="full">Account<input name="bk-acct" value="${esc(bank.accountNumber || '')}" placeholder="12345678"></label></div>
      <label class="full">Account name<input name="bk-name" value="${esc(bank.accountName || '')}" placeholder="Your name or business"></label>
      <label class="full">Aggregator webhook secret<input name="bk-hook" type="password" placeholder="${bank.webhookSecret ? 'saved — leave blank to keep' : 'HMAC secret'}"></label>
      <label class="row" style="gap:8px;margin-top:6px"><input type="checkbox" name="bk-on"${bank.enabled ? ' checked' : ''}> Accept bank transfer</label>
      <p class="hint">Webhook: <span class="num">${esc(location.origin)}/webhooks/bank</span> · header <span class="num">X-Yabbai-Signature: t=…,v1=…</span></p>
    </div>
    <div class="card"><b>Solana</b> ${rcvBadge('sol')}
      <label class="full" style="margin-top:8px">Vault address<input name="sol-vault" value="${esc(sol.vault || '')}" placeholder="your base58 address"></label>
      <label class="full">RPC<input name="sol-rpc" value="${esc(sol.rpc || '')}"></label>
      <label class="row" style="gap:8px;margin-top:6px"><input type="checkbox" name="sol-on"${sol.enabled !== false ? ' checked' : ''}> Accept SOL</label>
      <p class="hint">Read-only. YABBAI never holds a key and never signs.</p>
    </div>
    <div class="card"><b>Bitcoin / Ethereum</b> ${rcvBadge('btc')} ${rcvBadge('eth')}
      <label class="full" style="margin-top:8px">BTC address<input name="btc-addr" value="${esc(btc.address || '')}" placeholder="bc1…"></label>
      <label class="row" style="gap:8px"><input type="checkbox" name="btc-on"${btc.enabled ? ' checked' : ''}> Accept BTC</label>
      <label class="full">ETH address<input name="eth-addr" value="${esc(eth.address || '')}" placeholder="0x…"></label>
      <label class="full">Etherscan API key<input name="eth-key" value="${esc(eth.apiKey || '')}" placeholder="required to read ETH history"></label>
      <label class="row" style="gap:8px"><input type="checkbox" name="eth-on"${eth.enabled ? ' checked' : ''}> Accept ETH</label>
      <label class="full">Public base URL<input name="rcv-base" value="${esc(s.publicBase || '')}" placeholder="${esc(location.origin)} — set this when payers are remote"></label>
      <label class="full">Brand on pay page<input name="rcv-brand" value="${esc(s.brandName || 'YABBAI')}"></label>
    </div>
  </div>
  <div class="row" style="margin-top:12px;gap:8px"><button class="btn gold" data-act="save-rails">Save rails</button>${pp.secret.set ? '<button class="btn ghost danger" data-act="clear-pp">Remove PayPal secret</button>' : ''}</div>`;

  const invs = (st.invoices || []).slice();
  $('#rcv-invcount').textContent = `${invs.length} total · ${sum.open} open`;
  $('#rcv-invoices').innerHTML = invs.length
    ? `<div class="tablewrap"><table><thead><tr><th>Invoice</th><th>Client</th><th>Rails</th><th class="r">Total</th><th class="r">Paid</th><th>Status</th><th></th></tr></thead><tbody>${invs
        .map((inv) => {
          const link = rcvLink(inv);
          const actions =
            inv.status === 'paid'
              ? `<span class="hint">${ago(inv.paidAt || inv.updatedAt)}</span>`
              : `<div class="row" style="gap:6px;justify-content:flex-end">
                  <button class="btn sm" data-act="copy" data-url="${esc(link)}">Copy link</button>
                  <button class="btn sm" data-act="open" data-url="${esc(link)}">Open</button>
                  ${inv.status === 'draft' ? `<button class="btn sm gold" data-act="send" data-id="${inv.id}">Mark sent</button>` : ''}
                  <button class="btn sm" data-act="credit" data-id="${inv.id}">Book payment…</button>
                  <button class="btn sm ghost" data-act="requote" data-id="${inv.id}">Re-quote</button>
                  <button class="btn sm ghost danger" data-act="void" data-id="${inv.id}">Void</button>
                </div>`;
          return `<tr><td><b>${esc(inv.number)}</b><div class="hint">${esc(inv.reference)}</div></td><td>${esc(inv.client)}<div class="hint">${esc(inv.email || '')}</div></td><td class="dim" style="font-size:13px">${(inv.rails || []).map((r) => esc(r.toUpperCase())).join(' · ')}</td><td class="r num">${rcvMoney(inv.totalAud)}</td><td class="r num ${inv.paidAud ? 'pos' : 'dim'}">${rcvMoney(inv.paidAud || 0)}</td><td>${rcvStatusPill(inv)}<div class="hint">due ${esc(inv.dueDate)}</div></td><td class="r">${actions}</td></tr>`;
        })
        .join('')}</tbody></table></div>`
    : '<div class="empty">No invoices yet. Draft one, send its link, and the rails do the rest.</div>';

  const claims = (st.claims || []).filter((c) => c.status === 'pending');
  $('#rcv-claims').innerHTML = claims.length
    ? claims
        .map(
          (c) => `<div class="card"><div class="row spread"><div><b>${esc(c.invoiceNumber)}</b> <span class="pill gold">${esc(c.rail.toUpperCase())}</span> <b class="num">${rcvMoney(c.amountAud)}</b></div><span class="hint">${ago(c.at)}</span></div>
        <div class="dim" style="font-size:13px">${esc(c.ref ? `ref ${c.ref}` : 'no reference given')}${c.note ? ` · ${esc(c.note)}` : ''}</div>
        <div class="row" style="margin-top:8px;gap:6px"><button class="btn sm gold" data-act="claim-ok" data-id="${c.id}">Confirm in banking</button><button class="btn sm ghost" data-act="claim-no" data-id="${c.id}">Dismiss</button></div></div>`
        )
        .join('')
    : '<div class="empty">No claims waiting. A claim only exists so a payer has a button — it never credits anything.</div>';

  const un = st.unmatched || [];
  $('#rcv-unmatched').innerHTML = un.length
    ? un
        .map(
          (u) => `<div class="card"><div class="row spread"><div><span class="pill">${esc(String(u.kind).toUpperCase())}</span> <b class="num">${rcvMoney(u.amountAud)}</b> <span class="dim">${esc(u.payer || '')}</span></div><span class="hint">${ago(u.at)}</span></div>
        <div class="hint">${esc(u.reason || '')}${u.externalId ? ` · ${esc(String(u.externalId).slice(0, 24))}` : ''}</div>
        <button class="btn sm" style="margin-top:8px" data-act="attach" data-ext="${esc(u.externalId || '')}" data-amount="${Number(u.amountAud) || 0}">Attach to an invoice…</button></div>`
        )
        .join('')
    : '<div class="empty">Nothing unmatched. Every credit seen has an invoice.</div>';

  const batches = st.statements || [];
  $('#rcv-batches').innerHTML = batches.length
    ? `<div class="tablewrap"><table><thead><tr><th>When</th><th>File</th><th class="r">Rows</th><th class="r">Matched</th><th class="r">Skipped</th></tr></thead><tbody>${batches
        .map((b) => `<tr><td class="dim">${ago(b.at)}</td><td>${esc(b.filename || 'pasted')}</td><td class="r num">${b.rows}</td><td class="r num ${b.credits ? 'pos' : ''}">${b.credits}</td><td class="r num dim">${b.skipped}</td></tr>`)
        .join('')}</tbody></table></div>`
    : '';
}

async function saveRails(el) {
  const v = (n) => {
    const i = el.querySelector(`[name="${n}"]`);
    return i ? String(i.value).trim() : '';
  };
  const ck = (n) => {
    const i = el.querySelector(`[name="${n}"]`);
    return !!(i && i.checked);
  };
  const body = {
    brandName: v('rcv-brand') || 'YABBAI',
    publicBase: v('rcv-base'),
    sol: { enabled: ck('sol-on'), vault: v('sol-vault'), rpc: v('sol-rpc') || undefined },
    btc: { enabled: ck('btc-on'), address: v('btc-addr') },
    eth: { enabled: ck('eth-on'), address: v('eth-addr'), apiKey: v('eth-key') },
    bank: { enabled: ck('bk-on'), payId: v('bk-payid'), bsb: v('bk-bsb'), accountNumber: v('bk-acct'), accountName: v('bk-name') },
    paypal: { enabled: ck('pp-on'), mode: v('pp-mode') || 'sandbox', clientId: v('pp-id'), webhookId: v('pp-hook') },
  };
  const secretVal = v('pp-secret');
  if (secretVal) body.paypalSecret = secretVal;
  const hook = v('bk-hook');
  if (hook) body.bank.webhookSecret = hook;
  await withVault(() => api('/api/receive/settings', { method: 'POST', body }));
  toast('Rails saved');
  await refresh();
}

async function newInvoiceDialog() {
  const r = await ask(
    'New invoice',
    [
      { name: 'client', label: 'Client', required: true, hint: 'Business or person paying' },
      { name: 'email', label: 'Email (optional)', type: 'email' },
      { name: 'desc', label: 'Line item', required: true, hint: 'What you are billing for' },
      { name: 'amount', label: 'Amount AUD', type: 'number', required: true, hint: 'ex-GST unit price' },
      { name: 'qty', label: 'Quantity', type: 'number', hint: 'default 1' },
      { name: 'due', label: 'Due date', type: 'date' },
    ],
    'Create invoice'
  );
  if (!r) return;
  const items = [{ desc: r.desc, qty: Number(r.qty) || 1, unitAud: Number(r.amount) }];
  try {
    const inv = await api('/api/invoices', {
      method: 'POST',
      body: { client: r.client, email: r.email || '', items, rails: ['paypal', 'bank', 'sol'], dueDate: r.due || undefined },
    });
    await refresh();
    const url = rcvLink(inv);
    try {
      await navigator.clipboard.writeText(url);
      toast(`${inv.number} created — payment link copied`);
    } catch {
      toast(`${inv.number} created — open it from the list`);
    }
  } catch (err) {
    toast(err.message, true);
  }
}

async function creditDialog(id) {
  const inv = (S.st.invoices || []).find((i) => i.id === id);
  if (!inv) return;
  const out = Number(inv.totalAud) - Number(inv.paidAud || 0);
  const r = await ask(
    `Book a payment on ${inv.number}`,
    [
      { name: 'amountAud', label: 'Amount received AUD', type: 'number', required: true, hint: `${rcvMoney(out)} outstanding` },
      { name: 'externalId', label: 'Bank transaction id / hash', required: true, hint: 'Required — a payment without an id is a claim, not a credit' },
      { name: 'note', label: 'Note (optional)' },
    ],
    'Book payment'
  );
  if (!r) return;
  await withVault(() => api(`/api/invoices/${id}/credit`, { method: 'POST', body: r }));
  toast(`${inv.number}: payment booked with proof`);
  await refresh();
}

async function attachDialog(externalId, amount) {
  const open = (S.st.invoices || []).filter((i) => ['sent', 'part', 'overdue'].includes(i.status));
  if (!open.length) return toast('No open invoices to attach this to', true);
  const r = await ask(
    'Attach an unmatched credit',
    [
      { name: 'invoice', label: `Invoice (${open.map((i) => i.number).join(', ')})`, required: true, hint: 'Type the invoice number' },
      { name: 'amountAud', label: 'Amount AUD', type: 'number', hint: `default ${amount || ''}` },
    ],
    'Attach'
  );
  if (!r) return;
  const inv = open.find((i) => i.number.toLowerCase() === String(r.invoice).trim().toLowerCase());
  if (!inv) return toast('No such open invoice', true);
  await withVault(() =>
    api(`/api/invoices/${inv.id}/credit`, {
      method: 'POST',
      body: { amountAud: Number(r.amountAud) || amount, externalId: externalId || `manual:${Date.now()}`, note: 'attached from unmatched' },
    })
  );
  toast(`Attached to ${inv.number}`);
  await refresh();
}

// Register the surface. app.js keeps VIEWS in the shared global scope.
VIEWS.receive = { init: initReceive, render: renderReceive };
