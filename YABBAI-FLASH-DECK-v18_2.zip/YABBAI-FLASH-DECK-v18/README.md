# YABBAI FLASH · Command Deck v18

One system, three places to open it: your laptop, Render, and Google AI Studio.

- **Engine** (`engine/`, Node, no npm dependencies): the book of record. Ledger with receipts, invoices and payment rails, leads and outreach drafts, the oil journal, the agents and the MCP server.
- **Deck** (`studio/`, React): the screens. DECK, OPS, TREASURY, LEADS, RECEIVE, OIL DESK. The engine serves a built copy at `/studio/`; the same source runs in AI Studio.

**v18** adds an operations layer: `/api/v1` (CRM, sales, tasks, agents, workflows, events, executive overview, audit), a durable event bus, a registry of 10 agents with server-side permissions, and the first end-to-end workflow: a lead becomes a proposal drafted by the Sales Director agent, a person approves it with the Director vault, and the customer, opportunity, audit trail and executive view update. The OPS and TREASURY tabs are new. Start with `docs/V18-IMPLEMENTATION-STATUS.md`; the other `docs/V18-*.md` files cover the architecture, API, events, permissions, security, tests, deployment and what comes next.

Real things only. Every number on the deck comes from the engine: a ledger entry needs a receipt reference, an invoice is paid only when a rail proves it, a lead is a row someone actually supplied, an oil price carries its source and time, and a journal trade carries the broker's ticket. The v14 studio's simulated surfaces (random leads, random trade wins, invented bank trace IDs, browser-side balances) are gone, and the engine's crypto paper loop is off by default.

## What each screen does

| Screen | Reads / writes | Notes |
|---|---|---|
| OPS (v18) | `/api/v1/*` | Executive metrics, each with its source, basis, time and a live / stale / estimated / unavailable status. Proposals waiting for you (approve or reject with the vault), workflow runs, agent tasks, the agent registry, the event bus and dead letters. |
| TREASURY (v18 tab, v16 engine) | `/api/v2/*` | Cash by stage (cleared, seen in accounts, available, reserved, committed, pending), what still needs configuring, approvals, accounts, reconciliation, the journal and the kill switch. |
| DECK | `/api/state`, `/api/desk` | Ledger totals, MRR from recurring receipts, money owed, pipeline by stage and source, what is waiting on you, agents, connections, activity. |
| LEADS | `/api/leads*`, `/api/outbox/*` | Import from Pancake, CSV, a pasted table or JSON. Duplicates (same email, website or source id) are skipped. The Closer drafts outreach that waits for your approval. "Won" books the payment to the ledger and needs a receipt reference. |
| RECEIVE | `/api/invoices*`, `/api/receive*` | Unchanged from v14: invoices, pay links, PayPal, AU bank (INV reference), Solana Pay, BTC/ETH. |
| OIL DESK | `/api/desk*` | Live WTI and Brent (Yahoo Finance, Stooq fallback), a position-size calculator, a journal of trades you placed at your broker (ticket required), and a guardian for daily loss and drawdown. It does not place orders. |

## Run it on the laptop (Windows)

1. `INSTALL-YABBAI.bat` once (Node, Ollama and the model).
2. `START-YABBAI.bat`. It opens `http://127.0.0.1:7860`, which now goes straight to the deck. The engine console (models, brains, rails setup) moved to `http://127.0.0.1:7860/console`.
3. On this machine the deck links itself. Your data stays in the `data` folder next to `START-YABBAI.bat` (back it up; it is your ledger). When you upgrade, carry that folder over.

## Run it on Render

`render.yaml` describes one web service with a 1 GB disk at `/var/data`. A disk needs a paid instance (Starter). Region is Singapore.

1. Push this folder to a GitHub repo, then in Render: **New → Blueprint** and pick the repo.
2. Fill `HF_TOKEN` (Hugging Face, for the brain; Render has no Ollama) and, if you use PayPal, `PAYPAL_CLIENT_SECRET`.
3. When it is live, open `https://<your-service>.onrender.com/login?token=<YABBAI_TOKEN>` once. The token is in the service's Environment tab. That sets a 30-day cookie and the deck opens.
4. Rails setup (bank, PayPal client ID, wallets) is in `/console` → Receive, same as v14. Pay links and webhooks use the Render URL automatically (`RENDER_EXTERNAL_URL`).

Pick one book of record. If Render holds your invoices and ledger, use the laptop for the model (or keep the laptop engine for offline work), but do not run two engines that both take payments.

## Open it in Google AI Studio

Upload `studio/` (the zip `yabbai-flash-deck-studio-v18.zip`) to your AI Studio app. Then click **NOT LINKED** in the deck and paste the engine URL (Render) and token. AI Studio cannot reach your laptop's `127.0.0.1`, so link it to Render or to a tunnel URL. The deck uses no Gemini key and makes no metered calls.

Cross-origin rules: a page from another origin (AI Studio) must send the token as a bearer header on every request. A website open in the same browser cannot drive your local engine, because loopback trust no longer applies to foreign origins.

## Hook up Pancake (pancake.ai)

Pancake works through MCP inside Claude, so the hookup goes through Claude too:

1. claude.ai → Settings → Connectors: finish connecting **Pancake**.
2. Add a custom connector for YABBAI with the URL from LEADS → Hook up Pancake → Show my connector URL. It looks like `https://<render-url>/mcp/<token>`; keep it private.
3. Ask Claude: "Pull my new Pancake leads into YABBAI." Claude reads them from Pancake and calls the engine's `import_leads` tool. Run it as a scheduled task if you want it daily.

Without the connector: export or copy the leads from Pancake and use LEADS → Import. Same mapping, same duplicate checks.

New MCP / OpenAPI tools in v15: `import_leads`, `list_leads`, `get_oil_desk` (read-only).

## Oil desk

- Prices: Yahoo Finance chart API (`CL=F`, `BZ=F`), Stooq (`cl.f`, `cb.f`) as fallback. If both fail, the desk says so and shows the last known price with its time.
- Journal: log a trade after you place it. Entry is your fill price; the broker ticket is required. Open rows are marked to the live price. Record the close with the broker's exit price (or the broker's P&L, which wins over the computed figure).
- Guardian: set your account size and limits (daily loss %, max drawdown %, risk per trade %, barrels per lot, daily reset hour). It shows today's headroom, what happens if every stop is hit, drawdown used and risk per trade.
- Orders: since v16 the desk can link your cTrader account (demo first) and send a market order with its stop when you press the button. Every order meets the guardian first and the account has to be armed. No agent, workflow or API route can send one.

## Tests

```
cd engine
npm test          # 8 suites, 499 checks (v18: smoke18-ops, 103 checks in 18 gates)
cd ../studio
npx tsc --noEmit  # type check
npm run build:studio   # builds the deck into engine/public/studio
```

Results and what the tests do not cover: `docs/V18-TEST-REPORT.md`.

## Files

- `engine/lib/leadimport.js` (new): column mapping, CSV / markdown table / JSON parsing, duplicate keys.
- `engine/lib/desk.js` (new): quotes, journal, guardian.
- `engine/server.js`: Render env (`PORT`, `RENDER_EXTERNAL_URL`, `YABBAI_TOKEN`), `/healthz`, `/mcp/<token>`, CORS + bearer rules, `/` → deck, `/console`.
- `studio/src/`: four screens, one engine poll shared by all of them (`context/EngineContext.tsx`).
- `docs/ENGINE-REFERENCE-v14.md`: the full v14 engine guide (rails, brains, Open WebUI).
