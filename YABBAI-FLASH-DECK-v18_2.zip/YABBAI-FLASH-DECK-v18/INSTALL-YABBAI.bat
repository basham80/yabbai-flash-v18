@echo off
setlocal
cd /d "%~dp0"
title YABBAI LOCAL - install
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\install.ps1" %*
echo.
pause
