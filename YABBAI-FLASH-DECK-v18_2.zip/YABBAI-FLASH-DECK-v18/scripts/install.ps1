# YABBAI LOCAL - Windows installer. Run it with INSTALL-YABBAI.bat (double-click).
# Installs/updates: Node.js LTS, Ollama, uv. Then the Node launcher picks the model for
# this PC, downloads it from Hugging Face, test-loads it on the GPU and prepares Open WebUI.
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }

function Say([string]$Text, [string]$Color = 'Gray') { Write-Host $Text -ForegroundColor $Color }
function Step([string]$Text) { Write-Host ''; Write-Host "> $Text" -ForegroundColor Cyan }
function Has([string]$Name) { return [bool](Get-Command $Name -ErrorAction SilentlyContinue) }
function Refresh-Path {
  $machine = [Environment]::GetEnvironmentVariable('Path', 'Machine')
  $user = [Environment]::GetEnvironmentVariable('Path', 'User')
  $env:Path = "$machine;$user;$env:USERPROFILE\.local\bin"
}
function Winget-Install([string]$Id) {
  winget install --id $Id -e --silent --accept-package-agreements --accept-source-agreements
}

$Root = Split-Path -Parent $PSScriptRoot
Say ''
Say 'YABBAI LOCAL - installer' 'White'

# 1. Stay out of OneDrive: its sync locks break saving.
if ($Root -match 'OneDrive') {
  $Target = 'C:\yabbai\yabbai-local'
  Step "Moving YABBAI out of OneDrive to $Target"
  New-Item -ItemType Directory -Force -Path $Target | Out-Null
  robocopy "$Root" "$Target" /E /NFL /NDL /NJH /NJS /NP /XD data | Out-Null
  Say "Copied. Continuing from $Target" 'Green'
  & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $Target 'scripts\install.ps1') @args
  exit $LASTEXITCODE
}

Get-ChildItem -Path $Root -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue
$HasWinget = Has 'winget'
if (-not $HasWinget) { Say 'winget not found - using direct downloads where possible.' 'Yellow' }

# 2. Node.js 18+ (runs the YABBAI engine; no npm packages needed)
Step 'Node.js'
$nodeOk = $false
if (Has 'node') {
  $major = [int]((node --version).TrimStart('v').Split('.')[0])
  if ($major -ge 18) { $nodeOk = $true; Say "Node $(node --version) found" 'Green' }
}
if (-not $nodeOk) {
  if (-not $HasWinget) { Say 'Install Node.js LTS from https://nodejs.org, then run this installer again.' 'Red'; exit 1 }
  Say 'Installing Node.js LTS (Windows may ask for permission)...'
  Winget-Install 'OpenJS.NodeJS.LTS'
  Refresh-Path
  if (-not (Has 'node')) { Say 'Node.js is installed but this window cannot see it yet. Close it and run INSTALL-YABBAI.bat again.' 'Yellow'; exit 1 }
}

# 3. Ollama (runs the model) - install, or update so it can load Qwen3.5 GGUFs
Step 'Ollama'
$ollamaExe = Join-Path $env:LOCALAPPDATA 'Programs\Ollama\ollama.exe'
if ((Has 'ollama') -or (Test-Path $ollamaExe)) {
  if ($HasWinget) {
    Say 'Checking for an Ollama update...'
    winget upgrade --id Ollama.Ollama -e --silent --accept-package-agreements --accept-source-agreements | Out-Null
  }
  Say 'Ollama ready' 'Green'
} else {
  if ($HasWinget) {
    Say 'Installing Ollama...'
    Winget-Install 'Ollama.Ollama'
  } else {
    $setup = Join-Path $env:TEMP 'OllamaSetup.exe'
    Say 'Downloading Ollama...'
    Invoke-WebRequest -Uri 'https://ollama.com/download/OllamaSetup.exe' -OutFile $setup -UseBasicParsing
    Start-Process -FilePath $setup -ArgumentList '/VERYSILENT', '/NORESTART', '/SUPPRESSMSGBOXES' -Wait
  }
  Refresh-Path
}

# 4. Tune Ollama for an 8 GB GPU (user-level settings, picked up on restart)
Step 'Tuning Ollama'
$tuning = @{ 'OLLAMA_FLASH_ATTENTION' = '1'; 'OLLAMA_KV_CACHE_TYPE' = 'q8_0'; 'OLLAMA_KEEP_ALIVE' = '30m'; 'OLLAMA_CONTEXT_LENGTH' = '8192' }
foreach ($k in $tuning.Keys) {
  [Environment]::SetEnvironmentVariable($k, $tuning[$k], 'User')
  Set-Item -Path "Env:$k" -Value $tuning[$k]
}
Get-Process -Name 'ollama app', 'ollama' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Say 'Flash attention on, 8-bit KV cache, 8K context, model stays loaded for 30 min' 'Green'

# 5. uv - runs Open WebUI with its own private Python 3.11
Step 'uv (for Open WebUI)'
$uvx = Join-Path $env:USERPROFILE '.local\bin\uvx.exe'
if ((Has 'uvx') -or (Test-Path $uvx)) {
  Say 'uv ready' 'Green'
} else {
  if ($HasWinget) { Winget-Install 'astral-sh.uv' } else { Invoke-RestMethod 'https://astral.sh/uv/install.ps1' | Invoke-Expression }
  Refresh-Path
}

# 6. Model pick, Hugging Face download, GPU test, Open WebUI prep
Step 'Model, GPU test and Open WebUI'
$code = 1
Push-Location $Root
try {
  & node 'scripts\launcher.js' install @args
  $code = $LASTEXITCODE
} finally {
  Pop-Location
}
if ($code -ne 0) { Say 'Install did not finish - read the messages above, then run INSTALL-YABBAI.bat again.' 'Red'; exit $code }

# 7. Desktop shortcut
try {
  $shell = New-Object -ComObject WScript.Shell
  $lnk = $shell.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) 'YABBAI.lnk'))
  $lnk.TargetPath = Join-Path $Root 'START-YABBAI.bat'
  $lnk.WorkingDirectory = $Root
  $lnk.Description = 'Start YABBAI LOCAL'
  $lnk.Save()
  Say 'Desktop shortcut "YABBAI" created' 'Green'
} catch {
  Say 'Could not create a desktop shortcut (not critical).' 'Yellow'
}
exit 0
