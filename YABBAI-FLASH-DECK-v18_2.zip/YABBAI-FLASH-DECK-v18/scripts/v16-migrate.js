#!/usr/bin/env node
'use strict';
// YABBAI v15 → v16 migration, by hand. The engine runs the same migration by itself at start-up
// (once, and again for anything v15 booked that the journal has not seen); use this to see the
// plan first, or to run it with the engine stopped and read the full report.
//
//   node scripts/v16-migrate.js                 plan only (nothing is written)
//   node scripts/v16-migrate.js --run           back up, migrate, print the report
//   node scripts/v16-migrate.js --data D:\yabbai-data --run
//
// The v15 records are read, never changed: the report proves it with a fingerprint of the v15
// ledger, payments, allocations and payouts taken before and after. Exit code 1 if a check fails.
const path = require('path');

const args = process.argv.slice(2);
const flag = (f) => args.includes(f);
const opt = (f) => {
  const i = args.indexOf(f);
  return i >= 0 ? args[i + 1] : null;
};
if (flag('--help') || flag('-h')) {
  console.log('node scripts/v16-migrate.js [--data DIR] [--run]\n  without --run: shows the plan and writes nothing');
  process.exit(0);
}
if (opt('--data')) process.env.YABBAI_DATA = path.resolve(opt('--data'));
const E = (m) => require(path.join(__dirname, '..', 'engine', 'lib', m));

function main() {
  const { DATA_DIR } = E('util');
  E('enginelock').assertStopped();
  const store = E('store');
  const tstore = E('tstore');
  const audit = E('audit');
  const journal = E('journal');
  const vault = E('vault');
  const bookkeeper = E('bookkeeper');
  store.load();
  tstore.load();
  audit.load();
  journal.load();
  vault.load();
  console.log(`YABBAI v16 migration · data folder ${DATA_DIR}\n`);
  const plan = bookkeeper.migrate({ dryRun: true });
  const b = plan.before;
  console.log('v15 baseline');
  console.log(`  ledger      ${b.ledger.count} entries · income A$${b.ledger.income.toFixed(2)} · costs A$${b.ledger.costs.toFixed(2)}`);
  console.log(`  payments    ${b.payments.count} · A$${b.payments.total.toFixed(2)}`);
  console.log(`  allocations ${b.allocations.count} · executed A$${b.allocations.executed.toFixed(2)} · pending A$${b.allocations.pending.toFixed(2)}`);
  console.log(`  payouts     ${b.payouts.count} · paid A$${b.payouts.paid.toFixed(2)} · requested A$${b.payouts.requested.toFixed(2)}`);
  console.log(`  fingerprint ${b.fingerprint}\n`);
  console.log('to carry into the journal');
  console.log(`  ${plan.plan.ledgerEntries} ledger entries, ${plan.plan.allocations} allocations, ${plan.plan.payoutsPaid} paid payouts`);
  if (plan.plan.payoutsRequested.length) console.log(`  ${plan.plan.payoutsRequested.length} unpaid payout request(s) stay in the queue: mark them paid there, or cancel them`);
  if (!flag('--run')) {
    console.log('\nPlan only. Add --run to back up and migrate.');
    return 0;
  }
  const actor = { type: 'system', id: 'cli', label: 'v16-migrate script' };
  const bk = E('backup').create(actor, { note: 'before v16-migrate --run' });
  console.log(`\nbackup ${bk.id} (${bk.files} files) in ${path.join(DATA_DIR, 'backups', bk.id)}`);
  const r = bookkeeper.migrate();
  tstore.flush();
  store.flush();
  console.log(`\nreport ${r.id} · ${r.ok ? 'PASS' : 'FAIL'}`);
  for (const c of r.checks) console.log(`  ${c.ok ? 'ok  ' : 'FAIL'} ${c.what}: v15 A$${c.v15.toFixed(2)} · journal A$${c.journal.toFixed(2)}`);
  console.log(`  ${r.v15Untouched ? 'ok  ' : 'FAIL'} v15 records unchanged (fingerprint before = after)`);
  for (const e of r.errors) console.log(`  error ${e.ledgerId || e.payoutId}: ${e.error}`);
  console.log(`\ncarried: ${r.carried.ledgerEntries} ledger entries, ${r.carried.allocations} allocations, ${r.carried.payoutsPaid} paid payouts`);
  if (r.accountsRegistered.length) console.log(`registered (watch-only): ${r.accountsRegistered.join(', ')}`);
  console.log(`full report: ${path.join(DATA_DIR, 'treasury', 'migrations', `v15-to-v16-${r.at.replace(/[:.]/g, '-')}.json`)}`);
  return r.ok ? 0 : 1;
}

try {
  process.exitCode = main();
} catch (e) {
  console.error(`v16-migrate: ${e.message}`);
  process.exitCode = 1;
}
