#!/usr/bin/env node
/**
 * YABBAI — public tunnel supervisor.
 *
 * Quick tunnels are disposable: the hostname dies with the process, and every
 * restart changes the URL. That silently breaks two things — pay links already
 * sent to clients, and the PayPal webhook. This script keeps the pair honest:
 *
 *   1. runs `cloudflared tunnel --url http://127.0.0.1:PORT`
 *   2. reads the new https://….trycloudflare.com host out of the log
 *   3. writes it into the engine as receive.publicBase
 *   4. points the PayPal webhook at /webhooks/paypal on that host (deleting the
 *      stale one so you never accumulate dead endpoints)
 *   5. restarts the tunnel if it dies, and repeats
 *
 *   node scripts/tunnel-supervise.mjs
 *
 * For a permanent hostname do the named-tunnel dance in GO-LIVE.txt instead;
 * this is the "keep it reachable today" answer.
 */
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const dataDir = process.env.YABBAI_DATA || path.join(root, 'data');
const logs = path.join(dataDir, 'logs');
fs.mkdirSync(logs, { recursive: true });

const PORT = process.env.YABBAI_PORT || '7860';
const BASE = `http://127.0.0.1:${PORT}`;
const LOG = path.join(logs, 'tunnel.log');
const STATE = path.join(dataDir, 'state');
fs.mkdirSync(STATE, { recursive: true });

const CF = process.env.CLOUDFLARED || 'C:\\Program Files (x86)\\cloudflared\\cloudflared.exe';
const PAYPAL_FILE = path.join(dataDir, 'secrets', 'paypal.json');

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const log = (...a) => console.log(new Date().toISOString().slice(11, 19), ...a);

function readJson(file, fallback = null) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return fallback;
  }
}
function token() {
  const s = readJson(path.join(dataDir, 'secret.json'), {});
  if (!s.token) throw new Error('engine token missing — is YABBAI installed here?');
  return s.token;
}
async function api(pathname, init = {}) {
  const res = await fetch(`${BASE}${pathname}`, {
    method: init.method || 'GET',
    headers: { Authorization: `Bearer ${token()}`, 'X-Yabbai': '1', ...(init.body ? { 'Content-Type': 'application/json' } : {}) },
    body: init.body ? JSON.stringify(init.body) : undefined,
  });
  const text = await res.text();
  let data = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = { raw: text.slice(0, 200) };
  }
  if (!res.ok) throw new Error(`${pathname} -> ${res.status} ${(data && data.error) || ''}`);
  return data;
}

function paypalCreds() {
  const set = readJson(path.join(dataDir, 'db.json'), {})?.settings?.receive?.paypal || {};
  const secret = process.env.PAYPAL_CLIENT_SECRET || readJson(PAYPAL_FILE, {})?.secret || '';
  return { mode: set.mode === 'live' ? 'live' : 'sandbox', clientId: set.clientId, secret, webhookId: set.webhookId };
}
async function paypalToken({ mode, clientId, secret }) {
  const host = mode === 'live' ? 'https://api-m.paypal.com' : 'https://api-m.sandbox.paypal.com';
  const auth = Buffer.from(`${clientId}:${secret}`).toString('base64');
  const res = await fetch(`${host}/v1/oauth2/token`, {
    method: 'POST',
    headers: { Authorization: `Basic ${auth}`, 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'grant_type=client_credentials',
  });
  const j = await res.json();
  if (!j.access_token) throw new Error(`PayPal auth failed: ${j.error_description || j.error || res.status}`);
  return { host, token: j.access_token };
}

// Re-point PayPal's webhook at a new host. Old ones are deleted by id — a stale
// webhook is worse than none: it looks configured and delivers nowhere.
async function pointWebhook(url) {
  const creds = paypalCreds();
  if (!creds.clientId || !creds.secret) return { skipped: 'no paypal creds' };
  const { host, token: bearer } = await paypalToken(creds);
  const h = { Authorization: `Bearer ${bearer}`, 'Content-Type': 'application/json' };
  const list = await (await fetch(`${host}/v1/notifications/webhooks`, { headers: h })).json();
  const existing = (list.webhooks || []).find((w) => w.url === url);
  if (existing) {
    if (existing.id !== creds.webhookId) await api('/api/receive/settings', { method: 'POST', body: { paypal: { webhookId: existing.id } } });
    return { kept: existing.id };
  }
  const created = await fetch(`${host}/v1/notifications/webhooks`, {
    method: 'POST',
    headers: h,
    body: JSON.stringify({
      url,
      event_types: ['CHECKOUT.ORDER.APPROVED', 'PAYMENT.CAPTURE.COMPLETED', 'PAYMENT.CAPTURE.DENIED', 'PAYMENT.CAPTURE.REFUNDED'].map((name) => ({ name })),
    }),
  });
  const w = await created.json();
  if (!created.ok || !w.id) throw new Error(`webhook create failed: ${JSON.stringify(w).slice(0, 200)}`);
  for (const old of list.webhooks || []) {
    if (old.id === w.id) continue;
    await fetch(`${host}/v1/notifications/webhooks/${old.id}`, { method: 'DELETE', headers: h });
  }
  await api('/api/receive/settings', { method: 'POST', body: { paypal: { webhookId: w.id } } });
  return { created: w.id, removed: (list.webhooks || []).length };
}

let child = null;
let stopping = false;

async function runOnce() {
  try {
    fs.rmSync(LOG, { force: true });
  } catch {
    /* log may be locked by the previous process */
  }
  log(`starting tunnel -> ${BASE}`);
  child = spawn(CF, ['tunnel', '--url', BASE, '--no-autoupdate', '--logfile', LOG, '--loglevel', 'info'], {
    stdio: 'ignore',
    detached: false,
  });

  const deadline = Date.now() + 60000;
  let url = null;
  while (Date.now() < deadline) {
    await sleep(1500);
    let text = '';
    try {
      text = fs.readFileSync(LOG, 'utf8');
    } catch {
      continue;
    }
    const m = /https:\/\/[a-z0-9-]+\.trycloudflare\.com/.exec(text);
    if (m) {
      url = m[0];
      break;
    }
  }
  if (!url) throw new Error('cloudflared produced no hostname in 60s');

  fs.writeFileSync(path.join(STATE, 'tunnel.json'), JSON.stringify({ url, at: new Date().toISOString(), port: PORT }, null, 2));
  log('public host:', url);
  await api('/api/receive/settings', { method: 'POST', body: { publicBase: url } });
  log('engine publicBase updated');
  try {
    const w = await pointWebhook(`${url}/webhooks/paypal`);
    log('paypal webhook:', JSON.stringify(w));
  } catch (e) {
    log('paypal webhook not updated:', e.message);
  }

  // Watch the process. A quick tunnel can die without the child exiting, so also
  // poll the public host and restart when it stops answering.
  let failures = 0;
  for (;;) {
    await sleep(15000);
    if (stopping) return 'stop';
    if (!child || child.exitCode !== null) {
      log('tunnel process exited');
      return 'restart';
    }
    try {
      const res = await fetch(`${url}/pay/healthcheck`, { method: 'GET' });
      // 404 is fine: it proves the tunnel reached the engine.
      if (res.status >= 500) throw new Error(`HTTP ${res.status}`);
      failures = 0;
    } catch (e) {
      failures++;
      log(`public probe failed (${failures}/3): ${e.message}`);
      if (failures >= 3) {
        try {
          child.kill();
        } catch {
          /* already gone */
        }
        return 'restart';
      }
    }
  }
}

async function main() {
  for (;;) {
    try {
      const outcome = await runOnce();
      if (outcome === 'stop') break;
    } catch (e) {
      log('tunnel error:', e.message);
    }
    if (stopping) break;
    log('restarting in 10s…');
    await sleep(10000);
  }
}

process.on('SIGINT', () => {
  stopping = true;
  try {
    child && child.kill();
  } catch {
    /* nothing */
  }
  process.exit(0);
});
process.on('SIGTERM', () => {
  stopping = true;
  try {
    child && child.kill();
  } catch {
    /* nothing */
  }
  process.exit(0);
});

main().catch((e) => {
  console.error('[tunnel] fatal:', e.message);
  process.exit(1);
});
