#!/usr/bin/env bash
# YABBAI LOCAL — macOS / Linux installer: Node.js, Ollama, uv, then the model + GPU test.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
have() { command -v "$1" >/dev/null 2>&1; }
echo; echo "YABBAI LOCAL — installer"
if ! have node || [ "$(node -p 'process.versions.node.split(".")[0]')" -lt 18 ]; then
  if have brew; then brew install node; else echo "Install Node.js 18+ from https://nodejs.org and run this again."; exit 1; fi
fi
if ! have ollama; then
  if [[ "$(uname)" == "Darwin" ]] && have brew; then brew install ollama; else curl -fsSL https://ollama.com/install.sh | sh; fi
fi
if ! have uvx && [ ! -x "$HOME/.local/bin/uvx" ]; then curl -LsSf https://astral.sh/uv/install.sh | sh; fi
export PATH="$HOME/.local/bin:$PATH"
export OLLAMA_FLASH_ATTENTION=1 OLLAMA_KV_CACHE_TYPE=q8_0 OLLAMA_KEEP_ALIVE=30m OLLAMA_CONTEXT_LENGTH=8192
cd "$ROOT" && node scripts/launcher.js install "$@"
echo "Start YABBAI with: ./scripts/start.sh"
