#!/usr/bin/env node
'use strict';
// Restore a YABBAI v16 backup, with the engine stopped.
//
//   node scripts/v16-restore.js                       list the backups
//   node scripts/v16-restore.js bk-2026-11-15T…       drill only: would this restore cleanly?
//   node scripts/v16-restore.js bk-2026-11-15T… --yes restore it
//   add --data DIR for a data folder other than data/ in the YABBAI folder (or YABBAI_DATA)
//
// Before anything is overwritten, the backup passes its drill (every file's sha256, both hash
// chains, every balance rebuilt from its own journal) and the current state is backed up as
// "pre-restore", so a wrong restore can be undone the same way. The vault (data/secrets) is
// never in a backup and is not touched: unlock with the vault you kept, or set it up again.
const path = require('path');

const args = process.argv.slice(2);
const opt = (f) => {
  const i = args.indexOf(f);
  return i >= 0 ? args[i + 1] : null;
};
if (args.includes('--help') || args.includes('-h')) {
  console.log('node scripts/v16-restore.js [backup-id] [--yes] [--data DIR]');
  process.exit(0);
}
if (opt('--data')) process.env.YABBAI_DATA = path.resolve(opt('--data'));
const id = args.find((a, i) => !a.startsWith('--') && args[i - 1] !== '--data') || null;
const E = (m) => require(path.join(__dirname, '..', 'engine', 'lib', m));

function main() {
  const { DATA_DIR } = E('util');
  E('enginelock').assertStopped();
  const store = E('store');
  const tstore = E('tstore');
  const audit = E('audit');
  const journal = E('journal');
  const backup = E('backup');
  store.load();
  tstore.load();
  audit.load();
  journal.load();
  const list = backup.list();
  if (!id) {
    console.log(`Backups in ${path.join(DATA_DIR, 'backups')}:`);
    if (!list.length) console.log('  (none: make one in Treasury → Controls → Backups)');
    for (const b of list) console.log(`  ${b.id}  ${b.files} files · ${b.transactions} journal entries · ${b.auditRecords} audit records${b.lastDrill ? ` · last drill ${b.lastDrill.ok ? 'ok' : 'FAILED'}` : ''}${b.note ? ` · ${b.note}` : ''}`);
    return 0;
  }
  const drill = backup.verify(id);
  console.log(`drill for ${id}: ${drill.ok ? 'PASS' : 'FAIL'}`);
  for (const c of drill.checks) console.log(`  ${c.ok ? 'ok  ' : 'FAIL'} ${c.what}${c.detail ? ` (${c.detail})` : ''}`);
  if (!drill.ok) return 1;
  if (!args.includes('--yes')) {
    console.log(`\nDrill only. To restore over ${DATA_DIR}, run again with --yes (the engine must stay stopped).`);
    return 0;
  }
  const actor = { type: 'system', id: 'cli', label: 'v16-restore script' };
  const safety = backup.create(actor, { note: `pre-restore (before restoring ${id})` });
  console.log(`\ncurrent state saved as ${safety.id}`);
  journal.close();
  audit.close();
  const out = backup.restoreInto(id, DATA_DIR);
  // The restored audit trail records the restore itself, at the end of its own chain.
  audit.load();
  audit.record(actor, 'backup.restored', id, { files: out.restored, safetyBackup: safety.id });
  audit.close();
  const again = backup.balancesFromFile(path.join(DATA_DIR, 'treasury', 'journal.jsonl'));
  console.log(`restored ${out.restored} files into ${DATA_DIR}`);
  console.log(`journal: ${again.transactions} entries · chain ${again.chain.ok ? 'ok' : 'BROKEN'} · ${Object.keys(again.balances).length} balances`);
  console.log('Start the engine and unlock the vault.');
  return again.chain.ok ? 0 : 1;
}

try {
  process.exitCode = main();
} catch (e) {
  console.error(`v16-restore: ${e.message}`);
  process.exitCode = 1;
}
