#!/usr/bin/env node
'use strict';
// YABBAI LOCAL launcher — install | start | stop | status | doctor
// Zero dependencies. Windows, macOS and Linux.
const { spawn, spawnSync } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const DATA = path.resolve(process.env.YABBAI_DATA || path.join(ROOT, 'data'));
const LOGS = path.join(DATA, 'logs');
const PIDS = path.join(DATA, 'pids.json');
const IS_WIN = process.platform === 'win32';
const ENGINE_PORT = Number(process.env.YABBAI_PORT || 7860);
const WEBUI_PORT = Number(process.env.OPENWEBUI_PORT || 8080);
const OLLAMA = String(process.env.OLLAMA_URL || 'http://127.0.0.1:11434').replace(/\/+$/, '');
const WEBUI_VERSION = process.env.OPENWEBUI_VERSION || '0.12.3'; // the version YABBAI's wiring was verified against
const ENGINE = `http://127.0.0.1:${ENGINE_PORT}`;
const WEBUI = `http://127.0.0.1:${WEBUI_PORT}`;

const TIERS = {
  XL: ['hf.co/unsloth/Qwen3.6-27B-GGUF:UD-Q4_K_XL', 'hf.co/unsloth/Qwen3.5-9B-GGUF:Q4_K_M', 'qwen3.5:9b'],
  M: ['hf.co/unsloth/Qwen3.5-9B-GGUF:Q4_K_M', 'qwen3.5:9b'],
  S: ['hf.co/unsloth/Qwen3.5-4B-GGUF:UD-Q4_K_XL', 'qwen3.5:4b'],
};
const OLLAMA_TUNING = { OLLAMA_FLASH_ATTENTION: '1', OLLAMA_KV_CACHE_TYPE: 'q8_0', OLLAMA_KEEP_ALIVE: '30m', OLLAMA_CONTEXT_LENGTH: '8192' };

// ── output ──────────────────────────────────────────────────
const tty = process.stdout.isTTY;
const c = (code) => (s) => (tty ? `\x1b[${code}m${s}\x1b[0m` : s);
const green = c(32);
const yellow = c(33);
const red = c(31);
const cyan = c(36);
const bold = c(1);
const say = (s = '') => console.log(s);
const step = (s) => say(`\n${cyan('▸')} ${bold(s)}`);
const okLine = (s) => say(`  ${green('✓')} ${s}`);
const warn = (s) => say(`  ${yellow('!')} ${s}`);
const bad = (s) => say(`  ${red('✗')} ${s}`);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ── small helpers ───────────────────────────────────────────
async function getJson(url, { method = 'GET', body, timeout = 4000 } = {}) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeout);
  try {
    const res = await fetch(url, { method, headers: body ? { 'Content-Type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined, signal: ctrl.signal });
    const text = await res.text();
    let data = null;
    try {
      data = JSON.parse(text);
    } catch {}
    return { ok: res.ok, status: res.status, data, text };
  } catch (e) {
    return { ok: false, status: 0, data: null, text: '', error: e.name === 'AbortError' ? 'timeout' : e.message };
  } finally {
    clearTimeout(t);
  }
}
const up = async (url) => (await getJson(url, { timeout: 1500 })).ok;
async function waitFor(url, ms) {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) {
    if (await up(url)) return true;
    await sleep(500);
  }
  return false;
}
const readJson = (f, d = null) => {
  try {
    return JSON.parse(fs.readFileSync(f, 'utf8'));
  } catch {
    return d;
  }
};
const writeJson = (f, v) => {
  fs.mkdirSync(path.dirname(f), { recursive: true });
  fs.writeFileSync(f, JSON.stringify(v, null, 2));
};

function which(cmd) {
  const r = spawnSync(IS_WIN ? 'where' : 'which', [cmd], { encoding: 'utf8' });
  if (r.status !== 0) return null;
  return r.stdout.split(/\r?\n/).map((s) => s.trim()).filter(Boolean)[0] || null;
}
function firstExisting(list) {
  return list.find((p) => p && fs.existsSync(p)) || null;
}
function findOllama() {
  return (
    which('ollama') ||
    firstExisting(
      IS_WIN
        ? [path.join(process.env.LOCALAPPDATA || '', 'Programs', 'Ollama', 'ollama.exe'), path.join(process.env.ProgramFiles || '', 'Ollama', 'ollama.exe')]
        : ['/usr/local/bin/ollama', '/opt/homebrew/bin/ollama', '/usr/bin/ollama', '/Applications/Ollama.app/Contents/Resources/ollama'],
    )
  );
}
function findUvx() {
  return which('uvx') || firstExisting([path.join(os.homedir(), '.local', 'bin', IS_WIN ? 'uvx.exe' : 'uvx'), path.join(os.homedir(), '.cargo', 'bin', IS_WIN ? 'uvx.exe' : 'uvx')]);
}

function spawnDetached(name, cmd, args, opts = {}) {
  fs.mkdirSync(LOGS, { recursive: true });
  const out = fs.openSync(path.join(LOGS, `${name}.log`), 'a');
  const child = spawn(cmd, args, { ...opts, detached: true, stdio: ['ignore', out, out], windowsHide: true });
  child.unref();
  const pids = readJson(PIDS, {});
  pids[name] = child.pid;
  writeJson(PIDS, pids);
  return child.pid;
}
function killPid(pid) {
  if (!pid) return;
  if (IS_WIN) spawnSync('taskkill', ['/PID', String(pid), '/T', '/F'], { stdio: 'ignore' });
  else {
    try {
      process.kill(-pid, 'SIGTERM');
    } catch {
      try {
        process.kill(pid, 'SIGTERM');
      } catch {}
    }
  }
}
function openBrowser(url) {
  try {
    if (IS_WIN) spawn('cmd', ['/c', 'start', '', url], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
    else spawn(process.platform === 'darwin' ? 'open' : 'xdg-open', [url], { detached: true, stdio: 'ignore' }).unref();
  } catch {}
}
const gb = (b) => `${(b / 1024 ** 3).toFixed(1)} GB`;

// ── Ollama ──────────────────────────────────────────────────
async function ensureOllama() {
  const v = await getJson(`${OLLAMA}/api/version`, { timeout: 2000 });
  if (v.ok) return v.data.version;
  const bin = findOllama();
  if (!bin) {
    bad('Ollama is not installed. Run INSTALL-YABBAI (Windows) or scripts/install.sh, or get it from https://ollama.com/download');
    return null;
  }
  spawnDetached('ollama', bin, ['serve'], { env: { ...OLLAMA_TUNING, ...process.env } });
  if (await waitFor(`${OLLAMA}/api/version`, 30000)) {
    const again = await getJson(`${OLLAMA}/api/version`);
    return again.data && again.data.version;
  }
  bad(`Ollama did not answer at ${OLLAMA} — see ${path.join(LOGS, 'ollama.log')}`);
  return null;
}

function detectHardware() {
  const ramGB = Math.round(os.totalmem() / 1024 ** 3);
  let gpu = null;
  const smi = spawnSync('nvidia-smi', ['--query-gpu=name,memory.total', '--format=csv,noheader,nounits'], { encoding: 'utf8' });
  if (smi.status === 0 && smi.stdout.trim()) {
    const [name, mem] = smi.stdout.trim().split(/\r?\n/)[0].split(',').map((s) => s.trim());
    if (Number(mem) > 0) gpu = { vendor: 'nvidia', name, vramMB: Number(mem) };
  }
  const apple = process.platform === 'darwin' && os.arch() === 'arm64';
  return { platform: process.platform, arch: os.arch(), ramGB, gpu, apple, cpus: os.cpus().length };
}

function pickTier(hw) {
  if ((hw.gpu && hw.gpu.vramMB >= 20000) || (hw.apple && hw.ramGB >= 32)) return 'XL';
  if ((hw.gpu && hw.gpu.vramMB >= 7500) || (hw.apple && hw.ramGB >= 16) || (!hw.gpu && !hw.apple && hw.ramGB >= 32)) return 'M';
  return 'S';
}

async function pullModel(model) {
  const res = await fetch(`${OLLAMA}/api/pull`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ model, stream: true }) });
  if (!res.ok) throw new Error(`HTTP ${res.status}: ${await res.text()}`);
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let buf = '';
  let lastPrint = 0;
  let lastLine = '';
  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i).trim();
      buf = buf.slice(i + 1);
      if (!line) continue;
      const evt = JSON.parse(line);
      if (evt.error) throw new Error(evt.error);
      const pct = evt.total ? ` ${((evt.completed || 0) / evt.total * 100).toFixed(1)}% of ${gb(evt.total)}` : '';
      const text = `  ${evt.status}${pct}`;
      if (tty) {
        if (Date.now() - lastPrint > 200 || evt.status === 'success') {
          process.stdout.write(`\r${text.padEnd(lastLine.length)}`);
          lastLine = text;
          lastPrint = Date.now();
        }
      } else if (evt.status !== lastLine) {
        say(`  ${evt.status}`);
        lastLine = evt.status;
      }
    }
  }
  if (tty) process.stdout.write('\n');
}

async function smokeTest(model) {
  const show = await getJson(`${OLLAMA}/api/show`, { method: 'POST', body: { model }, timeout: 15000 });
  const caps = (show.data && show.data.capabilities) || [];
  const body = { model, stream: false, messages: [{ role: 'user', content: 'Reply with exactly: ready' }], options: { num_ctx: 8192, num_predict: 16 }, keep_alive: '30m' };
  if (caps.includes('thinking')) body.think = false;
  const r = await getJson(`${OLLAMA}/api/chat`, { method: 'POST', body, timeout: 240000 });
  if (!r.ok) throw new Error((r.data && r.data.error) || r.error || `HTTP ${r.status}`);
  const d = r.data;
  const tps = d.eval_duration ? Math.round((d.eval_count / (d.eval_duration / 1e9)) * 10) / 10 : null;
  const ps = await getJson(`${OLLAMA}/api/ps`);
  const m = ps.data && (ps.data.models || []).find((x) => x.name === model || x.model === model);
  const gpuPct = m && m.size ? Math.round(((m.size_vram || 0) / m.size) * 100) : null;
  return { reply: (d.message && d.message.content || '').trim().slice(0, 40), tokensPerSec: tps, gpuPct, loadMs: Math.round((d.load_duration || 0) / 1e6) };
}

// ── commands ────────────────────────────────────────────────
async function install(flags) {
  say(bold('\nYABBAI LOCAL — installer'));
  if (/onedrive/i.test(ROOT)) warn(`This folder is inside OneDrive (${ROOT}). Sync locks can break saves — move it to e.g. C:\\yabbai and run the installer again.`);
  fs.mkdirSync(LOGS, { recursive: true });

  step('Checking Ollama (runs the AI model)');
  const ver = await ensureOllama();
  if (!ver) process.exit(1);
  okLine(`Ollama ${ver} at ${OLLAMA}`);

  step('Reading this machine');
  const hw = detectHardware();
  const tier = flags.tier && TIERS[flags.tier] ? flags.tier : pickTier(hw);
  okLine(`${hw.gpu ? `${hw.gpu.name} · ${(hw.gpu.vramMB / 1024).toFixed(1)} GB VRAM` : hw.apple ? 'Apple Silicon (unified memory)' : 'No NVIDIA GPU found (CPU mode)'} · ${hw.ramGB} GB RAM`);
  const why = { XL: 'big GPU/memory → the 27B model', M: '8 GB-class GPU → Qwen3.5 9B (fits fully on the card at 8K context)', S: 'smaller GPU/memory → the fast 4B model' };
  okLine(`Model tier ${tier}: ${why[tier]}`);

  step('Getting the AI model from Hugging Face');
  const have = await getJson(`${OLLAMA}/api/tags`);
  const installed = new Set(((have.data && have.data.models) || []).map((m) => m.name));
  const candidates = flags.model ? [flags.model] : TIERS[tier];
  let chosen = null;
  for (const model of candidates) {
    try {
      if (installed.has(model)) okLine(`${model} already downloaded`);
      else {
        say(`  pulling ${model}`);
        await pullModel(model);
      }
      say('  test-loading it (first load can take a minute)…');
      const t = await smokeTest(model);
      chosen = { model, ...t };
      okLine(`${model} answers "${t.reply}" at ${t.tokensPerSec ?? '?'} tokens/s`);
      if (t.gpuPct === null) warn('Could not read GPU placement (not critical).');
      else if (t.gpuPct >= 90) okLine(`${t.gpuPct}% of the model is on the GPU`);
      else if (t.gpuPct === 0 && hw.gpu) warn('The model is running on the CPU. Update the NVIDIA driver and Ollama, restart, then run DOCTOR-YABBAI. On laptops, set ollama.exe to "High performance" in Windows Settings → Display → Graphics.');
      else warn(`${t.gpuPct}% on the GPU — the rest spills to RAM. It works, just slower. Lower the context size in the Model tab for more speed.`);
      break;
    } catch (e) {
      warn(`${model} did not work: ${e.message}`);
      if (/architecture/i.test(e.message)) warn('Your Ollama is too old for this model family — run INSTALL-YABBAI again to update it.');
    }
  }
  if (!chosen) {
    bad('No model could be installed. Check your internet connection and free disk space, then run the installer again.');
    process.exit(1);
  }
  writeJson(path.join(DATA, 'install.json'), { model: chosen.model, tier, hardware: hw, ollamaVersion: ver, tokensPerSec: chosen.tokensPerSec, gpuPct: chosen.gpuPct, at: new Date().toISOString() });

  step('Preparing Open WebUI (the chat app)');
  const uvx = findUvx();
  if (flags['skip-webui']) warn('Skipped (--skip-webui). The YABBAI cockpit has its own chat.');
  else if (!uvx) warn('uv is not installed, so Open WebUI was skipped. The installer normally adds it; the YABBAI cockpit chat still works.');
  else {
    say(`  downloading Open WebUI ${WEBUI_VERSION} and its Python packages once (a few GB, several minutes)…`);
    const r = spawnSync(uvx, ['--python', '3.11', `open-webui@${WEBUI_VERSION}`, '--version'], { stdio: 'inherit', env: { ...process.env, PYTHONUTF8: '1' } });
    if (r.status === 0) okLine('Open WebUI ready');
    else warn('Open WebUI did not finish preparing — START-YABBAI will retry. The cockpit works without it.');
  }

  say(`\n${green(bold('Done.'))} Start YABBAI with ${bold(IS_WIN ? 'START-YABBAI.bat (or the desktop shortcut)' : './scripts/start.sh')}.`);
}

function hfToken() {
  if (process.env.HF_TOKEN) return process.env.HF_TOKEN.trim();
  const j = readJson(path.join(DATA, 'secrets', 'hf.json'), null);
  return (j && j.token) || '';
}

function deepPaths() {
  const dir = path.join(DATA, 'deepbrain');
  const py = IS_WIN ? path.join(dir, '.venv', 'Scripts', 'python.exe') : path.join(dir, '.venv', 'bin', 'python');
  return { dir, py, cfg: path.join(dir, 'config.json'), server: path.join(ROOT, 'deepbrain', 'server.py') };
}

function webuiEnv(token) {
  const hf = hfToken(); // adds Hugging Face's 70B+ models (Llama 3.3 70B, GPT-OSS 120B…) to Open WebUI's picker
  const suggestions = [
    { title: ['How are we tracking?', 'verified money + best moves today'], content: 'How are we tracking this month? Use the live state and give me the three highest-value moves for today.' },
    { title: ['Work the pipeline', 'which drafts to send first'], content: 'Which outreach drafts should I send first and why? Then tell me who to follow up.' },
    { title: ['Read the market', 'is any spread worth it after fees?'], content: 'Walk me through the current spread board. Is anything worth acting on after fees and transfer time?' },
    { title: ['Ship a product', 'pick a kit and launch it today'], content: 'Pick the Forge kit most likely to sell this week and give me a step-by-step plan to list it on Gumroad today.' },
  ];
  const toolServer = {
    type: 'openapi',
    url: ENGINE,
    path: 'openapi.json',
    auth_type: 'bearer',
    key: token,
    config: { enable: true },
    info: { id: 'yabbai', name: 'YABBAI', description: 'Money snapshot, live spread board, leads and drafts, product kits, verified ledger' },
  };
  // These seed Open WebUI on its FIRST launch; after that, changes you make in its Admin panel win.
  return {
    ...process.env,
    DATA_DIR: path.join(DATA, 'openwebui'),
    PORT: String(WEBUI_PORT),
    OLLAMA_BASE_URL: OLLAMA,
    ENABLE_OLLAMA_API: 'true',
    ENABLE_OPENAI_API: 'true',
    OPENAI_API_BASE_URLS: hf ? `${ENGINE}/v1;https://router.huggingface.co/v1` : `${ENGINE}/v1`,
    OPENAI_API_KEYS: hf ? `${token};${hf}` : token,
    TASK_MODEL_EXTERNAL: 'yabbai-lite',
    DEFAULT_MODELS: 'yabbai-director',
    TOOL_SERVER_CONNECTIONS: JSON.stringify([toolServer]),
    DEFAULT_PROMPT_SUGGESTIONS: JSON.stringify(suggestions),
    WEBUI_NAME: 'YABBAI',
    ANONYMIZED_TELEMETRY: 'false',
    SCARF_NO_ANALYTICS: 'true',
    DO_NOT_TRACK: 'true',
    PYTHONUTF8: '1',
  };
}

async function start(flags) {
  say(bold('\nYABBAI LOCAL — starting'));
  if (/onedrive/i.test(ROOT)) warn(`Running from OneDrive (${ROOT}). If the installer copied YABBAI to C:\\yabbai\\yabbai-local, use that copy (desktop shortcut) instead.`);
  fs.mkdirSync(LOGS, { recursive: true });
  const ver = await ensureOllama();
  if (ver) okLine(`Ollama ${ver}`);
  else warn('Continuing without Ollama — the cockpit will show it as down.');

  if (await up(`${ENGINE}/api/health`)) okLine(`Engine already running at ${ENGINE}`);
  else {
    spawnDetached('engine', process.execPath, [path.join(ROOT, 'engine', 'server.js')], { cwd: ROOT, env: { ...process.env, YABBAI_PORT: String(ENGINE_PORT), YABBAI_DATA: DATA, OLLAMA_URL: OLLAMA, OPENWEBUI_URL: WEBUI } });
    if (await waitFor(`${ENGINE}/api/health`, 20000)) okLine(`Engine running at ${ENGINE}`);
    else {
      bad(`Engine did not start — see ${path.join(LOGS, 'engine.log')}`);
      process.exit(1);
    }
  }
  const health = (await getJson(`${ENGINE}/api/health`)).data || {};
  if (!health.model) warn('No AI model installed yet — run the installer, or pull one in the cockpit’s Model tab.');
  else okLine(`Model: ${health.model}`);

  const dp = deepPaths();
  if (fs.existsSync(dp.cfg) && fs.existsSync(dp.py) && !flags['no-deep']) {
    const tok = (readJson(path.join(DATA, 'secret.json'), {}) || {}).token;
    const h = await getJson('http://127.0.0.1:7861/health', { timeout: 1500 });
    if (h.status === 401 || h.ok) okLine('Deep brain (AirLLM) already running');
    else if (tok) {
      spawnDetached('deepbrain', dp.py, [dp.server, '--config', dp.cfg, '--data', DATA], { cwd: dp.dir, env: { ...process.env, PYTHONUTF8: '1' } });
      okLine('Deep brain (AirLLM 70B) starting — it loads the model on its first job');
    }
  }

  if (!flags['no-webui']) {
    if (await up(`${WEBUI}/health`)) okLine(`Open WebUI already running at ${WEBUI}`);
    else {
      const uvx = findUvx();
      const token = (readJson(path.join(DATA, 'secret.json'), {}) || {}).token;
      if (!uvx) warn('uv not found, so Open WebUI was not started. Run the installer to add it; the cockpit chat works meanwhile.');
      else if (!token) warn('Engine token missing — restart YABBAI.');
      else {
        const dir = path.join(DATA, 'openwebui');
        fs.mkdirSync(dir, { recursive: true });
        spawnDetached('openwebui', uvx, ['--python', '3.11', `open-webui@${WEBUI_VERSION}`, 'serve', '--host', '127.0.0.1', '--port', String(WEBUI_PORT)], { cwd: dir, env: webuiEnv(token) });
        okLine(`Open WebUI starting at ${WEBUI} (first launch takes a few minutes; create your admin account there)`);
      }
    }
  }
  say(`\n  Cockpit     ${bold(`${ENGINE}/`)}`);
  say(`  Open WebUI  ${bold(WEBUI)}`);
  say(`  Logs        ${LOGS}`);
  if (!flags['no-browser']) openBrowser(`${ENGINE}/`);
}

function stop(flags) {
  const pids = readJson(PIDS, {});
  for (const name of ['openwebui', 'deepbrain', 'engine', ...(flags.all ? ['ollama'] : [])]) {
    if (pids[name]) {
      killPid(pids[name]);
      okLine(`stopped ${name} (pid ${pids[name]})`);
      delete pids[name];
    }
  }
  writeJson(PIDS, pids);
  if (!flags.all) say('  Ollama keeps running (other apps may use it). Use --all to stop it too.');
}

async function status() {
  const [o, e, w] = await Promise.all([getJson(`${OLLAMA}/api/version`), getJson(`${ENGINE}/api/health`), getJson(`${WEBUI}/health`)]);
  say(`${o.ok ? green('●') : red('●')} Ollama      ${o.ok ? o.data.version : 'down'}  ${OLLAMA}`);
  say(`${e.ok ? green('●') : red('●')} Engine      ${e.ok ? `${e.data.version} · model ${e.data.model || 'none'}` : 'down'}  ${ENGINE}`);
  say(`${w.ok ? green('●') : yellow('●')} Open WebUI  ${w.ok ? 'up' : 'down / starting'}  ${WEBUI}`);
  const d = await getJson('http://127.0.0.1:7861/health', { timeout: 1500 });
  const installed = fs.existsSync(deepPaths().cfg);
  say(`${d.status === 401 || d.ok ? green('●') : installed ? yellow('●') : '○'} Deep brain  ${d.status === 401 || d.ok ? 'up' : installed ? 'installed, not running' : 'not installed (INSTALL-DEEP-BRAIN.bat)'}  http://127.0.0.1:7861`);
}

async function doctor() {
  const e = await getJson(`${ENGINE}/api/doctor?warm=1`, { timeout: 300000 });
  if (!e.ok) {
    await status();
    say('\nThe engine is not running, so only the basics were checked. Start YABBAI and run this again for the full check.');
    say(`Node ${process.versions.node} · Ollama binary: ${findOllama() || 'not found'} · uvx: ${findUvx() || 'not found'}`);
    return;
  }
  for (const ch of e.data.checks) {
    say(`${ch.ok ? green('✓') : red('✗')} ${ch.name.padEnd(15)} ${ch.detail}`);
    if (ch.fix) say(`  ${yellow('→')} ${ch.fix}`);
  }
}

// ── entry ───────────────────────────────────────────────────
const [cmd = 'start', ...rest] = process.argv.slice(2);
const flags = {};
for (let i = 0; i < rest.length; i++) {
  const a = rest[i];
  if (!a.startsWith('--')) continue;
  const key = a.slice(2);
  const next = rest[i + 1];
  if (next && !next.startsWith('--')) {
    flags[key] = next;
    i++;
  } else flags[key] = true;
}
const major = Number(process.versions.node.split('.')[0]);
if (major < 18) {
  console.error('YABBAI needs Node.js 18 or newer. Install the LTS from https://nodejs.org and try again.');
  process.exit(1);
}
const COMMANDS = { install, start, stop, status, doctor };
if (require.main !== module) module.exports = { pickTier, detectHardware, webuiEnv, TIERS };
else if (!COMMANDS[cmd]) {
  say('Usage: node scripts/launcher.js <install|start|stop|status|doctor> [--model <name>] [--tier S|M|XL] [--no-webui] [--no-browser] [--skip-webui] [--all]');
  process.exit(1);
} else {
  Promise.resolve(COMMANDS[cmd](flags)).catch((err) => {
    bad(err.stack || err.message);
    process.exit(1);
  });
}
