# YABBAI deep brain (AirLLM) installer - runs a 70B+ model on an 8 GB GPU, slowly.
# Run it with INSTALL-DEEP-BRAIN.bat. Needs YABBAI LOCAL installed first.
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
function Say([string]$Text, [string]$Color = 'Gray') { Write-Host $Text -ForegroundColor $Color }
function Step([string]$Text) { Write-Host ''; Write-Host "> $Text" -ForegroundColor Cyan }

$Root = Split-Path -Parent $PSScriptRoot
$Data = Join-Path $Root 'data'
$Deep = Join-Path $Data 'deepbrain'
New-Item -ItemType Directory -Force -Path $Deep, (Join-Path $Data 'secrets') | Out-Null

Say ''
Say 'YABBAI deep brain - AirLLM, 70B on your laptop' 'White'
Say 'What to expect: AirLLM reads the whole model off your SSD for EVERY word it writes.' 'Yellow'
Say 'On a fast NVMe that is roughly 3-30 seconds per word, so a 300-word answer can take 20 minutes to hours.' 'Yellow'
Say 'Use it for overnight deep work (strategy reviews, long product files), not chat. Chat stays on the fast brains.' 'Yellow'

# 1. Model
Step 'Pick the 70B model'
Say '  1) Qwen/Qwen2.5-72B-Instruct        - no licence gate (recommended)'
Say '  2) meta-llama/Llama-3.3-70B-Instruct - accept the Meta licence on huggingface.co with your account first'
$sel = Read-Host 'Choose 1 or 2 [1]'
$Model = if ($sel -eq '2') { 'meta-llama/Llama-3.3-70B-Instruct' } else { 'Qwen/Qwen2.5-72B-Instruct' }
Say "Model: $Model" 'Green'

# 2. Disk
Step 'Checking disk space'
$driveName = (Split-Path -Qualifier $Root).TrimEnd(':')
$freeGB = [math]::Round((Get-PSDrive -Name $driveName).Free / 1GB)
Say "Free on ${driveName}: $freeGB GB (needs about 170 GB: ~140 GB download, then 4-bit layer shards; originals are deleted after splitting)"
if ($freeGB -lt 170) {
  Say 'Not enough free space for a 70B model.' 'Red'
  $go = Read-Host 'Continue anyway? (y/N)'
  if ($go -ne 'y') { exit 1 }
}

# 3. Hugging Face token - hidden prompt, stored only for your Windows user
Step 'Hugging Face token'
$TokFile = Join-Path $Data 'secrets\hf.json'
if ($env:HF_TOKEN) {
  Say 'Using HF_TOKEN from the environment.' 'Green'
} elseif (Test-Path $TokFile) {
  Say 'A token is already saved (data\secrets\hf.json).' 'Green'
} else {
  Say 'Create a NEW token at huggingface.co/settings/tokens (Read access; add "Make calls to Inference Providers" to also use the fast 70B+ brain).'
  $sec = Read-Host 'Paste it here (hidden)' -AsSecureString
  $plain = [Runtime.InteropServices.Marshal]::PtrToStringBSTR([Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec))
  if ($plain -notmatch '^hf_[A-Za-z0-9]{20,}$') { Say 'That does not look like a Hugging Face token (hf_...).' 'Red'; exit 1 }
  @{ token = $plain; savedAt = (Get-Date).ToString('o') } | ConvertTo-Json | Set-Content -Path $TokFile -Encoding UTF8
  icacls $TokFile /inheritance:r /grant:r "$($env:USERNAME):(R,W)" | Out-Null
  $plain = $null
  Say 'Saved, readable only by your Windows user.' 'Green'
}

# 4. Python + PyTorch (CUDA 12.8 build: needed for RTX 50-series) + AirLLM
Step 'Installing Python packages (several GB, one time)'
$uv = (Get-Command uv -ErrorAction SilentlyContinue).Source
if (-not $uv) { $uv = Join-Path $env:USERPROFILE '.local\bin\uv.exe' }
if (-not (Test-Path $uv)) { Say 'uv is missing - run INSTALL-YABBAI.bat first.' 'Red'; exit 1 }
$Venv = Join-Path $Deep '.venv'
& $uv venv $Venv --python 3.11
$Py = Join-Path $Venv 'Scripts\python.exe'
& $uv pip install --python $Py torch --index-url https://download.pytorch.org/whl/cu128
& $uv pip install --python $Py 'airllm==3.1.0' bitsandbytes 'transformers>=4.49,<5.13' accelerate safetensors huggingface_hub sentencepiece scipy
& $Py -c "import torch; print('CUDA available:', torch.cuda.is_available(), '|', torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'CPU only')"

# 5. Config
$cfg = @{ model = $Model; compression = '4bit'; shards = (Join-Path $Deep 'shards'); hf_home = (Join-Path $Deep 'hf'); port = 7861; max_seq_len = 4096; delete_original = $true }
$cfg | ConvertTo-Json | Set-Content -Path (Join-Path $Deep 'config.json') -Encoding UTF8

# 6. Download + split (resumable - rerun this installer if it stops)
Step "Downloading and splitting $Model (this is the long part - leave it running)"
& $Py (Join-Path $Root 'deepbrain\server.py') --config (Join-Path $Deep 'config.json') --data $Data --prepare
if ($LASTEXITCODE -ne 0) { Say 'The download/split did not finish. Rerun INSTALL-DEEP-BRAIN.bat to resume.' 'Red'; exit $LASTEXITCODE }
Say ''
Say 'Deep brain ready. START-YABBAI now starts it automatically; use it from Brains -> Deep brain.' 'Green'
exit 0
