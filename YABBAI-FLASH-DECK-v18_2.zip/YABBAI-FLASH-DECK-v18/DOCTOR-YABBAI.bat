@echo off
setlocal
cd /d "%~dp0"
title YABBAI LOCAL - health check
node "%~dp0scripts\launcher.js" doctor
echo.
pause
