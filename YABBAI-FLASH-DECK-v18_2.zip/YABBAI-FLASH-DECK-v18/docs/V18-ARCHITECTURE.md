# V18 architecture

YABBAI is one Node process: the engine. It owns every record, runs every agent and serves the deck. v18 adds an operations layer next to the v15 cockpit and the v16 treasury without changing how either of them stores money.

```mermaid
flowchart LR
  subgraph Deck["Deck (React, served at /studio)"]
    OPS[Ops tab]
    TRE[Treasury tab]
    LEADS[Leads tab]
  end
  subgraph Engine["Engine (engine/server.js)"]
    V1["/api/v1 — api-v1.js"]
    V2["/api/v2 — treasury-api.js"]
    LEG["/api/* — v15 cockpit"]
    PERM[permissions.js]
    VAULT[vault.js]
    BUS[events.js]
    RT[agentops.js]
    WF[salesflow.js]
    EXE[executive.js]
    OPSS[(data/ops/state.json)]
    DB[(data/db.json)]
    TS[(data/treasury/*)]
  end
  OPS --> V1
  TRE --> V2
  LEADS --> LEG
  V1 --> PERM --> VAULT
  V1 --> WF
  V1 --> EXE
  WF --> OPSS
  RT --> OPSS
  BUS --> OPSS
  LEG --> DB
  V2 --> TS
  DB -. "facts (lead.created, invoice.issued …)" .-> BUS
  TS -. "facts (journal_posted, approval.* …)" .-> BUS
  BUS --> RT
  BUS --> WF
```

## Stores

| Store | File | Owner module | Holds |
|---|---|---|---|
| CRM and cockpit | `data/db.json` | `store.js`, `ops.js` | leads, v15 ledger, invoices, settings, v15 outreach drafts |
| Treasury | `data/treasury/state.json`, `journal.jsonl`, `audit.jsonl` | `tstore.js`, `journal.js`, `audit.js` | accounts, policy, approvals, transfers, exceptions; the double-entry journal; the audit chain |
| Operations (new) | `data/ops/state.json` | `opsstore.js` | businesses, customers, opportunities, proposals, tasks, agent runs, workflow runs, the event outbox, inbox and dead letters, idempotency keys, agent overrides |

Every operations record carries `id`, `businessId`, `version`, `createdAt`, `updatedAt` and the last 50 changes (`history`). The backup module copies `ops/state.json` with the rest.

### Writing to the operations store

`opsstore.tx(fn)` is the only way to change it:

- `fn` runs synchronously, so no other request sees half a change.
- The whole document is written once, atomically (temp file and rename).
- If `fn` throws, the in-memory state is restored from a snapshot and nothing is written.
- A `tx` inside a `tx` joins the outer one.

`repo(name)` gives each collection `get`, `list`, `insert` and `update(id, patch, by, change, expectVersion)`; a stale `expectVersion` is a 409. The PostgreSQL plan keeps this interface (`V18-DATABASE-MIGRATION.md`).

## The event bus

Events are written in the same `tx` as the change they describe (a transactional outbox), so a change without its event, or an event without its change, cannot be saved.

1. **Publish.** Inside a `tx`, `events.publish(s, {...})` builds the envelope (`event.v1`), validates it and adds it to the outbox. An event id that already exists returns the existing event.
2. **Facts from other stores.** Modules that keep their own files (`journal.js`, `approvals.js`, `invoices.js`, `reconcile.js`, the lead hook in `server.js`) emit `bus.emit('fact', …)`. `events.js` saves each fact with a deterministic id, `evt_` plus the first 24 hex characters of `sha256(type|factId)`, so the same fact twice is one event.
3. **Deliver.** A tick (every 2 s, `YABBAI_EVENTS_TICK_MS`) drains each consumer in parallel. A consumer handler returns an optional `apply(s)`; that runs in the same `tx` that marks the event done in the consumer's inbox, so each consumer's effect happens once.
4. **Retry.** A failed delivery waits 15 s, 1 min, 4 min, 16 min (base `YABBAI_EVENTS_BACKOFF_MS`, capped at 30 min). After 5 attempts, or at once if the error is marked permanent, it becomes a dead letter and a `risk.exception_detected` event; the consumer's `onDead` hook can escalate (the agent runtime sends the task to a person).
5. **Replay.** Only the director, with a fresh authenticator code, can put a dead letter back in the queue. The replay is audited and the consumer's `onReplay` hook can reset state (an escalated task goes back to its agent).

Consumers today: `agent-runtime` (task.created), `sales-intake` (lead.created), `approval-router` (proposal.created), `workflow-escalations` (task.escalated).

## Agents

`agentops.js` holds a registry of 10 agents. Each declares permissions (capped by `permissions.AGENT_CEILING`: no agent can ever hold approve, execute or administer), tools, a model setting, budgets (runs per hour, tool calls per run, output tokens) and the workflows it serves.

A run:

1. The `agent-runtime` consumer picks up `task.created`.
2. Checks: the task is still open, the agent is enabled, the hourly budget is not spent, a worker exists for the task kind.
3. The run is recorded as `running` (with `agent.run_started`).
4. The worker gets a toolbox. Every call is recorded, refused ones too: an unknown tool, a tool the agent may not use, or a permission it lacks is refused, and so is the call after the budget runs out.
5. The answer is validated against the task's output schema. Invalid answers fail the run.
6. On success the run, its result and the worker's state changes are written in one `tx` with `agent.run_completed`. On failure the run and task are marked failed with `agent.run_failed`, and the bus retries.
7. After a restart, runs left `running` are failed and their tasks retried (`recover()`).

Only the Sales Director is enabled. The other agents have no workflow wired to them, and the engine refuses to enable an agent with no workflow (it would sit idle) or no data source (farms, drones).

## The lead-to-proposal workflow

`salesflow.js`, steps `qualify` → `approve` → `record`:

1. A lead arrives through `POST /api/v1/crm/leads` (starts the workflow unless `startWorkflow: false`), or a person presses the proposal button on a lead in the Leads tab. When `settings.workflows.autoQualify` is on (off by default, with no switch in the deck yet), leads from any source start it.
2. `start()` creates one opportunity, one workflow run and one task in a single `tx`. A second start for the same lead returns the run already in progress.
3. The Sales Director reads the lead through `crm.read_lead` (no email address or phone number), asks the model for a qualification, and proposes lines through `sales.propose_proposal`.
4. The engine, not the model, works out the totals in cents (BigInt), adds GST only when GST registration is confirmed in Treasury settings, keeps only evidence the agent actually read, and forces `approval_required = true`.
5. `approval-router` opens a request in the shared approvals queue (the one Treasury uses), risk `low` up to A$5,000 and `medium` above, valid 7 days.
6. A person with an unlocked vault approves or rejects (deck, `/api/v1` or `/api/v2`). Approval creates or updates a customer with status `prospect`, moves the opportunity to `proposal_approved`, completes the task and the run. Rejection closes them as rejected. Expiry sends the task to a person and the run to `needs_attention`.
7. Each step is an event under the run's correlation id and the decision is in the audit chain. If recording a decision fails, `settle()` finishes it 30 s later and at every start.

Approving records that the business stands behind the offer. Nothing is sent to the customer.

## Permissions and the vault

`permissions.js` defines actions (view, create, edit, propose, approve, execute, administer) over 13 resources for five roles. Every `/api/v1` route names the action and resource it needs; `api-v1.js` checks it before the handler runs.

| Caller | Role |
|---|---|
| Cockpit token, no vault session | operator |
| Vault session, director | director |
| Vault session, approver | approver |
| An agent run | agent |
| Engine internals | system |

Approve, execute and administer belong to people only: the operator gets 423 (unlock the vault) and an agent gets 403. Administer also needs a fresh authenticator code (`X-Yabbai-Otp`), as does approving a high-risk request. Full matrix: `V18-AGENT-PERMISSIONS.md`.

## The executive view

`executive.js` builds 19 metrics from the stores that hold the facts: journal, treasury, invoices, forecast, opportunities, leads, approvals, reconciliation, tasks, runs, workflow runs, the bus, plus farms and drones (no data source, so "unavailable"). Each metric names its source, basis, unit, the time of the data behind it, a quality (`verified`, `recorded`, `estimate`, `unverified`) and a status (`live`, `stale`, `estimated`, `unavailable`).

## The deck

- **Ops** (new): executive cards, proposals waiting on a person, workflow runs, tasks, the agent registry, the event bus and dead letters.
- **Treasury** (new): cash by stage, items that still need configuring, approvals, accounts, reconciliation, the journal, and the kill switch.
- **VaultProvider** wraps the app. Any action that needs a person goes through `guard()`: on 423 it opens vault setup or unlock and retries; on 428 it asks for an authenticator code and retries. One idempotency key is kept across those retries.
- The deck refreshes when the engine's `/api/events` stream says something changed (the ops store announces changes, debounced 300 ms).

## API layers

| Prefix | Purpose | Notes |
|---|---|---|
| `/api/v1` | Operations: CRM, sales, tasks, agents, workflows, events, executive, audit | v18. Idempotency, correlation ids, one error shape, OpenAPI |
| `/api/v2` | Treasury control plane: accounts, approvals, transfers, journal, kill switch | v16, unchanged |
| `/api/*` | v15 cockpit routes | unchanged |
| `/v1/*`, `/openapi.json`, `/mcp` | Model gateway and agent tools for outside clients | unchanged |
| `/health`, `/healthz`, `/ready`, `/readyz` | Host probes, no token, no data | `/ready` and `/readyz` are new |

## Known overlaps

- With the v15 autopilot on, a new lead also wakes the v15 qualifier and closer. They draft outreach messages; v18 drafts a proposal. Both wait for a person, and neither sends anything.
- `approvals.js` lives in the treasury store while proposals live in the ops store. The decision is applied through a handler and repaired by `settle()` if that write fails, so the two can disagree for at most 30 s or until the next start.
