# YABBAI LOCAL v14 — YABBAI FLASH, real

Everything the YABBAI FLASH cockpit showed — COSMOS, MISSION CONTROL, MONEY DESK, BANG TERMINAL, AUTONOMY CORE, INCOME CORE, **RECEIVE**, PAYOUT BRIDGE, VAULT & STUDIO, AGENT HUB, OPS DESK, 12 agents, the approval queue, the 30% treasury law, the autopilot loop — now running on your laptop **on real data only**.

## What v14 adds: RECEIVE — invoices people can actually pay

v13 could watch a Solana wallet and log money you typed in by hand. It had no way to **ask** anyone for money, and no rail that could prove a payment except one chain. v14 adds the inbound side: invoices with a public pay page, three rails, and a matching engine that will not book a dollar without a receipt.

| Rail | How it is proven |
|---|---|
| **PayPal** (card, balance, Pay in 4) | Server-side order + capture (`/v2/checkout/orders`), or a webhook verified with PayPal's own `/v1/notifications/verify-webhook-signature` |
| **Bank transfer (AU)** | PayID or BSB + a unique `INV-000N` reference — matched from an exported statement CSV, a HMAC-verified aggregator webhook, or a Director confirmation that quotes the bank transaction id |
| **Solana** | Solana Pay reference key per invoice, read from a public RPC, keyless |
| **Bitcoin / Ethereum** | Unique-amount quote per invoice (the extra digits are the tag), read from mempool.space / Etherscan |

**The rule that makes the ledger worth reading:** a payment is booked only when an independent source proves it. A payer pressing “I've paid” creates a **claim**, never a credit. Claims sit in a queue until a chain transaction, a verified PayPal capture, a statement line, or a Director confirmation with a transaction id lands. Unmatched money goes to **Unmatched**, not into the top line.

Every booking writes a ledger entry whose `ref` is `INV-000N · <rail> <transaction-id>` — so every dollar in the header still has something you can open.

### Set it up (10 minutes)

1. **RECEIVE → Rails → Rail settings.**
   - **Bank:** PayID or BSB + account name. That is the whole config; the reference is generated per invoice.
   - **Solana:** paste your vault address (or Connect Phantom on Payout Bridge). Keyless — YABBAI never holds a key.
   - **PayPal:** mode (`sandbox` first), client ID, client secret, and the webhook ID from the PayPal dashboard.
   - **BTC / ETH:** address, plus an Etherscan API key for ETH history (JSON-RPC cannot list transfers to an address, so a key is genuinely required).
2. **Set the public base URL** if payers are remote — it is whatever tunnel or hostname points at this engine (`https://pay.yourdomain.com`). Left blank, links use `127.0.0.1` and only work on this machine.
3. **New invoice** → client, line item, amount → **Copy link** → send it. The pay page carries the reference and all three rails.
4. **Reconcile** runs on the autopilot loop every 4 cycles, or press **Reconcile now**. Bank transfers stay invisible until you import the statement (or an aggregator pushes a webhook) — that is a bank limitation, not a bug.

### Webhooks

| Provider | URL | Auth |
|---|---|---|
| PayPal | `https://<your-base>/webhooks/paypal` | PayPal signature verify (`webhookId` in settings) |
| Bank aggregator | `https://<your-base>/webhooks/bank` | `X-Yabbai-Signature: t=<unix>,v1=<hmac-sha256 of "t.body">`, secret in Rail settings |

The engine listens on `127.0.0.1` only, so webhooks need a tunnel (cloudflared, ngrok) forwarding to `YABBAI_PORT`. PayPal webhooks deliver to `http://` fine in sandbox; for live use put them behind the tunnel's https.

### Bank statement import

Export the operating account as CSV (CommBank, ANZ, NAB, Westpac layouts all parse — quoted thousands, `24/10/2026`, debit/credit column pairs, EU decimals). Paste it or choose the file. Rows are matched on the `INV` reference in the reference/description field; rows without one are reported as skipped, never guessed. Deterministic row ids mean importing the same file twice credits nothing.

### API

| Method | Path | Purpose |
|---|---|---|
| `POST` | `/api/invoices` | draft an invoice (`client`, `items`, `rails`) |
| `POST` | `/api/invoices/:id/send\|void\|requote\|credit` | lifecycle, re-quote, book a proven payment |
| `GET` | `/api/invoices/:id/link` | the public pay URL |
| `POST` | `/api/receive/reconcile` | scan every rail now |
| `POST` | `/api/receive/statement` | import a statement (`text`, `filename`) |
| `POST` | `/api/receive/settings` | rail addresses; secrets need the vault PIN |
| `POST` | `/api/claims/:id/confirm\|dismiss` | decide a claim |

Public (no cockpit token, one invoice per token): `GET /pay/:token`, `POST /pay/:token/paypal`, `POST /pay/:token/paypal-return`, `POST /pay/:token/claim`.

### Tests

`node engine/test/receive-smoke.js` — 19 checks, no network: base58, Solana/BTC/ETH reducers, unique-amount quotes, statement parsing, reference matching, the proof rule, claim demotion, idempotent imports, HMAC replay window, pay-page escaping, ledger refs.

> **Why “real data only” matters.** In the v11 recording, “TOTAL LIQUID $694,955”, “MONTHLY MRR $286,000” and “Banked $8000 from Marcus Vance” come from v11’s random simulator: leads are picked from a fixed name list (“David Chen, Nexus Health” in four different industries) and trade wins are `Math.random()`. v13 keeps every capability and drops every invented number. The header shows money with receipts; the PAPER lane is clearly paper.

## What’s new in v13

| Surface | What it really does |
|---|---|
| **COSMOS** | Money-spine pools (from moved splits of verified income), the 12-agent clan, live telemetry |
| **MISSION CONTROL** | Executive posture on demand, today’s missions, lead funnel, **approval queue** — every draft, split, payout, deposit and finding waits for your sign-off |
| **MONEY DESK** | The **30% treasury law**: Treasurer splits each verified income entry across Treasury / Reserve / Reinvest / Pay yourself / Trading fuel; you move the money and approve. Real MRR from retainers you tick as monthly |
| **BANG TERMINAL** | Live spread board (Binance, Coinbase, Kraken, CoinSpot) + Scout briefs |
| **AUTONOMY CORE** | The operator loop (10–120 s cadence), SPREAD / MOMENTUM / MIXED strategies and the **self-upgrade judge** — on real prices with **paper** money, never mixed with the ledger |
| **INCOME CORE** | Leads with Qualifier scores, outreach drafts, paste-in replies for Supporter |
| **PAYOUT BRIDGE** | **Keyless Solana deposit monitor** (public RPC, read-only; Connect Phantom just reads your address) + payout requests you execute yourself |
| **VAULT & STUDIO** | Forge kits → **Builder writes the actual product files** → Shipper packs BUNDLE/LISTING/LAUNCH; Director vault PIN guards every money action |
| **AGENT HUB** | 12 agents: Scout, Qualifier, Pitcher, Caller, Builder, Supporter, Forge (AI) + Shipper, Diagnost, Configurator, Auditor, Treasurer (rules — they can’t invent numbers) |
| **OPS DESK / BRAINS** | Chat on **Local 9B** or **Hugging Face 70B+**; the **AirLLM deep brain** for slow 70B jobs |

## The three brains

| Brain | Model | Speed | Cost | Use it for |
|---|---|---|---|---|
| **Local** (default) | Qwen3.5 9B on your RTX 5050 | ~30–40 tokens/s | free, unlimited, offline | chat, all agents |
| **Hugging Face 70B+** | Llama 3.3 70B · GPT-OSS 120B · DeepSeek V3.2 (Inference Providers) | fast | your HF credits | harder writing and strategy when you want a bigger brain |
| **Deep brain (AirLLM)** | Qwen2.5 72B or Llama 3.3 70B on your 8 GB GPU | **≈3–30 s per token** (it reads the whole model off your SSD for every word) | free | overnight jobs: 90-day plans, long reviews |

AirLLM really does run a 70B model on an 8 GB card — but at that speed a 400-token answer takes roughly an hour, so it is never used for chat or the agents. Send it jobs from **BRAINS → Deep jobs**.

**Install the deep brain:** run `INSTALL-DEEP-BRAIN.bat` after the main install. It checks you have ~170 GB free, asks for your Hugging Face token in a hidden prompt (stored in `data\secrets\hf.json`, readable only by your Windows user), installs PyTorch for RTX 50-series (CUDA 12.8) + AirLLM 3.1, then downloads and splits the model (hours; rerun to resume). START-YABBAI then starts it automatically.

**Hugging Face token:** make a fine-grained token at huggingface.co/settings/tokens with *Read* (for downloads) and *Make calls to Inference Providers* (for the fast 70B+ brain). Paste it into BRAINS or the deep-brain installer — never into a chat or a file you share. With a token saved, START-YABBAI also adds Hugging Face’s models to Open WebUI’s model picker.

---

## Original v12 guide

YABBAI running entirely on your own machine. A Hugging Face model (Qwen3.5 9B) runs on your GPU through Ollama, **Open WebUI** is the chat app, and the **YABBAI engine** plugs into it with three agents that find and prepare money — Scout (crypto spreads after fees), Closer (outreach drafts for your leads) and Forge (Gumroad-ready product kits) — plus a ledger that only counts money with a receipt.

No message caps, no API bill, no cloud account. After the one-time downloads it keeps working offline (except Scout, which needs live exchange prices).

| Piece | Address | What it is |
|---|---|---|
| YABBAI cockpit | http://127.0.0.1:7860 | Agents, Markets, Pipeline, Forge, Ledger, Chat, Model manager, Settings |
| Open WebUI 0.12.3 | http://127.0.0.1:8080 | Full chat app. YABBAI agents appear in its model picker; YABBAI tools in its tools menu |
| Ollama + model | http://127.0.0.1:11434 | Runs `hf.co/unsloth/Qwen3.5-9B-GGUF:Q4_K_M` (picked for 8 GB GPUs) |
| Classic v11 | http://127.0.0.1:7860/classic/ | Your original YABBAI FLASH v11, with fixes (see below) |

Everything listens on 127.0.0.1 only — nothing is reachable from your network unless you tunnel it yourself.

---

## Install — Windows

1. **Unzip to `C:\yabbai`** (not Desktop/Documents if those sync to OneDrive — OneDrive locks files while syncing. If you forget, the installer copies itself to `C:\yabbai\yabbai-local` and carries on there).
2. **Double-click `INSTALL-YABBAI.bat`.** It:
   - installs or updates Node.js, Ollama and uv (Windows may ask for permission once),
   - tunes Ollama for an 8 GB GPU (flash attention, 8-bit KV cache, 8K context),
   - reads your GPU and RAM and picks the model,
   - downloads it from Hugging Face (about 5.7 GB),
   - test-loads it and prints **tokens per second** and **how much sits on the GPU**,
   - downloads Open WebUI once (a few GB of Python packages),
   - puts a **YABBAI** shortcut on your desktop.

   Budget roughly 10 GB of disk and 15–40 minutes depending on your connection.
3. **Double-click `START-YABBAI.bat`** (or the desktop shortcut). The cockpit opens in your browser. Open WebUI takes a few minutes on its very first launch — then open http://127.0.0.1:8080 and create your account. That account lives only on your machine; the first one created is the admin.

**macOS / Linux:** `./scripts/install.sh`, then `./scripts/start.sh` (stop with `./scripts/stop.sh`).

Other buttons: `STOP-YABBAI.bat` stops YABBAI and Open WebUI (Ollama keeps running for other apps). `DOCTOR-YABBAI.bat` runs a full health check.

---

## Your first 15 minutes

1. **Settings → What Closer sells.** Three offers are pre-filled: Capital Colony (SEO & schema audits for Melbourne law firms), the Agency Onboarding System, and BASHAM Automations. Fix the wording, add real proof and links, and set the name drafts are signed with. Closer only claims what's written here.
2. **Pipeline → add five real leads.** Business name and niche is enough. Closer writes a first message plus two follow-ups for each within a few minutes. Read it, copy it, send it yourself, press **Mark sent**.
3. **Forge** builds a kit from the idea queue every 6 hours (or press **Build next kit now**). Each kit has contents, build steps, price, listing copy, FAQ and launch posts, and is saved as Markdown in `data\forge`. Build it, upload it, press **Mark listed**.
4. **Markets.** Scout scans Binance, Coinbase, Kraken and CoinSpot every 5 minutes. Put your real fee tier in **Settings → Scout** so the "net" column means something.
5. **Ledger.** Every real sale or payment goes here **with its receipt link, invoice number or transaction signature**. The gold number at the top of the cockpit is the only money number in YABBAI.

---

## Using it from Open WebUI

On first launch the starter scripts wire Open WebUI to YABBAI for you:

- **Models:** `YABBAI · Director` (default — knows your ledger, pipeline, kits and spreads), `Scout`, `Closer`, `Forge`, and `Lite` (fast, no context). The raw Hugging Face model is listed too, for plain unlimited chat.
- **Tools:** in a chat, open the tools / integrations menu and switch on **YABBAI**. The model can then pull your money snapshot and spread board, add leads, list drafts, queue product ideas and log income (it must ask you for the receipt). To have them on every time: **Workspace → Models → YABBAI · Director → Tools → YABBAI**. Small local models handle one tool step at a time best — ask for one thing per message.
- **Thinking:** set *Reasoning Effort* in the chat controls to let YABBAI models think before answering (slower, often better).
- **Automations:** User menu → Automations → e.g. a daily 8:00 "Morning brief" using `YABBAI · Director`. Each run is saved as a chat you can read later.

These settings seed Open WebUI on its **first** launch only; after that, whatever you change in its Admin Panel wins.

---

## The rules YABBAI runs on

- **Money is only real in the Ledger, and only with a reference.** Income without a receipt/invoice/tx signature is refused — by the cockpit, the Open WebUI tools and MCP alike.
- **Agents never send, trade or spend.** They draft, compute and suggest. Sending messages, placing trades and publishing products is always you.
- **A spread is not profit.** Scout's numbers come from live public order books after both taker fees and a transfer buffer — but prices move while coins transfer, and withdrawals have fees, limits and delays.
- **AI drafts are labelled.** Check every claim before you send or publish.

---

## Models

| Model | Size | Best for |
|---|---|---|
| `hf.co/unsloth/Qwen3.5-9B-GGUF:Q4_K_M` | 5.7 GB | **Default.** 8 GB GPUs (RTX 5050/4060/3070), 16 GB Macs |
| `hf.co/unsloth/Qwen3.5-9B-GGUF:UD-Q4_K_XL` | ≈6 GB | Slightly sharper; a little more VRAM |
| `hf.co/unsloth/Qwen3.5-4B-GGUF:UD-Q4_K_XL` | ≈3 GB | 4–6 GB GPUs, 8 GB Macs, CPU-only — fastest |
| `hf.co/unsloth/Qwen3.6-27B-GGUF:UD-Q4_K_XL` | ≈17 GB | 20 GB+ VRAM or 32 GB+ Macs |
| `qwen3.5:9b` | 6.6 GB | Fallback (Ollama's own packaging of the same model) |

Pull, switch or remove models in the cockpit's **Model** tab — any GGUF on Hugging Face works with `hf.co/<user>/<repo>:<quant>`. Context size lives there too: 8,192 keeps the 9B model fully on an 8 GB card; larger contexts spill into RAM and slow down.

---

## Connect other apps

**Settings → Connect** (only shown on this computer) has the token and copy-ready configs.

- **MCP** (Claude Desktop, AnythingLLM, LibreChat, Jan, …): `http://127.0.0.1:7860/mcp`, Streamable HTTP, header `Authorization: Bearer <token>`.
- **OpenAI-compatible:** base URL `http://127.0.0.1:7860/v1`, API key = the token. Models: `yabbai-director`, `yabbai-scout`, `yabbai-closer`, `yabbai-forge`, `yabbai-lite`.
- **OpenAPI tool server:** `http://127.0.0.1:7860/openapi.json` with the same bearer token.

**Remote access (e.g. cloudflared):** the cockpit refuses anything that isn't this computer unless it has the token. Open `https://<your-tunnel>/login?token=<token>` once per device to set a cookie. Never share the token; Open WebUI has its own login.

---

## Troubleshooting

Run **DOCTOR-YABBAI.bat** first — it loads the model, measures speed and GPU placement, and tells you the fix for anything red.

- **GPU offload 0% (running on CPU):** update the NVIDIA driver (RTX 50-series cards need a recent one), run the installer again to update Ollama, and on laptops set `ollama.exe` to *High performance* in Windows Settings → System → Display → Graphics. Then restart.
- **Partly on the GPU:** lower the context size in the Model tab, or switch to the 4B model.
- **"unknown model architecture":** Ollama is too old for Qwen3.5 — run the installer again, or switch to `qwen3.5:9b` in the Model tab.
- **Open WebUI never comes up:** read `data\logs\openwebui.log`. Port 8080 taken? Set `OPENWEBUI_PORT=8081` before starting.
- **Port 7860 taken:** set `YABBAI_PORT`.
- **Markets says "Feeds offline":** no internet or a firewall blocking the exchanges. Scout retries on its schedule and never invents prices.
- **Agents say "Needs attention":** the reason is printed on the card (usually Ollama not running → START-YABBAI).

---

## Your data

Everything is in the `data` folder: `db.json` (agents, leads, drafts, kits, ledger, settings), `chats\`, `forge\*.md` (kits), `openwebui\` (Open WebUI's own data), `logs\`, `install.json` (your machine + chosen model) and `secret.json` (the token). **Back up = copy the `data` folder.** Export the ledger as CSV from the Ledger tab.

To uninstall: stop YABBAI, delete the folder, `ollama rm <model>` to free the model's disk space, and `uv cache clean` to drop Open WebUI's downloaded packages.

---

## What changed from YABBAI FLASH v11 (Classic)

- Its AI brief runs on your local model instead of a cloud key.
- Simulated trade "wins" (random numbers) were being credited to TREASURY as verified real-lane money. They no longer count.
- Mock and real balances are kept in separate pools when you switch lanes.
- Its auto-generated leads and template drafts are labelled as demos.

The real versions of those jobs — live spreads, AI outreach, product kits, receipts — live in the main cockpit.

---

## For developers

- No npm dependencies. `node engine/server.js` runs the engine; `node scripts/launcher.js <install|start|stop|status|doctor>` runs the stack.
- `node engine/test/smoke.js` + `node engine/test/smoke13.js` — 76 + 50 end-to-end checks against a mock Ollama (security, ledger rules, all agents, spread maths, chat streaming, the OpenAI gateway, tool server, MCP, model pulls, persistence).
- Environment: `YABBAI_PORT` (7860), `YABBAI_HOST` (127.0.0.1), `YABBAI_DATA`, `YABBAI_MODEL`, `OLLAMA_URL`, `OPENWEBUI_PORT` (8080), `OPENWEBUI_URL`, `OPENWEBUI_VERSION` (0.12.3 — the version this wiring was tested against).
- Layout: `engine/lib/markets.js` (order books + fee maths), `agents.js` (scheduler + the three agents), `prompts.js` (personas, live state, JSON schemas), `ops.js` (validated money/pipeline actions), `gateway.js` (OpenAI-compatible `/v1`), `tools.js` (OpenAPI + MCP), `store.js` (persistence).
