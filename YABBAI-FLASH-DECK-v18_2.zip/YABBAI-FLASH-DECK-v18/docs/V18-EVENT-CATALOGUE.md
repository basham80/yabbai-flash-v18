# V18 event catalogue

Every event on the YABBAI bus uses one envelope and one of 23 registered types (`engine/lib/contracts.js`). An event with an unknown type, a bad id or a missing field is refused when it is built, so it never reaches the outbox.

## Envelope (`event.v1`)

| Field | Type | Meaning |
|---|---|---|
| `event_id` | string | `evt_…`. Random for events published inside an ops transaction; deterministic (`evt_` + first 24 hex of `sha256(type|factId)`) for facts bridged from other stores, so the same fact twice is one event |
| `event_type` | string | One of the types below |
| `event_version` | integer | 1 for every type today |
| `occurred_at` | ISO 8601 | When the change happened |
| `source_service` | string | engine, treasury, receive, crm, sales, agents, workflows, operations, farms, drones or events |
| `business_id` | string | `biz_default` until a second business exists |
| `actor_id` | string | `type:id`, e.g. `agent:sales-director`, `director:pr_…`, `system:engine` |
| `correlation_id` | string | Ties a chain together. For lead-to-proposal it is the workflow run id; for API calls, the request's `X-Correlation-Id` |
| `payload` | object | Type-specific, below. Ids and kinds; contact details never; amounts only where marked |
| `sensitivity` | string | public, internal, confidential or restricted |

Stored events also carry `delivery`, one entry per consumer: `{ status: pending | running | retrying | done | dead, attempts, nextAt, lastError }`. A delivery left `running` by a stopped engine is set back to `retrying` when the bus starts.

## Delivery guarantees

- **Written with the change.** Events published inside `opsstore.tx` are saved in the same write as the change. Facts from other stores are saved right after their own store writes; if that save fails, the failure is audited as `event.publish_failed`.
- **At least once, applied once.** A consumer may see an event again after a crash; its inbox key (`consumer:event_id`) is written in the same transaction as its effect, so the effect happens once.
- **No ordering promise** across consumers or types. Within a consumer, events are taken oldest first.
- **Retries:** 15 s, 1 min, 4 min, 16 min (`YABBAI_EVENTS_BACKOFF_MS` sets the base, 50 ms minimum, 30 min cap). After 5 attempts, or straight away for a permanent error, the delivery becomes a dead letter and a `risk.exception_detected` event.
- **Replay:** director only, fresh authenticator code, audited (`event.replayed`). Replaying resets that one consumer's delivery.
- **Listing:** `GET /api/v1/events` never lists `restricted` events. No type is restricted today; the level exists for future payment-instruction events.
- **Retention:** nothing is deleted yet. The outbox grows with use (see `V18-NEXT-STEPS.md`).

## Types

"Consumers" are bus consumers in the engine. Every event is also visible to people through `/api/v1/events` and the Ops tab.

### Emitted in v18

| Type | Emitted by | When | Payload | Sensitivity | Consumers |
|---|---|---|---|---|---|
| `lead.created` | `server.js` lead hook (fact, id = lead id) | A lead is added from any source. Redrafts are not new leads | `leadId`, `source`, `channel`, `autoStart` | internal | `sales-intake` |
| `opportunity.updated` | `salesflow.js` | The run starts (qualifying), a proposal is drafted, a decision is recorded | `opportunityId`, `stage`, and `leadId`, `valueMinor`, `valueStatus` where known | internal | — |
| `proposal.created` | `salesflow.js` (Sales Director's run) | A proposal draft is saved. It is not sent or approved | `proposalId`, `leadId`, `totalMinor`, `currency` | internal | `approval-router` |
| `proposal.approved` | `salesflow.js` | A person approves | `proposalId`, `totalMinor`, `currency`, `customerId` | internal | — |
| `proposal.rejected` | `salesflow.js` | A person rejects | `proposalId`, `totalMinor`, `currency`, `customerId` (null) | internal | — |
| `invoice.issued` | `invoices.js` (fact, id = invoice id) | An invoice is marked sent | `invoiceId`, `number`, `currency`, `totalMinor` | internal | — |
| `payment.evidence_received` | `invoices.js` (fact, id = payment id) | A payment is applied with external evidence | `paymentId`, `invoiceId`, `kind`, `currency`, `amountMinor`, `invoiceStatus`, `ledgerId` | confidential | — |
| `payment.reconciled` | `reconcile.js` (fact, id = run id) | An account matches its books, first time or after a difference | `runId`, `accountId`, `asset`, `periodEnd` | internal | — |
| `treasury.journal_posted` | `journal.js` (fact, id = transaction id) | A journal transaction is posted | `txId`, `type`, `sourceSystem`, `postings` (count), `currencies`, `reversalOf`. No amounts | confidential | — |
| `approval.requested` | `approvals.js` (fact, id = `approval:open`) | An approval request opens (proposal, allocation, transfer, policy) | `approvalId`, `kind`, `targetId`, `risk`, `required` | internal | — |
| `approval.decided` | `approvals.js` (fact, id = `approval:status`) | The final outcome only: approved (quorum met) or rejected. One "yes" toward a quorum of two is not an outcome; expiry is not a decision | the above plus `decision` | internal | — |
| `task.created` | `agentops.js` | A task is created and assigned | `taskId`, `kind`, `agent`, `objective`, `contextRefs`, `deadline` | internal | `agent-runtime` |
| `task.completed` | `salesflow.js` | A person approves or rejects the task's proposal | `taskId`, `outcome`, `evidence` | internal | — |
| `task.escalated` | `agentops.js` (retries ran out), `salesflow.js` (the agent asked for a person, or the approval expired) | A task needs a person | `taskId`, `agent`, `reason` | internal | `workflow-escalations` |
| `agent.run_started` | `agentops.js` | A run begins | `runId`, `agent`, `taskId`, `attempt` | internal | — |
| `agent.run_completed` | `agentops.js` | A run returns a valid answer | `runId`, `agent`, `taskId`, `status` (ok, needs_more_info, escalate) | internal | — |
| `agent.run_failed` | `agentops.js` | Model, tool, budget or validation failure | `runId`, `agent`, `taskId`, `error` | internal | — |
| `risk.exception_detected` | `events.js` (dead letter); `reconcile.js` (fact, id = exception id) | A delivery ran out of retries; a reconciliation exception first appears | dead letter: `kind: dead_letter`, `consumer`, `eventId`, `eventType`, `error`. Reconciliation: `kind`, `exceptionId`, `accountId` | internal | — |

### Registered, not emitted yet

| Type | Waiting on |
|---|---|
| `customer.onboarded` | A customer acceptance step. v18 makes a customer a `prospect` when a proposal is approved internally; nothing records the customer accepting |
| `project.status_changed` | A projects module |
| `farm.asset_alert`, `farm.production_recorded` | A farm data source |
| `drone.maintenance_due` | A fleet data source |

## Rules for adding a type

1. Add it to `EVENT_TYPES` in `contracts.js` with a one-line meaning.
2. Payloads carry ids, kinds and counts. Contact details never; amounts only when the consumer needs them, and then mark the event `confidential`.
3. Publish inside the same `opsstore.tx` as the change, or as a fact with a stable id if the change lives in another store.
4. A new payload shape is a new `event_version`; consumers keep handling the versions they know.
5. Add a consumer with `events.consume(name, types, handler, { onDead, onReplay })`. Return `apply(s)` for state changes so they land with the inbox mark. Mark an error `permanent` when retrying cannot help.
