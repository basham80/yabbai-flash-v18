# V18 implementation status

Each line of the v18 brief, what exists, and the proof. "Done" means built, wired into the running engine and covered by a passing automated check. "Partial" means part of it works and the rest is listed. "Not started" means no code.

Status date: 15 November 2026. Verified on a local build only; nothing is deployed (see `V18-DEPLOYMENT-RUNBOOK.md`).

## Platform

| Requirement | Status | What exists | Proof |
|---|---|---|---|
| Inspect the code and find the real gaps first | Done | `V18-BASELINE-AUDIT.md` | — |
| Modular monolith | Done | One process; new modules `opsstore`, `events`, `contracts`, `permissions`, `agentops`, `salesflow`, `executive`, `api-v1` | All suites |
| Repository abstraction | Done | `opsstore.repo(name)`: get, list, insert, update with expected version; `tx()` with rollback | E1, E2, R1 |
| PostgreSQL in production when available | Not started | Not available: no instance exists and the switch needs approval. Plan, schema and blockers written | `V18-DATABASE-MIGRATION.md` |
| Keep the JSON data; no uncontrolled dual writes; no silent storage switching | Done | Existing files untouched apart from added fields; the ops store is a new file; one store per record type; no fallback logic | Suites from v15 and v16 still pass (396 assertions) |
| Shared contracts | Done | `event.v1`, `task.v1`, `approval.v1`, `agent.result.v1`, `sales.qualification.v1`; served at `/api/v1/contracts` | C1 |

## API

| Requirement | Status | What exists | Proof |
|---|---|---|---|
| `/api/v1` | Done | 29 routes: system, CRM, sales, tasks, agents, workflows, events, executive, audit | X2, V1 |
| OpenAPI | Done | `/api/v1/openapi.json`, OpenAPI 3.1, generated from the route table | X2 |
| Idempotency, correlation ids, one error shape | Done | `Idempotency-Key` on writes; `X-Correlation-Id` in and out; `{ error: { code, message }, correlation_id }` | X2, E3 |
| `/health` and `/ready` | Done | `/health`, `/ready` (also `/healthz`, `/readyz`) without a token; `/api/v1/health`, `/api/v1/ready` with detail | O1 |

## Event bus

| Requirement | Status | What exists | Proof |
|---|---|---|---|
| Durable outbox and inbox | Done | Events saved in the same write as the change; per-consumer inbox keys written with the effect | E1, E3 |
| Defined envelope | Done | `event.v1` with id, type, version, time, source, business, actor, correlation, payload, sensitivity | C1 |
| Retry with backoff | Done | 15 s × 4ⁿ, cap 30 min, 5 attempts | E4 |
| Dead letters | Done | Stored, raised as `risk.exception_detected`, task escalated to a person | E4 |
| Audited replay | Done | Director with a fresh code; audit `event.replayed` | E5 |
| Event catalogue | Done | 23 types; 18 emitted today, 5 registered for modules that don't exist yet | `V18-EVENT-CATALOGUE.md` |
| Retention and compaction | Not started | The outbox only grows | `V18-NEXT-STEPS.md` |

## Agents

| Requirement | Status | What exists | Proof |
|---|---|---|---|
| Registry of 10 agents, read-only by default | Done | CEO, CFO, Treasurer, COO, Sales Director, Marketing Director, Customer Success, Auditor, Farm Ops, Drone Ops | P1 |
| Runtime: budgets, validation, retry, escalation, run log | Done | Runs per hour, tool calls, output tokens; schema validation; bus retries; escalation on dead letter, on an agent's "escalate" answer and on approval expiry; every run and tool call recorded | A1, A2, E4 |
| Agents that do work | Partial | Sales Director only. The other seven registered agents have no workflow or tools yet, and the engine refuses to enable them; Farm and Drone have no data source | P1 |
| Prompt-injection boundary | Done | Lead as marked data; approval, arithmetic and evidence decided by the engine | A3 |

## Permissions

| Requirement | Status | What exists | Proof |
|---|---|---|---|
| view, create, edit, propose, approve, execute, administer | Done | 5 roles × 7 actions × 13 resources | P1 |
| Enforced on the server | Done | Checked in `api-v1.js` before every handler | P1, P2 |
| Person-only actions need the vault; administer needs a fresh code | Done | 423 / 403 / 428 as documented | P2 |

## Vertical slice

| Step | Status | Proof |
|---|---|---|
| Lead (API or deck) | Done | V1 |
| Sales task created and assigned | Done | V1, A1 |
| Agent run: reads the lead, drafts, validated | Done | A1, A2 |
| Proposal with engine-computed totals, no GST until registration is confirmed | Done | A2, V1 |
| Human approval through the shared queue | Done | V1, P2 |
| Customer (prospect) and opportunity updated | Done | V1 |
| Audit | Done | V1 |
| Executive view reflects it | Done | V1, X1 |
| Rejection, expiry, model outage, paused agent | Done | A3, E4, A1, R1 |

## Deck

| Requirement | Status | What exists | Proof |
|---|---|---|---|
| Treasury in the navigation | Done | Treasury tab: cash by stage, needs configuration, approvals, accounts, reconciliation, journal, kill switch | Screenshot check |
| Command centre | Partial | Ops tab: executive metrics, proposals waiting, workflow runs, tasks, agents, events and dead letters. Not built: separate CRM, projects, customers, marketing, farms and drones sections | Screenshot check |
| Metrics with source, basis, unit, time, quality, status | Done | 19 metrics; live / stale / estimated / unavailable shown as pills with a legend | X1 |
| Approvals from the deck with the vault | Done | One `guard()` handles set up, unlock and fresh code, then retries the action | Screenshot check of the vault dialog; `npx tsc --noEmit` |
| Phone layout | Done | Single column at 390 px, no sideways scroll; the agent table scrolls inside its own box | Screenshot check |

## Documents

All eleven are in `docs/`: BASELINE-AUDIT, ARCHITECTURE, IMPLEMENTATION-STATUS, API-CONTRACTS, EVENT-CATALOGUE, AGENT-PERMISSIONS, DATABASE-MIGRATION, SECURITY-REVIEW, TEST-REPORT, DEPLOYMENT-RUNBOOK, NEXT-STEPS.

## Deployment

| Target | Status |
|---|---|
| Local engine and deck | Running and tested in the build container |
| Local test suite | Passing (`V18-TEST-REPORT.md`) |
| Staging | Not deployed |
| Production | Not deployed. Render needs GitHub access to the repository first |
