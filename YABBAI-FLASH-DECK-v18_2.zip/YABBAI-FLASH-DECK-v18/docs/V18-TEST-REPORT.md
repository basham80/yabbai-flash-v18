# V18 test report

Every number here comes from runs in the build container on 15 November 2026 (Node 22.23.4, Linux). No result is estimated. The model in the tests is `engine/test/mock-ollama.js`, a local stand-in that answers with schema-shaped placeholder values; no real model, bank, provider or chain was called.

## Commands and results

| Command | Where | Result |
|---|---|---|
| `npm test` | `engine/` | exit 0 in 1 min 15 s; 8 suites, **499 assertions passed, 0 failed** |
| `node test/smoke18-ops.js` | `engine/` | 103 passed, 0 failed; 18 of 18 gates pass |
| `npx tsc --noEmit` | `studio/` | exit 0, no type errors (18 source files checked, including the four new ones) |
| `npm run build:studio` | `studio/` | Vite build OK (1,676 modules, JS 347 KB / 102 KB gzip, CSS 28 KB); copied to `engine/public/studio` (372 KB) |
| `npm audit --omit=dev` | `studio/` | found 0 vulnerabilities |
| Secret-format scan of every changed and new file | repo | no matches |
| Screenshot check (Playwright, Chromium) | Ops desktop 1280 px, Ops phone 390 px, Treasury desktop, vault dialog | rendered; no horizontal overflow on any page |

### Per suite

| Suite | Covers | v16 | v18 |
|---|---|---|---|
| `smoke.js` | The engine end to end: cockpit, model gateway, tools, MCP | 79 | 79 |
| `smoke13.js` | Brains, agents, approval queue, money spine and vault, payouts, MRR, Solana deposits, paper loop | 55 | 55 |
| `smoke15.js` | Lead intake (Pancake, CSV, pasted tables, MCP), oil desk journal and guardian, AI Studio cross-origin rules | 45 | 45 |
| `smoke15-token.js` | Render-generated token and the claude.ai connector URL | 13 | 13 |
| `receive-smoke.js` | Payment rails and the invoice lifecycle | 19 | 19 |
| `smoke16-broker.js` | Oil desk against a stand-in cTrader API: connect, symbols, guardian, orders a person sends | 45 | 45 |
| `smoke16-treasury.js` | Treasury, journal, vault; 29 release gates | 140 | 140 |
| `smoke18-ops.js` | **New:** operations layer; 18 gates | — | 103 |
| **Total** | | **396** | **499** |

Nothing that passed in v16 fails in v18.

## v18 gates

| Gate | Requirement | Checks |
|---|---|---|
| C1 | Shared contracts validate events, tasks, approvals and agent results | 9 |
| P1 | Permissions are checked on the server; no agent holds approve, execute or administer | 11 |
| P2 | Person-only actions need an unlocked vault; administer needs a fresh code | 7 |
| E1 | A state change and its events are written together (transactional outbox) | 4 |
| E2 | A failed write leaves no partial state and no event | 3 |
| E3 | Duplicate events are ignored (stable fact ids, inbox once per consumer) | 8 |
| E4 | Failed deliveries retry with backoff, then dead-letter and escalate to a person | 9 |
| E5 | A dead letter is replayed only by the director, and the replay is audited | 6 |
| A1 | Task lifecycle: created, assigned, run recorded, output validated, approval state, completion or failure | 13 |
| A2 | Agent output is validated; the model decides neither approval nor arithmetic | 4 |
| A3 | Instructions inside a lead cannot approve anything or reach past the data boundary | 4 |
| V1 | Lead → task → agent → proposal → human approval → customer and opportunity → audit → executive | 18 |
| X1 | Executive metrics carry source, basis, unit, time and live/stale/estimated/unavailable status | 7 |
| X2 | `/api/v1`: idempotency keys, correlation ids, one error shape, OpenAPI | 9 |
| R1 | State survives a restart with no duplicate work | 4 |
| J1 | The journal still balances; journal facts carry no amounts | 4 |
| S1 | CSRF, foreign origins and secret refusal apply to `/api/v1`; no contact details in ops data | 9 |
| O1 | `/health`, `/ready` (and the z forms) and `/api/v1/ready` report readiness without leaking data | 3 |

A check can count toward more than one gate, so the gate column adds up to more than 103.

## How the v18 suite works

- **Part 1, in process:** contracts, permissions and the event bus run against a temporary data folder with a 50 ms retry base, so retries and dead letters happen in seconds.
- **Part 2, a real engine:** the suite starts `server.js` on port 7896 with the mock model on 7897 (`YABBAI_EVENTS_BACKOFF_MS=50`, `YABBAI_EVENTS_TICK_MS=200`) and drives it over HTTP like a client would. It stops and restarts the engine twice, and once edits the treasury file while the engine is off to make an approval expire.
- Both parts use throwaway folders that are deleted at the end. Nothing touches a real `data/` folder.

## Every v18 check (all passed)

The gate tags after each check are the gates it counts toward.

**contracts**

- an event envelope carries id, type, version, time, source, business, actor, correlation, payload and sensitivity `C1`
- unknown types, malformed ids and unknown sensitivity are refused `C1`
- publishing an event outside the catalogue fails and saves nothing `C1 E2`
- a well-formed sales result passes `C1`
- zero quantities, negative prices, a missing approval flag and unknown fit values are refused `C1 A2`
- a hand-off to a person may leave the proposal out; a proposal with no lines is refused `C1 A2`
- approval records are checked (risk and quorum) `C1`
- every agent can return the common result shape `C1`

**permissions**

- no agent role can approve, execute or administer anything `P1`
- an agent gets 403, the cockpit without a vault gets 423, the director may `P1 P2`
- the agent ceiling allows propose and refuses approve and execute `P1`
- the registry has 10 agents, none above the ceiling `P1`
- an agent cannot change an agent profile, its own included `P1`
- an agent with no workflow or no data source cannot be switched on to sit idle `P1`
- an agent cannot decide an approval, even a low-risk one it asked for `P1 A3`

**event bus**

- the change and its event are on disk after one write `E1`
- a write that fails leaves neither the record nor its event, in memory or on disk `E2`
- earlier writes survive a later rollback `E2`
- the same fact twice is one event `E3`
- a redelivered event is recognised by the inbox: the effect happens once `E3`
- a failing consumer is tried five times, then stops `E4`
- the waits grow by four each time (50 ms, 200 ms, 800 ms, 3.2 s here; 15 s to 30 min in production) `E4`
- the dead letter is kept, a risk exception is raised and the consumer is told `E4`
- the dead letter is in the audit trail `E4`
- a permanent error goes straight to a dead letter (no pointless retries) `E4`
- a replayed dead letter is delivered once the consumer is healthy `E5`
- the replay is audited with who did it `E5`
- a task is created once per key, assigned, and matches the task contract `A1 E3`
- an answer that breaks the contract fails the run; nothing is saved from it `A1 A2`
- the run records every tool call, including the one it was refused `A1 P1`

**readiness and the API surface**

- /readyz answers without a token and says only ready and version `O1`
- /health and /ready answer the same way without a token `O1`
- /api/v1/ready checks the stores, the journal and event delivery, and says the vault is not set up `O1`
- errors share one shape and echo the correlation id `X2`
- a wrong method is 405 with a generated correlation id `X2`
- OpenAPI 3.1 lists every route with its permission and the Idempotency-Key on writes `X2`
- the contracts route serves the schemas and the full event catalogue `C1 X2`
- the deck without a vault is the operator; agents have no approve, execute or administer `P1`
- the registry: 10 agents, the Sales Director enabled with its tools installed, farm and drone agents not connected `P1`

**lead to proposal**

- a write without an Idempotency-Key is refused (428) `X2`
- a lead is added through /api/v1; the answer leaves contact details out `V1 S1`
- the same key and body again returns the first answer (Idempotent-Replay) `X2 E3`
- the same key with a different body is 409 `X2`
- the workflow starts by itself and reaches "waiting for approval" `V1`
- lead.created carries the request correlation id and no contact details `V1 S1 X2`
- the sales task: assigned, analysed, waiting on a person, with evidence `A1 V1`
- one run, recorded: the tools it called, the tokens used, the validated result `A1`
- the proposal total is worked out by the engine in cents (2 × 49 × A$49 = A$4,802.00), with no GST until registration is confirmed `A2 V1`
- the opportunity shows the draft as an estimate `V1`
- the executive view counts the one proposal waiting, in plain words `X1`
- every step left an event under the run’s correlation id `V1 E1`
- the model saw the lead as marked data, without the email address or phone number `A3 S1`

**a person decides**

- approving without the vault is 423 `P2`
- the director turns the step-up window off (the fresh session still counts once)
- an administer action without a fresh authenticator code is 428 `P2`
- with a fresh code the director sets a 10-minute window
- the director approves the proposal `V1 P2`
- a retried approval with the same key is a replay, not a second decision `X2 E3`
- approving it again with a new key is 409 `E3`
- the customer record exists as a prospect (it is approved internally, not yet accepted) `V1 S1`
- the opportunity moves to "proposal approved" and links the customer `V1`
- the task completes only after a person approved, with that approval as evidence `A1 V1`
- the workflow run is complete, step by step `V1`
- the decision and its effects are events under the same correlation id `V1 E1`
- the audit trail records who approved, and its hash chain verifies `V1`
- the executive pipeline shows the approved proposal, marked estimated `V1 X1`
- every executive figure names its source, basis, unit, time and status `X1`
- farms and drones say "unavailable", not zero `X1`
- approvals, agent runs and conversion reflect what just happened `V1 X1`

**instructions hidden in a lead**

- the agent still only drafts: the proposal waits for a person, approval_required stays true `A3`
- the injected text reached the model only inside the lead record `A3`
- a person rejects it: opportunity rejected, no customer made, run closed `V1`

**the model goes away**

- with no model, the run fails, is retried with backoff, and stops after five tries `E4 A1`
- the task.created delivery is a dead letter `E4`
- a risk exception is raised, the task is escalated and the run waits for a person `E4`
- the executive view shows the dead letter and the run that needs a person `X1 E4`
- replaying a dead letter without the vault is 423 `E5 P2`
- the director replays it `E5`
- with the model back, the replayed task drafts its proposal and the run continues `E5 A1`
- the replay is in the audit trail `E5`

**the director pauses the agent**

- the director pauses the Sales Director (inside the step-up window) `P2`
- a paused agent runs nothing: the task goes straight to a person `A1 P1`
- the director enables it again
- a person sends the task back to the agent `A1`
- the retried task drafts its proposal `A1`
- starting the workflow again for a lead in progress returns the same run `E3`
- both profile changes are audited `P2`
- one Harbour lead, despite the replayed request `E3`

**money and the journal**

- a person books a A$49 sale with its receipt
- the journal verifies and rebuilds `J1`
- the journal fact names the entry, never the amounts `J1`
- collected revenue on the executive view comes from the journal (A$49.00) `X1 J1`

**guards on /api/v1**

- a write without the cockpit header is blocked (CSRF) `S1`
- another site cannot read /api/v1 without the bearer token `S1`
- a recovery phrase in a lead is refused before anything saves it `S1`

**restart**

- after a restart: the same records and events, and no work done twice `R1`
- finished and waiting runs keep their state `R1`
- the audit chain and the journal verify after the restart `R1 J1`
- the ops store holds no contact details and no recovery phrase `S1`
- no /api/v1 answer repeated the email address `S1`

**an approval runs out of time while the engine is off**

- at start-up the expired request is recorded: proposal expired, task back with a person, run needs attention `A1 R1`
- the expiry is one task.escalated event and an audit entry `E1 A1`
- an expired proposal makes no customer `V1`

## What these tests do not cover

- **A real model.** The mock always answers well-formed placeholders ("mock title", 49 × A$49). How a real Hugging Face or Ollama model qualifies leads, and how often it produces invalid answers, is untested.
- **A deployed engine.** Nothing ran on Render, behind a real domain or TLS.
- **PostgreSQL.** Not built.
- **Load.** No concurrency or volume test. The whole-file write cost was measured separately (`V18-DATABASE-MIGRATION.md`).
- **Clicking through the deck.** The deck was type-checked, built and screenshotted with seeded data; button flows were exercised through the same API calls the deck makes, not by a browser robot clicking them.
- **Multiple approvers.** Quorums above one and approver-role principals are covered by the v16 treasury suite, not by a v18 proposal scenario.
