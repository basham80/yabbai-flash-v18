# V18 security review

Scope: what v18 added (the operations store, the event bus, the agent runtime, the lead-to-proposal workflow, `/api/v1`, the Ops and Treasury tabs, the vault flow in the deck) and how it touches the v16 controls. This is an internal review by the builder, backed by the automated tests named below. No external penetration test has been done.

## Controls and their evidence

| Control | How it works | Evidence |
|---|---|---|
| Permissions are enforced on the server | Every `/api/v1` route names an action and resource; `permissions.need()` runs before the handler, whatever the deck shows | Gate P1 (11 checks), P2 (7) |
| Agents cannot approve, execute or administer | The roles give agents none of these; the registry is checked against `AGENT_CEILING` at load, and the engine won't start if an entry is above it | P1: every resource × person-only action checked for the agent role; all 10 entries checked |
| Approvals need a person | `approvals.decide()` accepts only director or approver principals with a vault session; agents get 403, the bare cockpit 423 | P1, P2, V1; v16 gate T4 |
| Administer needs a fresh code | Agent changes and dead-letter replays call `vault.stepUp()` (authenticator code unless the session is under 120 s old) | P2, E5 |
| Writes are idempotent | `Idempotency-Key` required; same key and body replays the first answer; a different body is 409 | X2, E3 |
| Duplicate events cannot double-act | Deterministic fact ids; one inbox key per consumer written in the same transaction as the effect; one task per workflow key; one active run per lead | E3 (8 checks) |
| No partial writes | `opsstore.tx` restores a snapshot on any throw; the event is in the same write as the change | E1, E2 |
| CSRF and foreign origins | Writes need `X-Yabbai: 1`; a page on another origin needs the bearer token for any `/api/` call | S1; v16 gate S6 |
| Secrets are refused at the door | Any recovery phrase or private key in any request body is refused (422) before a handler, a log, the audit trail or a prompt sees it | S1 (a phrase in a lead's notes); v16 S3 (14 checks) |
| Contact details stay out of the new layers | `/api/v1` lead views, events, the ops store, agent tools and model prompts never include email addresses or phone numbers | S1: the ops file and every `/api/v1` answer in the run were searched for the test email and phone |
| Prompt injection does not get far | The lead is wrapped as data; the model cannot set `approval_required`, totals or GST, and evidence it did not read is dropped; a person approves every proposal | A2, A3 |
| Agent budgets | Runs per hour, tool calls per run and output tokens per run are capped; refused tool calls are recorded and fail the run permanently | A1 |
| Journal integrity | v18 posts nothing to the journal itself; journal facts on the bus carry no amounts; `/ready` verifies the chain and balances | J1 (4 checks); v16 M4, M7 |
| Audit | Every `/api/v1` write (allowed or refused), agent run, profile change, replay and decision is in the hash-chained audit trail | V1, P2, E5 |
| Readiness without leaks | `/health`, `/ready`, `/healthz`, `/readyz` answer without a token and return only ok/ready and the version | O1 (3 checks) |

## Dependency and secret checks (run for this release)

| Check | Command | Result |
|---|---|---|
| Engine third-party code | `engine/package.json` | No npm dependencies (Node built-ins only) |
| Deck runtime dependencies | `npm audit --omit=dev` in `studio/` | `found 0 vulnerabilities` |
| Secrets in the change set | regex scan of every changed and new file for API key, token and private-key formats | No matches |
| Data folders in git | `.gitignore` | `data/`, `engine/data/`, `.env*`, logs and the test token file are ignored |

## Residual risks

Ordered by how much they matter now.

1. **One shared engine token.** Anyone holding `YABBAI_TOKEN` acts as the operator: they can read everything (leads without email or phone, proposals, events, the audit trail, executive figures), add leads, start workflows and retry or cancel tasks. They cannot approve, move money or change agents without the Director vault. Keep the token private, and replace it if it leaks (Render: generate a new value; laptop: `data/secret.json`).
2. **Lead text goes to the model provider.** With the Hugging Face brain (the Render default), each lead's business details and notes are sent to Hugging Face for qualification. Email and phone are never sent. With a local Ollama model nothing leaves the machine. Choose the brain with that in mind (`settings.brains.agents`).
3. **The deck has no Content-Security-Policy header.** The deck never renders raw HTML (`dangerouslySetInnerHTML` is not used) and React escapes all lead text, so stored script injection has no obvious path, but a CSP would add a second layer. The vault session lives in `sessionStorage` for up to 2 hours (15 minutes idle), so script running in the deck could use it. Planned in `V18-NEXT-STEPS.md`.
4. **Idempotency is checked before the handler and stored after it.** Two requests with the same new key arriving at the same moment could both run. Today every `/api/v1` write handler is synchronous, so Node runs them one after the other and this cannot happen; an asynchronous write handler added later would need an in-flight lock.
5. **The outbox is never trimmed.** It grows about 0.7 KB per event. A disk-filling attack would need the token. Retention is planned.
6. **Data at rest is not encrypted by the application.** The JSON files rely on the disk (Render's encrypted volumes; the laptop's own disk encryption). Vault secrets and provider keys live in `data/secrets/`, which backups leave out on purpose.
7. **Single-process assumptions.** The opsstore transaction model and idempotency rely on one engine process per data folder. `enginelock.js` (v16) prevents two engines on one folder on the same machine; Render must stay at one instance.

## Things checked and not changed

- The money path is untouched: no v18 code creates, approves or submits a transfer. `/api/v1` reads the treasury overview only.
- No new outbound network calls except the model call the Sales Director makes through the existing `brains.js`.
- The cTrader integration and its demo-first default are unchanged. Orders still need a person to send them from the oil desk; no agent tool, workflow step or `/api/v1` route can place one.
- No credential is requested, stored or displayed by any v18 screen. The vault setup dialog shows the user's own authenticator secret and recovery codes once, as v16 already did.
