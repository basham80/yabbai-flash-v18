# V18 API contracts — `/api/v1`

The operations API: CRM, sales, tasks, agents, workflows, events, the executive overview and the audit trail. Money stays on `/api/v2` (treasury control plane, unchanged since v16); `/api/v1` only reads the treasury overview. The machine-readable contract is served by the engine at `GET /api/v1/openapi.json` (OpenAPI 3.1, generated from the same route table the server uses, so the two cannot drift).

## Calling it

| Header | When | Notes |
|---|---|---|
| `Authorization: Bearer <engine token>` | From anywhere but the engine's own machine, and from any page on another origin | The cockpit on `127.0.0.1` and a browser holding the login cookie don't need it |
| `X-Yabbai: 1` | Every request that is not a GET | The engine's CSRF guard. A page on another site cannot add it |
| `Content-Type: application/json` | Requests with a body | Bodies over 4 MB are refused |
| `Idempotency-Key` | Every `/api/v1` write | 8–120 of letters, digits, `.`, `:`, `_`, `-`. A fresh value per action; the same value when retrying that action |
| `X-Correlation-Id` | Optional | 3–120 of letters, digits, `_ : . -`. Kept if valid, otherwise one is made (`cor_…`). Always echoed back |
| `X-Yabbai-Vault` | Approve, execute, administer | A Director vault session from `POST /api/v2/vault/unlock` |
| `X-Yabbai-Otp` | Administer, and approving a high-risk request | A current authenticator code, unless the session was opened within the step-up window (default 120 s) |

Example (the token and session are placeholders):

```bash
curl -s https://<engine-host>/api/v1/crm/leads \
  -H "Authorization: Bearer <engine token>" -H "X-Yabbai: 1" \
  -H "Content-Type: application/json" -H "Idempotency-Key: lead-2026-11-15-001" \
  -d '{"business":"Harbour Plumbing Co","niche":"plumbing","location":"Geelong","notes":"40 quotes a month, slow follow-up"}'
```

### Idempotency

The first successful answer for a key is stored with a hash of the method, path and body.

| Same key, then… | Result |
|---|---|
| same method, path and body | the stored answer again, with `Idempotent-Replay: true`; nothing runs twice |
| a different body or path | 409 `conflict` |
| no key at all | 428 `precondition_required` |

Keys are kept for 7 days. Only successful answers are stored, so a failed request can be retried with the same key.

### Errors

Every error has one shape:

```json
{ "error": { "code": "locked", "message": "To approve on sales, unlock the Director vault (PIN and authenticator)." }, "correlation_id": "cor_1f2e3d4c5b6a7980" }
```

| Status | `code` | Meaning |
|---|---|---|
| 400 | `bad_request` | Malformed input, such as an `Idempotency-Key` in the wrong format |
| 401 | — | No token where one is needed (plain-text answer from the engine's front door) |
| 403 | `forbidden` | The caller's role may not do this (an agent, or a person role without the permission). A write without `X-Yabbai: 1` is also 403, answered by the engine's front door as `{ "error": "…" }` |
| 404 | `not_found` | No such route or record |
| 405 | `method_not_allowed` | The path exists, the method doesn't |
| 409 | `conflict` | Idempotency key reused for something else, a record changed meanwhile, or the item is already decided |
| 422 | `unprocessable` | The body fails its schema, or the action makes no sense (enabling an agent with no workflow) |
| 423 | `locked` | Needs a person: set up or unlock the Director vault |
| 428 | `precondition_required` | Missing `Idempotency-Key`, or a fresh authenticator code is needed |
| 429 | `rate_limited` | Vault lockout or an agent budget |
| 500 | `internal` | Server error; the message is not exposed, the log has it |
| 503 | `unavailable` | `/api/v1/ready` when a check fails |

Every write, successful or not, is recorded in the audit chain as `api.v1.post` with the status, the key and the correlation id.

### Lists

List routes take `limit` (1–200, default 50) and `offset`, and answer `{ "data": [...], "meta": { "total", "limit", "offset" } }`, newest first.

## Routes

The permission column is what the server checks before the handler runs (`permissions.js`). Operator is the cockpit with no vault session.

| Method and path | Needs | Who can | Notes |
|---|---|---|---|
| `GET /api/v1/health` | view:system | everyone with access | `{ ok, version, uptimeSec, at }` |
| `GET /api/v1/ready` | view:system | everyone with access | Checks the ops store, journal (cached 30 s), event delivery and vault setup; 503 if a check fails |
| `GET /api/v1/contracts` | view:system | everyone with access | Shared schemas, the event catalogue, sensitivity levels, task statuses |
| `GET /api/v1/permissions` | view:system | everyone with access | Your role and the full matrix |
| `GET /api/v1/openapi.json` | view:system | everyone with access | OpenAPI 3.1 |
| `GET /api/v1/crm/leads` | view:crm | operator up | Query `stage`, `q`. Email address and phone number are never returned |
| `POST /api/v1/crm/leads` | create:crm | operator, approver, director | Body below. Starts lead-to-proposal unless `startWorkflow: false` |
| `GET /api/v1/crm/opportunities` | view:crm | operator up | Query `stage` |
| `GET /api/v1/crm/customers` | view:customers | operator up | Query `status` |
| `GET /api/v1/sales/proposals` | view:sales | operator up | Query `status` |
| `GET /api/v1/sales/proposals/:id` | view:sales | operator up | With its approval request |
| `POST /api/v1/sales/proposals/:id/approve` | approve:sales | director, approver (vault session) | Body `{ "note"? }` (≤300). High risk also needs a fresh code |
| `POST /api/v1/sales/proposals/:id/reject` | approve:sales | director, approver (vault session) | Body `{ "note"? }` |
| `GET /api/v1/tasks` | view:workflows | operator up | Query `status`, `agent` |
| `GET /api/v1/tasks/:id` | view:workflows | operator up | With every run, its tool calls and result |
| `POST /api/v1/tasks/:id/retry` | edit:workflows | operator, approver, director | Only failed or escalated tasks; back to the agent |
| `POST /api/v1/tasks/:id/cancel` | edit:workflows | operator, approver, director | Body `{ "reason"? }` (≤200) |
| `GET /api/v1/agents` | view:agents | operator up | Registry with tools (and whether each is installed), work and run stats |
| `GET /api/v1/agents/:id/runs` | view:agents | operator up | |
| `POST /api/v1/agents/:id` | administer:agents | director, fresh code | Body `{ "status"?: "enabled" \| "paused" \| "registered", "budget"?: { "runsPerHour": 0–500 } }`. Permissions cannot be changed here |
| `GET /api/v1/workflows` | view:workflows | operator up | The workflow definitions |
| `GET /api/v1/workflows/runs` | view:workflows | operator up | Query `status` |
| `GET /api/v1/workflows/runs/:id` | view:workflows | operator up | With its tasks, proposal, opportunity and events |
| `POST /api/v1/workflows/lead-to-proposal/start` | create:workflows | operator, approver, director | Body `{ "leadId" }`. One active run per lead: a second call returns the same run |
| `GET /api/v1/events` | view:events | operator up | Query `type`, `correlationId`, `limit`. Restricted events are never listed |
| `GET /api/v1/events/dead-letters` | view:events | operator up | |
| `POST /api/v1/events/dead-letters/:id/replay` | administer:events | director, fresh code | Audited as `event.replayed` |
| `GET /api/v1/executive/overview` | view:treasury | operator up | The metrics below |
| `GET /api/v1/audit` | view:audit | operator up | Query `action`, `target`, `limit` (≤500). `meta.verify` is the hash-chain check |

### `POST /api/v1/crm/leads` body

| Field | Type | Rule |
|---|---|---|
| `business` | string | required, 1–160 |
| `name` | string | ≤120 (contact person) |
| `email` | string | ≤200. Stored in the CRM, never returned, never shown to a model |
| `phone` | string | ≤60. Same as email |
| `niche`, `location` | string | ≤120 each |
| `website` | string | ≤300 |
| `notes` | string | ≤1,500 |
| `source` | string | ≤40, default `api` |
| `startWorkflow` | boolean | default `true` |

A wallet recovery phrase or private key anywhere in a body is refused with 422 by the engine's secret guard before any handler sees it. That refusal comes from the engine's front door, so its body is `{ "error": "…" }` rather than the v1 shape.

## Record shapes

**Task** (`task.v1`): `task_id`, `kind`, `requester`, `assigned_agent`, `objective`, `context_refs` (e.g. `lead:ld_…`), `output_schema`, `deadline`, `priority` (low, normal, high, urgent), `permissions`, `approval` `{ required, status: not_needed | pending | approved | rejected, approvalId? }`, `status` (created, assigned, running, awaiting_approval, completed, failed, escalated, cancelled), `result` (the validated agent answer or null), `evidence_refs`, `correlation_id`, `attempts`, `escalation?`, plus `version`, `createdAt`, `updatedAt`, `history`.

**Agent run**: `id`, `agentId`, `taskId`, `attempt`, `status` (running, completed, failed), `startedAt`, `completedAt`, `toolCalls` `[{ tool, at, args (names only), ok, error? }]`, `model`, `tokens`, `costAud` (always null for now), `error`, `result`, `instructionsVersion`, `correlationId`.

**Proposal**: `id`, `leadId`, `opportunityId`, `taskId`, `workflowRunId`, `title`, `summary`, `lines` `[{ desc, qty, unitMinor, lineMinor }]`, `currency` (AUD), `subtotalMinor`, `taxMinor`, `taxNote`, `totalMinor` (all cents as strings), `validDays`, `fit`, `findings`, `status` (awaiting_approval, approved, rejected, expired), `approvalId`, `decidedBy`, `decidedAt`, `draftedBy`.

**Opportunity**: `id`, `leadId`, `name`, `owner`, `customerId`, `stage` (qualifying, proposal_drafted, proposal_approved, proposal_rejected, proposal_expired), `valueMinor`, `valueStatus` (unknown before a draft, estimated while a draft waits, proposed once approved), `currency`, `fit`.

**Customer**: `id`, `leadId`, `name`, `contactName`, `channel`, `status` (`prospect` after an approved proposal; nothing in v18 marks a customer active), `lastProposalId?`.

**Workflow run**: `id`, `workflow` (`lead-to-proposal`), `subject` `{ type: "lead", id }`, `status` (running, waiting_approval, needs_attention, completed, rejected), `steps` `[{ id, status, at, … }]`, `opportunityId`, `proposalId`, `owner`, `startedBy`, `source` (`api` when started through `/api/v1`, the deck button included; `auto` when the auto-qualify setting started it), `correlationId` (the run id).

**Event**: the envelope in `V18-EVENT-CATALOGUE.md`, plus `delivery` per consumer `{ status, attempts, nextAt, lastError }`.

**Executive metric**: `id`, `label`, `value`, `display`, `unit`, `source`, `basis`, `at`, `status` (live, stale, estimated, unavailable), `quality` (verified, recorded, estimate, unverified, n/a), `note`. Money values are cents as strings.

## Probes outside `/api/v1`

| Path | Token | Answer |
|---|---|---|
| `GET /health`, `GET /healthz` | no | `{ ok: true, version }`: the process is up |
| `GET /ready`, `GET /readyz` | no | `{ ready, version }`, 200 or 503. No detail, no data |

## Versioning rules

- A field may be added to a v1 answer at any time; clients ignore what they don't know.
- Removing or renaming a field, changing a type, or tightening a rule needs `/api/v2`-style versioning: a new prefix, with v1 kept until callers move.
- Events carry `event_version`; a consumer handles the versions it knows.
