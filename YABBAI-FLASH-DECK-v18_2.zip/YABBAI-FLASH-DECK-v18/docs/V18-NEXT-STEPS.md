# V18 next steps

In order. "Owner" items need a person with access to accounts the build cannot reach; "Build" items are code.

## Do next

| # | Step | Owner | Why now |
|---|---|---|---|
| 1 | Let Render read the GitHub repository, create the service from `render.yaml` on branch `v18`, and check `/health` and `/ready` | Owner | Nothing is deployed. Every later step is easier to test on a running staging copy |
| 2 | Set up the Director vault and work through Treasury → "Needs configuration" (entity, GST registration, income-tax reserve rate, policy, trading cap, limits, quorum, accounts you own) | Owner | Approvals and money actions stay off until the vault exists. GST and the tax rate change real numbers: proposals add GST only once registration is confirmed |
| 3 | Give the Sales Director your real services and prices, then trial it on 10–20 real leads with the brain you choose | Build, then owner review | Today the model proposes its own line items and prices within the contract's limits. A price list in settings, which the agent must quote from, makes proposals consistent and checkable. The trial measures how often a real model returns an invalid answer |
| 4 | Outbox retention: move delivered events older than 90 days to a dated `events-YYYY-MM.jsonl` archive; keep dead letters, open deliveries and the inbox keys still needed | Build | The outbox grows by about 0.7 KB per event and every write rewrites the file |
| 5 | Customer acceptance: record that the customer accepted a proposal, emit `customer.onboarded`, make the customer active and draft the invoice in Receive (a person still sends it) | Build | Closes the loop from lead to cash; v18 stops at "approved internally" |

## After that

| Step | Owner | Notes |
|---|---|---|
| A Content-Security-Policy header for the deck | Build | Second layer behind React's escaping; protects the vault session in `sessionStorage` |
| An "auto-qualify every lead" switch in the deck | Build | The setting exists (`settings.workflows.autoQualify`), the switch doesn't |
| A weekly cash brief from the CFO or Treasurer agent | Build | Install the read-only tools they already declare (`treasury.read_overview`, `treasury.read_exceptions`, `exec.read_overview`) and wire a scheduled workflow; then they can be enabled |
| The rest of the command centre: pipeline board, customers, projects | Build | Ops and Treasury exist; these sections don't |
| Proposal documents: a PDF or a page to send to the customer after approval | Build | Approval records the decision only |
| PostgreSQL backend behind the repository interface | Build, after owner approval and an instance | `V18-DATABASE-MIGRATION.md`: convert the 26 direct reads, decide sync vs async `tx`, import with a hash manifest, cut over by hand |
| An in-flight lock for idempotency keys | Build | Needed only if an asynchronous `/api/v1` write handler is added |
| Farm and drone modules | Owner first | Only when a real data source exists; the agents and event types are registered and waiting |

## Not planned

- Agents that approve, execute or administer anything. The ceiling is deliberate.
- Moving money from `/api/v1`. Money stays on the treasury control plane with its limits, quorum and kill switch.
- Placing trades from an agent or a workflow.
