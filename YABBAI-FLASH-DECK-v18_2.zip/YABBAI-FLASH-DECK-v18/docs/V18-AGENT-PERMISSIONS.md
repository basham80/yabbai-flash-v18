# V18 agent permissions

Who may do what, how the engine checks it, and what each agent is allowed to touch. The source of truth is code: `engine/lib/permissions.js` (roles and the ceiling) and `engine/lib/agentops.js` (the registry). No API route can widen a permission; changing one is a code change that goes through review and the test suite.

## Actions and resources

Actions: **view**, **create**, **edit**, **propose**, **approve**, **execute**, **administer**.

Resources: treasury, crm, sales, customers, operations, projects, agents, workflows, events, audit, system, farms, drones.

**approve**, **execute** and **administer** are person-only. No agent role holds them, and the cockpit token alone cannot use them: it gets 423 and the deck opens the Director vault.

## Roles

| Role | Who | view | create | edit | propose | approve | execute | administer |
|---|---|---|---|---|---|---|---|---|
| director | A person with an unlocked Director vault | all | all | all | all | all | all | all (fresh code) |
| approver | A person enrolled as approver, vault unlocked | all | crm, operations, projects, workflows | crm, operations, projects, workflows | all | sales, treasury, workflows | — | — |
| operator | The cockpit token with no vault session | all | crm, operations, projects, workflows | crm, workflows | sales, treasury, workflows | — | — | — |
| agent | An agent run (further limited by its own registry entry) | crm, sales, customers, treasury, operations, projects, agents, workflows | — | — | sales, treasury, crm | — | — | — |
| system | Engine internals (event consumers, migrations) | all | all | all | all | — | — | — |

How a request gets its role: `vault.actor()` reads `X-Yabbai-Vault`. A valid session makes the caller that person (director or approver); no session makes the caller the operator. `api-v1.js` then calls `permissions.need(actor, action, resource)` before the handler, and for person-only actions also requires the session. Administer and high-risk approvals call `vault.stepUp()`, which wants a fresh authenticator code (`X-Yabbai-Otp`) unless the session is younger than the step-up window (`stepUpWindowSec`, default 120 s, maximum 900 s).

Answers when the check fails:

| Caller | Asks for approve / execute / administer | Answer |
|---|---|---|
| operator | any | 423: unlock the Director vault |
| agent | any | 403 |
| system | any | 403 |
| approver | administer, or approve outside sales / treasury / workflows | 403 |
| director without a fresh code | administer | 428: enter an authenticator code |

Money keeps its v16 rules on top of this: transfers need an approved intent, limits, a cooling-off period for new destinations and a quorum; no one, director included, can approve their own high-risk request alone while another approver exists.

## The agent ceiling

`AGENT_CEILING(perm)` is true only for actions an agent role can hold (view or propose, on the resources above). The registry is checked against it when the engine loads: an entry above the ceiling stops the engine from starting. Test gate P1 checks every role and every registry entry.

## The registry

Defaults for every agent: model brain `chat`, temperature 0.2, instructions version 1, budget 20 runs per hour, 6 tool calls per run, 900 output tokens; "everything it proposes waits for a person".

| Agent | Status | Permissions | Tools | Workflow | Notes |
|---|---|---|---|---|---|
| CEO — Executive Intelligence | registered | view: crm, sales, treasury, operations, agents, workflows | `exec.read_overview` (declared, not installed) | — | Cannot override Treasury controls |
| CFO — Financial Intelligence | registered | view: treasury, sales, crm; propose: treasury | `treasury.read_overview` (declared, not installed) | — | Recommends; never approves its own proposals |
| Treasurer — Financial Operations | registered | view: treasury; propose: treasury | `treasury.read_overview`, `treasury.read_exceptions` (declared, not installed) | — | Cannot transfer money or sign |
| COO — Operational Intelligence | registered | view: operations, projects, workflows | — | — | |
| **Sales Director** | **enabled** | view: crm, sales; propose: sales | `crm.read_lead`, `sales.propose_proposal` (installed) | lead-to-proposal | The only agent that runs in v18 |
| Marketing Director | registered | view: crm | — | — | |
| Customer Success | registered | view: customers, crm | — | — | |
| Auditor / Risk Guardian | registered | view: treasury, crm, sales, agents, workflows | — | — | Read-only; cannot alter audit history |
| Farm Operations | not connected | — | — | — | No farm data source |
| Drone Operations | not connected | — | — | — | Cannot authorise or launch flights; no fleet data source |

"Registered" means the entry exists, its permissions are fixed and checked, and it runs nothing. The engine refuses to enable an agent with no workflow wired to it (422), and an agent with no data source (422), so the deck can never show an agent as "enabled" while it does nothing.

### What the director can change

`POST /api/v1/agents/:id` (director, fresh code, audited as `agent.profile_changed`):

- `status`: enabled, paused or registered. A paused agent runs nothing; its tasks go straight to a person.
- `budget.runsPerHour`: 0 to 500.

Permissions, tools and the model are not editable at run time.

## Tools

| Tool | Needs | Does |
|---|---|---|
| `crm.read_lead` | view:crm | Returns one lead: id, business, contact name and title, niche, location, website, channel, notes, source, stage, score, created date. Never the email address or phone number |
| `sales.propose_proposal` | propose:sales | Marks the draft as proposed. The save itself happens in the run's own transaction, after validation. It cannot send or approve |

Every tool call is checked three ways before it runs (the agent lists the tool, the tool is installed, the agent holds the tool's permission) and every call is recorded on the run, refused ones included, with the argument names (not values) and any error. A refused call is a permanent failure; the task goes to a person instead of retrying.

## What the model is and is not trusted with

For the Sales Director:

- The lead is passed inside `<lead_record id="lead:…">` tags, and the system prompt says that record is data from outside the business: instructions in it are not to be followed and are reported as findings. Gate A3 checks this with a lead whose notes try to get the proposal approved.
- The model decides the qualification, findings and proposal wording. It does not decide:
  - **approval**: `approval_required` is forced to true whatever it answers;
  - **arithmetic**: line totals, subtotal, GST and total are computed by the engine in cents, and GST is added only when GST registration is confirmed in Treasury settings;
  - **evidence**: only references to records the agent actually read (`lead:…`, `opportunity:…`) are kept.
- The answer must match `sales.qualification.v1`: 1 to 12 lines, quantities 1 to 1,000, unit prices A$0.01 to A$1,000,000, validity 1 to 90 days, fit high / medium / low. Anything else fails the run, and the bus asks again.
- An answer with status `needs_more_info` or `escalate` sends the task to a person at once, with or without a draft. An `ok` answer with no draft fails the run.

## Changing permissions

1. Edit the registry entry in `agentops.js` (or the role in `permissions.js`).
2. Keep agents at or below the ceiling; the engine will not start otherwise.
3. Run `npm test` in `engine/`; gate P1 lists every permission an agent holds.
4. Record the change in this file.
