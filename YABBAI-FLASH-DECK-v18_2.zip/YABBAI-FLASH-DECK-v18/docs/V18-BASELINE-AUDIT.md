# V18 baseline audit

What the code base was when v18 work started, checked against the v18 brief. The baseline is commit `33b1dbd` on branch `v16` (engine and deck version 16.0.0). Everything below was read from that commit or run against it; nothing is inferred from earlier plans.

## The system at v16

| Area | State at v16 | Evidence |
|---|---|---|
| Runtime | One Node process (Node 18+, tested on 22), no npm dependencies in the engine | `engine/package.json`, `engine/server.js` (1,133 lines) |
| Code | 38 modules in `engine/lib` (11,867 lines, of which about 2,000 are the BIP-39 word list the secret guard uses) | `git ls-tree 33b1dbd engine/lib` |
| Storage | JSON documents written atomically: `data/db.json` (leads, ledger, invoices, settings, v15 outbox) and `data/treasury/state.json`; append-only, hash-chained `data/treasury/journal.jsonl` and `audit.jsonl` | `lib/store.js`, `lib/tstore.js`, `lib/journal.js`, `lib/audit.js` |
| Data access | Modules read and change `store.db` directly. No repository layer, no record versions, no per-record history | `lib/ops.js`, `lib/invoices.js` |
| Business API | Unversioned `/api/*` for the cockpit; `/api/v2/*` for the treasury control plane (writes need `Idempotency-Key`) | `server.js`, `lib/treasury-api.js` |
| Machine APIs | `/v1/*` OpenAI-compatible model gateway, `/openapi.json` for agent tools, `/mcp` | `lib/gateway.js`, `server.js` |
| Events | In-process `EventEmitter` (`util.bus`) plus a server-sent events stream at `/api/events` that tells the deck to refresh. Nothing durable: no outbox, retries, dead letters or consumer de-duplication | `lib/util.js`, `server.js` |
| Agents | v15 named agents (qualifier, closer, supporter, builder and others) run by `agents.js` and `loop.js`; their drafts wait in a shared approval queue. No registry with declared permissions, tools or budgets, no task contract, no per-run record of tool calls | `lib/agents.js`, `lib/loop.js`, `lib/queue.js` |
| Permissions | Director vault v2 (PIN plus authenticator) guards money actions on `/api/v2`; director and approver are the people roles. Everything else is open to whoever holds the cockpit token. No view / create / edit / propose / approve / execute / administer model | `lib/vault.js`, `lib/approvals.js` |
| Deck (studio) | Four tabs: Deck, Leads, Receive, Oil desk. Treasury had no tab (only the engine console at `/console`). No operations view, no executive metrics with a data-quality status | `studio/src/App.tsx`, `studio/src/components/Header.tsx` |
| Health | `/healthz` (process up, no token) and `/api/health` (token, detail). No readiness probe | `server.js` |
| Tests | 7 suites, 396 assertions, all passing (table below) | `engine/test/*` |
| Deployment | `render.yaml`: one web service in Singapore, starter plan, 1 GB disk at `/var/data`, health check `/healthz`. Not deployed: Render has no GitHub access to `yabbiebass-debug/YABBAI-gng`. No PostgreSQL instance exists | `render.yaml` |

### Test baseline (v16)

| Suite | Assertions |
|---|---|
| `test/smoke.js` | 79 |
| `test/smoke13.js` | 55 |
| `test/smoke15.js` | 45 |
| `test/smoke15-token.js` | 13 |
| `test/receive-smoke.js` | 19 |
| `test/smoke16-broker.js` | 45 |
| `test/smoke16-treasury.js` | 140 (29 release gates) |
| **Total** | **396** |

## Gaps against the v18 brief

| v18 requirement | Gap at v16 | What v18 did |
|---|---|---|
| Modular monolith with a repository abstraction; PostgreSQL in production when available | Monolith yes; no repository layer; JSON only | New `lib/opsstore.js` repository (get, list, insert, update with expected version, `tx`). PostgreSQL not built: plan and blockers in `V18-DATABASE-MIGRATION.md` |
| Versioned API with OpenAPI | Only `/api/v2` (treasury) was versioned; no OpenAPI for the business API | `/api/v1` (29 routes) with OpenAPI 3.1 at `/api/v1/openapi.json` |
| Durable event bus: envelope, outbox and inbox, retries with backoff, dead letters, audited replay | None | `lib/events.js`, `lib/contracts.js` (23-type catalogue) |
| Agent registry, read-only by default, runtime with budgets, validation, retry, escalation and run logs | Agents existed without declared limits | `lib/agentops.js`: 10 agents; one enabled (Sales Director) |
| Server-side permissions: view, create, edit, propose, approve, execute, administer | Vault for money only | `lib/permissions.js`, checked on every `/api/v1` route |
| Command centre with Treasury in the navigation; metrics carry source, basis, unit, time, quality and status | No Treasury tab, no such metrics | Ops and Treasury tabs; `lib/executive.js` (19 metrics) |
| `/health` and `/ready` | Liveness only | `/health`, `/ready` (and `/healthz`, `/readyz`), `/api/v1/health`, `/api/v1/ready` |
| Vertical slice: lead → task → agent → proposal → person approves → customer and opportunity → audit → executive view | Not present | `lib/salesflow.js`; gate V1 in `test/smoke18-ops.js` |
| Tests for permissions, duplicate events, journal balance, security | Treasury covered; nothing for the new layers | `test/smoke18-ops.js`: 18 gates |

## Carried-over facts that still hold

- Money never moves on its own. Transfers need an approved intent, limits and a person; v18 adds no money path.
- The journal and audit trail are append-only and hash-chained; v18 reads them and adds facts about them, never rewrites them.
- The cTrader link is demo-first, and an order goes out only when a person sends it from the oil desk (or in cTrader itself). v18 adds no way for an agent, workflow or API call to place one.
