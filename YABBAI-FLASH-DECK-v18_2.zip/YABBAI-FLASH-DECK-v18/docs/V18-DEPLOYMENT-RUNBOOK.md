# V18 deployment runbook

How to run v18 on the laptop and on Render, how to upgrade from v16, how to check it, and how to roll back.

**Current state:** verified on a local build only. Nothing has been deployed to staging or production. The Render service `yabbai-flash-deck` cannot be created until Render can read the GitHub repository.

## What changes on upgrade

- New file `data/ops/state.json`, created on first start. Nothing else is migrated.
- Existing files keep their formats. Approval records gain an optional `correlationId` field; v16 ignores it.
- New routes: `/api/v1/*`, `/health`, `/ready`. Old routes are unchanged.
- Backups (`POST /api/v2/treasury/backup`) now include `ops/state.json`.
- The deck gains the Ops and Treasury tabs.

## Laptop (Windows)

1. Back up first: stop YABBAI (`STOP-YABBAI.bat`) and copy the whole `data` folder somewhere safe.
2. Get the code: `git fetch origin && git checkout v18` in the YABBAI folder (or download the `v18` branch as a zip and replace the folder, keeping `data`).
3. Start: `START-YABBAI.bat`. The engine listens on `http://127.0.0.1:7860`; the deck is at `/studio`.
4. Check: open `http://127.0.0.1:7860/ready`. It should say `{"ready":true,"version":"18.0.0"}`.
5. Optional: run the tests (`cd engine && npm test`, about 70 seconds; they use temporary folders, never your data).

Mac or Linux: `scripts/start.sh` and `scripts/stop.sh`, or `node engine/server.js`.

## Render

### One-time setup (owner)

1. **Give Render access to the repository.** On GitHub: Settings → Applications → Installed GitHub Apps → Render → Configure → Repository access, and add `yabbiebass-debug/YABBAI-gng`. (If Render's GitHub app is not installed yet, connect GitHub from Render's dashboard first.) Without this the blueprint cannot be created.
2. **Create the service from the blueprint.** In Render, create a new Blueprint from the repository, branch `v18`. `render.yaml` creates `yabbai-flash-deck`: Node, Singapore, starter plan, 1 GB disk at `/var/data`, `YABBAI_DATA=/var/data/yabbai`, a generated `YABBAI_TOKEN`, `YABBAI_BRAIN=hf`, health check `/healthz`. The disk needs a paid plan.
3. **Add secrets on the Environment tab** (never in git): `HF_TOKEN` for the Hugging Face brain; `PAYPAL_CLIENT_SECRET` if you invoice through PayPal; `YABBAI_BANK_WEBHOOK_SECRET` if a bank feed posts webhooks.
4. **Copy the token.** Environment tab → `YABBAI_TOKEN`. It links the deck in AI Studio and builds the claude.ai connector URL. Keep it private.

### Every deploy

1. Push to the branch the service follows (auto-deploy is on in `render.yaml`).
2. Watch the deploy log until the line `YABBAI engine 18.0.0 → …` appears.
3. Check `https://<service>.onrender.com/health` then `/ready`. `/ready` is 503 until the stores load, the journal verifies and the event bus ticks.
4. Open `https://<service>.onrender.com/login?token=<engine token>` once per browser to get the deck's cookie.

Keep the service at **one instance**. The stores assume one engine per data folder.

### Health checks

| Probe | Use it for | Notes |
|---|---|---|
| `/healthz` or `/health` | Render's health check (liveness) | Leave `render.yaml` on `/healthz`: a restart would not fix a failed readiness check such as a journal problem, so restarting on it would only loop |
| `/ready` or `/readyz` | An uptime monitor that pages a person | 503 means the ops store, journal or event bus needs a look; `/api/v1/ready` (with the token) says which |

## After the first v18 start (owner)

These make the new screens useful. None of them can be done by the engine for you.

1. **Set up the Director vault.** Deck → Treasury → "Set up vault" (or approve anything; the deck opens setup). Choose a PIN, add the authenticator secret to your phone's authenticator app, confirm with a code, and store the recovery codes offline. Until this is done, approvals and money actions stay off.
2. **Work through "Needs configuration"** on the Treasury tab: the business entity that owns the accounts, GST registration (ask your accountant), the income-tax reserve rate, review or replace policy v1, whether trading capital is funded and its cap, transfer limits, approval quorum per risk level, and the accounts you own (watch-only addresses).
3. **cTrader (optional).** In the cTrader developer app, add the redirect URL `https://<service>.onrender.com/broker/callback` (or `http://127.0.0.1:7860/broker/callback` on the laptop). Connect a demo account first. An order goes out only when you send it from the oil desk or from cTrader.
4. **Try the slice.** Leads tab → the proposal button on a lead (or `POST /api/v1/crm/leads`). Watch it in Ops, then approve or reject it there.

## Environment variables used by v18

| Variable | Default | Purpose |
|---|---|---|
| `YABBAI_DATA` | `./data` | Data folder |
| `YABBAI_PORT` / `PORT` | 7860 | Listen port (Render sets `PORT`) |
| `YABBAI_TOKEN` | generated into `data/secret.json` | Engine bearer token |
| `YABBAI_PUBLIC_URL` / `RENDER_EXTERNAL_URL` | — | Public address for links and the cTrader redirect |
| `YABBAI_BRAIN` | — | `hf` on Render; local Ollama otherwise |
| `YABBAI_EVENTS_TICK_MS` | 2000 | How often the event bus drains |
| `YABBAI_EVENTS_BACKOFF_MS` | 15000 | First retry delay (×4 each time, 30 min cap, 50 ms minimum) |
| `YABBAI_BUSINESS_NAME` | `YABBAI business` | Name of the default business record |

## Rollback

v18 adds data and changes no existing format, so going back to v16 is a code change only:

1. Stop the engine.
2. Laptop: `git checkout v16`. Render: change the service's branch to `v16` in its settings and deploy.
3. Start. v16 ignores `data/ops/`; leads, invoices, the treasury, the journal and the audit trail open as before. Proposals, tasks and workflow runs made in v18 stay in `data/ops/state.json` for when you return to v18.

If a data folder itself is damaged, restore the copy taken before the upgrade, or a backup with `node scripts/v16-restore.js <backup id> --yes` while the engine is stopped. The script runs a drill first (file hashes, both hash chains, balances) and saves the current state as a "pre-restore" backup. Backups made by v18 include `ops/state.json`; the vault (`data/secrets`) is never in a backup.
