# V18 database migration plan

**Status: not started.** v18 runs on JSON files. PostgreSQL is not provisioned anywhere, and moving the book of record needs a person's approval, so this document is the plan and the list of what blocks it. Nothing in the code switches storage on its own, and nothing writes to two stores at once.

## Where data lives today

| Data | File | Format | Written by |
|---|---|---|---|
| Leads, v15 ledger, invoices, settings | `data/db.json` | one JSON document, atomic rewrite, 300 ms debounce | `store.js` |
| Treasury state (accounts, policy, approvals, transfers, exceptions) | `data/treasury/state.json` | one JSON document, atomic rewrite, 150 ms debounce | `tstore.js` |
| Double-entry journal | `data/treasury/journal.jsonl` | append-only lines, hash-chained | `journal.js` |
| Audit trail | `data/treasury/audit.jsonl` | append-only lines, hash-chained | `audit.js` |
| Operations (v18) | `data/ops/state.json` | one JSON document, atomic rewrite on every `tx` | `opsstore.js` |

On Render the folder is `YABBAI_DATA=/var/data/yabbai` on a 1 GB persistent disk.

### How far the JSON store goes

Every operations `tx` rewrites the whole file. Measured in the build container with event records of the real shape (about 0.7 KB each):

| Events in the outbox | File size | One write |
|---|---|---|
| 1,000 | 0.7 MB | 2 ms |
| 10,000 | 6.7 MB | 30 ms |
| 50,000 | 33.9 MB | 241 ms |

One lead taken through to an approved proposal produces about 12 events. A business adding a few hundred leads a month stays under 10 MB for a long time; the first fix needed is outbox retention (`V18-NEXT-STEPS.md`), not a database. The real reasons to move are concurrent writers (more than one engine process), querying at scale, and managed backups.

## The repository interface the database must implement

`opsstore.js` is the only module that touches the operations file:

| Call | Contract |
|---|---|
| `load()` | Open the store; refuse to start on unreadable data (`EOPSCORRUPT`) |
| `tx(fn)` | Run `fn(state)` as one atomic unit. Throw → nothing persists. Nested `tx` joins the outer one. `fn` must be synchronous |
| `repo(name).get(id, businessId?)` | One record or null |
| `repo(name).list(pred?, businessId?)` | Records for the business matching `pred` |
| `repo(name).insert(rec, by)` | Adds `businessId`, `version: 1`, timestamps and history; 409 if the id exists |
| `repo(name).update(id, patch, by, change, expectVersion?)` | Bumps `version`, appends history (last 50); 404 if missing; 409 if `expectVersion` is stale |
| `counts()` | Records per collection (used by `/ready`) |

### Calls that still bypass the interface

These read `opsstore.raw()` directly and must move to repository calls (or purpose-built queries) before a database backend can work:

| Module | `raw()` uses | What for |
|---|---|---|
| `events.js` | 9 | Outbox scans, delivery slots, inbox and dead letters |
| `agentops.js` | 7 | Run counts per hour, task and run lookups, overrides |
| `api-v1.js` | 5 | Idempotency keys, run detail joins |
| `salesflow.js` | 3 | Proposal and task lookups inside consumers |
| `executive.js` | 2 | Task and run statistics |

`tx(fn)` being synchronous is the other gap: with PostgreSQL every read inside a transaction is a round trip. The plan is to keep the in-process synchronous model for decision logic and make the backend a write-behind journal of whole-transaction change sets, or to make `tx` async and convert its callers. That choice is the first design decision of the migration.

## Target schema (sketch)

```sql
-- one table per collection; the record body stays JSONB during the move
create table ops_records (
  collection   text        not null,          -- customers, opportunities, proposals, tasks, agent_runs, workflow_runs, businesses
  id           text        not null,
  business_id  text        not null,
  version      integer     not null,
  created_at   timestamptz not null,
  updated_at   timestamptz not null,
  body         jsonb       not null,
  primary key (collection, id)
);
create index on ops_records (collection, business_id, updated_at desc);

create table ops_outbox (
  event_id       text primary key,
  event_type     text        not null,
  event_version  integer     not null,
  occurred_at    timestamptz not null,
  source_service text        not null,
  business_id    text        not null,
  actor_id       text        not null,
  correlation_id text        not null,
  sensitivity    text        not null,
  payload        jsonb       not null,
  recorded_at    timestamptz not null default now()
);
create index on ops_outbox (event_type, recorded_at);
create index on ops_outbox (correlation_id);

create table ops_deliveries (           -- one row per (event, consumer)
  event_id   text not null references ops_outbox(event_id),
  consumer   text not null,
  status     text not null,             -- pending | running | retrying | done | dead
  attempts   integer not null default 0,
  next_at    timestamptz,
  last_error text,
  primary key (event_id, consumer)
);
create table ops_inbox (                -- the exactly-once mark, written with the effect
  consumer text not null,
  event_id text not null,
  at       timestamptz not null,
  primary key (consumer, event_id)
);
create table ops_dead_letters (
  id text primary key, event_id text not null, consumer text not null,
  attempts integer not null, error text, at timestamptz not null, correlation_id text
);
create table ops_idempotency (
  key text primary key, fingerprint text not null, status integer not null,
  body jsonb not null, path text not null, at timestamptz not null
);
```

The journal and audit trail stay as hash-chained files in the first phase: they are already append-only and verified on every `/ready`. Moving them is a separate, later decision.

## Procedure

Each phase ends at a check a person signs off. There is no automatic switch.

1. **Provision (human).** Create a Render PostgreSQL instance in the same region as the web service. Put its internal URL in a new environment variable, `YABBAI_OPS_DATABASE_URL`, on the service. This is a production change and needs the owner's explicit approval.
2. **Build the backend (code).** Implement the interface above against PostgreSQL, behind `YABBAI_OPS_BACKEND=json|postgres` (default `json`). Convert the `raw()` callers. The engine refuses to start if the backend says `postgres` and the database is unreachable or holds no imported data: it never falls back silently.
3. **Import (read-only on the source).** A one-off command copies `data/ops/state.json` into the database inside one transaction and writes a manifest: counts per collection, and a SHA-256 of each record's canonical JSON.
4. **Verify.** Compare the manifest with the file: counts equal, hashes equal, the outbox and inbox keys equal, `/ready` green with the database backend on a staging copy.
5. **Cut over (human approval).** Take a backup (`POST /api/v2/treasury/backup` with an unlocked vault; it now includes `ops/state.json`), stop the engine, copy `data/` as well, run the import again on the final file, verify again, set `YABBAI_OPS_BACKEND=postgres`, start. The JSON file stays on disk, untouched, as the rollback point.
6. **Watch.** For a week: `/ready`, dead letters, executive metrics against the last JSON numbers.

Rollback at any point before step 5: nothing to undo. After step 5: stop, set `YABBAI_OPS_BACKEND=json`, start. Writes made on PostgreSQL after the cut-over are not in the JSON file; export them with the same tool in reverse before rolling back, or accept losing them. That trade-off is why step 5 needs a person.

## Blockers

| Blocker | Owner |
|---|---|
| No PostgreSQL instance exists (Render Postgres is a paid add-on) | Owner: approve the cost and create it |
| The web service itself is not deployed: Render has no GitHub access to the repository | Owner: grant the Render GitHub app access to `yabbiebass-debug/YABBAI-gng` |
| `tx` is synchronous; the async design choice is open | Build |
| 26 direct `raw()` reads to convert | Build |
