@echo off
setlocal
cd /d "%~dp0"
title YABBAI - deep brain install
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\install-deep-brain.ps1" %*
echo.
pause
