@echo off
setlocal
cd /d "%~dp0"
node "%~dp0scripts\launcher.js" stop %*
timeout /t 4 >nul
