@echo off
setlocal
cd /d "%~dp0"
title YABBAI LOCAL
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js was not found. Run INSTALL-YABBAI.bat first.
  pause
  exit /b 1
)
node "%~dp0scripts\launcher.js" start %*
if errorlevel 1 (
  pause
  exit /b 1
)
timeout /t 5 >nul
