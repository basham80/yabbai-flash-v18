#!/usr/bin/env node
/**
 * Build the React cockpit and drop it into the YABBAI engine.
 *
 *   npm run build:studio                # -> ../engine/public/studio
 *   STUDIO_OUT=... npm run build:studio # -> somewhere else
 *
 * Why a script instead of two commands: the base path must be /studio, and the
 * output must land exactly where the engine serves it, or you get a blank page
 * with 404'd assets. One command, one truth.
 */
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const enginePublic = path.resolve(root, '..', 'yabbai', 'yabbai-local', 'engine', 'public');
// Fall back to a sibling engine copy when the app is unzipped inside the engine.
const outDefault = fs.existsSync(enginePublic) ? path.join(enginePublic, 'studio') : path.resolve(root, '..', 'engine', 'public', 'studio');
const out = path.resolve(process.env.STUDIO_OUT || outDefault);

console.log(`[studio] building with base=/studio/ -> ${out}`);

const viteBin = path.join(root, 'node_modules', 'vite', 'bin', 'vite.js');
if (!fs.existsSync(viteBin)) {
  console.error('[studio] vite is not installed. Run: npm install');
  process.exit(1);
}

const build = spawnSync(process.execPath, [viteBin, 'build'], {
  cwd: root,
  stdio: 'inherit',
  env: { ...process.env, STUDIO_BASE: '/studio/' },
});
if (build.status !== 0) process.exit(build.status || 1);

const dist = path.join(root, 'dist');
if (!fs.existsSync(path.join(dist, 'index.html'))) {
  console.error('[studio] build produced no dist/index.html');
  process.exit(1);
}

fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });
fs.cpSync(dist, out, { recursive: true });

const bytes = fs.readdirSync(out, { recursive: true })
  .map((f) => {
    try {
      return fs.statSync(path.join(out, String(f))).size;
    } catch {
      return 0;
    }
  })
  .reduce((a, b) => a + b, 0);

console.log(`[studio] deployed to ${out} (${(bytes / 1024).toFixed(0)} KB)`);
console.log('[studio] open http://127.0.0.1:7860/studio');
