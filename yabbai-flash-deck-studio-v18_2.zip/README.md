# YABBAI FLASH Deck (AI Studio / React)

The screens for the YABBAI engine: DECK, OPS, TREASURY, LEADS, RECEIVE, OIL DESK. It has no data and no model of its own; everything comes from your engine (laptop or Render), so every number on it is real.

## In Google AI Studio

1. Upload this folder (or the zip) to your AI Studio app.
2. Open the app and click **NOT LINKED** (top right).
3. Paste your engine URL (for example `https://yabbai-flash-deck.onrender.com`) and the engine token (Render: `YABBAI_TOKEN` in the Environment tab; laptop: `data/secret.json` in the YABBAI folder).
4. Tick "Remember on this device" if you want it to stay linked after you close the tab.

AI Studio cannot reach `127.0.0.1` on your laptop. Link it to Render or to a tunnel URL.

Approving proposals (OPS) and anything in TREASURY that moves money asks for your Director vault: PIN plus a code from your authenticator app. Set it up once from the TREASURY tab.

## Locally

```
npm install
npm run dev            # http://localhost:3000, link it to http://127.0.0.1:7860
npm run build:studio   # builds into ../engine/public/studio (served at /studio/)
```

No Gemini key is needed and none is used.
