import React, { useEffect, useState } from 'react';
import { Link2, Unlink } from 'lucide-react';
import { engineConfig, linkEngine, servedByEngine, unlinkEngine } from '../services/brain';
import { useEngine } from '../context/EngineContext';
import { aud } from '../services/engineApi';
import { inputCls } from './ui';

/**
 * The engine link. Shows whether the deck is talking to a live engine and the two
 * numbers that matter most, both straight from the engine: income with a receipt
 * in the ledger, and what open invoices are still owed.
 */
export const EngineTruthChip: React.FC = () => {
  const { snap, error, linked } = useEngine();
  const local = servedByEngine();
  const [open, setOpen] = useState(false);
  const [base, setBase] = useState(() => engineConfig().base);
  const [token, setToken] = useState('');
  const [remember, setRemember] = useState(false);

  useEffect(() => {
    if (!linked && !local) setOpen(true);
  }, [linked, local]);

  const live = linked && !!snap && !error;
  const label = !linked ? 'NOT LINKED' : live ? 'ENGINE LIVE' : 'ENGINE OFFLINE';
  const tone = live ? 'border-[#14F195]/50 bg-[#14F195]/10 text-[#14F195]' : linked ? 'border-[#FF4D6D]/50 bg-[#FF4D6D]/10 text-[#FF4D6D]' : 'border-[#F5A623]/50 bg-[#F5A623]/10 text-[#F5A623]';

  const save = (e: React.FormEvent) => {
    e.preventDefault();
    if (!token.trim()) return;
    linkEngine(local ? '' : base, token, remember);
    setToken('');
    setOpen(false);
  };

  return (
    <div className="relative flex items-center gap-2 text-xs font-mono-num">
      <button
        onClick={() => setOpen((v) => !v)}
        className={`flex items-center gap-2 px-2.5 py-1 rounded border ${tone}`}
        title={live ? `Engine ${snap?.version} · ${snap?.ledgerTotals.count ?? 0} ledger entries` : error || 'Link the deck to your YABBAI engine'}
      >
        <span className={`w-2 h-2 rounded-full bg-current ${live ? 'animate-pulse' : ''}`} />
        <span className="uppercase tracking-wider text-[10px]">{label}</span>
        {live && snap && (
          <>
            <span className="opacity-40">|</span>
            <span className="text-[#f5c518] font-bold">{aud(snap.ledgerTotals.all)}</span>
            <span className="hidden sm:inline text-[9px] uppercase tracking-wider opacity-70">verified</span>
            <span className="hidden md:inline opacity-40">|</span>
            <span className="hidden md:inline text-[#b98cff] font-bold">{aud(snap.receive.summary.receivableAud)}</span>
            <span className="hidden md:inline text-[9px] uppercase tracking-wider opacity-70">owed</span>
          </>
        )}
      </button>

      {open && (
        <form
          onSubmit={save}
          className="absolute right-0 top-full mt-2 z-50 w-[min(92vw,360px)] bg-[#0a1224] border border-[#131d33] rounded-lg p-3 shadow-2xl space-y-2"
        >
          <div className="text-[11px] font-semibold text-white">Link this deck to your engine</div>
          {!local && (
            <label className="block space-y-1">
              <span className="text-[9px] uppercase tracking-wider text-[#8B93A7]">Engine URL</span>
              <input
                className={inputCls}
                value={base}
                onChange={(e) => setBase(e.target.value)}
                placeholder="https://yabbai-deck.onrender.com"
                inputMode="url"
                autoComplete="url"
              />
            </label>
          )}
          <label className="block space-y-1">
            <span className="text-[9px] uppercase tracking-wider text-[#8B93A7]">Engine token</span>
            <input className={inputCls} type="password" value={token} onChange={(e) => setToken(e.target.value)} placeholder="yb_…" autoComplete="off" />
          </label>
          <p className="text-[10px] text-[#5d6780] leading-snug">
            Laptop: <span className="text-[#8B93A7]">engine/data/secret.json</span>. Render: the <span className="text-[#8B93A7]">YABBAI_TOKEN</span> value in the service's Environment tab.
          </p>
          <label className="flex items-center gap-2 text-[10px] text-[#8B93A7]">
            <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} className="accent-[#f5c518]" />
            Remember on this device
          </label>
          {error && linked && <p className="text-[10px] text-[#FF4D6D] leading-snug">{error}</p>}
          <div className="flex items-center justify-between gap-2 pt-1">
            {linked && !local ? (
              <button
                type="button"
                onClick={() => {
                  unlinkEngine();
                  setOpen(true);
                }}
                className="inline-flex items-center gap-1 text-[10px] uppercase tracking-wider text-[#8B93A7] hover:text-[#FF4D6D]"
              >
                <Unlink className="w-3 h-3" /> Unlink
              </button>
            ) : (
              <span />
            )}
            <button type="submit" className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded border border-[#f5c518]/60 bg-[#f5c518]/10 text-[#f5c518] text-[10px] font-semibold uppercase tracking-wider">
              <Link2 className="w-3 h-3" /> Link
            </button>
          </div>
        </form>
      )}
    </div>
  );
};
