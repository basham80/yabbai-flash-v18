import React from 'react';
import { RefreshCw } from 'lucide-react';
import { useEngine } from '../context/EngineContext';
import type { EngineSnapshot } from '../services/engineApi';
import { servedByEngine } from '../services/brain';
import { Btn, Notice, Panel } from './ui';

/** Renders a surface only when the engine has answered; otherwise says what is missing. */
export const EngineGate: React.FC<{ children: (snap: EngineSnapshot) => React.ReactNode }> = ({ children }) => {
  const { snap, error, loading, linked, refresh } = useEngine();

  if (!linked) {
    return (
      <Panel title="Link your engine">
        <div className="space-y-3 text-sm text-slate-300 max-w-2xl leading-relaxed">
          <p>
            This deck shows nothing until it is linked to your YABBAI engine, because the engine is where the real numbers live: the ledger with receipts, invoices,
            leads and the oil journal.
          </p>
          <ol className="list-decimal pl-5 space-y-1.5 text-[13px] text-[#a7afc2]">
            <li>
              Start the engine on your laptop (<span className="font-mono-num text-[#f5c518]">START-YABBAI.bat</span>) or open your Render service.
            </li>
            <li>
              Click <span className="text-[#F5A623] font-semibold">NOT LINKED</span> at the top right and paste the engine URL and token.
            </li>
            <li>The token is in engine/data/secret.json on the laptop, or YABBAI_TOKEN in the Render service's Environment tab.</li>
          </ol>
          {!servedByEngine() && (
            <Notice tone="gold">
              Running inside AI Studio? Use the engine's public URL (Render, or a tunnel). A browser cannot reach your laptop's 127.0.0.1 from AI Studio's servers.
            </Notice>
          )}
        </div>
      </Panel>
    );
  }

  if (!snap) {
    if (loading) {
      return <div className="py-16 text-center text-xs uppercase tracking-wider text-[#8B93A7]">Connecting to the engine…</div>;
    }
    return (
      <Panel title="Engine unreachable" right={<Btn onClick={refresh}><RefreshCw className="w-3 h-3" /> Try again</Btn>}>
        <div className="space-y-3 max-w-2xl">
          <Notice tone="red">{error || 'No answer from the engine.'}</Notice>
          <ul className="list-disc pl-5 text-[13px] text-[#a7afc2] space-y-1">
            <li>Is the engine running? On the laptop, START-YABBAI.bat; on Render, check the service is live.</li>
            <li>Is the URL right? It should open the engine when you paste it into a new tab.</li>
            <li>Was the token changed? Link again with the current one.</li>
          </ul>
        </div>
      </Panel>
    );
  }

  return <>{children(snap)}</>;
};
