import React, { useMemo, useRef, useState } from 'react';
import { CheckCircle2, ChevronDown, ChevronUp, FileText, Plus, RefreshCw, Send, Trash2, Trophy, Upload, X } from 'lucide-react';
import { EngineGate } from '../EngineGate';
import { engineChanged } from '../../context/EngineContext';
import { engineApi, LEAD_STAGES, v1, type ConnectInfo, type EngineDraft, type EngineLead, type EngineSnapshot, type LeadImportResult, type LeadStage } from '../../services/engineApi';
import { ago, Btn, CopyBtn, Empty, Field, inputBase, inputCls, Notice, Panel, Pill, useFlash } from '../ui';

const STAGE_LABEL: Record<LeadStage, string> = { new: 'New', drafted: 'Drafted', sent: 'Sent', replied: 'Replied', won: 'Won', lost: 'Lost' };
const STAGE_TONE: Record<LeadStage, 'slate' | 'gold' | 'purple' | 'green' | 'red' | 'orange'> = {
  new: 'slate',
  drafted: 'gold',
  sent: 'purple',
  replied: 'orange',
  won: 'green',
  lost: 'red',
};

/** LEADS: the real pipeline. Pancake, CSV exports and hand-entered leads land in the same table. */
export const LeadsSurface: React.FC = () => <EngineGate>{(snap) => <Leads snap={snap} />}</EngineGate>;

const Leads: React.FC<{ snap: EngineSnapshot }> = ({ snap }) => {
  const [flash, show] = useFlash();
  const [stage, setStage] = useState<LeadStage | 'all'>('all');
  const [source, setSource] = useState('all');
  const [q, setQ] = useState('');
  const [panel, setPanel] = useState<'import' | 'add' | 'pancake' | null>(snap.leads.length ? null : 'import');

  const drafts = snap.outbox.filter((d) => d.status === 'draft');
  const sources = useMemo(() => Array.from(new Set(snap.leads.map((l) => l.source || 'manual'))).sort(), [snap.leads]);
  const counts = useMemo(() => {
    const c: Record<string, number> = { all: snap.leads.length };
    for (const l of snap.leads) c[l.stage] = (c[l.stage] || 0) + 1;
    return c;
  }, [snap.leads]);
  const rows = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return snap.leads.filter(
      (l) =>
        (stage === 'all' || l.stage === stage) &&
        (source === 'all' || (l.source || 'manual') === source) &&
        (!needle || `${l.business} ${l.name} ${l.contact} ${l.niche} ${l.location} ${l.title || ''}`.toLowerCase().includes(needle)),
    );
  }, [snap.leads, stage, source, q]);

  const act = async (fn: () => Promise<unknown>, ok: string) => {
    try {
      await fn();
      show(ok);
      engineChanged();
    } catch (e) {
      show((e as Error).message, 'red');
    }
  };

  const toggle = (p: 'import' | 'add' | 'pancake') => setPanel((cur) => (cur === p ? null : p));

  return (
    <div className="space-y-4">
      {flash}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-bold text-white tracking-wide">Leads</h1>
          <p className="text-xs text-[#8B93A7]">
            {snap.leads.length} in the pipeline · {drafts.length} outreach draft{drafts.length === 1 ? '' : 's'} waiting for approval. Nothing is sent without you.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Btn tone={panel === 'import' ? 'gold' : 'ghost'} onClick={() => toggle('import')}>
            <Upload className="w-3 h-3" /> Import
          </Btn>
          <Btn tone={panel === 'pancake' ? 'gold' : 'ghost'} onClick={() => toggle('pancake')}>
            Hook up Pancake
          </Btn>
          <Btn tone={panel === 'add' ? 'gold' : 'ghost'} onClick={() => toggle('add')}>
            <Plus className="w-3 h-3" /> Add lead
          </Btn>
        </div>
      </div>

      {panel === 'import' && <ImportPanel onDone={(r) => show(`Imported ${r.added} · ${r.duplicates} duplicate${r.duplicates === 1 ? '' : 's'} · ${r.skipped.length} skipped`)} onError={(m) => show(m, 'red')} />}
      {panel === 'pancake' && <PancakePanel />}
      {panel === 'add' && <AddLead onAdded={(l) => show(`Lead added: ${l.business}`)} onError={(m) => show(m, 'red')} />}

      {drafts.length > 0 && (
        <Panel title={`Outreach drafts waiting · ${drafts.length}`}>
          <div className="space-y-3">
            {drafts.slice(0, 20).map((d) => (
              <DraftCard key={d.id} d={d} onStatus={(s, msg) => act(() => engineApi.outbox.setStatus(d.id, s), msg)} />
            ))}
          </div>
        </Panel>
      )}

      <Panel
        title="Pipeline"
        right={
          <>
            <select className={`${inputBase} w-auto py-1 text-xs`} value={source} onChange={(e) => setSource(e.target.value)} aria-label="Filter by source">
              <option value="all">All sources</option>
              {sources.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
            <input className={`${inputBase} w-40 py-1 text-xs`} placeholder="Search" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search leads" />
          </>
        }
      >
        <div className="flex flex-wrap gap-1 mb-3">
          {(['all', ...LEAD_STAGES] as Array<LeadStage | 'all'>).map((s) => (
            <button
              key={s}
              onClick={() => setStage(s)}
              className={`px-2.5 py-1 rounded border text-[10px] uppercase tracking-wider ${stage === s ? 'border-[#f5c518]/60 text-[#f5c518] bg-[#f5c518]/10' : 'border-[#131d33] text-[#8B93A7] hover:text-white'}`}
            >
              {s === 'all' ? 'All' : STAGE_LABEL[s]} <span className="font-mono-num opacity-70">{counts[s] || 0}</span>
            </button>
          ))}
        </div>
        {rows.length === 0 ? (
          <Empty title={snap.leads.length ? 'No leads match these filters' : 'No leads yet'}>
            {snap.leads.length ? 'Clear the search or pick another stage.' : 'Import a Pancake export or CSV above, or add one by hand.'}
          </Empty>
        ) : (
          <div className="overflow-x-auto -mx-1">
            <table className="w-full text-xs min-w-[760px]">
              <thead>
                <tr className="text-[9px] uppercase tracking-wider text-[#5d6780] text-left">
                  <th className="px-1.5 py-1.5 font-medium">Business</th>
                  <th className="px-1.5 py-1.5 font-medium">Contact</th>
                  <th className="px-1.5 py-1.5 font-medium">Source</th>
                  <th className="px-1.5 py-1.5 font-medium text-right">Score</th>
                  <th className="px-1.5 py-1.5 font-medium">Stage</th>
                  <th className="px-1.5 py-1.5 font-medium">Added</th>
                  <th className="px-1.5 py-1.5" />
                </tr>
              </thead>
              <tbody>
                {rows.slice(0, 300).map((l) => (
                  <LeadRow key={l.id} l={l} act={act} />
                ))}
              </tbody>
            </table>
            {rows.length > 300 && <p className="text-[10px] text-[#5d6780] mt-2">Showing 300 of {rows.length}. Narrow with the filters.</p>}
          </div>
        )}
      </Panel>
    </div>
  );
};

const LeadRow: React.FC<{ l: EngineLead; act: (fn: () => Promise<unknown>, ok: string) => Promise<void> }> = ({ l, act }) => {
  const [mode, setMode] = useState<'won' | 'delete' | null>(null);
  const [amount, setAmount] = useState('');
  const [ref, setRef] = useState('');
  return (
    <>
      <tr className="border-t border-[#131d33] align-top">
        <td className="px-1.5 py-2 min-w-0">
          <div className="text-slate-100 font-semibold">{l.business}</div>
          <div className="text-[#8B93A7]">
            {[l.name, l.title].filter(Boolean).join(' · ') || '—'}
            {l.location ? ` · ${l.location}` : ''}
          </div>
          {l.notes && <div className="text-[10px] text-[#5d6780] mt-0.5 max-w-md line-clamp-2 whitespace-pre-line">{l.notes}</div>}
        </td>
        <td className="px-1.5 py-2">
          <div className="text-slate-300 break-all">{l.contact || '—'}</div>
          {l.website && (
            <a href={/^https?:/i.test(l.website) ? l.website : `https://${l.website}`} target="_blank" rel="noreferrer" className="text-[10px] text-[#8B93A7] hover:text-[#f5c518] break-all">
              {l.website}
            </a>
          )}
        </td>
        <td className="px-1.5 py-2">
          <Pill tone={l.source === 'pancake' ? 'purple' : 'slate'}>{l.source || 'manual'}</Pill>
        </td>
        <td className="px-1.5 py-2 text-right font-mono-num">{l.score ?? '—'}</td>
        <td className="px-1.5 py-2">
          <select
            className={`${inputBase} w-28 py-1 text-xs`}
            value={l.stage}
            onChange={(e) => {
              const next = e.target.value as LeadStage;
              if (next === 'won') setMode('won');
              else act(() => engineApi.leads.update(l.id, { stage: next }), `${l.business} → ${STAGE_LABEL[next]}`);
            }}
            aria-label={`Stage for ${l.business}`}
          >
            {LEAD_STAGES.map((s) => (
              <option key={s} value={s}>
                {STAGE_LABEL[s]}
              </option>
            ))}
          </select>
          <div className="mt-1">
            <Pill tone={STAGE_TONE[l.stage]}>{STAGE_LABEL[l.stage]}</Pill>
          </div>
        </td>
        <td className="px-1.5 py-2 text-[#8B93A7] whitespace-nowrap">{ago(l.createdAt)}</td>
        <td className="px-1.5 py-2">
          <div className="flex flex-wrap justify-end gap-1">
            <button title="Draft new outreach" onClick={() => act(() => engineApi.leads.redraft(l.id), `Redrafting for ${l.business}`)} className="p-1 text-[#8B93A7] hover:text-[#f5c518]">
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
            <button title="Ask the Sales Director for a proposal (you approve it in Ops)" onClick={() => act(() => v1.startWorkflow(l.id), `Sales Director is drafting a proposal for ${l.business}`)} className="p-1 text-[#8B93A7] hover:text-[#b98cff]">
              <FileText className="w-3.5 h-3.5" />
            </button>
            <button title="Mark won and book the payment" onClick={() => setMode(mode === 'won' ? null : 'won')} className="p-1 text-[#8B93A7] hover:text-[#14F195]">
              <Trophy className="w-3.5 h-3.5" />
            </button>
            <button title="Delete lead" onClick={() => setMode(mode === 'delete' ? null : 'delete')} className="p-1 text-[#8B93A7] hover:text-[#FF4D6D]">
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </td>
      </tr>
      {mode && (
        <tr className="bg-[#020814]">
          <td colSpan={7} className="px-2 py-2">
            {mode === 'won' ? (
              <form
                className="flex flex-wrap items-end gap-2"
                onSubmit={(e) => {
                  e.preventDefault();
                  act(() => engineApi.leads.won(l.id, { amount: Number(amount), ref }), `${l.business} won · booked to the ledger`).then(() => setMode(null));
                }}
              >
                <Field label="Amount received (A$)">
                  <input className={`${inputBase} w-32`} inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} required />
                </Field>
                <Field label="Receipt reference" className="flex-1 min-w-[220px]" hint="Invoice number, bank reference, PayPal ID or tx signature. No reference, no income.">
                  <input className={inputCls} value={ref} onChange={(e) => setRef(e.target.value)} required minLength={3} />
                </Field>
                <Btn type="submit" tone="green">
                  <CheckCircle2 className="w-3 h-3" /> Book it
                </Btn>
                <Btn tone="ghost" onClick={() => setMode(null)}>
                  <X className="w-3 h-3" /> Cancel
                </Btn>
              </form>
            ) : (
              <div className="flex flex-wrap items-center gap-2 text-xs">
                <span className="text-[#ffb3c0]">Delete {l.business}? Its unsent drafts go too.</span>
                <Btn tone="red" onClick={() => act(() => engineApi.leads.remove(l.id), `Deleted ${l.business}`)}>
                  Delete
                </Btn>
                <Btn tone="ghost" onClick={() => setMode(null)}>
                  Keep
                </Btn>
              </div>
            )}
          </td>
        </tr>
      )}
    </>
  );
};

const DraftCard: React.FC<{ d: EngineDraft; onStatus: (s: EngineDraft['status'], msg: string) => void }> = ({ d, onStatus }) => {
  const [open, setOpen] = useState(false);
  const text = [d.subject ? `Subject: ${d.subject}` : '', d.message].filter(Boolean).join('\n\n');
  return (
    <div className="border border-[#131d33] rounded p-3 bg-[#020814]">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="min-w-0">
          <span className="text-slate-100 font-semibold text-sm">{d.business}</span>
          <span className="text-[10px] text-[#8B93A7] ml-2 uppercase tracking-wider">
            {d.channel}
            {d.offerName ? ` · ${d.offerName}` : ''} · {ago(d.createdAt)}
          </span>
        </div>
        <div className="flex flex-wrap gap-1.5">
          <CopyBtn text={text} />
          <Btn tone="green" onClick={() => onStatus('approved', `Approved: ${d.business}`)}>
            Approve
          </Btn>
          <Btn tone="ghost" onClick={() => onStatus('sent', `Marked sent: ${d.business}`)}>
            <Send className="w-3 h-3" /> Sent it
          </Btn>
          <Btn tone="ghost" onClick={() => onStatus('skipped', `Skipped: ${d.business}`)}>
            Skip
          </Btn>
        </div>
      </div>
      {d.subject && <div className="text-xs text-[#f5c518] mt-2">{d.subject}</div>}
      <div className={`text-xs text-slate-300 mt-1 whitespace-pre-line ${open ? '' : 'line-clamp-3'}`}>{d.message}</div>
      <button onClick={() => setOpen(!open)} className="mt-1 text-[10px] uppercase tracking-wider text-[#8B93A7] hover:text-white inline-flex items-center gap-1">
        {open ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />} {open ? 'Less' : 'Full draft'}
      </button>
    </div>
  );
};

const SOURCES = [
  { id: 'pancake', label: 'Pancake' },
  { id: 'csv', label: 'CSV / CRM export' },
  { id: 'list', label: 'Other list' },
];

const ImportPanel: React.FC<{ onDone: (r: LeadImportResult) => void; onError: (m: string) => void }> = ({ onDone, onError }) => {
  const [text, setText] = useState('');
  const [source, setSource] = useState('pancake');
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<LeadImportResult | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const readFile = (f: File | undefined) => {
    if (!f) return;
    if (f.size > 3 * 1024 * 1024) return onError('That file is over 3 MB. Split it and import in parts.');
    const r = new FileReader();
    r.onload = () => setText(String(r.result || ''));
    r.onerror = () => onError('Could not read that file');
    r.readAsText(f);
  };

  const go = async () => {
    setBusy(true);
    try {
      const r = await engineApi.leads.import({ text, source });
      setResult(r);
      onDone(r);
      if (r.added) setText('');
      engineChanged();
    } catch (e) {
      onError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Panel title="Import leads">
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_260px] gap-4">
        <div className="space-y-2 min-w-0">
          <textarea
            className={`${inputCls} h-40 font-mono-num text-xs`}
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={'Paste a Pancake export, a CSV, a table copied from a chat, or JSON.\n\nCompany,Name,Email,Website,Title,Notes\nAcme Plumbing,Jane Doe,jane@acme.com.au,acme.com.au,Owner,Hiring apprentices'}
            aria-label="Leads to import"
          />
          <div className="flex flex-wrap items-center gap-2">
            <input ref={fileRef} type="file" accept=".csv,.tsv,.txt,.json,text/csv,application/json" className="hidden" onChange={(e) => readFile(e.target.files?.[0])} />
            <Btn tone="ghost" onClick={() => fileRef.current?.click()}>
              <Upload className="w-3 h-3" /> Choose file
            </Btn>
            <select className={`${inputBase} w-auto py-1 text-xs`} value={source} onChange={(e) => setSource(e.target.value)} aria-label="Where these leads came from">
              {SOURCES.map((s) => (
                <option key={s.id} value={s.id}>
                  From: {s.label}
                </option>
              ))}
            </select>
            <Btn onClick={go} disabled={busy || !text.trim()}>
              {busy ? 'Importing…' : 'Import'}
            </Btn>
          </div>
        </div>
        <div className="text-[11px] text-[#8B93A7] leading-relaxed space-y-2">
          <p>Columns are matched by name: company, name or first/last, email, phone, website or domain, title, location, industry, notes or signal, score, id.</p>
          <p>Rows already in the pipeline (same email, website or source id) are skipped, so importing the same export twice adds nothing.</p>
          <p>Each new lead gets an outreach draft from the Closer that waits for your approval.</p>
        </div>
      </div>
      {result && (
        <div className="mt-3 space-y-2">
          <Notice tone={result.added ? 'green' : 'slate'}>
            {result.added} added · {result.duplicates} already in the pipeline · {result.skipped.length} skipped (of {result.total} rows, source "{result.source}")
          </Notice>
          {result.skipped.length > 0 && (
            <ul className="text-[11px] text-[#8B93A7] list-disc pl-5">
              {result.skipped.slice(0, 8).map((s) => (
                <li key={s.row}>
                  Row {s.row}: {s.reason}
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </Panel>
  );
};

const PancakePanel: React.FC = () => {
  const [info, setInfo] = useState<ConnectInfo | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [reveal, setReveal] = useState(false);
  const load = async () => {
    try {
      setInfo(await engineApi.connect());
      setErr(null);
    } catch (e) {
      setErr((e as Error).message);
    }
  };
  const url = info?.mcpConnectorUrl || '';
  const local = /\/\/(127\.0\.0\.1|localhost)[:/]/.test(url);
  const masked = url ? url.replace(/\/mcp\/(.{6}).*(.{4})$/, (_m, a, b) => `/mcp/${a}…${b}`) : '';
  return (
    <Panel title="Hook up Pancake">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 text-xs text-[#a7afc2] leading-relaxed">
        <ol className="list-decimal pl-5 space-y-2">
          <li>
            In claude.ai, open <span className="text-white">Settings → Connectors</span> and finish connecting <span className="text-white">Pancake</span> (sign in at app.pancake.ai when asked).
          </li>
          <li>
            Add YABBAI as a <span className="text-white">custom connector</span> with the URL on the right. It is the engine's MCP server with your token in the path, so keep it private.
          </li>
          <li>
            Ask Claude: <span className="text-[#f5c518]">"Pull my new Pancake leads into YABBAI."</span> Claude reads them from Pancake and calls <span className="font-mono-num">import_leads</span>. They appear here as source "pancake", duplicates skipped.
          </li>
          <li>Want it daily? Ask Claude to make that a scheduled task.</li>
        </ol>
        <div className="space-y-2 min-w-0">
          {!info ? (
            <Btn onClick={load}>Show my connector URL</Btn>
          ) : (
            <>
              <div className="font-mono-num text-[11px] bg-[#020814] border border-[#131d33] rounded px-2 py-1.5 break-all text-slate-200">{reveal ? url : masked}</div>
              <div className="flex flex-wrap gap-2">
                <CopyBtn text={url} label="Copy URL" />
                <Btn tone="ghost" onClick={() => setReveal(!reveal)}>
                  {reveal ? 'Hide' : 'Show'}
                </Btn>
              </div>
              {local && (
                <Notice tone="gold">
                  This URL points at your laptop (127.0.0.1), which claude.ai cannot reach. Use the engine on Render, or set YABBAI_PUBLIC_URL to your tunnel address and restart.
                </Notice>
              )}
            </>
          )}
          {err && <Notice tone="red">{err}</Notice>}
          <p className="text-[10px] text-[#5d6780]">No connector? Export the leads from Pancake (or copy its table) and use Import. Same result, same duplicate checks.</p>
        </div>
      </div>
    </Panel>
  );
};

const AddLead: React.FC<{ onAdded: (l: EngineLead) => void; onError: (m: string) => void }> = ({ onAdded, onError }) => {
  const empty = { business: '', name: '', contact: '', website: '', niche: '', location: '', notes: '' };
  const [f, setF] = useState(empty);
  const set = (k: keyof typeof empty) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setF({ ...f, [k]: e.target.value });
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const l = await engineApi.leads.add({ ...f, source: 'manual' });
      setF(empty);
      onAdded(l);
      engineChanged();
    } catch (err) {
      onError((err as Error).message);
    }
  };
  return (
    <Panel title="Add a lead">
      <form onSubmit={submit} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        <Field label="Business *">
          <input className={inputCls} value={f.business} onChange={set('business')} required />
        </Field>
        <Field label="Contact person">
          <input className={inputCls} value={f.name} onChange={set('name')} />
        </Field>
        <Field label="Email / phone / handle">
          <input className={inputCls} value={f.contact} onChange={set('contact')} />
        </Field>
        <Field label="Website">
          <input className={inputCls} value={f.website} onChange={set('website')} />
        </Field>
        <Field label="Niche">
          <input className={inputCls} value={f.niche} onChange={set('niche')} />
        </Field>
        <Field label="Location">
          <input className={inputCls} value={f.location} onChange={set('location')} />
        </Field>
        <Field label="Notes for the outreach" className="sm:col-span-2 lg:col-span-3">
          <textarea className={`${inputCls} h-16`} value={f.notes} onChange={set('notes')} />
        </Field>
        <div className="sm:col-span-2 lg:col-span-3">
          <Btn type="submit">
            <Plus className="w-3 h-3" /> Add lead
          </Btn>
        </div>
      </form>
    </Panel>
  );
};
