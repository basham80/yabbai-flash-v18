import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Pause, Play, RefreshCw, RotateCcw, X } from 'lucide-react';
import { EngineGate } from '../EngineGate';
import { engineChanged, useEngine } from '../../context/EngineContext';
import { isCancelled, useVault } from '../../context/VaultContext';
import { v1, type DeadLetter, type ExecMetric, type ExecOverview, type OpsAgent, type OpsEvent, type OpsTask, type Proposal, type WorkflowRun } from '../../services/engineApi';
import { ago, Btn, Empty, Notice, Panel, Pill, useFlash, when } from '../ui';

/**
 * OPS: the v18 operating layer. The executive view (every figure with its source and status),
 * what is waiting for a person, the workflow runs, the agents' tasks and runs, the agent
 * registry, and the event bus with its dead letters.
 */
export const OpsSurface: React.FC = () => <EngineGate>{() => <Ops />}</EngineGate>;

const STATUS_TONE: Record<string, 'green' | 'orange' | 'purple' | 'slate' | 'red' | 'gold'> = {
  live: 'green',
  stale: 'orange',
  estimated: 'purple',
  unavailable: 'slate',
  enabled: 'green',
  paused: 'orange',
  registered: 'slate',
  not_connected: 'slate',
  completed: 'green',
  approved: 'green',
  running: 'gold',
  assigned: 'gold',
  waiting_approval: 'purple',
  awaiting_approval: 'purple',
  needs_attention: 'red',
  escalated: 'red',
  failed: 'red',
  rejected: 'slate',
  cancelled: 'slate',
  expired: 'slate',
  done: 'green',
  waiting: 'purple',
  dead: 'red',
  retrying: 'orange',
  pending: 'slate',
};
const aud = (minor: string) => `A$${(Number(minor) / 100).toLocaleString('en-AU', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const label = (s: string) => s.replace(/_/g, ' ');

const Ops: React.FC = () => {
  const { snap } = useEngine();
  const { guard } = useVault();
  const [ov, setOv] = useState<ExecOverview | null>(null);
  const [props, setProps] = useState<Proposal[]>([]);
  const [runs, setRuns] = useState<WorkflowRun[]>([]);
  const [tasks, setTasks] = useState<OpsTask[]>([]);
  const [agents, setAgents] = useState<OpsAgent[]>([]);
  const [events, setEvents] = useState<OpsEvent[]>([]);
  const [health, setHealth] = useState<{ events: number; backlog: number; retrying: number; deadLetters: number; tickAgeSec: number | null } | null>(null);
  const [dead, setDead] = useState<DeadLetter[]>([]);
  const [note, setNote] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [flash, show] = useFlash();

  const load = useCallback(async () => {
    const r = await Promise.allSettled([v1.overview(), v1.proposals(), v1.runs(), v1.tasks(), v1.agents(), v1.events(), v1.deadLetters()]);
    if (r[0].status === 'fulfilled') setOv(r[0].value);
    if (r[1].status === 'fulfilled') setProps(r[1].value);
    if (r[2].status === 'fulfilled') setRuns(r[2].value);
    if (r[3].status === 'fulfilled') setTasks(r[3].value);
    if (r[4].status === 'fulfilled') setAgents(r[4].value);
    if (r[5].status === 'fulfilled') {
      setEvents(r[5].value.data);
      setHealth(r[5].value.meta.health);
    }
    if (r[6].status === 'fulfilled') setDead(r[6].value);
    const failed = r.find((x) => x.status === 'rejected') as PromiseRejectedResult | undefined;
    setErr(failed ? (failed.reason as Error).message : null);
  }, []);
  useEffect(() => {
    load();
    const id = setInterval(load, 15000);
    window.addEventListener('yabbai:changed', load);
    return () => {
      clearInterval(id);
      window.removeEventListener('yabbai:changed', load);
    };
  }, [load]);

  const act = async (key: string, fn: () => Promise<unknown>, ok: string) => {
    setBusy(key);
    try {
      await fn();
      show(ok);
      engineChanged();
      await load();
    } catch (e) {
      if (!isCancelled(e)) show((e as Error).message, 'red');
    } finally {
      setBusy(null);
    }
  };
  const leadName = useMemo(() => {
    const m = new Map<string, string>();
    for (const l of snap?.leads || []) m.set(l.id, l.business);
    return (id: string) => m.get(id) || id;
  }, [snap]);
  const waiting = props.filter((p) => p.status === 'awaiting_approval');
  const attention = runs.filter((r) => r.status === 'needs_attention');

  return (
    <div className="space-y-4">
      {flash}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-bold text-white tracking-wide">Operations</h1>
          <p className="text-[11px] text-[#8B93A7]">Agents draft and analyse; a person approves. Every step is an event you can trace.</p>
        </div>
        <Btn tone="ghost" onClick={load} title="Read again">
          <RefreshCw className="w-3 h-3" /> Refresh
        </Btn>
      </div>
      {err && <Notice tone="red">{err}</Notice>}

      <Panel title="Executive view" right={ov ? <span className="text-[10px] text-[#5d6780]">as of {when(ov.at)}</span> : null}>
        {!ov ? (
          <div className="text-xs text-[#8B93A7]">Reading…</div>
        ) : (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
              {ov.metrics.map((m) => (
                <MetricCard key={m.id} m={m} />
              ))}
            </div>
            <div className="flex flex-wrap gap-3 mt-3 text-[10px] text-[#5d6780]">
              {Object.entries(ov.legend).map(([k, v]) => (
                <span key={k}>
                  <Pill tone={STATUS_TONE[k]}>{k}</Pill> {v}
                </span>
              ))}
            </div>
          </>
        )}
      </Panel>

      <Panel title={`Waiting on you · ${waiting.length} proposal${waiting.length === 1 ? '' : 's'}`} right={<span className="text-[10px] text-[#8B93A7]">Approving asks for the vault</span>}>
        {waiting.length === 0 ? (
          <Empty title="No proposals to review">Add a lead through the API, or start the lead-to-proposal workflow from a lead below. The Sales Director drafts; you decide.</Empty>
        ) : (
          <ul className="space-y-3">
            {waiting.map((p) => (
              <li key={p.id} className="border border-[#131d33] rounded-lg p-3 bg-[#020814]">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="min-w-0">
                    <div className="text-sm font-semibold text-white">{leadName(p.leadId)}</div>
                    <div className="text-[11px] text-[#8B93A7]">
                      {p.title} · fit {p.fit} · drafted {ago(p.createdAt)} by {p.draftedBy.replace('agent:', '')}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-mono-num text-lg font-bold text-[#f5c518]">{aud(p.totalMinor)}</div>
                    <div className="text-[10px] text-[#5d6780]">{p.taxNote}</div>
                  </div>
                </div>
                <p className="text-xs text-[#a7afc2] mt-2 leading-relaxed">{p.summary}</p>
                <div className="overflow-x-auto mt-2">
                  <table className="w-full text-xs">
                    <tbody className="divide-y divide-[#131d33]">
                      {p.lines.map((l, i) => (
                        <tr key={i}>
                          <td className="py-1 pr-2 text-white">{l.desc}</td>
                          <td className="py-1 pr-2 text-[#8B93A7] font-mono-num whitespace-nowrap">
                            {l.qty} × {aud(l.unitMinor)}
                          </td>
                          <td className="py-1 text-right font-mono-num text-white whitespace-nowrap">{aud(l.lineMinor)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {p.findings.length > 0 && (
                  <ul className="mt-2 text-[11px] text-[#8B93A7] list-disc pl-4 space-y-0.5">
                    {p.findings.map((f, i) => (
                      <li key={i}>{f}</li>
                    ))}
                  </ul>
                )}
                <div className="flex flex-wrap items-center gap-2 mt-3">
                  <input
                    aria-label="Note"
                    placeholder="Note for the record (optional)"
                    value={note[p.id] || ''}
                    onChange={(e) => setNote({ ...note, [p.id]: e.target.value })}
                    className="flex-1 min-w-[10rem] bg-[#0a1224] border border-[#131d33] rounded px-2 py-1 text-xs"
                  />
                  <Btn tone="green" disabled={!!busy || !p.approvalId} onClick={() => act(`${p.id}:a`, () => guard((g) => v1.approve(p.id, note[p.id] || '', g)), 'Proposal approved')}>
                    Approve
                  </Btn>
                  <Btn tone="red" disabled={!!busy || !p.approvalId} onClick={() => act(`${p.id}:r`, () => guard((g) => v1.reject(p.id, note[p.id] || '', g)), 'Proposal rejected')}>
                    Reject
                  </Btn>
                  {!p.approvalId && <span className="text-[10px] text-[#8B93A7]">Opening the approval request…</span>}
                </div>
              </li>
            ))}
          </ul>
        )}
      </Panel>

      <div className="grid lg:grid-cols-2 gap-4">
        <Panel title={`Workflow runs · ${runs.length}`} right={attention.length ? <Pill tone="red">{attention.length} need a person</Pill> : null}>
          {runs.length === 0 ? (
            <Empty title="No runs yet">Each lead that enters lead-to-proposal gets one run: qualify, approve, record.</Empty>
          ) : (
            <ul className="divide-y divide-[#131d33]">
              {runs.slice(0, 20).map((r) => (
                <li key={r.id} className="py-2">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="text-xs text-white font-semibold">{leadName(r.subject.id)}</span>
                    <Pill tone={STATUS_TONE[r.status] || 'slate'}>{label(r.status)}</Pill>
                  </div>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {r.steps.map((s) => (
                      <Pill key={s.id} tone={STATUS_TONE[s.status] || 'slate'} title={s.reason || s.by || ''}>
                        {s.id}: {label(s.status)}
                      </Pill>
                    ))}
                  </div>
                  <div className="text-[10px] text-[#5d6780] mt-1">
                    started {ago(r.createdAt)} via {r.source} · trace {r.correlationId}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Panel>

        <Panel title={`Tasks · ${tasks.length}`}>
          {tasks.length === 0 ? (
            <Empty title="No tasks yet">Tasks are created by workflows and assigned to one agent each.</Empty>
          ) : (
            <ul className="divide-y divide-[#131d33]">
              {tasks.slice(0, 20).map((t) => (
                <li key={t.id} className="py-2">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="text-xs text-white min-w-0 truncate">{t.objective}</span>
                    <Pill tone={STATUS_TONE[t.status] || 'slate'}>{label(t.status)}</Pill>
                  </div>
                  <div className="text-[10px] text-[#5d6780] mt-0.5">
                    {t.assigned_agent} · {t.attempts} attempt{t.attempts === 1 ? '' : 's'} · approval {label(t.approval.status)} · due {when(t.deadline)}
                  </div>
                  {t.escalation && <div className="text-[11px] text-[#ffb3c0] mt-1">{t.escalation.reason}</div>}
                  {['failed', 'escalated', 'assigned'].includes(t.status) && (
                    <div className="flex gap-2 mt-1.5">
                      {['failed', 'escalated'].includes(t.status) && (
                        <Btn tone="gold" disabled={!!busy} onClick={() => act(`${t.id}:retry`, () => guard((g) => v1.retryTask(t.id, g)), 'Sent back to the agent')}>
                          <RotateCcw className="w-3 h-3" /> Retry
                        </Btn>
                      )}
                      <Btn tone="ghost" disabled={!!busy} onClick={() => act(`${t.id}:cancel`, () => guard((g) => v1.cancelTask(t.id, 'Cancelled from the deck', g)), 'Task cancelled')}>
                        <X className="w-3 h-3" /> Cancel
                      </Btn>
                    </div>
                  )}
                </li>
              ))}
            </ul>
          )}
        </Panel>
      </div>

      <Panel
        title={`Agents · ${agents.filter((a) => a.status === 'enabled').length} of ${agents.length} enabled`}
        right={<span className="text-[10px] text-[#8B93A7]">Read-only by default · changes need the director and a fresh code</span>}
      >
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="text-[9px] uppercase tracking-wider text-[#8B93A7] text-left">
                <th className="py-1.5 pr-2 font-medium">Agent</th>
                <th className="py-1.5 pr-2 font-medium">Status</th>
                <th className="py-1.5 pr-2 font-medium">Can</th>
                <th className="py-1.5 pr-2 font-medium">Work</th>
                <th className="py-1.5 pr-2 font-medium">Runs</th>
                <th className="py-1.5 font-medium" />
              </tr>
            </thead>
            <tbody className="divide-y divide-[#131d33]">
              {agents.map((a) => (
                <tr key={a.id} className="align-top">
                  <td className="py-2 pr-2 min-w-[14rem]">
                    <div className="text-white font-semibold">{a.name}</div>
                    <div className="text-[10px] text-[#5d6780] leading-snug">{a.purpose}</div>
                    {a.notes && <div className="text-[10px] text-[#8B93A7] leading-snug">{a.notes}</div>}
                  </td>
                  <td className="py-2 pr-2">
                    <Pill tone={STATUS_TONE[a.status] || 'slate'}>{label(a.status)}</Pill>
                  </td>
                  <td className="py-2 pr-2 min-w-[10rem]">
                    <div className="flex flex-wrap gap-1">
                      {a.permissions.length ? (
                        a.permissions.map((p) => (
                          <Pill key={p} tone={p.startsWith('propose') ? 'gold' : 'slate'}>
                            {p}
                          </Pill>
                        ))
                      ) : (
                        <span className="text-[#5d6780]">nothing yet</span>
                      )}
                    </div>
                  </td>
                  <td className="py-2 pr-2 text-[#a7afc2] whitespace-nowrap">
                    {a.work.open} open · {a.work.completed} done
                    {a.work.escalated ? <span className="text-[#FF4D6D]"> · {a.work.escalated} escalated</span> : null}
                  </td>
                  <td className="py-2 pr-2 text-[#a7afc2] whitespace-nowrap">
                    {a.runs.total} ({a.runs.failed} failed)
                    <div className="text-[10px] text-[#5d6780]">last {ago(a.runs.lastAt)}</div>
                  </td>
                  <td className="py-2 text-right">
                    {a.status === 'enabled' && (
                      <Btn tone="ghost" disabled={!!busy} onClick={() => act(`${a.id}:pause`, () => guard((g) => v1.setAgent(a.id, { status: 'paused' }, g)), `${a.name} paused`)}>
                        <Pause className="w-3 h-3" /> Pause
                      </Btn>
                    )}
                    {a.status === 'paused' && (
                      <Btn tone="green" disabled={!!busy} onClick={() => act(`${a.id}:on`, () => guard((g) => v1.setAgent(a.id, { status: 'enabled' }, g)), `${a.name} enabled`)}>
                        <Play className="w-3 h-3" /> Enable
                      </Btn>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>

      <div className="grid lg:grid-cols-2 gap-4">
        <Panel
          title="Event bus"
          right={
            health ? (
              <Pill tone={health.deadLetters ? 'red' : health.backlog || health.retrying ? 'orange' : 'green'}>
                {health.deadLetters
                  ? `${health.deadLetters} dead letter${health.deadLetters === 1 ? '' : 's'}`
                  : health.backlog || health.retrying
                    ? `${health.backlog + health.retrying} in flight`
                    : 'clear'}
              </Pill>
            ) : null
          }
        >
          {events.length === 0 ? (
            <Empty title="No events yet">Every lead, task, run, proposal, approval and journal posting is recorded here.</Empty>
          ) : (
            <ul className="space-y-1 max-h-80 overflow-y-auto pr-1">
              {events.map((e) => {
                const states = Object.values(e.delivery || {}).map((d) => d.status);
                return (
                  <li key={e.event_id} className="text-[11px] flex flex-wrap items-center gap-x-2 gap-y-0.5">
                    <span className="text-[#5d6780] font-mono-num whitespace-nowrap">{when(e.occurred_at)}</span>
                    <span className="text-white">{e.event_type}</span>
                    <span className="text-[#8B93A7]">{e.actor_id}</span>
                    {states.includes('dead') && <Pill tone="red">dead</Pill>}
                    {states.includes('retrying') && <Pill tone="orange">retrying</Pill>}
                    {e.sensitivity !== 'internal' && <Pill tone="purple">{e.sensitivity}</Pill>}
                  </li>
                );
              })}
            </ul>
          )}
        </Panel>

        <Panel title={`Dead letters · ${dead.length}`}>
          {dead.length === 0 ? (
            <Empty title="Nothing stuck">A delivery that fails five times stops here and escalates. Fix the cause, then replay it.</Empty>
          ) : (
            <ul className="divide-y divide-[#131d33]">
              {dead.map((d) => (
                <li key={d.id} className="py-2">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="text-xs text-white">
                      {d.eventType} → {d.consumer}
                    </span>
                    <Btn tone="gold" disabled={!!busy} onClick={() => act(`${d.id}:replay`, () => guard((g) => v1.replay(d.id, g)), 'Replayed')}>
                      <RotateCcw className="w-3 h-3" /> Replay
                    </Btn>
                  </div>
                  <div className="text-[11px] text-[#ffb3c0] mt-0.5">{d.error}</div>
                  <div className="text-[10px] text-[#5d6780]">
                    {d.attempts} attempt{d.attempts === 1 ? '' : 's'} · {ago(d.at)}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Panel>
      </div>
    </div>
  );
};

const MetricCard: React.FC<{ m: ExecMetric }> = ({ m }) => (
  <div className="border border-[#131d33] rounded-lg p-3 bg-[#020814] min-w-0">
    <div className="flex items-start justify-between gap-2">
      <span className="text-[10px] uppercase tracking-wider text-[#8B93A7] leading-snug">{m.label}</span>
      <Pill tone={STATUS_TONE[m.status]}>{m.status}</Pill>
    </div>
    <div className={`font-mono-num text-lg font-bold mt-1 truncate ${m.status === 'unavailable' ? 'text-[#4a5468]' : 'text-white'}`}>{m.display}</div>
    <div className="text-[10px] text-[#5d6780] mt-1 leading-snug">
      <span className="text-[#8B93A7]">{m.source}</span>
      {m.at ? ` · ${ago(m.at)}` : ''}
      {m.quality && m.quality !== 'n/a' ? ` · ${m.quality}` : ''}
    </div>
    {(m.basis || m.note) && <div className="text-[10px] text-[#5d6780] mt-1 leading-snug">{m.basis || m.note}</div>}
  </div>
);
