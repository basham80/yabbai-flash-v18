import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { AlertTriangle, BookOpen, RefreshCw, Trash2, X } from 'lucide-react';
import { EngineGate } from '../EngineGate';
import { engineChanged } from '../../context/EngineContext';
import { engineApi, usd, type DeskAccount, type DeskQuote, type DeskSummary, type DeskTrade } from '../../services/engineApi';
import { ago, Btn, Empty, Field, fmt, inputBase, inputCls, Notice, Panel, Pill, Spark, Stat, useFlash, when } from '../ui';

type Inst = 'WTI' | 'BRENT';
type Side = 'long' | 'short';
interface Prefill {
  instrument: Inst;
  side: Side;
  lots: string;
  stop: string;
}

/**
 * OIL DESK: live WTI and Brent, a calculator, and a journal of trades you placed at
 * your broker. No paper book: every row needs the broker's ticket, and the desk never
 * places or closes an order itself.
 */
export const OilDeskSurface: React.FC = () => <EngineGate>{() => <Desk />}</EngineGate>;

const Desk: React.FC = () => {
  const [desk, setDesk] = useState<DeskSummary | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [prefill, setPrefill] = useState<Prefill | null>(null);
  const [flash, show] = useFlash();

  const load = useCallback(async (force = false) => {
    setBusy(true);
    try {
      setDesk(await engineApi.desk.get(force));
      setErr(null);
    } catch (e) {
      setErr((e as Error).message);
    } finally {
      setBusy(false);
    }
  }, []);

  useEffect(() => {
    load();
    const id = setInterval(() => load(), 30000);
    return () => clearInterval(id);
  }, [load]);

  const write = async (fn: () => Promise<unknown>, ok: string) => {
    try {
      await fn();
      show(ok);
      await load();
      engineChanged();
      return true;
    } catch (e) {
      show((e as Error).message, 'red');
      return false;
    }
  };

  if (!desk) {
    return err ? <Notice tone="red">{err}</Notice> : <div className="py-16 text-center text-xs uppercase tracking-wider text-[#8B93A7]">Fetching WTI and Brent…</div>;
  }

  const price = (id: Inst) => {
    const q = desk.instruments.find((x) => x.id === id);
    return q?.ok ? q.price : q?.last?.price;
  };

  return (
    <div className="space-y-4">
      {flash}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-bold text-white tracking-wide">Oil desk</h1>
          <p className="text-xs text-[#8B93A7]">Live prices, position sizing and a journal of trades placed at your broker. Prices in {desk.unit}.</p>
        </div>
        <Btn tone="ghost" onClick={() => load(true)} disabled={busy}>
          <RefreshCw className={`w-3 h-3 ${busy ? 'animate-spin' : ''}`} /> Refresh prices
        </Btn>
      </div>

      {!desk.broker.connected && <Notice tone="slate">{desk.broker.note}</Notice>}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {desk.instruments.map((q) => (
          <QuoteCard key={q.id} q={q} />
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Calculator account={desk.account} price={price} onUse={(p) => setPrefill(p)} />
        <Guardian desk={desk} onSave={(a) => write(() => engineApi.desk.account(a), 'Account limits saved')} />
      </div>

      <LogTrade
        key={prefill ? JSON.stringify(prefill) : 'blank'}
        prefill={prefill}
        account={desk.account}
        onLog={(body) => write(() => engineApi.desk.addTrade(body), 'Trade journaled')}
      />

      <Panel title={`Open trades · ${desk.open.length}`}>
        {desk.open.length === 0 ? (
          <Empty title="No open trades in the journal">After you place a trade at your broker, log it above with the fill price and ticket number.</Empty>
        ) : (
          <div className="overflow-x-auto -mx-1">
            <table className="w-full text-xs min-w-[860px]">
              <thead>
                <tr className="text-[9px] uppercase tracking-wider text-[#5d6780] text-left">
                  <th className="px-1.5 py-1.5 font-medium">Trade</th>
                  <th className="px-1.5 py-1.5 font-medium text-right">Entry</th>
                  <th className="px-1.5 py-1.5 font-medium text-right">Stop / target</th>
                  <th className="px-1.5 py-1.5 font-medium text-right">Mark</th>
                  <th className="px-1.5 py-1.5 font-medium text-right">Open P&L</th>
                  <th className="px-1.5 py-1.5 font-medium text-right">Risk to stop</th>
                  <th className="px-1.5 py-1.5 font-medium">Ticket</th>
                  <th className="px-1.5 py-1.5" />
                </tr>
              </thead>
              <tbody>
                {desk.open.map((t) => (
                  <OpenRow key={t.id} t={t} write={write} />
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Panel>

      <Panel title="Closed trades">
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 mb-4">
          <Stat label="Realized" value={usd(desk.stats.realizedUsd, true)} tone={desk.stats.realizedUsd >= 0 ? 'green' : 'red'} />
          <Stat label="Today" value={usd(desk.stats.realizedTodayUsd, true)} tone={desk.stats.realizedTodayUsd >= 0 ? 'green' : 'red'} />
          <Stat label="Win rate" value={desk.stats.winRatePct === null ? '—' : `${fmt(desk.stats.winRatePct, 1)}%`} sub={`${desk.stats.wins} won · ${desk.stats.losses} lost`} />
          <Stat label="Average win" value={usd(desk.stats.avgWinUsd)} />
          <Stat label="Average loss" value={usd(desk.stats.avgLossUsd)} />
          <Stat label="Profit factor" value={desk.stats.profitFactor === null ? '—' : fmt(desk.stats.profitFactor)} />
        </div>
        {desk.closed.length === 0 ? (
          <Empty title="No closed trades yet" />
        ) : (
          <div className="overflow-x-auto -mx-1">
            <table className="w-full text-xs min-w-[680px]">
              <thead>
                <tr className="text-[9px] uppercase tracking-wider text-[#5d6780] text-left">
                  <th className="px-1.5 py-1.5 font-medium">Trade</th>
                  <th className="px-1.5 py-1.5 font-medium text-right">Entry → exit</th>
                  <th className="px-1.5 py-1.5 font-medium text-right">P&L</th>
                  <th className="px-1.5 py-1.5 font-medium">Ticket</th>
                  <th className="px-1.5 py-1.5 font-medium">Closed</th>
                </tr>
              </thead>
              <tbody>
                {desk.closed.map((t) => (
                  <tr key={t.id} className="border-t border-[#131d33]">
                    <td className="px-1.5 py-2">
                      <TradeLabel t={t} />
                    </td>
                    <td className="px-1.5 py-2 text-right font-mono-num">
                      {fmt(t.entry, 3)} → {fmt(t.exit, 3)}
                    </td>
                    <td className={`px-1.5 py-2 text-right font-mono-num font-semibold ${(t.pnlUsd || 0) >= 0 ? 'text-[#14F195]' : 'text-[#FF4D6D]'}`}>
                      {usd(t.pnlUsd, true)}
                      <div className="text-[9px] text-[#5d6780] font-normal">{t.pnlSource === 'broker' ? 'broker figure' : `computed${t.feesUsd ? `, ${usd(t.feesUsd)} fees` : ''}`}</div>
                    </td>
                    <td className="px-1.5 py-2 text-[#8B93A7]">
                      {t.ticket}
                      <div className="text-[10px]">{t.broker}</div>
                    </td>
                    <td className="px-1.5 py-2 text-[#8B93A7] whitespace-nowrap">{when(t.closedAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Panel>
    </div>
  );
};

const TradeLabel: React.FC<{ t: DeskTrade }> = ({ t }) => (
  <div>
    <span className="font-semibold text-slate-100">{t.instrument}</span>{' '}
    <Pill tone={t.side === 'long' ? 'green' : 'red'}>{t.side}</Pill>
    <div className="text-[10px] text-[#8B93A7]">
      {fmt(t.lots, 2)} lot · {fmt(t.bbl, 0)} bbl
    </div>
  </div>
);

const QuoteCard: React.FC<{ q: DeskQuote }> = ({ q }) => {
  const up = (q.changePct || 0) >= 0;
  return (
    <Panel>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="text-[10px] uppercase tracking-wider text-[#8B93A7]">{q.name}</div>
          <div className="text-[10px] text-[#5d6780]">{q.contract}</div>
        </div>
        {q.ok ? (
          <Pill tone="green">live</Pill>
        ) : (
          <Pill tone="red" title={q.error}>
            feed down
          </Pill>
        )}
      </div>
      {q.ok ? (
        <>
          <div className="flex items-baseline gap-3 mt-2">
            <span className="font-mono-num text-3xl font-bold text-white">${fmt(q.price, 2)}</span>
            {q.change !== null && q.change !== undefined && (
              <span className={`font-mono-num text-sm ${up ? 'text-[#14F195]' : 'text-[#FF4D6D]'}`}>
                {up ? '+' : ''}
                {fmt(q.change, 2)} ({up ? '+' : ''}
                {fmt(q.changePct, 2)}%)
              </span>
            )}
          </div>
          <div className="mt-2">
            <Spark points={q.spark || []} up={up} label={`${q.name} intraday`} />
          </div>
          <div className="flex flex-wrap justify-between gap-2 text-[10px] text-[#5d6780] mt-1">
            <span>
              Day {q.dayLow ? fmt(q.dayLow) : '—'} – {q.dayHigh ? fmt(q.dayHigh) : '—'}
              {q.prevClose ? ` · prev close ${fmt(q.prevClose)}` : ''}
            </span>
            <span>
              {q.source} · {q.at ? when(q.at) : q.asOf}
            </span>
          </div>
        </>
      ) : (
        <div className="mt-2 space-y-1">
          <div className="font-mono-num text-2xl font-bold text-[#8B93A7]">{q.last ? `$${fmt(q.last.price)}` : '—'}</div>
          <div className="text-[10px] text-[#8B93A7]">{q.last ? `Last known price, ${q.last.source}, ${when(q.last.at)}. Not live.` : 'No price yet.'}</div>
          <div className="text-[10px] text-[#FF4D6D] break-words">{q.error}</div>
        </div>
      )}
    </Panel>
  );
};

const Calculator: React.FC<{ account: DeskAccount; price: (id: Inst) => number | undefined; onUse: (p: Prefill) => void }> = ({ account, price, onUse }) => {
  const [instrument, setInstrument] = useState<Inst>('WTI');
  const [side, setSide] = useState<Side>('long');
  const [entry, setEntry] = useState('');
  const [stop, setStop] = useState('');
  const [riskPct, setRiskPct] = useState(String(account.riskPct || 1));
  const [riskUsdIn, setRiskUsdIn] = useState('');

  const live = price(instrument);
  const e = Number(entry || live || 0);
  const s = stop.trim() ? Number(stop) : NaN;
  const riskUsd = account.sizeUsd > 0 ? (account.sizeUsd * Number(riskPct || 0)) / 100 : Number(riskUsdIn || 0);
  const dist = Math.abs(e - s);
  const wrongSide = s > 0 && e > 0 && (side === 'long' ? s >= e : s <= e);
  const perLot = dist * account.bblPerLot;
  const lots = s > 0 && e > 0 && perLot > 0 && riskUsd > 0 && !wrongSide ? Math.floor((riskUsd / perLot) * 100) / 100 : 0;
  const actualRisk = lots * perLot;

  return (
    <Panel title="Position size">
      <div className="grid grid-cols-2 gap-3">
        <Field label="Instrument">
          <select className={inputCls} value={instrument} onChange={(ev) => setInstrument(ev.target.value as Inst)}>
            <option value="WTI">WTI</option>
            <option value="BRENT">Brent</option>
          </select>
        </Field>
        <Field label="Side">
          <select className={inputCls} value={side} onChange={(ev) => setSide(ev.target.value as Side)}>
            <option value="long">Long (buy)</option>
            <option value="short">Short (sell)</option>
          </select>
        </Field>
        <Field label="Entry" hint={live ? `blank = live ${fmt(live)}` : 'no live price'}>
          <input className={inputCls} inputMode="decimal" value={entry} onChange={(ev) => setEntry(ev.target.value)} placeholder={live ? fmt(live) : ''} />
        </Field>
        <Field label="Stop">
          <input className={inputCls} inputMode="decimal" value={stop} onChange={(ev) => setStop(ev.target.value)} />
        </Field>
        {account.sizeUsd > 0 ? (
          <Field label="Risk % of account" hint={`account ${usd(account.sizeUsd)}`}>
            <input className={inputCls} inputMode="decimal" value={riskPct} onChange={(ev) => setRiskPct(ev.target.value)} />
          </Field>
        ) : (
          <Field label="Risk in US$" hint="or set the account size to use %">
            <input className={inputCls} inputMode="decimal" value={riskUsdIn} onChange={(ev) => setRiskUsdIn(ev.target.value)} />
          </Field>
        )}
        <Field label="Contract" hint="check your broker's contract spec">
          <div className="text-xs text-slate-300 py-1.5">{fmt(account.bblPerLot, 0)} bbl per lot</div>
        </Field>
      </div>
      <div className="mt-3 grid grid-cols-3 gap-3 bg-[#020814] border border-[#131d33] rounded p-3">
        <Stat label="Lots" value={lots ? fmt(lots) : '—'} tone="gold" />
        <Stat label="Risk if stopped" value={lots ? usd(actualRisk) : '—'} sub={riskUsd ? `budget ${usd(riskUsd)}` : undefined} />
        <Stat label="Notional" value={lots ? usd(lots * account.bblPerLot * e) : '—'} />
      </div>
      {wrongSide && <p className="text-[11px] text-[#FF4D6D] mt-2">For a {side}, the stop sits {side === 'long' ? 'below' : 'above'} the entry.</p>}
      <div className="mt-3">
        <Btn tone="ghost" disabled={!lots} onClick={() => onUse({ instrument, side, lots: String(lots), stop })}>
          <BookOpen className="w-3 h-3" /> Use in the journal form
        </Btn>
      </div>
    </Panel>
  );
};

const Guardian: React.FC<{ desk: DeskSummary; onSave: (a: Partial<DeskAccount>) => Promise<boolean> }> = ({ desk, onSave }) => {
  const a = desk.account;
  const [f, setF] = useState({
    name: a.name,
    sizeUsd: String(a.sizeUsd || ''),
    dailyLossPct: String(a.dailyLossPct),
    maxDrawdownPct: String(a.maxDrawdownPct),
    riskPct: String(a.riskPct),
    bblPerLot: String(a.bblPerLot),
    resetHourUtc: String(a.resetHourUtc ?? 0),
  });
  const [editing, setEditing] = useState(!a.sizeUsd);
  const g = desk.guard;
  const used = g ? Math.max(0, g.dailyLimitUsd - g.headroomUsd) : 0;
  const usedPct = g && g.dailyLimitUsd ? Math.min(100, (used / g.dailyLimitUsd) * 100) : 0;
  const ddPct = g && g.ddUsedUsd !== null && g.ddLimitUsd ? Math.min(100, (g.ddUsedUsd / g.ddLimitUsd) * 100) : 0;
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    const ok = await onSave({
      name: f.name,
      sizeUsd: Number(f.sizeUsd) || 0,
      dailyLossPct: Number(f.dailyLossPct),
      maxDrawdownPct: Number(f.maxDrawdownPct),
      riskPct: Number(f.riskPct),
      bblPerLot: Number(f.bblPerLot),
      resetHourUtc: Number(f.resetHourUtc),
    });
    if (ok) setEditing(false);
  };

  return (
    <Panel
      title={`Guardian${a.name ? ` · ${a.name}` : ''}`}
      right={
        !editing && (
          <Btn tone="ghost" onClick={() => setEditing(true)}>
            Edit limits
          </Btn>
        )
      }
    >
      {editing ? (
        <form onSubmit={save} className="grid grid-cols-2 gap-3">
          <Field label="Account (broker / prop firm)">
            <input className={inputCls} value={f.name} onChange={set('name')} placeholder="SabioTrade" />
          </Field>
          <Field label="Account size (US$)">
            <input className={inputCls} inputMode="decimal" value={f.sizeUsd} onChange={set('sizeUsd')} required />
          </Field>
          <Field label="Daily loss limit %">
            <input className={inputCls} inputMode="decimal" value={f.dailyLossPct} onChange={set('dailyLossPct')} />
          </Field>
          <Field label="Max drawdown %">
            <input className={inputCls} inputMode="decimal" value={f.maxDrawdownPct} onChange={set('maxDrawdownPct')} />
          </Field>
          <Field label="Risk per trade %">
            <input className={inputCls} inputMode="decimal" value={f.riskPct} onChange={set('riskPct')} />
          </Field>
          <Field label="Barrels per lot">
            <input className={inputCls} inputMode="decimal" value={f.bblPerLot} onChange={set('bblPerLot')} />
          </Field>
          <Field label="Day resets at (UTC hour)" hint="your firm's daily reset time" className="col-span-2 sm:col-span-1">
            <input className={inputCls} inputMode="numeric" value={f.resetHourUtc} onChange={set('resetHourUtc')} />
          </Field>
          <div className="col-span-2 flex gap-2">
            <Btn type="submit">Save limits</Btn>
            {a.sizeUsd > 0 && (
              <Btn tone="ghost" onClick={() => setEditing(false)}>
                Cancel
              </Btn>
            )}
          </div>
          <p className="col-span-2 text-[10px] text-[#5d6780]">Use the rules of your real account. The guardian measures your journal against them; it cannot stop a trade at the broker.</p>
        </form>
      ) : !g ? (
        <Empty title="Set the account size to see your limits" />
      ) : (
        <div className="space-y-4">
          {g.dailyBreached && <Notice tone="red">Daily loss limit reached on the journal. Stop trading for today.</Notice>}
          {!g.dailyBreached && g.stopsWouldBreach && <Notice tone="gold">If every open stop is hit, today's loss passes the daily limit.</Notice>}
          {desk.stats.unprotected > 0 && <Notice tone="gold">{desk.stats.unprotected} open trade{desk.stats.unprotected === 1 ? ' has' : 's have'} no stop in the journal.</Notice>}
          <div>
            <div className="flex justify-between text-[10px] uppercase tracking-wider text-[#8B93A7]">
              <span>Daily loss used</span>
              <span className="font-mono-num">
                {usd(used)} of {usd(g.dailyLimitUsd)}
              </span>
            </div>
            <div className="h-2 bg-[#020814] rounded mt-1 overflow-hidden">
              <div className={`h-full ${usedPct >= 80 ? 'bg-[#FF4D6D]' : usedPct >= 50 ? 'bg-[#F5A623]' : 'bg-[#14F195]'}`} style={{ width: `${usedPct}%` }} />
            </div>
          </div>
          <div>
            <div className="flex justify-between text-[10px] uppercase tracking-wider text-[#8B93A7]">
              <span>Drawdown used</span>
              <span className="font-mono-num">
                {usd(g.ddUsedUsd)} of {usd(g.ddLimitUsd)}
              </span>
            </div>
            <div className="h-2 bg-[#020814] rounded mt-1 overflow-hidden">
              <div className={`h-full ${ddPct >= 80 ? 'bg-[#FF4D6D]' : ddPct >= 50 ? 'bg-[#F5A623]' : 'bg-[#14F195]'}`} style={{ width: `${ddPct}%` }} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Stat label="Headroom today" value={usd(g.headroomUsd)} tone={g.dailyBreached ? 'red' : 'white'} />
            <Stat label="If all stops hit" value={usd(g.ifAllStopsHitTodayUsd, true)} tone={g.stopsWouldBreach ? 'orange' : 'white'} />
            <Stat label="Equity" value={usd(g.equityUsd)} sub={g.markedLive ? 'marked to live prices' : 'some marks are not live'} />
            <Stat label="Risk per trade" value={usd(g.riskPerTradeUsd)} sub={`${fmt(a.riskPct, 2)}%`} />
          </div>
          <p className="text-[10px] text-[#5d6780]">Day started {when(g.dayStart)} (reset {a.resetHourUtc}:00 UTC). Losses count from closed trades plus open losses at the live price.</p>
        </div>
      )}
    </Panel>
  );
};

const LogTrade: React.FC<{ prefill: Prefill | null; account: DeskAccount; onLog: (body: Record<string, unknown>) => Promise<boolean> }> = ({ prefill, account, onLog }) => {
  const blank = { instrument: 'WTI' as Inst, side: 'long' as Side, lots: '', entry: '', stop: '', target: '', ticket: '', broker: account.name || '', openedAt: '', note: '' };
  const [f, setF] = useState({ ...blank, ...(prefill || {}) });
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value });
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const ok = await onLog({
      instrument: f.instrument,
      side: f.side,
      lots: Number(f.lots),
      entry: Number(f.entry),
      stop: f.stop === '' ? null : Number(f.stop),
      target: f.target === '' ? null : Number(f.target),
      ticket: f.ticket,
      broker: f.broker,
      openedAt: f.openedAt ? new Date(f.openedAt).toISOString() : undefined,
      note: f.note,
    });
    if (ok) setF({ ...blank, broker: f.broker });
  };
  return (
    <Panel title="Log a trade you placed">
      <form onSubmit={submit} className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3">
        <Field label="Instrument">
          <select className={inputCls} value={f.instrument} onChange={set('instrument')}>
            <option value="WTI">WTI</option>
            <option value="BRENT">Brent</option>
          </select>
        </Field>
        <Field label="Side">
          <select className={inputCls} value={f.side} onChange={set('side')}>
            <option value="long">Long</option>
            <option value="short">Short</option>
          </select>
        </Field>
        <Field label="Lots">
          <input className={inputCls} inputMode="decimal" value={f.lots} onChange={set('lots')} required />
        </Field>
        <Field label="Fill price">
          <input className={inputCls} inputMode="decimal" value={f.entry} onChange={set('entry')} required />
        </Field>
        <Field label="Stop">
          <input className={inputCls} inputMode="decimal" value={f.stop} onChange={set('stop')} />
        </Field>
        <Field label="Target">
          <input className={inputCls} inputMode="decimal" value={f.target} onChange={set('target')} />
        </Field>
        <Field label="Broker ticket *" hint="position or order number from the platform">
          <input className={inputCls} value={f.ticket} onChange={set('ticket')} required minLength={3} />
        </Field>
        <Field label="Broker">
          <input className={inputCls} value={f.broker} onChange={set('broker')} placeholder="SabioTrade" />
        </Field>
        <Field label="Opened at" hint="blank = now">
          <input className={inputCls} type="datetime-local" value={f.openedAt} onChange={set('openedAt')} />
        </Field>
        <Field label="Note" className="col-span-2 sm:col-span-3 lg:col-span-2">
          <input className={inputCls} value={f.note} onChange={set('note')} placeholder="Why you took it" />
        </Field>
        <div className="col-span-2 sm:col-span-4 lg:col-span-1 flex items-end">
          <Btn type="submit">Journal it</Btn>
        </div>
      </form>
    </Panel>
  );
};

const OpenRow: React.FC<{ t: DeskTrade; write: (fn: () => Promise<unknown>, ok: string) => Promise<boolean> }> = ({ t, write }) => {
  const [mode, setMode] = useState<'close' | 'delete' | null>(null);
  const [exit, setExit] = useState('');
  const [fees, setFees] = useState('');
  const [pnl, setPnl] = useState('');
  const pnlTone = (t.openPnlUsd || 0) >= 0 ? 'text-[#14F195]' : 'text-[#FF4D6D]';
  const preview = useMemo(() => {
    const x = Number(exit);
    if (!x) return null;
    return (x - t.entry) * t.bbl * (t.side === 'long' ? 1 : -1) - (Number(fees) || 0);
  }, [exit, fees, t]);
  return (
    <>
      <tr className="border-t border-[#131d33] align-top">
        <td className="px-1.5 py-2">
          <TradeLabel t={t} />
          {t.alert && (
            <div className="mt-1 flex items-start gap-1 text-[10px] text-[#F5A623] max-w-[220px]">
              <AlertTriangle className="w-3 h-3 shrink-0 mt-px" /> {t.alert}
            </div>
          )}
        </td>
        <td className="px-1.5 py-2 text-right font-mono-num">{fmt(t.entry, 3)}</td>
        <td className="px-1.5 py-2 text-right font-mono-num text-[#8B93A7]">
          {t.stop ? fmt(t.stop, 3) : <span className="text-[#F5A623]">no stop</span>}
          <div>{t.target ? fmt(t.target, 3) : '—'}</div>
        </td>
        <td className="px-1.5 py-2 text-right font-mono-num">
          {t.mark ? fmt(t.mark, 3) : '—'}
          <div className="text-[9px] text-[#5d6780]">{t.markLive ? 'live' : t.mark ? 'last known' : 'no price'}</div>
        </td>
        <td className={`px-1.5 py-2 text-right font-mono-num font-semibold ${pnlTone}`}>{usd(t.openPnlUsd, true)}</td>
        <td className="px-1.5 py-2 text-right font-mono-num">{usd(t.riskUsd)}</td>
        <td className="px-1.5 py-2 text-[#8B93A7]">
          {t.ticket}
          <div className="text-[10px]">
            {t.broker} · {ago(t.openedAt)}
          </div>
        </td>
        <td className="px-1.5 py-2">
          <div className="flex justify-end gap-1">
            <Btn tone="ghost" onClick={() => setMode(mode === 'close' ? null : 'close')}>
              Close
            </Btn>
            <button title="Delete this row (a typo, not a closed trade)" onClick={() => setMode(mode === 'delete' ? null : 'delete')} className="p-1 text-[#8B93A7] hover:text-[#FF4D6D]">
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </td>
      </tr>
      {mode && (
        <tr className="bg-[#020814]">
          <td colSpan={8} className="px-2 py-2">
            {mode === 'close' ? (
              <form
                className="flex flex-wrap items-end gap-2"
                onSubmit={async (e) => {
                  e.preventDefault();
                  const ok = await write(
                    () => engineApi.desk.closeTrade(t.id, { exit: Number(exit), fees: Number(fees) || 0, ...(pnl !== '' ? { pnl: Number(pnl) } : {}) }),
                    `${t.instrument} ${t.ticket} closed`,
                  );
                  if (ok) setMode(null);
                }}
              >
                <Field label="Exit price (broker)">
                  <input className={`${inputBase} w-28`} inputMode="decimal" value={exit} onChange={(e) => setExit(e.target.value)} required />
                </Field>
                <Field label="Fees + swaps (US$)">
                  <input className={`${inputBase} w-28`} inputMode="decimal" value={fees} onChange={(e) => setFees(e.target.value)} />
                </Field>
                <Field label="Broker P&L (optional)" hint="if given, it wins over the computed figure">
                  <input className={`${inputBase} w-36`} inputMode="decimal" value={pnl} onChange={(e) => setPnl(e.target.value)} />
                </Field>
                <div className="text-xs font-mono-num text-[#8B93A7] pb-2">{preview !== null ? `computed ${usd(preview, true)}` : ''}</div>
                <Btn type="submit" tone="green">
                  Record close
                </Btn>
                <Btn tone="ghost" onClick={() => setMode(null)}>
                  <X className="w-3 h-3" />
                </Btn>
              </form>
            ) : (
              <div className="flex flex-wrap items-center gap-2 text-xs">
                <span className="text-[#ffb3c0]">Delete journal row {t.ticket}? Use this only for a mistake. A real close should be recorded with its exit.</span>
                <Btn tone="red" onClick={() => write(() => engineApi.desk.deleteTrade(t.id), 'Row deleted')}>
                  Delete
                </Btn>
                <Btn tone="ghost" onClick={() => setMode(null)}>
                  Keep
                </Btn>
              </div>
            )}
          </td>
        </tr>
      )}
    </>
  );
};
