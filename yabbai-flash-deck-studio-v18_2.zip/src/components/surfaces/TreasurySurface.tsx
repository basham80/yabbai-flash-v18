import React, { useCallback, useEffect, useState } from 'react';
import { OctagonAlert, RefreshCw, ShieldCheck, ShieldOff } from 'lucide-react';
import { EngineGate } from '../EngineGate';
import { engineChanged } from '../../context/EngineContext';
import { isCancelled, useVault } from '../../context/VaultContext';
import { v2, type Approval, type JournalTx, type TreasuryAccount, type TreasuryOverview } from '../../services/engineApi';
import { ago, Btn, Empty, Notice, Panel, Pill, Stat, useFlash, when } from '../ui';

/**
 * TREASURY: the v16 control plane in the deck. Cash as the journal knows it and as each account
 * reports it, what is reserved and committed, the shared approvals queue, reconciliation
 * exceptions and the journal itself. Reads need no vault; decisions do.
 */
export const TreasurySurface: React.FC = () => <EngineGate>{() => <Treasury />}</EngineGate>;

type Inbox = Awaited<ReturnType<typeof v2.inbox>>;
const FRESH: Record<string, 'green' | 'orange' | 'red' | 'slate'> = { fresh: 'green', pending: 'orange', stale: 'orange', failed: 'red' };
const RISK: Record<string, 'green' | 'orange' | 'red'> = { low: 'green', medium: 'orange', high: 'red' };

const Treasury: React.FC = () => {
  const { guard, open, status, unlock } = useVault();
  const [ov, setOv] = useState<TreasuryOverview | null>(null);
  const [accounts, setAccounts] = useState<TreasuryAccount[]>([]);
  const [approvals, setApprovals] = useState<Approval[]>([]);
  const [inbox, setInbox] = useState<Inbox | null>(null);
  const [journal, setJournal] = useState<{ items: JournalTx[]; total: number } | null>(null);
  const [verify, setVerify] = useState<Awaited<ReturnType<typeof v2.verify>> | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [note, setNote] = useState<Record<string, string>>({});
  const [flash, show] = useFlash();

  const load = useCallback(async () => {
    const [o, a, ap, ib, j, vf] = await Promise.allSettled([v2.overview(), v2.accounts(), v2.approvals('pending'), v2.inbox(), v2.journal(12), v2.verify()]);
    if (o.status === 'fulfilled') setOv(o.value);
    if (a.status === 'fulfilled') setAccounts(a.value);
    if (ap.status === 'fulfilled') setApprovals(ap.value);
    if (ib.status === 'fulfilled') setInbox(ib.value);
    if (j.status === 'fulfilled') setJournal(j.value);
    if (vf.status === 'fulfilled') setVerify(vf.value);
    setErr(o.status === 'rejected' ? (o.reason as Error).message : null);
  }, []);
  useEffect(() => {
    load();
    const id = setInterval(load, 30000);
    window.addEventListener('yabbai:changed', load);
    window.addEventListener('yabbai:vault', load);
    return () => {
      clearInterval(id);
      window.removeEventListener('yabbai:changed', load);
      window.removeEventListener('yabbai:vault', load);
    };
  }, [load]);

  const act = async (key: string, fn: () => Promise<unknown>, ok: string) => {
    setBusy(key);
    try {
      await fn();
      show(ok);
      engineChanged();
      await load();
    } catch (e) {
      if (!isCancelled(e)) show((e as Error).message, 'red');
    } finally {
      setBusy(null);
    }
  };
  const decide = (a: Approval, d: 'approve' | 'reject') => act(`${a.id}:${d}`, () => guard((g) => v2.decide(a.id, d, note[a.id] || '', g)), d === 'approve' ? 'Approved' : 'Rejected');
  const kill = (engaged: boolean) =>
    act(
      'kill',
      () => guard((g) => v2.killSwitch({ engaged, reason: engaged ? 'Stopped from the deck' : undefined }, g)),
      engaged ? 'Kill switch engaged: nothing can be submitted' : 'Kill switch released',
    );

  if (!ov) return <Panel title="Treasury">{err ? <Notice tone="red">{err}</Notice> : <div className="text-xs text-[#8B93A7]">Reading the treasury…</div>}</Panel>;
  const c = ov.cash;
  const exceptions = inbox ? inbox.exceptions : [];
  const feeds = inbox ? inbox.failedFeeds : [];

  return (
    <div className="space-y-4">
      {flash}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-bold text-white tracking-wide">Treasury</h1>
          <p className="text-[11px] text-[#8B93A7]">
            Read {ago(ov.at)} · reporting currency {ov.currency} · figures from the journal and each account’s own feed
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {ov.killSwitch.engaged ? <Pill tone="red">Kill switch on</Pill> : <Pill tone="green">Transfers allowed</Pill>}
          {status && !status.set ? (
            <Btn tone="gold" onClick={unlock}>
              <ShieldCheck className="w-3 h-3" /> Set up vault
            </Btn>
          ) : open ? (
            <Pill tone="purple">Vault open</Pill>
          ) : (
            <Btn tone="ghost" onClick={unlock}>
              <ShieldCheck className="w-3 h-3" /> Unlock vault
            </Btn>
          )}
          {ov.killSwitch.engaged ? (
            <Btn tone="green" onClick={() => kill(false)} disabled={busy === 'kill'} title="Director with a fresh code">
              <ShieldOff className="w-3 h-3" /> Release
            </Btn>
          ) : (
            <Btn tone="red" onClick={() => kill(true)} disabled={busy === 'kill'} title="Stops every submission at once">
              <OctagonAlert className="w-3 h-3" /> Stop all transfers
            </Btn>
          )}
          <Btn tone="ghost" onClick={load} title="Read again">
            <RefreshCw className="w-3 h-3" />
          </Btn>
        </div>
      </div>

      <Panel title="Cash">
        <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-4">
          <Stat label="Cleared (book)" value={c.cleared.display} tone="white" sub="Settled and final, from journal postings" />
          <Stat
            label="Seen in accounts"
            value={c.observed.sources.length ? c.observed.display : '—'}
            tone={c.observed.stale || c.observed.failed ? 'orange' : 'white'}
            sub={
              c.observed.sources.length
                ? `${c.observed.sources.length} confirmed account${c.observed.sources.length === 1 ? '' : 's'}${c.observed.stale ? ` · ${c.observed.stale} stale` : ''}${c.observed.failed ? ` · ${c.observed.failed} failed` : ''}`
                : 'No confirmed account read yet'
            }
          />
          <Stat label="Available" value={c.available.display} tone={c.available.short ? 'red' : 'green'} sub="Cleared − reserved − committed" />
          <Stat label="Reserved" value={c.reserved.display} tone="purple" sub={`GST ${c.reserved.gst} · tax pool ${c.reserved.taxPool} · emergency ${c.reserved.emergency}`} />
          <Stat label="Committed" value={c.committed.display} tone="orange" sub={`Transfers ${c.committed.transfers} · due in 30 days ${c.committed.obligations30d}`} />
          <Stat
            label="Pending, not cash"
            value={c.pending.display}
            tone="slate"
            sub={`${c.pending.claims} claim${c.pending.claims === 1 ? '' : 's'} · ${c.pending.reported} reported by AI · unconfirmed chain amounts`}
          />
        </div>
        {c.difference.minor !== '0' && c.observed.sources.length > 0 && (
          <div className="mt-3">
            <Notice tone="gold">
              Accounts and books differ by {c.difference.display}. {c.difference.note}
            </Notice>
          </div>
        )}
      </Panel>

      {ov.needs.length > 0 && (
        <Panel title={`Needs configuration · ${ov.needs.length}`}>
          <ul className="space-y-1.5 text-[13px] text-[#a7afc2]">
            {ov.needs.map((n) => (
              <li key={n.key} className="flex gap-2">
                <span className="text-[#F5A623]" aria-hidden>
                  ●
                </span>
                <span>{n.text}</span>
              </li>
            ))}
          </ul>
        </Panel>
      )}

      <Panel title={`Approvals waiting · ${approvals.length}`} right={!open && approvals.length > 0 ? <span className="text-[10px] text-[#8B93A7]">Deciding asks for the vault</span> : null}>
        {approvals.length === 0 ? (
          <Empty title="Nothing is waiting for a decision">Allocations, transfers and proposals drafted by agents land here until a person decides.</Empty>
        ) : (
          <ul className="divide-y divide-[#131d33]">
            {approvals.map((a) => (
              <li key={a.id} className="py-3 flex flex-col lg:flex-row lg:items-center gap-3">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <Pill tone="gold">{a.kind}</Pill>
                    <Pill tone={RISK[a.risk]}>{a.risk} risk</Pill>
                    <span className="text-sm text-white font-semibold truncate">{a.title}</span>
                  </div>
                  <p className="text-[11px] text-[#8B93A7] mt-1 leading-snug">{a.summary}</p>
                  <p className="text-[10px] text-[#5d6780] mt-1">
                    Asked by {a.createdBy.label} {ago(a.createdAt)} · {a.decisions.filter((d) => d.decision === 'approve').length} of {a.required} yes · expires {when(a.expiresAt)}
                  </p>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <input
                    aria-label="Note"
                    placeholder="Note (optional)"
                    value={note[a.id] || ''}
                    onChange={(e) => setNote({ ...note, [a.id]: e.target.value })}
                    className="w-44 bg-[#020814] border border-[#131d33] rounded px-2 py-1 text-xs"
                  />
                  <Btn tone="green" onClick={() => decide(a, 'approve')} disabled={!!busy}>
                    Approve
                  </Btn>
                  <Btn tone="red" onClick={() => decide(a, 'reject')} disabled={!!busy}>
                    Reject
                  </Btn>
                </div>
              </li>
            ))}
          </ul>
        )}
      </Panel>

      <div className="grid lg:grid-cols-2 gap-4">
        <Panel title={`Accounts · ${accounts.length}`}>
          {accounts.length === 0 ? (
            <Empty title="No accounts registered">
              Add your bank, PayPal and wallet addresses (watch-only) through Treasury → Accounts on the engine console. Balances appear once each feed answers.
            </Empty>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="text-[9px] uppercase tracking-wider text-[#8B93A7] text-left">
                    <th className="py-1.5 pr-2 font-medium">Account</th>
                    <th className="py-1.5 pr-2 font-medium">Seen</th>
                    <th className="py-1.5 pr-2 font-medium">Book</th>
                    <th className="py-1.5 font-medium">Feed</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#131d33]">
                  {accounts.map((a) => (
                    <tr key={a.id} className={a.enabled ? '' : 'opacity-50'}>
                      <td className="py-2 pr-2">
                        <div className="text-white font-semibold">{a.name}</div>
                        <div className="text-[10px] text-[#5d6780]">
                          {a.kind.replace(/_/g, ' ')} · {a.asset}
                          {a.ownershipConfirmed ? '' : ' · ownership not confirmed'}
                        </div>
                      </td>
                      <td className="py-2 pr-2 font-mono-num text-white">{a.observed.display ?? '—'}</td>
                      <td className="py-2 pr-2 font-mono-num text-[#a7afc2]">{a.book.display}</td>
                      <td className="py-2">
                        <Pill tone={FRESH[a.observed.freshness] || 'slate'} title={a.observed.error || a.observed.source || ''}>
                          {a.observed.freshness}
                        </Pill>
                        <div className="text-[10px] text-[#5d6780] mt-0.5">{a.observed.at ? ago(a.observed.at) : 'never read'}</div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Panel>

        <Panel title={`Reconciliation · ${exceptions.length + feeds.length} open`}>
          {exceptions.length + feeds.length === 0 ? (
            <Empty title="Books and accounts agree">Differences, failed feeds and unmatched payments show here, once each, until someone explains them.</Empty>
          ) : (
            <ul className="space-y-2">
              {feeds.map((f) => (
                <li key={f.id} className="text-xs">
                  <Pill tone="red">feed failed</Pill> <span className="text-white">{f.account}</span> <span className="text-[#8B93A7]">{f.error}</span>
                </li>
              ))}
              {exceptions.map((x) => (
                <li key={x.id} className="text-xs">
                  <Pill tone="orange">{x.kind}</Pill> <span className="text-white">{x.account || ''}</span> <span className="text-[#8B93A7]">{x.detail || x.difference || ''}</span>
                  <span className="text-[10px] text-[#5d6780]"> · since {when(x.firstSeenAt)}</span>
                </li>
              ))}
            </ul>
          )}
        </Panel>
      </div>

      <Panel
        title={`Journal · ${journal ? journal.total : 0} entries`}
        right={verify ? <Pill tone={verify.journal.ok && verify.audit.ok ? 'green' : 'red'}>{verify.journal.ok && verify.audit.ok ? 'Chain and balances verify' : 'Check failed'}</Pill> : null}
      >
        {!journal || journal.items.length === 0 ? (
          <Empty title="No journal entries yet">Every payment with evidence, cost and transfer is booked here as balanced double entry. Nothing is edited; corrections are reversals.</Empty>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="text-[9px] uppercase tracking-wider text-[#8B93A7] text-left">
                  <th className="py-1.5 pr-2 font-medium">When</th>
                  <th className="py-1.5 pr-2 font-medium">Type</th>
                  <th className="py-1.5 pr-2 font-medium">Description</th>
                  <th className="py-1.5 font-medium">Lines</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#131d33]">
                {journal.items.map((t) => (
                  <tr key={t.id}>
                    <td className="py-1.5 pr-2 text-[#a7afc2] whitespace-nowrap">{when(t.effectiveAt)}</td>
                    <td className="py-1.5 pr-2">
                      <Pill tone={t.reversalOf ? 'orange' : 'slate'}>{t.reversalOf ? 'reversal' : t.type}</Pill>
                    </td>
                    <td className="py-1.5 pr-2 text-white min-w-[12rem]">{t.description || t.sourceSystem}</td>
                    <td className="py-1.5 text-[#8B93A7]">{t.postings.length}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Panel>
    </div>
  );
};
