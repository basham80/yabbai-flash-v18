import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Activity, AlertTriangle, CheckCircle2, ExternalLink, Link2, Plus, RefreshCw, Send, Trash2, Zap } from 'lucide-react';
import {
  engineApi,
  payLink,
  aud,
  type EngineInvoice,
  type EngineSnapshot,
  type RailStatus,
} from '../../services/engineApi';
import { brainLabel, engineConfig } from '../../services/brain';
import { isCancelled, useVault } from '../../context/VaultContext';

/**
 * ENGINE — the real money surface.
 *
 * Every other tab in this cockpit runs on localStorage. This one does not: it
 * talks to the YABBAI engine, which owns the ledger, the invoices and the payment
 * rails. If a number shows here, the engine has a receipt for it. That distinction
 * is the whole point of merging the two apps.
 */
export const EngineSurface: React.FC = () => {
  const [snap, setSnap] = useState<EngineSnapshot | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [client, setClient] = useState('');
  const [desc, setDesc] = useState('');
  const [amount, setAmount] = useState('');
  const [payInput, setPayInput] = useState<{ id: string; amount: number; txId: string } | null>(null);
  const { guard, status: vault, open: vaultOpen } = useVault();

  const linked = !!engineConfig().token;

  const refresh = useCallback(async () => {
    if (!linked) {
      setError('Engine token is not linked — paste it in the header chip.');
      return;
    }
    try {
      const s = await engineApi.snapshot();
      setSnap(s);
      setError(null);
    } catch (err) {
      setError((err as Error).message);
    }
  }, [linked]);

  useEffect(() => {
    refresh();
    const id = setInterval(refresh, 20000);
    return () => clearInterval(id);
  }, [refresh]);

  const flash = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3200);
  };

  // The Director vault (v2) guards every money action: a sealed vault opens a PIN + code
  // dialog, and the action runs again once it is open (VaultContext).
  const run = async (key: string, fn: () => Promise<void>) => {
    setBusy(key);
    try {
      await guard(() => fn());
      await refresh();
    } catch (err) {
      if (!isCancelled(err)) flash((err as Error).message);
    } finally {
      setBusy(null);
    }
  };

  const rails: RailStatus[] = snap?.receive.summary.rails || [];
  const invoices: EngineInvoice[] = snap?.invoices || [];
  const open = invoices.filter((i) => ['sent', 'part', 'overdue'].includes(i.status));
  const claims = (snap?.claims || []).filter((c) => c.status === 'pending');
  const ledgerEntries = snap?.ledgerTotals?.count || 0;

  const create = () =>
    run('create', async () => {
      const lines = desc
        .split('\n')
        .map((l) => l.trim())
        .filter(Boolean)
        .map((l) => ({ desc: l, qty: 1, unitAud: Number(amount) || 0 }));
      if (!client.trim() || !lines.length || !(Number(amount) > 0)) throw new Error('Client, line item and amount are required');
      const inv = await engineApi.invoices.create({
        client: client.trim(),
        items: lines,
        rails: rails.filter((r) => r.ready).map((r) => r.id),
      });
      setClient('');
      setDesc('');
      setAmount('');
      flash(`${inv.number} drafted — ${payLink(inv)}`);
      try {
        await navigator.clipboard.writeText(payLink(inv));
        flash(`${inv.number} created — pay link copied`);
      } catch {
        /* clipboard denied: the link is in the list */
      }
    });

  const copy = async (inv: EngineInvoice) => {
    try {
      await navigator.clipboard.writeText(payLink(inv));
      flash(`${inv.number} pay link copied`);
    } catch {
      flash(payLink(inv));
    }
  };

  const stats = useMemo(
    () => [
      { label: 'VERIFIED LEDGER', value: aud(snap?.ledgerTotals?.all || 0), sub: `${ledgerEntries} receipts`, tone: 'text-[#f5c518]' },
      { label: 'RECEIVABLE', value: aud(snap?.receive.summary.receivableAud || 0), sub: `${snap?.receive.summary.open || 0} open invoices`, tone: 'text-[#9945FF]' },
      { label: 'COLLECTED', value: aud(snap?.receive.summary.collectedAud || 0), sub: `${snap?.receive.summary.paid || 0} settled`, tone: 'text-[#14F195]' },
      { label: 'PAY YOURSELF', value: aud(snap?.pools.pay.available || 0), sub: 'available to draw', tone: 'text-[#F5A623]' },
    ],
    [snap, ledgerEntries]
  );

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-[#f5c518] tracking-wide flex items-center gap-2">
            <Zap size={18} /> ENGINE · LIVE MONEY
          </h2>
          <p className="text-xs text-[#8B93A7] mt-1">
            Backed by the YABBAI engine at <span className="text-[#14F195]">{engineConfig().base || location.origin}</span> · brain:{' '}
            <span className="text-[#14F195]">{brainLabel()}</span>. Numbers here are the ones with receipts; every other tab is simulation.
          </p>
        </div>
        <div className="flex items-center gap-2">
          {vault?.set && (
            <span
              className={`text-[10px] uppercase tracking-wider px-2 py-1 rounded border ${
                vaultOpen ? 'border-[#14F195]/50 text-[#14F195] bg-[#14F195]/10' : 'border-[#9945FF]/50 text-[#9945FF] bg-[#9945FF]/10'
              }`}
              title={vaultOpen ? 'Money actions allowed until the session ends (15 minutes idle)' : 'Money actions ask for your PIN and an authenticator code'}
            >
              {vaultOpen ? 'VAULT OPEN' : 'VAULT SEALED'}
            </span>
          )}
          <button
            onClick={() => run('reconcile', async () => {
              const out = await engineApi.receive.reconcile();
              const n = (out.sol?.credits || 0) + (out.btc?.credits || 0) + (out.eth?.credits || 0);
              flash(n ? `${n} payment(s) booked` : 'Rails scanned — nothing new');
            })}
            disabled={busy === 'reconcile'}
            className="text-xs px-3 py-1.5 rounded border border-[#131d33] bg-[#0a1224] hover:border-[#f5c518]/60 flex items-center gap-1.5"
          >
            <RefreshCw size={13} className={busy === 'reconcile' ? 'animate-spin' : ''} /> Reconcile
          </button>
          <button onClick={refresh} className="text-xs px-3 py-1.5 rounded border border-[#131d33] bg-[#0a1224] hover:border-[#14F195]/60">
            Refresh
          </button>
        </div>
      </div>

      {error && (
        <div className="card-like flex items-start gap-2 border border-[#FF4D6D]/40 bg-[#FF4D6D]/10 text-[#FF4D6D] text-xs px-3 py-2 rounded">
          <AlertTriangle size={14} className="mt-0.5" /> {error}
        </div>
      )}

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {stats.map((s) => (
          <div key={s.label} className="bg-[#0a1224] border border-[#131d33] rounded-lg px-3 py-2.5">
            <span className="text-[9px] uppercase tracking-wider text-[#8B93A7]">{s.label}</span>
            <div className={`text-lg font-bold font-mono-num ${s.tone}`}>{s.value}</div>
            <span className="text-[10px] text-[#4a5468]">{s.sub}</span>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-4">
        <div className="bg-[#0a1224] border border-[#131d33] rounded-lg p-3">
          <h3 className="text-xs uppercase tracking-wider text-[#8B93A7] mb-2">Rails</h3>
          <div className="space-y-1.5">
            {rails.map((r) => (
              <div key={r.id} className="flex items-center justify-between text-xs">
                <span className="flex items-center gap-1.5">
                  <span className={`w-1.5 h-1.5 rounded-full ${r.ready ? 'bg-[#14F195]' : 'bg-[#4a5468]'}`} />
                  <span className={r.ready ? 'text-slate-200' : 'text-[#4a5468]'}>{r.label}</span>
                </span>
                <span className="text-[10px] text-[#8B93A7] font-mono-num">{r.detail}</span>
              </div>
            ))}
            {!rails.length && <span className="text-xs text-[#4a5468]">Engine not reporting rails.</span>}
          </div>
        </div>

        <div className="bg-[#0a1224] border border-[#131d33] rounded-lg p-3 lg:col-span-2">
          <h3 className="text-xs uppercase tracking-wider text-[#8B93A7] mb-2 flex items-center gap-1.5">
            <Plus size={12} /> New invoice
          </h3>
          <div className="grid sm:grid-cols-2 gap-2">
            <input value={client} onChange={(e) => setClient(e.target.value)} placeholder="Client" className="bg-[#020814] border border-[#131d33] rounded px-2 py-1.5 text-xs" />
            <input value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="Amount AUD (per line)" inputMode="decimal" className="bg-[#020814] border border-[#131d33] rounded px-2 py-1.5 text-xs font-mono-num" />
            <textarea value={desc} onChange={(e) => setDesc(e.target.value)} placeholder={'Line item(s), one per line\nSEO audit'} rows={2} className="bg-[#020814] border border-[#131d33] rounded px-2 py-1.5 text-xs sm:col-span-2" />
          </div>
          <div className="flex items-center justify-between mt-2">
            <span className="text-[10px] text-[#4a5468]">Uses every LIVE rail. Draft first — nothing is charged.</span>
            <button
              onClick={create}
              disabled={busy === 'create'}
              className="text-xs px-3 py-1.5 rounded bg-[#f5c518] text-[#020814] font-bold disabled:opacity-50"
            >
              {busy === 'create' ? 'Creating…' : 'Draft invoice'}
            </button>
          </div>
        </div>
      </div>

      <div className="bg-[#0a1224] border border-[#131d33] rounded-lg">
        <div className="px-3 py-2 border-b border-[#131d33] flex items-center justify-between">
          <h3 className="text-xs uppercase tracking-wider text-[#8B93A7]">Invoices ({invoices.length})</h3>
          <span className="text-[10px] text-[#4a5468]">{open.length} awaiting payment</span>
        </div>
        <div className="divide-y divide-[#131d33] max-h-[420px] overflow-auto">
          {invoices.map((inv) => (
            <div key={inv.id} className="px-3 py-2 flex flex-wrap items-center gap-2 text-xs">
              <span className="font-mono-num text-[#f5c518] font-bold w-20">{inv.number}</span>
              <span className="flex-1 min-w-[120px] text-slate-200">{inv.client}</span>
              <span className="font-mono-num text-slate-300 w-20 text-right">{aud(inv.totalAud)}</span>
              <span
                className={`px-1.5 py-0.5 rounded text-[10px] uppercase tracking-wider ${
                  inv.status === 'paid' ? 'bg-[#14F195]/15 text-[#14F195]' : inv.status === 'part' ? 'bg-[#f5c518]/15 text-[#f5c518]' : 'bg-[#131d33] text-[#8B93A7]'
                }`}
              >
                {inv.status}
              </span>
              <div className="flex items-center gap-1">
                <button onClick={() => copy(inv)} title="Copy pay link" className="p-1 rounded hover:bg-[#131d33] text-[#8B93A7]">
                  <Link2 size={13} />
                </button>
                <a href={payLink(inv)} target="_blank" rel="noreferrer" title="Open pay page" className="p-1 rounded hover:bg-[#131d33] text-[#8B93A7]">
                  <ExternalLink size={13} />
                </a>
                {inv.status === 'draft' && (
                  <button onClick={() => run(`send:${inv.id}`, async () => { await engineApi.invoices.send(inv.id); flash(`${inv.number} marked sent`); })} title="Mark sent" className="p-1 rounded hover:bg-[#131d33] text-[#f5c518]">
                    <Send size={13} />
                  </button>
                )}
                {['sent', 'part', 'overdue'].includes(inv.status) && (
                  <button
                    onClick={() => setPayInput({ id: inv.id, amount: Math.round((inv.totalAud - inv.paidAud) * 100) / 100, txId: '' })}
                    title="Book a proven payment"
                    className="p-1 rounded hover:bg-[#131d33] text-[#14F195]"
                  >
                    <CheckCircle2 size={13} />
                  </button>
                )}
                {inv.status !== 'paid' && inv.status !== 'void' && (
                  <button onClick={() => run(`void:${inv.id}`, async () => { await engineApi.invoices.void(inv.id); flash(`${inv.number} voided`); })} title="Void" className="p-1 rounded hover:bg-[#131d33] text-[#FF4D6D]">
                    <Trash2 size={13} />
                  </button>
                )}
              </div>
            </div>
          ))}
          {!invoices.length && <div className="px-3 py-6 text-center text-xs text-[#4a5468]">No invoices yet. Draft one above — the pay page does the rest.</div>}
        </div>
      </div>

      {payInput && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center p-4 z-50" onClick={() => setPayInput(null)}>
          <div className="bg-[#0a1224] border border-[#f5c518]/40 rounded-lg p-4 w-full max-w-md" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-sm font-bold text-[#f5c518] mb-1">Book a proven payment</h3>
            <p className="text-[11px] text-[#8B93A7] mb-3">
              Only for money you can see in your bank or chain. The transaction id becomes the ledger reference — no id, no credit.
            </p>
            <label className="text-[10px] uppercase tracking-wider text-[#8B93A7]">Amount AUD</label>
            <input
              value={payInput.amount}
              onChange={(e) => setPayInput({ ...payInput, amount: Number(e.target.value) })}
              inputMode="decimal"
              className="w-full bg-[#020814] border border-[#131d33] rounded px-2 py-1.5 text-xs font-mono-num mb-2"
            />
            <label className="text-[10px] uppercase tracking-wider text-[#8B93A7]">Transaction id / hash</label>
            <input
              value={payInput.txId}
              onChange={(e) => setPayInput({ ...payInput, txId: e.target.value })}
              placeholder="NPP ref, bank txn id, tx signature"
              className="w-full bg-[#020814] border border-[#131d33] rounded px-2 py-1.5 text-xs mb-3"
            />
            <div className="flex justify-end gap-2">
              <button onClick={() => setPayInput(null)} className="text-xs px-3 py-1.5 rounded border border-[#131d33] text-[#8B93A7]">
                Cancel
              </button>
              <button
                disabled={!payInput.txId.trim() || !(payInput.amount > 0)}
                onClick={() =>
                  run('book', async () => {
                    await engineApi.invoices.bookPayment(payInput.id, { amountAud: payInput.amount, externalId: payInput.txId.trim() });
                    flash('Payment booked with proof');
                    setPayInput(null);
                  })
                }
                className="text-xs px-3 py-1.5 rounded bg-[#14F195] text-[#020814] font-bold disabled:opacity-40"
              >
                Book
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="grid lg:grid-cols-2 gap-4">
        <div className="bg-[#0a1224] border border-[#131d33] rounded-lg p-3">
          <h3 className="text-xs uppercase tracking-wider text-[#8B93A7] mb-2">Payment claims ({claims.length})</h3>
          <div className="space-y-2 max-h-56 overflow-auto">
            {claims.map((c) => (
              <div key={c.id} className="text-xs flex items-center justify-between gap-2">
                <span>
                  <span className="font-mono-num text-[#f5c518]">{c.invoiceNumber}</span> <span className="text-[#8B93A7]">{c.rail}</span>{' '}
                  <span className="font-mono-num">{aud(c.amountAud)}</span>
                  {c.ref && <span className="text-[#4a5468]"> · {c.ref}</span>}
                </span>
                <span className="flex gap-1">
                  <button onClick={() => run(`c:${c.id}`, async () => { await engineApi.claims.confirm(c.id); flash('Claim confirmed'); })} className="px-1.5 py-0.5 rounded bg-[#14F195]/15 text-[#14F195] text-[10px]">
                    Confirm
                  </button>
                  <button onClick={() => run(`d:${c.id}`, async () => { await engineApi.claims.dismiss(c.id); flash('Claim dismissed'); })} className="px-1.5 py-0.5 rounded bg-[#131d33] text-[#8B93A7] text-[10px]">
                    Dismiss
                  </button>
                </span>
              </div>
            ))}
            {!claims.length && <span className="text-[11px] text-[#4a5468]">No claims. A claim never credits anything on its own.</span>}
          </div>
        </div>

        <div className="bg-[#0a1224] border border-[#131d33] rounded-lg p-3">
          <h3 className="text-xs uppercase tracking-wider text-[#8B93A7] mb-2 flex items-center gap-1.5">
            <Activity size={12} /> Engine activity
          </h3>
          <ul className="space-y-1 max-h-56 overflow-auto">
            {(snap?.activity || []).slice(0, 14).map((a) => (
              <li key={a.id} className="text-[11px] flex gap-2">
                <span className="text-[#4a5468] font-mono-num shrink-0">{new Date(a.at).toLocaleTimeString('en-AU', { hour12: false })}</span>
                <span className="text-[#8B93A7]">
                  <span className="text-[#f5c518] uppercase text-[9px]">[{a.kind}]</span> {a.text}
                </span>
              </li>
            ))}
            {!(snap?.activity || []).length && <li className="text-[11px] text-[#4a5468]">No engine events yet.</li>}
          </ul>
        </div>
      </div>

      {toast && <div className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-[#0a1224] border border-[#f5c518]/50 text-[#f5c518] text-xs px-4 py-2 rounded-lg shadow-xl">{toast}</div>}
    </div>
  );
};
