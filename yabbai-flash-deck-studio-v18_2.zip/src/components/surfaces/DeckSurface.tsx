import React, { useEffect, useMemo, useState } from 'react';
import { ArrowRight, Play } from 'lucide-react';
import { EngineGate } from '../EngineGate';
import { engineChanged } from '../../context/EngineContext';
import { aud, engineApi, LEAD_STAGES, usd, type DeskSummary, type EngineSnapshot } from '../../services/engineApi';
import { ago, Btn, Empty, fmt, Panel, Pill, Stat, useFlash, when } from '../ui';
import type { Tab } from '../Header';

const STAGE_LABEL: Record<string, string> = { new: 'New', drafted: 'Drafted', sent: 'Sent', replied: 'Replied', won: 'Won', lost: 'Lost' };

/** DECK: the whole business on one screen, every number from the engine. */
export const DeckSurface: React.FC<{ go: (t: Tab) => void }> = ({ go }) => <EngineGate>{(snap) => <Deck snap={snap} go={go} />}</EngineGate>;

const Deck: React.FC<{ snap: EngineSnapshot; go: (t: Tab) => void }> = ({ snap, go }) => {
  const [desk, setDesk] = useState<DeskSummary | null>(snap.desk || null);
  const [model, setModel] = useState<string | null | undefined>(undefined);
  const [flash, show] = useFlash();

  useEffect(() => {
    let alive = true;
    const load = () => engineApi.desk.get().then((d) => alive && setDesk(d)).catch(() => {});
    load();
    const id = setInterval(load, 60000);
    engineApi.health().then((h) => alive && setModel(h.model)).catch(() => alive && setModel(null));
    return () => {
      alive = false;
      clearInterval(id);
    };
  }, []);

  const t = snap.ledgerTotals;
  const rs = snap.receive.summary;
  const drafts = snap.outbox.filter((d) => d.status === 'draft');
  const claims = snap.claims.filter((c) => c.status === 'pending');
  const stageCounts = useMemo(() => {
    const c: Record<string, number> = {};
    for (const s of LEAD_STAGES) c[s] = 0;
    for (const l of snap.leads) c[l.stage] = (c[l.stage] || 0) + 1;
    return c;
  }, [snap.leads]);
  const sources = useMemo(() => {
    const c: Record<string, number> = {};
    for (const l of snap.leads) c[l.source || 'manual'] = (c[l.source || 'manual'] || 0) + 1;
    return Object.entries(c).sort((a, b) => b[1] - a[1]);
  }, [snap.leads]);
  const maxStage = Math.max(1, ...Object.values(stageCounts));
  const pancake = snap.leads.filter((l) => l.source === 'pancake').length;
  const agents = Object.entries(snap.agents || {}).sort((a, b) => a[1].name.localeCompare(b[1].name));

  const runAgent = async (id: string, name: string) => {
    try {
      await engineApi.agents.run(id);
      show(`${name} queued`);
      engineChanged();
    } catch (e) {
      show((e as Error).message, 'red');
    }
  };

  return (
    <div className="space-y-4">
      {flash}
      <Panel title="Book of record" right={<span className="text-[10px] text-[#5d6780]">Ledger entries need a receipt reference to count</span>}>
        <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-4">
          <Stat label="Net verified, all time" value={aud(t.all)} tone="gold" sub={`${t.count} ledger entries`} />
          <Stat label="This month" value={aud(t.month)} tone={t.month > 0 ? 'green' : 'white'} />
          <Stat label="This week" value={aud(t.week)} />
          <Stat label="MRR" value={aud(snap.mrr.amount)} tone="green" sub={`${snap.mrr.count} recurring receipt${snap.mrr.count === 1 ? '' : 's'}, last 31 days`} />
          <Stat label="Owed on open invoices" value={aud(rs.receivableAud)} tone="purple" sub={`${rs.open} open of ${rs.count}`} />
          <Stat label="Collected through rails" value={aud(rs.collectedAud)} sub={`${rs.paid} paid`} />
        </div>
      </Panel>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Panel title="Pipeline" className="lg:col-span-2" right={<Btn tone="ghost" onClick={() => go('leads')}>Leads <ArrowRight className="w-3 h-3" /></Btn>}>
          {snap.leads.length === 0 ? (
            <Empty title="No leads yet">Import from Pancake or a CSV on the Leads tab. The Closer drafts outreach for each one and waits for your approval.</Empty>
          ) : (
            <div className="space-y-4">
              <div className="space-y-1.5">
                {LEAD_STAGES.map((s) => (
                  <div key={s} className="grid grid-cols-[72px_1fr_40px] items-center gap-2 text-xs">
                    <span className="text-[#8B93A7]">{STAGE_LABEL[s]}</span>
                    <div className="h-2.5 bg-[#020814] rounded overflow-hidden">
                      <div
                        className={`h-full rounded ${s === 'won' ? 'bg-[#14F195]' : s === 'lost' ? 'bg-[#FF4D6D]/70' : 'bg-[#f5c518]/80'}`}
                        style={{ width: `${(stageCounts[s] / maxStage) * 100}%` }}
                      />
                    </div>
                    <span className="font-mono-num text-right text-slate-200">{stageCounts[s]}</span>
                  </div>
                ))}
              </div>
              <div className="flex flex-wrap items-center gap-1.5 text-[10px] text-[#8B93A7]">
                <span className="uppercase tracking-wider">Sources</span>
                {sources.map(([s, n]) => (
                  <Pill key={s} tone={s === 'pancake' ? 'purple' : 'slate'}>
                    {s} · {n}
                  </Pill>
                ))}
              </div>
            </div>
          )}
        </Panel>

        <Panel title="Waiting on you">
          <ul className="space-y-2 text-xs">
            <WaitRow n={drafts.length} label="outreach drafts to approve" onOpen={() => go('leads')} />
            <WaitRow n={claims.length} label="payment claims to check" onOpen={() => go('receive')} />
            <WaitRow n={snap.unmatched.length} label="payments not matched to an invoice" onOpen={() => go('receive')} />
            <WaitRow n={desk ? desk.open.filter((x) => x.alert).length : 0} label="oil trades past a stop or target" onOpen={() => go('desk')} />
          </ul>
          {drafts.length + claims.length + snap.unmatched.length === 0 && <p className="text-[11px] text-[#5d6780] mt-3">Nothing needs a decision right now.</p>}
        </Panel>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Panel title="Oil desk" right={<Btn tone="ghost" onClick={() => go('desk')}>Open desk <ArrowRight className="w-3 h-3" /></Btn>}>
          {!desk ? (
            <p className="text-xs text-[#8B93A7]">Fetching WTI and Brent…</p>
          ) : (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                {desk.instruments.map((q) => (
                  <div key={q.id} className="bg-[#020814] border border-[#131d33] rounded p-3 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[10px] uppercase tracking-wider text-[#8B93A7]">{q.name}</span>
                      {q.ok && q.changePct !== null && q.changePct !== undefined && (
                        <span className={`font-mono-num text-[11px] ${q.changePct >= 0 ? 'text-[#14F195]' : 'text-[#FF4D6D]'}`}>
                          {q.changePct >= 0 ? '+' : ''}
                          {fmt(q.changePct)}%
                        </span>
                      )}
                    </div>
                    <div className="font-mono-num text-xl font-bold text-white">{q.ok ? `$${fmt(q.price)}` : q.last ? `$${fmt(q.last.price)}` : '—'}</div>
                    <div className="text-[10px] text-[#5d6780] truncate">
                      {q.ok ? `${q.source} · ${q.at ? when(q.at) : q.asOf}` : q.last ? `last known · ${when(q.last.at)}` : q.error}
                    </div>
                  </div>
                ))}
              </div>
              <div className="grid grid-cols-3 gap-3">
                <Stat label="Open trades" value={desk.stats.open} sub={desk.stats.unprotected ? `${desk.stats.unprotected} without a stop` : undefined} />
                <Stat label="Open P&L" value={usd(desk.stats.openPnlUsd, true)} tone={(desk.stats.openPnlUsd || 0) >= 0 ? 'green' : 'red'} />
                <Stat
                  label="Today's headroom"
                  value={desk.guard ? usd(desk.guard.headroomUsd) : '—'}
                  tone={desk.guard && desk.guard.dailyBreached ? 'red' : 'white'}
                  sub={desk.guard ? `of ${usd(desk.guard.dailyLimitUsd)} daily limit` : 'Set the account size on the desk'}
                />
              </div>
              {!desk.broker.connected && <p className="text-[10px] text-[#5d6780]">No broker connected. The desk journals trades you place; it does not place them.</p>}
            </div>
          )}
        </Panel>

        <Panel title="Connections">
          <ul className="space-y-2 text-xs">
            <ConnRow ok={model !== null && model !== undefined} label="Brain" detail={model === undefined ? 'checking…' : model ? `model ${model}` : 'no model answering: on the laptop run INSTALL-YABBAI.bat, on Render add HF_TOKEN'} />
            {snap.receive.summary.rails.map((r) => (
              <ConnRow key={r.id} ok={r.ready} label={r.label} detail={r.detail} />
            ))}
            <ConnRow ok={pancake > 0} label="Pancake" detail={pancake > 0 ? `${pancake} lead${pancake === 1 ? '' : 's'} in from Pancake` : 'no Pancake leads yet: Leads tab, Hook up Pancake'} />
            <ConnRow ok={!!desk?.broker.connected} label="Oil broker" detail={desk?.broker.connected ? 'connected' : 'not connected: journal only, no order placement'} />
          </ul>
        </Panel>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Panel title="Agents" right={<Pill tone={snap.settings?.autopilot ? 'green' : 'slate'}>{snap.settings?.autopilot ? 'autopilot on' : 'autopilot off'}</Pill>}>
          {agents.length === 0 ? (
            <Empty title="No agents reported" />
          ) : (
            <div className="overflow-x-auto -mx-1">
              <table className="w-full text-xs min-w-[420px]">
                <thead>
                  <tr className="text-[9px] uppercase tracking-wider text-[#5d6780] text-left">
                    <th className="px-1 py-1 font-medium">Agent</th>
                    <th className="px-1 py-1 font-medium">State</th>
                    <th className="px-1 py-1 font-medium text-right">Runs</th>
                    <th className="px-1 py-1 font-medium">Last run</th>
                    <th className="px-1 py-1" />
                  </tr>
                </thead>
                <tbody>
                  {agents.map(([id, a]) => {
                    const state = a.running ? 'running' : a.status === 'queued' ? 'queued' : a.lastError ? 'error' : a.enabled ? 'idle' : 'off';
                    return (
                      <tr key={id} className="border-t border-[#131d33]">
                        <td className="px-1 py-1.5 text-slate-200">{a.name}</td>
                        <td className="px-1 py-1.5">
                          <Pill tone={state === 'running' ? 'green' : state === 'error' ? 'red' : state === 'queued' ? 'gold' : 'slate'} title={a.lastError || undefined}>
                            {state}
                          </Pill>
                        </td>
                        <td className="px-1 py-1.5 text-right font-mono-num">{a.runs}</td>
                        <td className="px-1 py-1.5 text-[#8B93A7]">{ago(a.lastRunAt)}</td>
                        <td className="px-1 py-1.5 text-right">
                          <button
                            onClick={() => runAgent(id, a.name)}
                            disabled={a.running || a.status === 'queued'}
                            className="inline-flex items-center gap-1 text-[10px] uppercase tracking-wider text-[#8B93A7] hover:text-[#f5c518] disabled:opacity-30"
                            title={`Run ${a.name} now`}
                          >
                            <Play className="w-3 h-3" /> Run
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </Panel>

        <Panel title="Activity">
          {snap.activity.length === 0 ? (
            <Empty title="Nothing logged yet" />
          ) : (
            <ul className="space-y-1.5 text-xs max-h-72 overflow-y-auto pr-1">
              {snap.activity.slice(0, 18).map((a) => (
                <li key={a.id} className="grid grid-cols-[64px_auto_1fr] gap-2 items-start">
                  <span className="text-[#5d6780] font-mono-num text-[10px] pt-0.5">{ago(a.at)}</span>
                  <Pill>{a.kind}</Pill>
                  <span className="text-slate-300 min-w-0 break-words">{a.text}</span>
                </li>
              ))}
            </ul>
          )}
        </Panel>
      </div>
    </div>
  );
};

const WaitRow: React.FC<{ n: number; label: string; onOpen: () => void }> = ({ n, label, onOpen }) => (
  <li className="flex items-center justify-between gap-2">
    <span className="flex items-center gap-2 min-w-0">
      <span className={`font-mono-num text-base font-bold w-8 text-right ${n > 0 ? 'text-[#F5A623]' : 'text-[#5d6780]'}`}>{n}</span>
      <span className="text-[#a7afc2] truncate">{label}</span>
    </span>
    {n > 0 && (
      <button onClick={onOpen} className="text-[10px] uppercase tracking-wider text-[#f5c518] hover:underline shrink-0">
        Open
      </button>
    )}
  </li>
);

const ConnRow: React.FC<{ ok: boolean; label: string; detail: string }> = ({ ok, label, detail }) => (
  <li className="grid grid-cols-[14px_110px_1fr] gap-2 items-start">
    <span className={`mt-1 w-2 h-2 rounded-full ${ok ? 'bg-[#14F195]' : 'bg-[#5d6780]'}`} aria-hidden />
    <span className="text-slate-200">{label}</span>
    <span className="text-[#8B93A7] min-w-0 break-words">
      {ok ? '' : 'Not live · '}
      {detail}
    </span>
  </li>
);
