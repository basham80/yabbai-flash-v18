import React from 'react';
import { useEngine } from '../context/EngineContext';
import { ago } from './ui';

export const Footer: React.FC = () => {
  const { snap, lastAt, error } = useEngine();
  return (
    <footer className="border-t border-[#131d33] bg-[#020814] mt-8">
      <div className="max-w-7xl mx-auto px-4 py-3 flex flex-wrap items-center justify-between gap-2 text-[10px] text-[#5d6780] uppercase tracking-wider">
        <span>Every figure here comes from the YABBAI engine: receipts in the ledger, live market feeds, your own journal. Nothing is simulated.</span>
        <span className="font-mono-num">
          {snap ? `engine ${snap.version} · synced ${ago(lastAt)}` : error ? 'engine unreachable' : 'not linked'}
        </span>
      </div>
    </footer>
  );
};
