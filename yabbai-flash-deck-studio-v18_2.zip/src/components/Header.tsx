import React from 'react';
import { EngineTruthChip } from './EngineTruthChip';
import { useEngine } from '../context/EngineContext';
import { aud } from '../services/engineApi';

export type Tab = 'deck' | 'ops' | 'treasury' | 'leads' | 'receive' | 'desk';

const TABS: Array<{ id: Tab; label: string; glyph: string }> = [
  { id: 'deck', label: 'DECK', glyph: '◆' },
  { id: 'ops', label: 'OPS', glyph: '⌬' },
  { id: 'treasury', label: 'TREASURY', glyph: '▣' },
  { id: 'leads', label: 'LEADS', glyph: '✦' },
  { id: 'receive', label: 'RECEIVE', glyph: '⛁' },
  { id: 'desk', label: 'OIL DESK', glyph: '▲' },
];

export const Header: React.FC<{ tab: Tab; go: (t: Tab) => void }> = ({ tab, go }) => {
  const { snap } = useEngine();
  const drafts = snap ? snap.outbox.filter((d) => d.status === 'draft').length : 0;
  const newLeads = snap ? snap.leads.filter((l) => l.stage === 'new').length : 0;
  const claims = snap ? snap.claims.filter((c) => c.status === 'pending').length : 0;
  const deskAlerts = snap?.desk ? snap.desk.open.filter((t) => t.alert).length : 0;
  const ops = snap?.ops || {};
  const opsWaiting = (ops.proposalsWaiting || 0) + (ops.needsAttention || 0) + (ops.deadLetters || 0);
  const approvalsWaiting = snap?.treasury?.approvalsPending || 0;
  const badge: Partial<Record<Tab, number>> = { ops: opsWaiting, treasury: approvalsWaiting, leads: drafts, receive: claims, desk: deskAlerts };

  return (
    <header className="border-b border-[#131d33] bg-[#020814]/90 backdrop-blur sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 py-2.5 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-8 h-8 shrink-0 rounded border border-[#f5c518]/40 bg-[#0a1224] flex items-center justify-center text-[#f5c518] font-bold text-base glow-gold">◆</div>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="font-bold tracking-wider text-white text-base">YABBAI FLASH</span>
              <span className="text-[10px] uppercase px-1.5 py-0.5 rounded border border-[#f5c518]/30 text-[#f5c518] bg-[#f5c518]/10 font-mono-num font-semibold">
                DECK v18
              </span>
            </div>
            <p className="text-[10px] text-[#8B93A7] tracking-wider uppercase truncate">
              {snap ? `Engine ${snap.version} · ${snap.leads.length} leads · ${snap.ledgerTotals.count} receipts` : 'Real data only · engine is the book of record'}
            </p>
          </div>
        </div>

        {snap && (
          <div className="hidden lg:flex items-center gap-4 bg-[#0a1224] px-3.5 py-1.5 rounded-lg border border-[#131d33] text-xs font-mono-num">
            <div>
              <span className="text-[9px] uppercase tracking-wider text-[#8B93A7] block">This month (ledger)</span>
              <span className="text-[#f5c518] font-bold">{aud(snap.ledgerTotals.month)}</span>
            </div>
            <div className="h-6 w-px bg-[#131d33]" />
            <div>
              <span className="text-[9px] uppercase tracking-wider text-[#8B93A7] block">MRR (recurring receipts)</span>
              <span className="text-[#14F195] font-bold">{aud(snap.mrr.amount)}</span>
            </div>
            <div className="h-6 w-px bg-[#131d33]" />
            <div>
              <span className="text-[9px] uppercase tracking-wider text-[#8B93A7] block">Waiting on you</span>
              <span className={drafts + claims + approvalsWaiting > 0 ? 'text-[#F5A623] font-bold' : 'text-[#8B93A7]'}>
                {approvalsWaiting} approvals · {drafts} drafts · {claims} claims · {newLeads} new
              </span>
            </div>
          </div>
        )}

        <EngineTruthChip />
      </div>

      <nav className="max-w-7xl mx-auto px-4 overflow-x-auto no-scrollbar flex items-center gap-1 py-1 text-[11px] font-medium tracking-wider" aria-label="Deck sections">
        {TABS.map((t) => {
          const active = tab === t.id;
          const n = badge[t.id] || 0;
          return (
            <button
              key={t.id}
              onClick={() => go(t.id)}
              aria-current={active ? 'page' : undefined}
              className={`whitespace-nowrap px-3 py-1.5 rounded transition-colors flex items-center gap-1.5 border ${
                active ? 'bg-[#0a1224] text-[#f5c518] border-[#f5c518]/50 font-semibold' : 'text-[#8B93A7] hover:text-white hover:bg-[#0a1224]/50 border-transparent'
              }`}
            >
              <span className={active ? 'text-[#f5c518]' : 'text-[#8B93A7]'}>{t.glyph}</span>
              <span>{t.label}</span>
              {n > 0 && <span className="text-[9px] px-1.5 rounded-full bg-[#FF4D6D] text-white font-bold">{n}</span>}
            </button>
          );
        })}
      </nav>
    </header>
  );
};
