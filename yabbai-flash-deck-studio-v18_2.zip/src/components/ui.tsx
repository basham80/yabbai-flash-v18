import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Check, Copy } from 'lucide-react';

/* Shared pieces for the deck. Palette and type come from index.css (navy, gold,
   Solana green/purple, Space Grotesk + JetBrains Mono). */

export const inputBase =
  'min-w-0 bg-[#020814] border border-[#131d33] rounded px-2.5 py-1.5 text-sm text-slate-200 placeholder:text-[#4a5468] focus:border-[#f5c518]/60 focus:outline-none focus-visible:ring-1 focus-visible:ring-[#f5c518]/50';
export const inputCls = `w-full ${inputBase}`;

type Tone = 'white' | 'gold' | 'green' | 'red' | 'purple' | 'slate' | 'orange';
const TONE_TEXT: Record<Tone, string> = {
  white: 'text-white',
  gold: 'text-[#f5c518]',
  green: 'text-[#14F195]',
  red: 'text-[#FF4D6D]',
  purple: 'text-[#9945FF]',
  slate: 'text-[#8B93A7]',
  orange: 'text-[#F5A623]',
};
const TONE_PILL: Record<Tone, string> = {
  white: 'border-white/30 text-white bg-white/5',
  gold: 'border-[#f5c518]/40 text-[#f5c518] bg-[#f5c518]/10',
  green: 'border-[#14F195]/40 text-[#14F195] bg-[#14F195]/10',
  red: 'border-[#FF4D6D]/50 text-[#FF4D6D] bg-[#FF4D6D]/10',
  purple: 'border-[#9945FF]/40 text-[#b98cff] bg-[#9945FF]/10',
  slate: 'border-[#131d33] text-[#8B93A7] bg-[#0a1224]',
  orange: 'border-[#F5A623]/40 text-[#F5A623] bg-[#F5A623]/10',
};

export const Panel: React.FC<{ title?: React.ReactNode; right?: React.ReactNode; className?: string; children: React.ReactNode }> = ({ title, right, className = '', children }) => (
  <section className={`bg-[#0a1224] border border-[#131d33] rounded-lg p-4 min-w-0 ${className}`}>
    {(title || right) && (
      <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
        {title && <h2 className="text-[11px] font-semibold uppercase tracking-[0.16em] text-[#8B93A7]">{title}</h2>}
        {right && <div className="flex flex-wrap items-center gap-2">{right}</div>}
      </div>
    )}
    {children}
  </section>
);

export const Stat: React.FC<{ label: string; value: React.ReactNode; sub?: React.ReactNode; tone?: Tone }> = ({ label, value, sub, tone = 'white' }) => (
  <div className="min-w-0">
    <div className="text-[9px] uppercase tracking-wider text-[#8B93A7]">{label}</div>
    <div className={`font-mono-num text-lg sm:text-xl font-bold truncate ${TONE_TEXT[tone]}`}>{value}</div>
    {sub && <div className="text-[10px] text-[#5d6780] mt-0.5 leading-snug">{sub}</div>}
  </div>
);

export const Pill: React.FC<{ tone?: Tone; children: React.ReactNode; title?: string }> = ({ tone = 'slate', children, title }) => (
  <span title={title} className={`inline-flex items-center gap-1 whitespace-nowrap text-[9px] uppercase tracking-wider font-semibold px-1.5 py-0.5 rounded border ${TONE_PILL[tone]}`}>
    {children}
  </span>
);

export const Btn: React.FC<{
  onClick?: () => void;
  children: React.ReactNode;
  tone?: 'gold' | 'green' | 'red' | 'ghost';
  disabled?: boolean;
  type?: 'button' | 'submit';
  title?: string;
}> = ({ onClick, children, tone = 'gold', disabled, type = 'button', title }) => {
  const cls = {
    gold: 'border-[#f5c518]/60 bg-[#f5c518]/10 text-[#f5c518] hover:bg-[#f5c518]/20',
    green: 'border-[#14F195]/60 bg-[#14F195]/10 text-[#14F195] hover:bg-[#14F195]/20',
    red: 'border-[#FF4D6D]/60 bg-[#FF4D6D]/10 text-[#FF4D6D] hover:bg-[#FF4D6D]/20',
    ghost: 'border-[#131d33] bg-[#0a1224] text-[#8B93A7] hover:text-white hover:border-[#1e2a44]',
  }[tone];
  return (
    <button
      type={type}
      title={title}
      onClick={onClick}
      disabled={disabled}
      className={`inline-flex items-center justify-center gap-1.5 px-2.5 py-1.5 rounded border text-[10px] font-semibold uppercase tracking-wider transition-colors disabled:opacity-40 disabled:cursor-not-allowed focus:outline-none focus-visible:ring-1 focus-visible:ring-[#f5c518] ${cls}`}
    >
      {children}
    </button>
  );
};

export const Field: React.FC<{ label: string; hint?: string; children: React.ReactNode; className?: string }> = ({ label, hint, children, className = '' }) => (
  <label className={`flex flex-col gap-1 min-w-0 ${className}`}>
    <span className="text-[9px] uppercase tracking-wider text-[#8B93A7]">{label}</span>
    {children}
    {hint && <span className="text-[10px] text-[#5d6780] leading-snug">{hint}</span>}
  </label>
);

export const Empty: React.FC<{ title: string; children?: React.ReactNode }> = ({ title, children }) => (
  <div className="border border-dashed border-[#1e2a44] rounded-lg px-4 py-6 text-center">
    <div className="text-sm text-slate-300 font-semibold">{title}</div>
    {children && <div className="text-xs text-[#8B93A7] mt-1.5 max-w-xl mx-auto leading-relaxed">{children}</div>}
  </div>
);

export const Notice: React.FC<{ tone?: 'red' | 'gold' | 'green' | 'slate'; children: React.ReactNode }> = ({ tone = 'slate', children }) => {
  const cls = {
    red: 'border-[#FF4D6D]/40 bg-[#FF4D6D]/10 text-[#ffb3c0]',
    gold: 'border-[#f5c518]/40 bg-[#f5c518]/10 text-[#f8dd6e]',
    green: 'border-[#14F195]/40 bg-[#14F195]/10 text-[#8ff5c8]',
    slate: 'border-[#131d33] bg-[#020814] text-[#a7afc2]',
  }[tone];
  return <div className={`border rounded px-3 py-2 text-xs leading-relaxed ${cls}`}>{children}</div>;
};

export function ago(at: string | number | null | undefined): string {
  if (!at) return 'never';
  const ms = typeof at === 'number' ? at : Date.parse(at);
  if (!Number.isFinite(ms) || ms <= 0) return 'never';
  const s = Math.round((Date.now() - ms) / 1000);
  if (s < 0) return 'just now';
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.round(s / 60)}m ago`;
  if (s < 86400) return `${Math.round(s / 3600)}h ago`;
  return `${Math.round(s / 86400)}d ago`;
}

export function fmt(n: number | null | undefined, d = 2): string {
  if (n === null || n === undefined || !Number.isFinite(n)) return '—';
  return n.toLocaleString('en-AU', { minimumFractionDigits: d, maximumFractionDigits: d });
}

export function when(at: string | null | undefined): string {
  if (!at) return '—';
  const d = new Date(at);
  if (Number.isNaN(d.getTime())) return at;
  return d.toLocaleString('en-AU', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit', hour12: false });
}

/** Short-lived status line for a surface ("Imported 12 leads"). */
export function useFlash(): [React.ReactNode, (msg: string, tone?: 'green' | 'red') => void] {
  const [msg, setMsg] = useState<{ text: string; tone: 'green' | 'red' } | null>(null);
  const timer = useRef<number | undefined>(undefined);
  const flash = useCallback((text: string, tone: 'green' | 'red' = 'green') => {
    setMsg({ text, tone });
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => setMsg(null), tone === 'red' ? 7000 : 3500);
  }, []);
  useEffect(() => () => window.clearTimeout(timer.current), []);
  const node = msg ? (
    <div role="status" className={`fixed bottom-4 left-1/2 -translate-x-1/2 z-50 max-w-[92vw] px-4 py-2 rounded border text-xs font-semibold shadow-xl ${msg.tone === 'red' ? 'bg-[#2a0a12] border-[#FF4D6D]/60 text-[#ffb3c0]' : 'bg-[#06231a] border-[#14F195]/60 text-[#8ff5c8]'}`}>
      {msg.text}
    </div>
  ) : null;
  return [node, flash];
}

export const CopyBtn: React.FC<{ text: string; label?: string }> = ({ text, label = 'Copy' }) => {
  const [done, setDone] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      setDone(true);
      setTimeout(() => setDone(false), 1500);
    } catch {
      window.prompt('Copy this:', text);
    }
  };
  return (
    <Btn tone="ghost" onClick={copy} title="Copy to clipboard">
      {done ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
      {done ? 'Copied' : label}
    </Btn>
  );
};

/** Intraday line for a quote. Points are [ms, price]. */
export const Spark: React.FC<{ points: Array<[number, number]>; up: boolean; label: string }> = ({ points, up, label }) => {
  if (!points || points.length < 2) return <div className="h-14 flex items-center text-[10px] text-[#5d6780]">No intraday series from this source</div>;
  const W = 300;
  const H = 56;
  const ys = points.map((p) => p[1]);
  const min = Math.min(...ys);
  const max = Math.max(...ys);
  const span = max - min || 1;
  const x = (i: number) => (i / (points.length - 1)) * W;
  const y = (v: number) => H - 4 - ((v - min) / span) * (H - 8);
  const line = points.map((p, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(p[1]).toFixed(1)}`).join(' ');
  const color = up ? '#14F195' : '#FF4D6D';
  const last = points[points.length - 1];
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-14" role="img" aria-label={`${label}: low ${min.toFixed(2)}, high ${max.toFixed(2)}`} preserveAspectRatio="none">
      <path d={`${line} L${W},${H} L0,${H} Z`} fill={color} fillOpacity="0.08" />
      <path d={line} fill="none" stroke={color} strokeWidth="1.5" vectorEffect="non-scaling-stroke" />
      <circle cx={x(points.length - 1)} cy={y(last[1])} r="2.5" fill={color} />
    </svg>
  );
};
