/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * YABBAI FLASH · Command Deck v18. Real things only: every surface reads the YABBAI
 * engine (ledger with receipts, invoices and rails, leads from Pancake and your own
 * lists, live oil prices and your broker journal), plus the v16 treasury control plane
 * and the v18 operating layer (agents, tasks, workflows, events, executive view).
 */
import React, { useEffect, useState } from 'react';
import { EngineProvider } from './context/EngineContext';
import { Header, type Tab } from './components/Header';
import { Footer } from './components/Footer';
import { DeckSurface } from './components/surfaces/DeckSurface';
import { LeadsSurface } from './components/surfaces/LeadsSurface';
import { EngineSurface } from './components/surfaces/EngineSurface';
import { OilDeskSurface } from './components/surfaces/OilDeskSurface';
import { OpsSurface } from './components/surfaces/OpsSurface';
import { TreasurySurface } from './components/surfaces/TreasurySurface';
import { VaultProvider } from './context/VaultContext';

const TABS: Tab[] = ['deck', 'ops', 'treasury', 'leads', 'receive', 'desk'];
const fromHash = (): Tab => {
  const h = (typeof location !== 'undefined' ? location.hash.replace('#', '') : '') as Tab;
  return TABS.includes(h) ? h : 'deck';
};

export default function App() {
  const [tab, setTab] = useState<Tab>(fromHash);

  useEffect(() => {
    const onHash = () => setTab(fromHash());
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);

  const go = (t: Tab) => {
    if (location.hash !== `#${t}`) location.hash = t;
    setTab(t);
    window.scrollTo({ top: 0 });
  };

  return (
    <EngineProvider>
      <VaultProvider>
        <div className="min-h-screen bg-[#020814] text-slate-200 flex flex-col selection:bg-[#f5c518]/30 selection:text-[#f5c518]">
          <Header tab={tab} go={go} />
          <main className="max-w-7xl mx-auto px-4 py-6 w-full flex-1 min-w-0">
            {tab === 'deck' && <DeckSurface go={go} />}
            {tab === 'ops' && <OpsSurface />}
            {tab === 'treasury' && <TreasurySurface />}
            {tab === 'leads' && <LeadsSurface />}
            {tab === 'receive' && <EngineSurface />}
            {tab === 'desk' && <OilDeskSurface />}
          </main>
          <Footer />
        </div>
      </VaultProvider>
    </EngineProvider>
  );
}
