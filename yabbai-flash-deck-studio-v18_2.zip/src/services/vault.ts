/**
 * YABBAI — the Director vault session in this browser tab.
 *
 * The session token from POST /api/v2/vault/unlock lives in sessionStorage only: it ends with
 * the tab, it is never written to localStorage, and the engine also expires it (15 minutes idle,
 * 2 hours at most by default). Money actions, approvals and agent administration need it.
 */
const KEY = 'yb_vault_session';
let memory = '';

export function vaultToken(): string {
  try {
    return sessionStorage.getItem(KEY) || memory;
  } catch {
    return memory;
  }
}

export function setVaultToken(token: string) {
  memory = token;
  try {
    if (token) sessionStorage.setItem(KEY, token);
    else sessionStorage.removeItem(KEY);
  } catch {
    /* storage blocked (private window): the session lasts until reload */
  }
  window.dispatchEvent(new Event('yabbai:vault'));
}

export const clearVaultToken = () => setVaultToken('');
