/**
 * YABBAI — where the engine is and how to reach it.
 *
 * The deck has no money and no brain of its own. The YABBAI engine is the book of
 * record (ledger with receipts, invoices, leads, the oil journal) and it runs the
 * model. This file only answers "which engine, with which token".
 *
 *   1. window.__YABBAI_CFG__  injected by the engine when it serves /studio to a
 *      caller that already proved the token (this machine, or the /login cookie).
 *   2. VITE_ENGINE_URL / VITE_ENGINE_TOKEN  at build time (optional).
 *   3. What you paste into the link chip: kept for this browser tab only, or on
 *      this device if you tick "remember".
 */
export interface EngineConfig {
  base: string;
  token: string;
  model: string;
}

declare global {
  interface Window {
    __YABBAI_CFG__?: Partial<EngineConfig>;
  }
}

const TOKEN_KEY = 'yb_engine_token';
const BASE_KEY = 'yb_engine_base';

function env(name: string): string {
  try {
    const e = (import.meta as unknown as { env?: Record<string, string | undefined> }).env;
    return String((e && e[name]) || '');
  } catch {
    return '';
  }
}

function read(key: string): string {
  try {
    return sessionStorage.getItem(key) || localStorage.getItem(key) || '';
  } catch {
    return '';
  }
}

function write(key: string, value: string, remember: boolean) {
  try {
    sessionStorage.removeItem(key);
    localStorage.removeItem(key);
    if (value) (remember ? localStorage : sessionStorage).setItem(key, value);
  } catch {
    /* storage blocked (private window): the link lasts until reload */
  }
}

let memory: { base: string; token: string } | null = null;

export function servedByEngine(): boolean {
  return typeof window !== 'undefined' && !!window.__YABBAI_CFG__;
}

export function engineConfig(): EngineConfig {
  const injected = typeof window !== 'undefined' ? window.__YABBAI_CFG__ : undefined;
  if (injected) {
    return { base: String(injected.base || '').replace(/\/+$/, ''), token: String(injected.token || ''), model: String(injected.model || 'yabbai-director') };
  }
  const base = env('VITE_ENGINE_URL') || read(BASE_KEY) || memory?.base || '';
  const token = env('VITE_ENGINE_TOKEN') || read(TOKEN_KEY) || memory?.token || '';
  return { base: base.replace(/\/+$/, ''), token: token.trim(), model: env('VITE_ENGINE_MODEL') || 'yabbai-director' };
}

export function linkEngine(base: string, token: string, remember: boolean) {
  const b = base.trim().replace(/\/+$/, '');
  const t = token.trim();
  memory = { base: b, token: t };
  write(BASE_KEY, b, remember);
  write(TOKEN_KEY, t, remember);
  window.dispatchEvent(new Event('yabbai:linked'));
}

export function unlinkEngine() {
  memory = null;
  write(BASE_KEY, '', false);
  write(TOKEN_KEY, '', false);
  window.dispatchEvent(new Event('yabbai:linked'));
}

export function brainLabel(): string {
  const cfg = engineConfig();
  return cfg.token ? `ENGINE · ${cfg.model}` : 'NOT LINKED';
}
