/**
 * YABBAI — ENGINE API CLIENT
 * The deck is the face; the Node engine is the book of record. Every function here
 * talks to the same endpoints the engine console uses, so an invoice made here is
 * the invoice the pay page serves, and a lead imported here is the lead the Closer
 * drafts for. No second source of truth, no browser-side money.
 */
import { engineConfig } from './brain';
import { vaultToken } from './vault';

export interface InvoiceItem {
  desc: string;
  qty: number;
  unitAud: number;
}

export interface EngineInvoice {
  id: string;
  number: string;
  token: string;
  client: string;
  email?: string;
  items: InvoiceItem[];
  subtotalAud: number;
  taxBps: number;
  taxAud: number;
  discountAud: number;
  totalAud: number;
  paidAud: number;
  reference: string;
  status: 'draft' | 'sent' | 'part' | 'paid' | 'overdue' | 'void';
  rails: string[];
  dueDate: string;
  createdAt: string;
  paidAt?: string | null;
}

export interface EnginePayment {
  id: string;
  invoiceNumber: string;
  amountAud: number;
  kind: string;
  proof: string;
  externalId: string;
  at: string;
}

export interface RailStatus {
  id: string;
  label: string;
  ready: boolean;
  detail: string;
}

export interface ReceiveSummary {
  count: number;
  open: number;
  paid: number;
  receivableAud: number;
  collectedAud: number;
  byRail: Record<string, number>;
  claims: number;
  unmatched: number;
  lastReconcileAt?: string | null;
  rails: RailStatus[];
}

export type LeadStage = 'new' | 'drafted' | 'sent' | 'replied' | 'won' | 'lost';
export const LEAD_STAGES: LeadStage[] = ['new', 'drafted', 'sent', 'replied', 'won', 'lost'];

export interface EngineLead {
  id: string;
  business: string;
  name: string;
  title?: string;
  niche: string;
  location: string;
  website: string;
  contact: string;
  email?: string;
  phone?: string;
  channel: string;
  notes: string;
  offerId: string;
  source?: string;
  externalId?: string;
  score?: number | null;
  stage: LeadStage;
  createdAt: string;
  updatedAt: string;
}

export interface EngineDraft {
  id: string;
  leadId: string;
  offerName?: string;
  business: string;
  channel: string;
  subject?: string;
  message: string;
  followup_1?: string;
  followup_2?: string;
  personal_hook?: string;
  status: 'draft' | 'approved' | 'sent' | 'skipped';
  createdAt: string;
}

export interface LedgerEntry {
  id: string;
  date: string;
  amount: number;
  currency: string;
  source: string;
  agent: string;
  ref: string;
  note: string;
  recurring: boolean;
  createdAt: string;
}

export interface EngineAgent {
  name: string;
  ai?: boolean;
  enabled: boolean;
  status?: string;
  runs: number;
  lastRunAt: number;
  nextRunAt?: number | null;
  lastError: string;
  running?: boolean;
  everyMin?: number;
}

export interface ActivityItem {
  id: string;
  at: string;
  kind: string;
  text: string;
}

export interface DeskQuote {
  id: 'WTI' | 'BRENT';
  name: string;
  contract: string;
  unit: string;
  ok: boolean;
  price?: number;
  prevClose?: number | null;
  change?: number | null;
  changePct?: number | null;
  dayHigh?: number | null;
  dayLow?: number | null;
  at?: string | null;
  asOf?: string | null;
  source?: string;
  spark?: Array<[number, number]>;
  fetchedAt?: number;
  error?: string;
  last?: { price: number; at: string; source: string } | null;
}

export interface DeskTrade {
  id: string;
  instrument: 'WTI' | 'BRENT';
  side: 'long' | 'short';
  lots: number;
  bblPerLot: number;
  bbl: number;
  entry: number;
  stop: number | null;
  target: number | null;
  ticket: string;
  broker: string;
  openedAt: string;
  status: 'open' | 'closed';
  exit: number | null;
  closedAt: string | null;
  feesUsd: number;
  pnlUsd: number | null;
  pnlSource: 'broker' | 'computed' | null;
  note: string;
  mark?: number | null;
  markLive?: boolean;
  markAt?: string | null;
  openPnlUsd?: number | null;
  riskUsd?: number | null;
  alert?: string | null;
}

export interface DeskAccount {
  name: string;
  sizeUsd: number;
  dailyLossPct: number;
  maxDrawdownPct: number;
  riskPct: number;
  bblPerLot: number;
  resetHourUtc: number;
}

export interface DeskGuard {
  dayStart: string;
  dailyLimitUsd: number;
  headroomUsd: number;
  dailyBreached: boolean;
  ifAllStopsHitTodayUsd: number;
  stopsWouldBreach: boolean;
  ddLimitUsd: number;
  equityUsd: number | null;
  ddUsedUsd: number | null;
  ddBreached: boolean;
  riskPerTradeUsd: number;
  markedLive: boolean;
}

export interface DeskSummary {
  instruments: DeskQuote[];
  unit: string;
  account: DeskAccount;
  open: DeskTrade[];
  closed: DeskTrade[];
  stats: {
    closed: number;
    open: number;
    wins: number;
    losses: number;
    winRatePct: number | null;
    avgWinUsd: number | null;
    avgLossUsd: number | null;
    profitFactor: number | null;
    realizedUsd: number;
    realizedTodayUsd: number;
    openPnlUsd: number | null;
    openRiskUsd: number;
    unprotected: number;
  };
  guard: DeskGuard | null;
  broker: { connected: boolean; note: string };
}

export interface LeadImportResult {
  source: string;
  total: number;
  added: number;
  duplicates: number;
  skipped: Array<{ row: number; reason: string }>;
  leads: Array<{ id: string; business: string; name: string; contact: string }>;
}

export interface ConnectInfo {
  token: string;
  mcpUrl: string;
  mcpConnectorUrl: string;
  openaiBase: string;
  remoteLogin: string;
}

export interface EngineSnapshot {
  version: string;
  dataDir?: string;
  ledger: LedgerEntry[];
  ledgerTotals: { all: number; month: number; week: number; count: number; monthCount?: number; bySource?: Record<string, number> };
  mrr: { amount: number; count: number };
  receive: {
    summary: ReceiveSummary;
    settings: Record<string, unknown>;
    paypal: { secret: { set: boolean } };
  };
  invoices: EngineInvoice[];
  payments: EnginePayment[];
  claims: Array<{ id: string; invoiceNumber: string; rail: string; amountAud: number; ref: string; status: string; at: string }>;
  unmatched: Array<{ id: string; kind: string; amountAud: number; payer?: string; reason: string; at: string }>;
  pools: { pay: { available: number; paidOut: number; requested: number } };
  activity: ActivityItem[];
  leads: EngineLead[];
  outbox: EngineDraft[];
  agents: Record<string, EngineAgent>;
  desk?: DeskSummary;
  settings?: { autopilot?: boolean; offers?: Array<{ id: string; name: string }> };
  brains?: { chat?: string; hf?: { set: boolean } };
  treasury?: { currency?: string; needs?: number; killSwitch?: boolean; approvalsPending?: number; error?: string };
  ops?: { proposalsWaiting?: number; needsAttention?: number; deadLetters?: number; tasksOpen?: number; error?: string };
}

export class EngineError extends Error {
  status: number;
  code?: string;
  correlationId?: string;
  constructor(message: string, status: number, code?: string, correlationId?: string) {
    super(message);
    this.status = status;
    this.code = code;
    this.correlationId = correlationId;
  }
}

/** Options for one call. `idem` is the Idempotency-Key (v1/v2 writes); `otp` a fresh authenticator code. */
export interface CallInit {
  method?: string;
  body?: unknown;
  idem?: string;
  otp?: string;
}

async function call<T>(path: string, init: CallInit = {}): Promise<T> {
  const cfg = engineConfig();
  if (!cfg.token) throw new EngineError('Engine is not linked yet', 401);
  const session = vaultToken();
  let res: Response;
  try {
    res = await fetch(`${cfg.base}${path}`, {
      method: init.method || 'GET',
      headers: {
        Authorization: `Bearer ${cfg.token}`,
        // The engine's CSRF guard requires this on every state-changing call.
        'X-Yabbai': '1',
        ...(init.body !== undefined ? { 'Content-Type': 'application/json' } : {}),
        // v16+: the Director vault session (sessionStorage, this tab only) and step-up code.
        ...(session ? { 'X-Yabbai-Vault': session } : {}),
        ...(init.otp ? { 'X-Yabbai-Otp': init.otp } : {}),
        ...(init.idem ? { 'Idempotency-Key': init.idem } : {}),
      },
      body: init.body === undefined ? undefined : JSON.stringify(init.body),
    });
  } catch {
    throw new EngineError(`Cannot reach the engine${cfg.base ? ` at ${cfg.base}` : ''}. Is it running?`, 0);
  }
  const text = await res.text();
  let data: unknown = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = { error: text.slice(0, 200) };
  }
  if (!res.ok) {
    // v15/v16 send { error: "…" }; v1 sends { error: { code, message }, correlation_id }.
    const e = (data as { error?: unknown; correlation_id?: string } | null) || {};
    const err = e.error as { code?: string; message?: string } | string | undefined;
    const msg = typeof err === 'string' ? err : err && err.message ? err.message : `HTTP ${res.status}`;
    const code = typeof err === 'object' && err ? err.code : undefined;
    throw new EngineError(res.status === 401 ? 'The engine refused the token. Check it and link again.' : msg, res.status, code, e.correlation_id);
  }
  return data as T;
}

/** A fresh Idempotency-Key: one per action, reused when the same action is retried. */
export function newKey(): string {
  const a = new Uint8Array(12);
  crypto.getRandomValues(a);
  return `deck-${Array.from(a, (b) => b.toString(16).padStart(2, '0')).join('')}`;
}

export const engineApi = {
  snapshot: () => call<EngineSnapshot>('/api/state'),

  summary: () => call<{ summary: ReceiveSummary }>('/api/receive'),

  connect: () => call<ConnectInfo>('/api/connect'),

  invoices: {
    create: (body: { client: string; email?: string; items: InvoiceItem[]; rails: string[]; dueDate?: string; note?: string }) =>
      call<EngineInvoice>('/api/invoices', { method: 'POST', body }),
    update: (id: string, body: Partial<{ client: string; email: string; items: InvoiceItem[]; rails: string[]; dueDate: string; note: string }>) =>
      call<EngineInvoice>(`/api/invoices/${id}`, { method: 'PATCH', body }),
    send: (id: string) => call<EngineInvoice>(`/api/invoices/${id}/send`, { method: 'POST', body: {} }),
    void: (id: string) => call<EngineInvoice>(`/api/invoices/${id}/void`, { method: 'POST', body: {} }),
    requote: (id: string) => call<Record<string, unknown>>(`/api/invoices/${id}/requote`, { method: 'POST', body: {} }),
    link: (id: string) => call<{ url: string; token: string; number: string }>(`/api/invoices/${id}/link`),
    bookPayment: (id: string, body: { amountAud: number; externalId: string; note?: string; date?: string }) =>
      call<{ payment: EnginePayment }>(`/api/invoices/${id}/credit`, { method: 'POST', body }),
    paypalOrder: (id: string) => call<{ id: string; status: string; approveUrl: string }>(`/api/invoices/${id}/paypal`, { method: 'POST', body: {} }),
  },

  claims: {
    confirm: (id: string) => call<unknown>(`/api/claims/${id}/confirm`, { method: 'POST', body: {} }),
    dismiss: (id: string) => call<unknown>(`/api/claims/${id}/dismiss`, { method: 'POST', body: {} }),
  },

  receive: {
    reconcile: () => call<{ sol?: { credits: number }; btc?: { credits: number }; eth?: { credits: number } }>('/api/receive/reconcile', { method: 'POST', body: {} }),
    importStatement: (text: string, filename?: string) =>
      call<{ rows: number; credits: number; duplicates: number; skipped: Array<{ reason: string }> }>('/api/receive/statement', { method: 'POST', body: { text, filename } }),
    settings: (body: Record<string, unknown>) => call<{ settings: Record<string, unknown>; summary: ReceiveSummary }>('/api/receive/settings', { method: 'POST', body }),
  },

  leads: {
    add: (body: Partial<EngineLead> & { business: string }) => call<EngineLead>('/api/leads', { method: 'POST', body }),
    import: (body: { text?: string; leads?: unknown[]; source: string }) => call<LeadImportResult>('/api/leads/import', { method: 'POST', body }),
    update: (id: string, body: Partial<EngineLead>) => call<EngineLead>(`/api/leads/${id}`, { method: 'PATCH', body }),
    remove: (id: string) => call<{ ok: boolean }>(`/api/leads/${id}`, { method: 'DELETE' }),
    redraft: (id: string) => call<EngineLead>(`/api/leads/${id}/redraft`, { method: 'POST', body: {} }),
    won: (id: string, body: { amount: number; ref: string; note?: string }) =>
      call<{ lead: EngineLead; entry: LedgerEntry }>(`/api/leads/${id}/won`, { method: 'POST', body }),
  },

  outbox: {
    setStatus: (id: string, status: EngineDraft['status']) => call<EngineDraft>(`/api/outbox/${id}`, { method: 'POST', body: { status } }),
  },

  agents: {
    run: (id: string) => call<unknown>(`/api/agents/${id}/run`, { method: 'POST', body: {} }),
  },

  desk: {
    get: (force = false) => call<DeskSummary>(`/api/desk${force ? '?force=1' : ''}`),
    addTrade: (body: Record<string, unknown>) => call<DeskTrade>('/api/desk/trades', { method: 'POST', body }),
    closeTrade: (id: string, body: { exit: number; fees?: number; pnl?: number; closedAt?: string }) =>
      call<DeskTrade>(`/api/desk/trades/${id}/close`, { method: 'POST', body }),
    deleteTrade: (id: string) => call<{ ok: boolean }>(`/api/desk/trades/${id}`, { method: 'DELETE' }),
    account: (body: Partial<DeskAccount>) => call<DeskAccount>('/api/desk/account', { method: 'POST', body }),
  },

  ledger: {
    add: (body: { amount: number; ref: string; note?: string; source?: string; date?: string; recurring?: boolean }) =>
      call<{ id: string; ref: string }>('/api/ledger', { method: 'POST', body }),
    csvUrl: () => `${engineConfig().base}/api/ledger.csv`,
  },

  payouts: (body: { amount: number; method: string; note?: string }) => call<{ id: string; status: string }>('/api/payouts', { method: 'POST', body }),

  // Director vault v2 (PIN + authenticator). The v15 PIN routes answer 410.
  vault: {
    status: () => call<VaultStatus>('/api/v2/vault'),
    setupStart: (body: { name: string; pin: string; legacyPin?: string }) => call<{ principalId: string; name: string; secret: string; otpauthUrl: string }>('/api/v2/vault/setup/start', { method: 'POST', body }),
    setupConfirm: (body: { principalId: string; code: string }) => call<{ principal: VaultPrincipal; recoveryCodes: string[]; session?: VaultSession }>('/api/v2/vault/setup/confirm', { method: 'POST', body }),
    unlock: (body: { pin: string; code: string; name?: string }) => call<VaultSession>('/api/v2/vault/unlock', { method: 'POST', body }),
    lock: () => call<{ ok: boolean }>('/api/v2/vault/lock', { method: 'POST', body: {} }),
  },

  health: () => call<{ ok: boolean; version: string; model: string | null }>('/api/health'),
};

// ── v18 operating API (/api/v1) and the v16 treasury control plane (/api/v2) ──
export type MetricStatus = 'live' | 'stale' | 'estimated' | 'unavailable';
export interface ExecMetric {
  id: string;
  label: string;
  value: string | number | null;
  display: string;
  unit: string | null;
  source: string | null;
  basis: string | null;
  at: string | null;
  status: MetricStatus;
  quality: string;
  note: string;
}
export interface ExecOverview {
  at: string;
  currency: string;
  metrics: ExecMetric[];
  legend: Record<MetricStatus, string>;
}
export interface OpsTask {
  id: string;
  task_id: string;
  kind: string;
  assigned_agent: string;
  objective: string;
  status: 'created' | 'assigned' | 'running' | 'awaiting_approval' | 'completed' | 'failed' | 'escalated' | 'cancelled';
  approval: { required: boolean; status: string; approvalId?: string };
  evidence_refs: string[];
  context_refs: string[];
  deadline: string;
  priority: string;
  correlation_id: string;
  workflowRunId: string | null;
  attempts: number;
  escalation?: { at: string; reason: string };
  proposalId?: string;
  createdAt: string;
  updatedAt: string;
}
export interface AgentRun {
  id: string;
  agentId: string;
  taskId: string;
  attempt: number;
  status: 'running' | 'completed' | 'failed';
  startedAt: string;
  completedAt: string | null;
  toolCalls: Array<{ tool: string; at: string; ok: boolean; error?: string }>;
  model: string | null;
  tokens: number | null;
  error: string | null;
}
export interface OpsAgent {
  id: string;
  name: string;
  role: string;
  purpose: string;
  status: 'enabled' | 'paused' | 'registered' | 'not_connected';
  permissions: string[];
  tools: Array<{ name: string; permission: string | null; available: boolean }>;
  budget: { runsPerHour: number; toolCalls: number; maxOutputTokens: number };
  approval: string;
  notes: string;
  work: { open: number; completed: number; escalated: number };
  runs: { total: number; failed: number; lastAt: string | null; lastSuccessAt: string | null; lastError: string | null; tokens: number };
}
export interface WorkflowRun {
  id: string;
  workflow: string;
  status: 'running' | 'waiting_approval' | 'needs_attention' | 'completed' | 'rejected';
  subject: { type: string; id: string };
  opportunityId: string;
  proposalId?: string;
  steps: Array<{ id: string; status: string; at: string; reason?: string; by?: string }>;
  correlationId: string;
  startedBy: string;
  source: string;
  createdAt: string;
  updatedAt: string;
}
export interface ProposalLine {
  desc: string;
  qty: number;
  unitAud: number;
  unitMinor: string;
  lineMinor: string;
}
export interface Proposal {
  id: string;
  leadId: string;
  opportunityId: string | null;
  workflowRunId: string | null;
  taskId: string;
  title: string;
  summary: string;
  lines: ProposalLine[];
  currency: string;
  subtotalMinor: string;
  taxMinor: string;
  totalMinor: string;
  taxNote: string;
  validDays: number;
  fit: 'high' | 'medium' | 'low';
  findings: string[];
  status: 'awaiting_approval' | 'approved' | 'rejected' | 'expired';
  approvalId: string | null;
  decidedBy: string | null;
  decidedAt: string | null;
  draftedBy: string;
  createdAt: string;
}
export interface OpsEvent {
  event_id: string;
  event_type: string;
  occurred_at: string;
  source_service: string;
  actor_id: string;
  correlation_id: string;
  sensitivity: string;
  payload: Record<string, unknown>;
  delivery: Record<string, { status: string; attempts: number; lastError: string | null }>;
}
export interface DeadLetter {
  id: string;
  eventId: string;
  eventType: string;
  consumer: string;
  attempts: number;
  error: string;
  at: string;
  correlationId: string;
}
export interface Approval {
  id: string;
  kind: string;
  targetId: string;
  title: string;
  summary: string;
  risk: 'low' | 'medium' | 'high';
  required: number;
  status: string;
  decisions: Array<{ by: { type: string; id: string; label: string }; decision: string; at: string; note: string }>;
  createdBy: { type: string; id: string; label: string };
  createdAt: string;
  expiresAt: string;
}
interface Money {
  minor: string;
  display: string;
  note?: string;
}
export interface TreasuryOverview {
  at: string;
  currency: string;
  cash: {
    observed: Money & { sources: Array<{ account: string; display: string; at: string; source: string; freshness: string }>; stale: number; failed: number; excluded: string[] };
    book: Money & { inAccounts: string; unassigned: string; source: string };
    cleared: Money;
    clearing: Money;
    pending: Money & { claims: number; reported: number };
    reserved: Money & { gst: string; taxPool: string; emergency: string; customerCredit: string; refundWindow: string };
    committed: Money & { transfers: string; obligations30d: string };
    available: Money & { short: boolean };
    difference: Money;
  };
  killSwitch: { engaged: boolean; at: string | null; by: string | null; reason: string };
  needs: Array<{ key: string; text: string }>;
}
export interface TreasuryAccount {
  id: string;
  name: string;
  kind: string;
  asset: string;
  network?: string;
  purpose: string;
  enabled: boolean;
  isInternal: boolean;
  ownershipConfirmed: boolean;
  observed: { minor: string | null; display: string | null; at: string | null; source: string | null; freshness: string; error?: string | null };
  book: { minor: string; display: string };
}
export interface JournalTx {
  id: string;
  type: string;
  effectiveAt: string;
  recordedAt: string;
  description: string;
  sourceSystem: string;
  postings: Array<{ accountId: string; currency: string; debitMinor?: string; creditMinor?: string }>;
  reversalOf: string | null;
}
/** Write options: the Idempotency-Key for this action and, when asked, a fresh authenticator code. */
export interface Guarded {
  idem?: string;
  otp?: string;
}
const T2 = '/api/v2/treasury';
const w = (method: string, body: unknown, g: Guarded = {}): CallInit => ({ method, body, idem: g.idem || newKey(), otp: g.otp });

export const v1 = {
  overview: () => call<{ data: ExecOverview }>('/api/v1/executive/overview').then((r) => r.data),
  agents: () => call<{ data: OpsAgent[] }>('/api/v1/agents').then((r) => r.data),
  tasks: (q = '') => call<{ data: OpsTask[] }>(`/api/v1/tasks?limit=100${q}`).then((r) => r.data),
  task: (id: string) => call<{ data: OpsTask & { runs: AgentRun[] } }>(`/api/v1/tasks/${encodeURIComponent(id)}`).then((r) => r.data),
  runs: (q = '') => call<{ data: WorkflowRun[] }>(`/api/v1/workflows/runs?limit=100${q}`).then((r) => r.data),
  proposals: (q = '') => call<{ data: Proposal[] }>(`/api/v1/sales/proposals?limit=100${q}`).then((r) => r.data),
  events: (q = '') => call<{ data: OpsEvent[]; meta: { health: { events: number; backlog: number; retrying: number; deadLetters: number; tickAgeSec: number | null } } }>(`/api/v1/events?limit=60${q}`),
  deadLetters: () => call<{ data: DeadLetter[] }>('/api/v1/events/dead-letters').then((r) => r.data),
  approve: (id: string, note: string, g?: Guarded) => call<{ data: { proposal: Proposal; approval: Approval } }>(`/api/v1/sales/proposals/${encodeURIComponent(id)}/approve`, w('POST', { note }, g)),
  reject: (id: string, note: string, g?: Guarded) => call<{ data: { proposal: Proposal; approval: Approval } }>(`/api/v1/sales/proposals/${encodeURIComponent(id)}/reject`, w('POST', { note }, g)),
  retryTask: (id: string, g?: Guarded) => call<{ data: OpsTask }>(`/api/v1/tasks/${encodeURIComponent(id)}/retry`, w('POST', {}, g)),
  cancelTask: (id: string, reason: string, g?: Guarded) => call<{ data: OpsTask }>(`/api/v1/tasks/${encodeURIComponent(id)}/cancel`, w('POST', { reason }, g)),
  setAgent: (id: string, body: { status?: string; budget?: { runsPerHour: number } }, g?: Guarded) => call<{ data: OpsAgent }>(`/api/v1/agents/${encodeURIComponent(id)}`, w('POST', body, g)),
  startWorkflow: (leadId: string, g?: Guarded) => call<{ data: WorkflowRun }>('/api/v1/workflows/lead-to-proposal/start', w('POST', { leadId }, g)),
  replay: (id: string, g?: Guarded) => call<{ data: { replayed: string } }>(`/api/v1/events/dead-letters/${encodeURIComponent(id)}/replay`, w('POST', {}, g)),
};

export const v2 = {
  overview: () => call<TreasuryOverview>(`${T2}/overview`),
  accounts: () => call<{ accounts: TreasuryAccount[] }>(`${T2}/accounts`).then((r) => r.accounts),
  approvals: (status = 'pending') => call<{ approvals: Approval[] }>(`${T2}/approvals?status=${status}`).then((r) => r.approvals),
  decide: (id: string, decision: 'approve' | 'reject', note: string, g?: Guarded) => call<Approval>(`${T2}/approvals/${encodeURIComponent(id)}/${decision}`, w('POST', { note }, g)),
  inbox: () => call<{ exceptions: Array<{ id: string; kind: string; account?: string; detail?: string; difference?: string; firstSeenAt: string; lastSeenAt: string }>; failedFeeds: Array<{ id: string; account: string; error: string }>; claims: unknown[]; unmatched: unknown[] }>(`${T2}/inbox`),
  journal: (limit = 12) => call<{ items: JournalTx[]; total: number }>(`${T2}/journal?limit=${limit}`),
  verify: () => call<{ journal: { ok: boolean; transactions: number; issues: string[] }; audit: { ok: boolean }; at: string }>(`${T2}/journal/verify`),
  killSwitch: (body: { engaged: boolean; reason?: string }, g?: Guarded) => call<unknown>(`${T2}/kill-switch`, w('POST', body, g)),
};

export interface VaultPrincipal {
  id: string;
  name: string;
  role: 'director' | 'approver';
  enrolledAt?: string | null;
}
export interface VaultSession {
  token: string;
  id: string;
  expiresAt: string;
  maxAt: string;
  principal: VaultPrincipal;
}
export interface VaultStatus {
  version: number;
  set: boolean;
  setupRequired: boolean;
  open: boolean;
  recovery: boolean;
  until: string | null;
  stepUpUntil: string | null;
  principal: VaultPrincipal | null;
  principals: VaultPrincipal[];
  legacyPin?: boolean;
}

export function payLink(invoice: EngineInvoice): string {
  const base = (engineConfig().base || (typeof location !== 'undefined' ? location.origin : '')).replace(/\/+$/, '');
  return `${base}/pay/${invoice.token}`;
}

export function aud(n: number): string {
  return `A$${(Number(n) || 0).toLocaleString('en-AU', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export function usd(n: number | null | undefined, sign = false): string {
  if (n === null || n === undefined || !Number.isFinite(n)) return '—';
  const s = Math.abs(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return `${n < 0 ? '−' : sign && n > 0 ? '+' : ''}US$${s}`;
}
