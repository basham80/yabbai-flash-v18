import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { KeyRound, Lock, ShieldCheck } from 'lucide-react';
import { EngineError, engineApi, newKey, type Guarded, type VaultStatus } from '../services/engineApi';
import { clearVaultToken, setVaultToken, vaultToken } from '../services/vault';
import { Btn, CopyBtn, Field, inputCls, Notice } from '../components/ui';

/**
 * The Director vault for the whole deck (v16 Vault v2: PIN + authenticator app).
 *
 * guard(fn) runs an action. If the engine answers 423 (sealed or not set up), the deck asks for
 * the PIN and a code, or walks through set-up, then runs the action again. If it answers 428
 * (this needs a fresh code), it asks for one code and retries with it. The action keeps one
 * Idempotency-Key across its retries, so it can never happen twice.
 */
type Ask = { mode: 'setup' | 'unlock' | 'code'; reason: string; resolve: (code?: string) => void; reject: (e: Error) => void };
interface VaultState {
  status: VaultStatus | null;
  open: boolean;
  guard: <T>(fn: (g: Guarded) => Promise<T>) => Promise<T>;
  refresh: () => Promise<void>;
  lock: () => Promise<void>;
  unlock: () => Promise<void>;
}
const Ctx = createContext<VaultState | null>(null);
const cancelled = () => Object.assign(new Error('Cancelled'), { cancelled: true });
export const isCancelled = (e: unknown) => !!(e && (e as { cancelled?: boolean }).cancelled);

export const VaultProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [status, setStatus] = useState<VaultStatus | null>(null);
  const [ask, setAsk] = useState<Ask | null>(null);

  const refresh = useCallback(async () => {
    try {
      const s = await engineApi.vault.status();
      setStatus(s);
      if (!s.open && vaultToken()) clearVaultToken(); // expired or locked elsewhere
    } catch {
      setStatus(null);
    }
  }, []);
  useEffect(() => {
    refresh();
    const id = setInterval(refresh, 30000);
    window.addEventListener('yabbai:vault', refresh);
    window.addEventListener('yabbai:linked', refresh);
    return () => {
      clearInterval(id);
      window.removeEventListener('yabbai:vault', refresh);
      window.removeEventListener('yabbai:linked', refresh);
    };
  }, [refresh]);

  const prompt = useCallback((mode: Ask['mode'], reason: string) => new Promise<string | undefined>((resolve, reject) => setAsk({ mode, reason, resolve, reject })), []);

  const guard = useCallback(
    async <T,>(fn: (g: Guarded) => Promise<T>): Promise<T> => {
      const idem = newKey();
      let otp: string | undefined;
      for (let round = 0; round < 3; round++) {
        try {
          return await fn({ idem, otp });
        } catch (e) {
          if (!(e instanceof EngineError)) throw e;
          if (e.status === 423) {
            const s = await engineApi.vault.status().catch(() => null);
            setStatus(s);
            if (s && s.open && !/recovery/i.test(e.message)) throw e; // open, yet refused: show why
            await prompt(s && !s.set ? 'setup' : 'unlock', e.message);
            otp = undefined; // a new session counts as a fresh code for a short window
            continue;
          }
          if (e.status === 428 && /code/i.test(e.message)) {
            otp = await prompt('code', e.message);
            continue;
          }
          throw e;
        }
      }
      throw new Error('The vault did not open');
    },
    [prompt],
  );

  const lock = useCallback(async () => {
    try {
      await engineApi.vault.lock();
    } catch {
      /* already closed on the engine */
    }
    clearVaultToken();
    await refresh();
  }, [refresh]);
  const unlock = useCallback(async () => {
    const s = await engineApi.vault.status().catch(() => null);
    setStatus(s);
    try {
      await prompt(s && !s.set ? 'setup' : 'unlock', s && !s.set ? 'Set up the Director vault' : 'Unlock the Director vault');
    } catch {
      /* closed the dialog */
    }
  }, [prompt]);

  const close = (err?: Error, code?: string) => {
    if (!ask) return;
    const a = ask;
    setAsk(null);
    if (err) a.reject(err);
    else a.resolve(code);
    refresh();
  };

  return (
    <Ctx.Provider value={{ status, open: !!(status && status.open && vaultToken()), guard, refresh, lock, unlock }}>
      {children}
      {ask && <VaultDialog ask={ask} status={status} done={(code) => close(undefined, code)} cancel={() => close(cancelled())} />}
    </Ctx.Provider>
  );
};

export function useVault(): VaultState {
  const v = useContext(Ctx);
  if (!v) throw new Error('useVault must be used inside VaultProvider');
  return v;
}

const digits = (s: string, n = 12) => s.replace(/\D/g, '').slice(0, n);
const VaultDialog: React.FC<{ ask: Ask; status: VaultStatus | null; done: (code?: string) => void; cancel: () => void }> = ({ ask, status, done, cancel }) => {
  const [pin, setPin] = useState('');
  const [pin2, setPin2] = useState('');
  const [legacy, setLegacy] = useState('');
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [enrol, setEnrol] = useState<{ principalId: string; secret: string; otpauthUrl: string } | null>(null);
  const [recovery, setRecovery] = useState<string[] | null>(null);
  const first = useRef<HTMLInputElement | null>(null);
  useEffect(() => first.current?.focus(), [enrol, recovery]);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && !recovery && cancel();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [cancel, recovery]);

  const act = async (fn: () => Promise<void>) => {
    setBusy(true);
    setErr(null);
    try {
      await fn();
    } catch (e) {
      setErr((e as Error).message);
    } finally {
      setBusy(false);
    }
  };
  const unlock = () =>
    act(async () => {
      const s = await engineApi.vault.unlock({ pin, code });
      setVaultToken(s.token);
      done();
    });
  const start = () =>
    act(async () => {
      if (pin !== pin2) throw new Error('The two PINs do not match');
      setEnrol(await engineApi.vault.setupStart({ name: 'Director', pin, legacyPin: status?.legacyPin ? legacy : undefined }));
    });
  const confirm = () =>
    act(async () => {
      if (!enrol) return;
      const out = await engineApi.vault.setupConfirm({ principalId: enrol.principalId, code });
      if (out.session) setVaultToken(out.session.token);
      setRecovery(out.recoveryCodes);
    });

  const title = ask.mode === 'setup' ? 'Set up the Director vault' : ask.mode === 'unlock' ? 'Unlock the Director vault' : 'A fresh authenticator code';
  const Icon = ask.mode === 'code' ? KeyRound : ask.mode === 'setup' ? ShieldCheck : Lock;
  const pinIn = (v: string, set: (s: string) => void, label: string, ref?: React.Ref<HTMLInputElement>) => (
    <Field label={label}>
      <input ref={ref} type="password" inputMode="numeric" autoComplete="off" value={v} onChange={(e) => set(digits(e.target.value))} className={`${inputCls} tracking-[0.35em] font-mono-num`} />
    </Field>
  );
  const codeIn = (ref?: React.Ref<HTMLInputElement>, onEnter?: () => void) => (
    <Field label="Code from your authenticator app" hint="Six digits. Each code works once.">
      <input
        ref={ref}
        inputMode="numeric"
        autoComplete="one-time-code"
        value={code}
        onChange={(e) => setCode(digits(e.target.value, 6))}
        onKeyDown={(e) => e.key === 'Enter' && code.length === 6 && onEnter && onEnter()}
        className={`${inputCls} tracking-[0.5em] font-mono-num text-center`}
      />
    </Field>
  );

  return (
    <div className="fixed inset-0 bg-black/75 flex items-center justify-center p-4 z-[60]" role="dialog" aria-modal="true" aria-labelledby="vault-title">
      <div className="bg-[#0a1224] border border-[#9945FF]/50 rounded-lg p-5 w-full max-w-md space-y-3 max-h-[92vh] overflow-y-auto">
        <div className="flex items-center gap-2">
          <Icon className="w-4 h-4 text-[#b98cff]" aria-hidden />
          <h3 id="vault-title" className="text-sm font-bold text-[#b98cff]">
            {title}
          </h3>
        </div>
        <p className="text-[11px] text-[#8B93A7] leading-relaxed">{ask.reason}</p>

        {ask.mode === 'unlock' && (
          <>
            {pinIn(pin, setPin, 'Director PIN', first)}
            {codeIn(undefined, () => pin && unlock())}
            <p className="text-[10px] text-[#5d6780]">The session lasts 15 minutes without use and 2 hours at most, in this tab only.</p>
          </>
        )}

        {ask.mode === 'code' && (
          <>
            {codeIn(first, () => done(code))}
            <p className="text-[10px] text-[#5d6780]">High-risk approvals and changes to agents, limits and settings ask for a code even while the vault is open.</p>
          </>
        )}

        {ask.mode === 'setup' && !enrol && (
          <>
            <Notice tone="gold">
              Money actions, approvals and agent changes stay off until this is done. You need an authenticator app on your phone (Google Authenticator, 1Password, Authy or similar).
            </Notice>
            {pinIn(pin, setPin, 'Choose a PIN (6 to 12 digits)', first)}
            {pinIn(pin2, setPin2, 'Type it again')}
            {status?.legacyPin && pinIn(legacy, setLegacy, 'Your current v15 vault PIN')}
          </>
        )}
        {ask.mode === 'setup' && enrol && !recovery && (
          <>
            <div className="space-y-1.5">
              <div className="text-[9px] uppercase tracking-wider text-[#8B93A7]">Add this key to your authenticator app</div>
              <div className="font-mono-num text-sm text-white bg-[#020814] border border-[#131d33] rounded px-3 py-2 break-all select-all">{enrol.secret.match(/.{1,4}/g)?.join(' ')}</div>
              <div className="flex flex-wrap gap-2">
                <CopyBtn text={enrol.secret} label="Copy key" />
                <CopyBtn text={enrol.otpauthUrl} label="Copy setup link" />
              </div>
              <p className="text-[10px] text-[#5d6780] leading-snug">
                In the app choose "enter a setup key", account name YABBAI Director, time-based. The key is shown once; it is never sent to an AI.
              </p>
            </div>
            {codeIn(first, confirm)}
          </>
        )}
        {ask.mode === 'setup' && recovery && (
          <>
            <Notice tone="green">The vault is set up and open in this tab.</Notice>
            <div className="text-[9px] uppercase tracking-wider text-[#8B93A7]">Recovery codes: each works once if you lose your phone</div>
            <div className="grid grid-cols-2 gap-1.5 font-mono-num text-xs text-white bg-[#020814] border border-[#131d33] rounded p-3">
              {recovery.map((c) => (
                <span key={c}>{c}</span>
              ))}
            </div>
            <CopyBtn text={recovery.join('\n')} label="Copy codes" />
            <p className="text-[10px] text-[#F5A623] leading-snug">Store them somewhere safe and offline. This is the only time they are shown.</p>
          </>
        )}

        {err && <Notice tone="red">{err}</Notice>}
        <div className="flex justify-end gap-2 pt-1">
          {!recovery && (
            <Btn tone="ghost" onClick={cancel}>
              Cancel
            </Btn>
          )}
          {ask.mode === 'unlock' && (
            <Btn tone="green" onClick={unlock} disabled={busy || pin.length < 6 || code.length !== 6}>
              {busy ? 'Checking…' : 'Unlock'}
            </Btn>
          )}
          {ask.mode === 'code' && (
            <Btn tone="green" onClick={() => done(code)} disabled={code.length !== 6}>
              Use this code
            </Btn>
          )}
          {ask.mode === 'setup' && !enrol && (
            <Btn tone="gold" onClick={start} disabled={busy || pin.length < 6 || !pin2 || (status?.legacyPin && legacy.length < 4)}>
              {busy ? 'Starting…' : 'Next'}
            </Btn>
          )}
          {ask.mode === 'setup' && enrol && !recovery && (
            <Btn tone="green" onClick={confirm} disabled={busy || code.length !== 6}>
              {busy ? 'Checking…' : 'Confirm'}
            </Btn>
          )}
          {recovery && (
            <Btn tone="green" onClick={() => done()}>
              I saved them
            </Btn>
          )}
        </div>
      </div>
    </div>
  );
};
