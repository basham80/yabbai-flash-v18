import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { engineApi, type EngineSnapshot } from '../services/engineApi';
import { engineConfig } from '../services/brain';

/**
 * One poll of the engine for the whole deck. Every surface reads the same snapshot,
 * so the header, the deck and the leads table can never disagree about a number.
 */
interface EngineState {
  snap: EngineSnapshot | null;
  error: string | null;
  loading: boolean;
  linked: boolean;
  lastAt: number;
  refresh: () => Promise<void>;
}

const Ctx = createContext<EngineState | null>(null);
const POLL_MS = 15000;

export const EngineProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [snap, setSnap] = useState<EngineSnapshot | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [linked, setLinked] = useState(() => !!engineConfig().token);
  const [lastAt, setLastAt] = useState(0);
  const busy = useRef(false);

  const refresh = useCallback(async () => {
    const isLinked = !!engineConfig().token;
    setLinked(isLinked);
    if (!isLinked) {
      setSnap(null);
      setError(null);
      setLoading(false);
      return;
    }
    if (busy.current) return;
    busy.current = true;
    try {
      const s = await engineApi.snapshot();
      setSnap(s);
      setError(null);
      setLastAt(Date.now());
    } catch (e) {
      setError((e as Error).message);
    } finally {
      busy.current = false;
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
    const id = setInterval(refresh, POLL_MS);
    const onLink = () => {
      setLoading(true);
      refresh();
    };
    window.addEventListener('yabbai:linked', onLink);
    window.addEventListener('yabbai:changed', refresh);
    return () => {
      clearInterval(id);
      window.removeEventListener('yabbai:linked', onLink);
      window.removeEventListener('yabbai:changed', refresh);
    };
  }, [refresh]);

  return <Ctx.Provider value={{ snap, error, loading, linked, lastAt, refresh }}>{children}</Ctx.Provider>;
};

export function useEngine(): EngineState {
  const v = useContext(Ctx);
  if (!v) throw new Error('useEngine must be used inside EngineProvider');
  return v;
}

/** Tell every surface the engine's data changed (after a write). */
export function engineChanged() {
  window.dispatchEvent(new Event('yabbai:changed'));
}
